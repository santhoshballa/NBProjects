--drop table CompareAndCheck
select * from CompareAndCheck where F1 like '%Carrier%'

update CompareAndCheck set F4 = ltrim(rtrim(F4))
update CompareAndCheck set F2 = ltrim(rtrim(F2))
update CompareAndCheck set F7 = ltrim(rtrim(F7))
update CompareAndCheck set F6 = ltrim(rtrim(F6))
update CompareAndCheck set F7 = ltrim(rtrim(F7))
update CompareAndCheck set F9 = ltrim(rtrim(F9))
update CompareAndCheck set F10 = ltrim(rtrim(F10))
update CompareAndCheck  set F1 = replace(F1, '"','')
update CompareAndCheck  set F4 = replace(F4, '"','')
update CompareAndCheck  set F7 = replace(F7, '"','')
update CompareAndCheck  set F10 = replace(F10, '$','')
update CompareAndCheck  set F13= replace(F13, '$','')
update CompareAndCheck  set F4 = replace(f4, ',', '')
update CompareAndCheck  set F7 = replace(f7, ',', '')
update CompareAndCheck  set F10 = replace(f10, ',', '')

drop table if exists #CarrierPurseAmount
select * into #CarrierPurseAmount from (
select a.Carrier, sum(cast(ltrim(rtrim(PurseAmount)) as decimal)) as PurseAmountByCarrier from 
	(
	select F1 as Carrier,F2 as PBP, F3 as Purse, F4 as PurseAmount, F5 as Frequency from  CompareAndCheck where F1 not like '%Carrier%' and (F4 is not null and F4 <> '')
	UNION all
	select F1 as Carrier,F2 as PBP, F6 as Purse, F7 as PurseAmount, F8 as Frequency from  CompareAndCheck where F1 not like '%Carrier%' and (F7 is not null and F7 <> '') 
	Union all
	select F1 as Carrier,F2 as PBP, F9 as Purse, F10 as PurseAmount, F11 as Frequency from  CompareAndCheck where F1 not like '%Carrier%' and (F10 is not null and F10 <> '') 
	) a
group by Carrier
) a


drop table if exists #CarrierPurseAmountALL
select * into #CarrierPurseAmountALL from (
select * from 
	(
	select F1 as Carrier,F2 as PBP, F3 as Purse, F4 as PurseAmount, F5 as Frequency from  CompareAndCheck where F1 not like '%Carrier%' and (F4 is not null and F4 <> '')
	UNION all
	select F1 as Carrier,F2 as PBP, F6 as Purse, F7 as PurseAmount, F8 as Frequency from  CompareAndCheck where F1 not like '%Carrier%' and (F7 is not null and F7 <> '') 
	Union all
	select F1 as Carrier,F2 as PBP, F9 as Purse, F10 as PurseAmount, F11 as Frequency from  CompareAndCheck where F1 not like '%Carrier%' and (F10 is not null and F10 <> '') 
	) a
) a


select * from #CarrierPurseAmountALL


select * from elig.clientcodes
where 1 = 1
and ClientName like '%av%'
--and DataSource like 'ELIG_E%'

select sum(BenefitCategoryValue) from 
(
select distinct clientid, fis_pursename, fis_purseslot, SubProgramID, HealthPlanID, carrierid, BenefitCategoryValue, BenefitFrequencyMonths
From flex.FISWalletMapping
where 1 = 1
and CarrierID = 269
and Level1ClientID = 995407
) a


select * from elig.clientcodes
where 1 = 1
and ClientName like '%av%'
--and DataSource like 'ELIG_E%'

select carrierID, sum(BenefitCategoryValue) from 
(
select distinct clientid, fis_pursename, fis_purseslot, SubProgramID, HealthPlanID, carrierid, BenefitCategoryValue, BenefitFrequencyMonths
From flex.FISWalletMapping
where 1 = 1
and CarrierID in (0,4,16,34,90,129,141,149,223,269,271,274,276,278,281,297,298,357,358,358,367,384,387,388,391,394,395,405,413,416,421,422,423,426,427,428,429,430,432,434,435,440,444)
and Level1ClientID = 995407
) a
group by carrierID


select 'Prod' as Environment,carrierID, CarrierName, sum(BenefitCategoryValue) as BenefitCategoryValue from 
(
select distinct clientid, fis_pursename, fis_purseslot, SubProgramID, HealthPlanID, carrierid, 
CarrierName = (select b.InsuranceCarrierName from insurance.insuranceCarriers b where b.InsuranceCarrierID = a.CarrierID),
BenefitCategoryValue, BenefitFrequencyMonths
From flex.FISWalletMapping a
where 1 = 1
--and CarrierID in (0,4,16,34,90,129,141,149,223,269,271,273,274,276,278,281,297,298,357,358,358,367,384,387,388,391,394,395,405,413,416,421,422,423,426,427,428,429,430,432,434,435,440,444)
and Level1ClientID = 995407
) a
group by carrierID, CarrierName
order by CarrierID


-- Please Keep This as a reference
-- All Carriers in the Excel Spreadsheet | The first SQL is as given in the excel, the next sql is modified to search the CarrierID
select * from elig.clientcodes where ClientName like '%Paramount/Promedica/Map%' -- select * from elig.clientcodes where ClientName like '%Promed%' | CarrierID is NULL or CarrierID is zero 0
select * from elig.clientcodes where ClientName like '%Central Health Plan%' --  -- Present in the Database and excel | CarrierID 4
select * from elig.clientcodes where ClientName like '%Aetna VA%' -- Present in the Database and excel | CarrierID 16
select * from elig.clientcodes where ClientName like '%Blue Cross and Blue Shield of Kansas City%' -- select * from elig.clientcodes where ClientName like '%BCBS-KC%' | CarrierID 34
select * from elig.clientcodes where ClientName like '%Health Plan of San Mateo%' -- Present in the Database and excel | CarrierID 90
select * from elig.clientcodes where ClientName like '%Medical Mutual of Ohio%'  -- Present in the Database and excel | CarrierID 129
select * from elig.clientcodes where ClientName like '%MVP Health Care, Inc.%' -- select * from elig.clientcodes where ClientName like '%MVP%' | CarrierID 141
select * from elig.clientcodes where ClientName like '%Partners Health Plan%' -- Present in the Database and excel | CarrierID 149
select * from elig.clientcodes where ClientName like '%HAP Medicare%'  -- select * from elig.clientcodes where ClientName like '%HAP%' || CarrierID 223
select * from elig.clientcodes where ClientName like '%Avmed%' -- Present in the Database and excel | CarrierID 269
select * from elig.clientcodes where ClientName like '%Capital Blue Cross%' -- select * from elig.clientcodes where ClientName like '%Capital Blue%' | CarrierID 271
select * from elig.clientcodes where ClientName like '%Clear Spring%' -- Present in the Database and excel | CarrierID 274
select * from elig.clientcodes where ClientName like '%Global Health%' -- Present in the Database and excel | CarrierID 276
select * from elig.clientcodes where ClientName like '%OptimaHealth%' -- select * from elig.clientcodes where ClientName like '%optima%' | Contains there CarrierID's ( 278, 402, 401)
select * from elig.clientcodes where ClientName like '%Zing Health%' -- select * from elig.clientcodes where ClientName like '%Zing%' | CarrierID 281
select * from elig.clientcodes where ClientName like '%ConnectiCare%' -- Present in the Database and excel | CarrierID 297
select * from elig.clientcodes where ClientName like '%EmblemHealth%' -- select * from elig.clientcodes where ClientName like '%Emblem%' | 298
select * from elig.clientcodes where ClientName like '%Care First%' -- select * from elig.clientcodes where ClientName like '%CareFirst%'  | 357
select * from elig.clientcodes where ClientName like '%American Health Plan (American Health Advantage)%' -- select * from elig.clientcodes where ClientName like '%American Health Plan%' | CarrierID 358
select * from elig.clientcodes where ClientName like '%American Health Plan (Kansas Health Advantage)%' -- select * from elig.clientcodes where ClientName like '%American Health Plan%' | CarrierID 358
select * from elig.clientcodes where ClientName like '%Florida Blue Funded%' -- select * from elig.clientcodes where ClientName like '%Florida%' | CarrierID = 367
select * from elig.clientcodes where ClientName like '%Brand New Day%' --Present in the Database and excel | CarrierID 384
select * from elig.clientcodes where ClientName like '%New Hanover%' --Present in the Database and excel | CarrierID 387
select * from elig.clientcodes where ClientName like '%Virginia Premier (Medicare)%' -- select * from elig.clientcodes where ClientName like '%Virginia%' | CarrierID 388
select * from elig.clientcodes where ClientName like '%Alterwood%'--Present in the Database and excel | CarrierID 391
select * from elig.clientcodes where ClientName like '%VIVA Health%'--Present in the Database and excel | CarrierID 394
select * from elig.clientcodes where ClientName like '%MetroPlus%'--Present in the Database and excel | CarrierID 395
select * from elig.clientcodes where ClientName like '%Lasso Healthcare%' --Present in the Database and excel | CarrierID 405
select * from elig.clientcodes where ClientName like '%AgeRight Advantage%'--select * from elig.clientcodes where ClientName like '%AgeRight%' | CarrierID 413
select * from elig.clientcodes where ClientName like '%Gold Kidney Health Plan%' --Present in the Database and excel | CarrierID 416
select * from elig.clientcodes where ClientName like '%Sonder Health Plan%' --Present in the Database and excel | CarrierID 421
select * from elig.clientcodes where ClientName like '%Aetna MMP%' --Present in the Database and excel | CarrierID 422
select * from elig.clientcodes where ClientName like '%AllyAlign%' --Present in the Database and excel | CarrierID 423
select * from elig.clientcodes where ClientName like '%LA Care%' -- Present in the Database and excel | CarrierID 426
select * from elig.clientcodes where ClientName like '%Imperial Health%'  -- Present in the Database and excel | CarrierID 427
select * from elig.clientcodes where ClientName like '%Hometown Health%' -- Present in the Database and excel | CarrierID 428
select * from elig.clientcodes where ClientName like '%Doctors Health%' -- Present in the Database and excel | CarrierID 429
select * from elig.clientcodes where ClientName like '%Cox HealthPlans%' -- select * from elig.clientcodes where ClientName like '%Cox%' | CarrierID 430
select * from elig.clientcodes where ClientName like '%BCBS Arizona%' -- select * from elig.clientcodes where ClientName like '%BCBS-AZ%' | CarrierID 432
select * from elig.clientcodes where ClientName like '%CDPHP Advantage%' -- select * from elig.clientcodes where ClientName like '%CDPHP%' | CarrierID 434
select * from elig.clientcodes where ClientName like '%MassAdvantage%' -- select * from elig.clientcodes where ClientName like '%Mass Advantage%' | CarrierID 435
select * from elig.clientcodes where ClientName like '%Community Health Choice%'  -- Present in the database and excel | CarrierID 440
select * from elig.clientcodes where ClientName like '%Chinese Community Health Plan%' --  | select * from elig.clientcodes where ClientName like '%CCHP%' | CarrierID 273
select * from elig.clientcodes where ClientName like '%Select Health%' -- Present in the database and excel | CarrierID 444
select * from elig.clientcodes where ClientName like '%Aetna%'  -- This has multiple InsuranceCarriers | CarrierIDs (16, 422)



-- All Carriers in the Excel Spreadsheet | The first SQL is as given in the excel, the next sql is modified to search the CarrierID
select * from elig.clientcodes where ClientName like '%Promed%'  -- select * from elig.clientcodes where ClientName like '%Promed%' | CarrierID is NULL or CarrierID is zero 0
select * from elig.clientcodes where ClientName like '%Central Health Plan%' --  -- Present in the Database and excel | CarrierID 4
select * from elig.clientcodes where ClientName like '%Aetna VA%' -- Present in the Database and excel | CarrierID 16
select * from elig.clientcodes where ClientName like '%BCBS-KC%'  -- | CarrierID 34
select * from elig.clientcodes where ClientName like '%Health Plan of San Mateo%' -- Present in the Database and excel | CarrierID 90
select * from elig.clientcodes where ClientName like '%Medical Mutual of Ohio%'  -- Present in the Database and excel | CarrierID 129
select * from elig.clientcodes where ClientName like '%MVP%'  -- | CarrierID 141
select * from elig.clientcodes where ClientName like '%Partners Health Plan%' -- Present in the Database and excel | CarrierID 149
select * from elig.clientcodes where ClientName like '%HAP%'  --  || CarrierID 223
select * from elig.clientcodes where ClientName like '%Avmed%' -- Present in the Database and excel | CarrierID 269
select * from elig.clientcodes where ClientName like '%Capital Blue%'  -- | CarrierID 271
select * from elig.clientcodes where ClientName like '%Clear Spring%' -- Present in the Database and excel | CarrierID 274
select * from elig.clientcodes where ClientName like '%Global Health%' -- Present in the Database and excel | CarrierID 276
select * from elig.clientcodes where ClientName like '%optima%' -- | Contains there CarrierID's ( 278, 402, 401)
select * from elig.clientcodes where ClientName like '%Zing%' -- | CarrierID 281
select * from elig.clientcodes where ClientName like '%ConnectiCare%' -- Present in the Database and excel | CarrierID 297
select * from elig.clientcodes where ClientName like '%Emblem%'  -- | 298
select * from elig.clientcodes where ClientName like '%CareFirst%'  --  | 357
select * from elig.clientcodes where ClientName like '%American Health Plan%'--  | CarrierID 358
select * from elig.clientcodes where ClientName like '%American Health Plan%'--  | CarrierID 358
 select * from elig.clientcodes where ClientName like '%Florida%'  --| CarrierID = 367
select * from elig.clientcodes where ClientName like '%Brand New Day%' --Present in the Database and excel | CarrierID 384
select * from elig.clientcodes where ClientName like '%New Hanover%' --Present in the Database and excel | CarrierID 387
select * from elig.clientcodes where ClientName like '%Virginia%' --  | CarrierID 388
select * from elig.clientcodes where ClientName like '%Alterwood%'--Present in the Database and excel | CarrierID 391
select * from elig.clientcodes where ClientName like '%VIVA Health%'--Present in the Database and excel | CarrierID 394
select * from elig.clientcodes where ClientName like '%MetroPlus%'--Present in the Database and excel | CarrierID 395
select * from elig.clientcodes where ClientName like '%Lasso Healthcare%' --Present in the Database and excel | CarrierID 405
select * from elig.clientcodes where ClientName like '%AgeRight%' --| CarrierID 413
select * from elig.clientcodes where ClientName like '%Gold Kidney Health Plan%' --Present in the Database and excel | CarrierID 416
select * from elig.clientcodes where ClientName like '%Sonder Health Plan%' --Present in the Database and excel | CarrierID 421
select * from elig.clientcodes where ClientName like '%Aetna MMP%' --Present in the Database and excel | CarrierID 422
select * from elig.clientcodes where ClientName like '%AllyAlign%' --Present in the Database and excel | CarrierID 423
select * from elig.clientcodes where ClientName like '%LA Care%' -- Present in the Database and excel | CarrierID 426
select * from elig.clientcodes where ClientName like '%Imperial Health%'  -- Present in the Database and excel | CarrierID 427
select * from elig.clientcodes where ClientName like '%Hometown Health%' -- Present in the Database and excel | CarrierID 428
select * from elig.clientcodes where ClientName like '%Doctors Health%' -- Present in the Database and excel | CarrierID 429
select * from elig.clientcodes where ClientName like '%Cox%'  -- | CarrierID 430
select * from elig.clientcodes where ClientName like '%BCBS-AZ%'  -- | CarrierID 432
select * from elig.clientcodes where ClientName like '%CDPHP%'  -- | CarrierID 434
select * from elig.clientcodes where ClientName like '%Mass Advantage%'--  | CarrierID 435
select * from elig.clientcodes where ClientName like '%Community Health Choice%'  -- Present in the database and excel | CarrierID 440
select * from elig.clientcodes where ClientName like '%CCHP%' --  |  CarrierID 273
select * from elig.clientcodes where ClientName like '%Select Health%' -- Present in the database and excel | CarrierID 444
select * from elig.clientcodes where ClientName like '%Aetna%'  -- This has multiple InsuranceCarriers | CarrierIDs (16, 422)


-- All Carriers in the Excel Spreadsheet | The first SQL is as given in the excel, the next sql is modified to search the CarrierID
select * from (
select * from elig.clientcodes where ClientName like '%Promed%'							-- select * from elig.clientcodes where ClientName like '%Promed%' | CarrierID is NULL or CarrierID is zero 0
union select * from elig.clientcodes where ClientName like '%Central Health Plan%'		--	Present in the Database and excel | CarrierID 4
union select * from elig.clientcodes where ClientName like '%Aetna VA%'					--	Present in the Database and excel | CarrierID 16
union select * from elig.clientcodes where ClientName like '%BCBS-KC%'					-- | CarrierID 34
union select * from elig.clientcodes where ClientName like '%Health Plan of San Mateo%' --	Present in the Database and excel | CarrierID 90
union select * from elig.clientcodes where ClientName like '%Medical Mutual of Ohio%'	--	Present in the Database and excel | CarrierID 129
union select * from elig.clientcodes where ClientName like '%MVP%'						-- | CarrierID 141
union select * from elig.clientcodes where ClientName like '%Partners Health Plan%'		--	Present in the Database and excel | CarrierID 149
union select * from elig.clientcodes where ClientName like '%HAP%'						-- | CarrierID 223
union select * from elig.clientcodes where ClientName like '%Avmed%'					--	Present in the Database and excel | CarrierID 269
union select * from elig.clientcodes where ClientName like '%Capital Blue%'				-- | CarrierID 271
union select * from elig.clientcodes where ClientName like '%Clear Spring%'				--	Present in the Database and excel | CarrierID 274
union select * from elig.clientcodes where ClientName like '%Global Health%'			--	Present in the Database and excel | CarrierID 276
union select * from elig.clientcodes where ClientName like '%optima%'					-- | Contains there CarrierID's ( 278, 402, 401)
union select * from elig.clientcodes where ClientName like '%Zing%'						-- | CarrierID 281
union select * from elig.clientcodes where ClientName like '%ConnectiCare%'				--	Present in the Database and excel | CarrierID 297
union select * from elig.clientcodes where ClientName like '%Emblem%'					-- | CarrierID 298
union select * from elig.clientcodes where ClientName like '%CareFirst%'				-- | CarrierID 357
union select * from elig.clientcodes where ClientName like '%American Health Plan%'		-- | CarrierID 358
union select * from elig.clientcodes where ClientName like '%American Health Plan%'		-- | CarrierID 358
union select * from elig.clientcodes where ClientName like '%Florida%'					-- | CarrierID 367
union select * from elig.clientcodes where ClientName like '%Brand New Day%'			--	Present in the Database and excel | CarrierID 384
union select * from elig.clientcodes where ClientName like '%New Hanover%'				--	Present in the Database and excel | CarrierID 387
union select * from elig.clientcodes where ClientName like '%Virginia%'					-- | CarrierID 388
union select * from elig.clientcodes where ClientName like '%Alterwood%'				--	Present in the Database and excel | CarrierID 391
union select * from elig.clientcodes where ClientName like '%VIVA Health%'				--	Present in the Database and excel | CarrierID 394
union select * from elig.clientcodes where ClientName like '%MetroPlus%'				--	Present in the Database and excel | CarrierID 395
union select * from elig.clientcodes where ClientName like '%Lasso Healthcare%'			--	Present in the Database and excel | CarrierID 405
union select * from elig.clientcodes where ClientName like '%AgeRight%'					--| CarrierID 413
union select * from elig.clientcodes where ClientName like '%Gold Kidney Health Plan%'	--	Present in the Database and excel | CarrierID 416
union select * from elig.clientcodes where ClientName like '%Sonder Health Plan%'		--	Present in the Database and excel | CarrierID 421
union select * from elig.clientcodes where ClientName like '%Aetna MMP%'				--	Present in the Database and excel | CarrierID 422
union select * from elig.clientcodes where ClientName like '%AllyAlign%'				--	Present in the Database and excel | CarrierID 423
union select * from elig.clientcodes where ClientName like '%LA Care%'					--	Present in the Database and excel | CarrierID 426
union select * from elig.clientcodes where ClientName like '%Imperial Health%'			--	Present in the Database and excel | CarrierID 427
union select * from elig.clientcodes where ClientName like '%Hometown Health%'			--	Present in the Database and excel | CarrierID 428
union select * from elig.clientcodes where ClientName like '%Doctors Health%'			--	Present in the Database and excel | CarrierID 429
union select * from elig.clientcodes where ClientName like '%Cox%'						-- | CarrierID 430
union select * from elig.clientcodes where ClientName like '%BCBS-AZ%'					-- | CarrierID 432
union select * from elig.clientcodes where ClientName like '%CDPHP%'					-- | CarrierID 434
union select * from elig.clientcodes where ClientName like '%Mass Advantage%'			-- | CarrierID 435
union select * from elig.clientcodes where ClientName like '%Community Health Choice%'  --	Present in the database and excel | CarrierID 440
union select * from elig.clientcodes where ClientName like '%CCHP%'						-- |  '%Chinese Community Health Plan%'  CarrierID 273
union select * from elig.clientcodes where ClientName like '%Select Health%'			--	Present in the database and excel | CarrierID 444
union select * from elig.clientcodes where ClientName like '%Aetna%'					-- This has multiple InsuranceCarriers | CarrierIDs (16, 422)
) a
where InsuranceCarrierID is not NULL
order by InsuranceCarrierID asc
