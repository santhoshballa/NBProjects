select * from [otcfunds].[FileTrack] where RefFileTrackID in (9948, 9945) or FileTrackID in (9948, 9945) order by ClientCode desc
select * from [otcfunds].[FileTrack] where DirectionCode = 'OUT'
select * from [otcfunds].[FileTrack] where DirectionCode = 'IN'


select * from (
select distinct  'select top 10 ' +' '+ ('''['+ table_schema +']'+ '.' +'['+ replace(replace(table_name,' ','_'),'-','_') +']'' as TableName_'+  table_schema + '_' + replace(replace(table_name,' ','_'),'-','_') +','  )  +  STRING_AGG(CONVERT(NVARCHAR(max), ('a.['+column_name+']' + ' as ' +column_name+ '_OUT' )),',') + ' from ' + '['+ table_schema +']'+ '.' +'['+ table_name +']' AS selectList from information_schema.columns
where table_name in ( select distinct table_name from information_schema.columns) and table_name in ('FileTrack')
group by table_schema, table_name
) a

select * from (
select distinct  'select top 10 ' +' '+ ('''['+ table_schema +']'+ '.' +'['+ replace(replace(table_name,' ','_'),'-','_') +']'' as TableName_'+  table_schema + '_' + replace(replace(table_name,' ','_'),'-','_') +','  )  +  STRING_AGG(CONVERT(NVARCHAR(max), ('b.['+column_name+']' + ' as ' +column_name+ '_IN')),',') + ' from ' + '['+ table_schema +']'+ '.' +'['+ table_name +']' AS selectList from information_schema.columns
where table_name in ( select distinct table_name from information_schema.columns) and table_name in ('FileTrack')
group by table_schema, table_name
) b


drop table if exists #FileTrack
select * into #FileTrack from (
select  a.*, b.* from [otcfunds].[FileTrack] a left Join [otcfunds].[FileTrack] b on a.RefFileTrackID = b.FileTrackID  where a.ClientCode is not null 
) a

-- FileTrack
drop table if exists #FileTrack
select * into #FileTrack from (
select
'[otcfunds].[FileTrack][OUT]' as TableNameFileTrack_OUT,a.[FileTrackID] as FileTrackID_OUT,a.[FileInfoID] as FileInfoID_OUT,a.[ClientCode] as ClientCode_OUT,a.[DirectionCode] as DirectionCode_OUT,a.[FileName] as FileName_OUT,a.[FileFormat] as FileFormat_OUT,a.[FileType] as FileType_OUT,a.[DataSource] as DataSource_OUT,a.[DateReceived] as DateReceived_OUT,a.[DateProcessed] as DateProcessed_OUT,a.[TotalRecords] as TotalRecords_OUT,a.[RecordsProcessed] as RecordsProcessed_OUT,a.[RecordsErrored] as RecordsErrored_OUT,a.[LoadStartTime] as LoadStartTime_OUT,a.[LoadEndTime] as LoadEndTime_OUT,a.[StatusCode] as StatusCode_OUT,a.[CreateDate] as CreateDate_OUT,a.[CreateUser] as CreateUser_OUT,a.[ModifyDate] as ModifyDate_OUT,a.[ModifyUser] as ModifyUser_OUT,a.[RefFileTrackID] as RefFileTrackID_OUT,a.[SnapshotFlag] as SnapshotFlag_OUT, 
'[otcfunds].[FileTrack][IN}'  as TableNameFileTrack_IN, b.[FileTrackID] as FileTrackID_IN,b.[FileInfoID] as FileInfoID_IN,b.[ClientCode] as ClientCode_IN,b.[DirectionCode] as DirectionCode_IN,b.[FileName] as FileName_IN,b.[FileFormat] as FileFormat_IN,b.[FileType] as FileType_IN,b.[DataSource] as DataSource_IN,b.[DateReceived] as DateReceived_IN,b.[DateProcessed] as DateProcessed_IN,b.[TotalRecords] as TotalRecords_IN,b.[RecordsProcessed] as RecordsProcessed_IN,b.[RecordsErrored] as RecordsErrored_IN,b.[LoadStartTime] as LoadStartTime_IN,b.[LoadEndTime] as LoadEndTime_IN,b.[StatusCode] as StatusCode_IN,b.[CreateDate] as CreateDate_IN,b.[CreateUser] as CreateUser_IN,b.[ModifyDate] as ModifyDate_IN,b.[ModifyUser] as ModifyUser_IN,b.[RefFileTrackID] as RefFileTrackID_IN,b.[SnapshotFlag] as SnapshotFlag_IN,

--(b.DateReceived - a.CreateDate) as DifferenceDate
DATEDIFF(DAY, a.CreateDate,b.DateReceived ) as DifferenceInDays
from [otcfunds].[FileTrack] a left Join [otcfunds].[FileTrack] b on a.RefFileTrackID = b.FileTrackID  where a.ClientCode is not null 
) a

select * from #FileTrack order by FileName_IN,DifferenceInDays desc



select * from (
select distinct  'select top 10 ' +' '+ ('''['+ table_schema +']'+ '.' +'['+ replace(replace(table_name,' ','_'),'-','_') +']'' as TableName_'+  table_schema + '_' + replace(replace(table_name,' ','_'),'-','_') +','  )  +  STRING_AGG(CONVERT(NVARCHAR(max), ('['+column_name+']')),',') + ' from ' + '['+ table_schema +']'+ '.' +'['+ table_name +']' AS selectList from information_schema.columns
where table_name in ( select distinct table_name from information_schema.columns)  and table_name in ('CardBenefitLoad_CI')
group by table_schema, table_name
) a


-- [otcfunds].[CardBenefitLoad_CI]
drop table if exists #CardBenefitLoad_CI
select * into #CardBenefitLoad_CI from (
select  '[otcfunds].[CardBenefitLoad_CI]' as TableName_otcfunds_CardBenefitLoad_CI,[CardBenefitLoadID],[MemberDataID],[ClientCode],[NHLinkID],[RecordType],[MemberDataSource],[InsCarrierID],[InsHealthPlanID],[BenefitCardNumber],[LastName],[MiddleInitial],[FirstName],[DOB],[MailingAddress1],[MailingAddress2],[MailingCity],[MailingState],[MailingZipCode],[MailingCountry],[HomePhoneNbr],[BenefitType],[BenefitSource],[NBWalletCode],[BenefitAmount],[BenefitValidFrom],[BenefitValidTo],[BenefitFreqInMonth],[BenefitYear],[BenefitPeriod],[IsActive],[RequestRecordStatus],[RequestToBeProcessed],[RequestProcessedFileID],[RequestProcessedDate],[ResponseRecordStatus],[ResponseRecordStatusCode],[ResponseProcessedFileID],[ResponseProcessedDate],[FirstTimeCardIssued],[CreateDate],[CreateUser],[ModifyDate],[ModifyUser],[RefCardBenefitLoadID],[ErrorProcessed],[Language],[DiscretionaryData1],[FourthLine],[CarrierMessage],[ClientID],[ProgramID],[SubProgramID],[PackageID],[FileGenInd],[Level1ClientID],[BenefitCardMappingID],
ROW_NUMBER () OVER (PARTITION BY [ClientCode], [NHLinkID] ORDER BY [ClientCode], [NHLinkID], [CreateDate] DESC) as rn
from [otcfunds].[CardBenefitLoad_CI]
where nhlinkID is not null
) a
where a.rn > 1 -- and ClientCode = 'H438_500K'

select top 100 * from elig.ClientCodes
select top 1000 * from [otcfunds].[FileTrack]
select top 1000 * from [otcfunds].CardBenefitLoad_CI
select top 1000 * from [otcfunds].CardBenefitLoad_FD

select distinct ClientCode, ClientName, DataSource, InsuranceCarrierID, InsuranceHealthPlanID, IsActive, MasterDataSource, RptClientName from elig.ClientCodes where InsuranceCarrierID is not null
select distinct insuranceCarrierID, InsuranceCarrierName, IsActive from insurance.InsuranceCarriers
select distinct InsuranceCarrierID, InsuranceHealthPlanID, HealthPlanName, IsActive from insurance.InsuranceHealthPlans

select distinct 'CI' as ClientCode, InsCarrierID, InsHealthPlanID from [otcfunds].CardBenefitLoad_CI

drop table if exists #ClientCodesCarriersHealthPlans
select * into #ClientCodesCarriersHealthPlans from (
select distinct 
a.ClientCode, a.ClientName,a.InsuranceCarrierID,a.InsuranceHealthPlanID as InsuranceHealthPlanID_ClientCode , a.IsActive,
--b.InsuranceCarrierID, 
b.InsuranceCarrierName, b.IsActive as IsActive_Ins,
--c.InsuranceCarrierID, 
c.InsuranceHealthPlanID, c.HealthPlanName, c.IsActive as IsActive_HealthPlan
from
elig.ClientCodes a 
left join insurance.InsuranceCarriers b on a.InsuranceCarrierID = b.InsuranceCarrierID
left join insurance.InsuranceHealthPlans c on a.InsuranceCarrierID = c.InsuranceCarrierID
where a.InsuranceCarrierID is not null and c.IsActive = 1
) a

select * from #ClientCodesCarriersHealthPlans

select distinct ClientCode, RecordType, InsCarrierID, InsHealthPlanID, RequestRecordStatus, ResponseRecordStatus, ResponseRecordStatusCode, cast(CreateDate as date) CreateDate from [otcfunds].CardBenefitLoad_CI
where ClientCode = 'H223_O'
select distinct ClientCode, RecordType, InsCarrierID, InsHealthPlanID, RequestRecordStatus, ResponseRecordStatus, ResponseRecordStatusCode, cast(CreateDate as date) CreateDate from [otcfunds].CardBenefitLoad_FD
where ClientCode = 'H223_O'
select distinct ClientCode, RecordType, RequestRecordStatus, ResponseRecordStatus, ResponseRecordStatusCode, cast(CreateDate as date) CreateDate from [otcfunds].CardBenefitLoad_CI order by ClientCode, CreateDate
select * from #CardBenefitLoad_CI
select ClientCode, count(*) from #CardBenefitLoad_CI group by ClientCode


drop table if exists #FileTrackClientCodesCarriersHealthPlans
select * into #FileTrackClientCodesCarriersHealthPlans from (
Select distinct a.*, b.* from 
#FileTrack a left join #ClientCodesCarriersHealthPlans b on a.ClientCode_OUT = b.ClientCode
) a

drop table if exists #FileTrackClientCodesCarriersHealthPlans
select * into #FileTrackClientCodesCarriersHealthPlans from (
Select distinct a.*, b.* from 
#FileTrack a left join #ClientCodesCarriersHealthPlans b on a.ClientCode_OUT = b.ClientCode
) a
where a.SnapshotFlag_OUT = 'CI'

select * from #FileTrackClientCodesCarriersHealthPlans

select a.* , b.* 
from [otcfunds].CardBenefitLoad_CI a join #FileTrackClientCodesCarriersHealthPlans b
on a.ClientCode = b.ClientCode and a.InsCarrierID = b.InsuranceCarrierID and a.InsHealthPlanID = b.InsuranceHealthPlanID

-- CardsIssued, either RequestRecordStatus has an error or ResponseRecordStatus has an error
drop table if exists #CardBenefitLoad_CI_Error
select * into #CardBenefitLoad_CI_Error from (
select distinct ClientCode as ClientCode_Error, InsCarrierID , InsHealthPlanID, try_cast(CreateDate as date) as CreateDate, RecordType, RequestRecordStatus, ResponseRecordStatus, ResponseRecordStatusCode from otcfunds.CardBenefitLoad_CI 
where InsCarrierID is not null and (RequestRecordStatus = 'SUCCESS' and (ResponseRecordStatus <> 'SUCCESS' or ResponseRecordStatus is NULL)  )
-- order by ClientCode,InsCarrierID, InsHealthPlanID, 4 asc
) a

select * from  #CardBenefitLoad_CI_Error order by ClientCode_Error, InsCarrierID, InsHealthPlanID, CreateDate asc

select distinct ClientCode, InsCarrierID, InsHealthPlanID, try_cast(CreateDate as date) as CreateDate, RecordType, RequestRecordStatus, ResponseRecordStatus, ResponseRecordStatusCode from otcfunds.CardBenefitLoad_CI 
where InsCarrierID is not null and (RequestRecordStatus = 'SUCCESS' and ResponseRecordStatus = 'SUCCESS' )
order by ClientCode,InsCarrierID, InsHealthPlanID, 4 asc


-- 
drop table if exists #CardBenefitLoad_CI_Error_Report
select * into #CardBenefitLoad_CI_Error_Report from (
select distinct
a.ClientCode_Error as ClientCode_Error1 , a.InsCarrierID as InsCarrierID_Error, a.InsHealthPlanID as InsHealthPlanID_Error, FileName_OUT as FileName_OUT1, FileName_IN as FileName_IN1, FileTrackID_OUT as FileTrackID_OUT1, a.CreateDate as CreateDate_ERROR, DATEDIFF(DAY, a.CreateDate, b.CreateDate_OUT) as DifferenceInDaysCIandOUT, b.CreateDate_OUT as CreateDate_Out1, b.CreateDate_IN as CreateDate_IN1, DifferenceInDays as DifferenceInDays1,
a.* , b.* from
#CardBenefitLoad_CI_Error a left join #FileTrackClientCodesCarriersHealthPlans b
on a.ClientCode_Error = b.ClientCode and a.InsCarrierID = b.InsuranceCarrierID and a.InsHealthPlanID = b.InsuranceHealthPlanID and a.CreateDate < b.CreateDate_OUT and b.CreateDate_OUT < b.CreateDate_IN
where a.CreateDate <= CreateDate_OUT and CreateDate_OUT <= CreateDate_IN
-- order by  a.ClientCode_Error, b.FileTrackID_OUT,  a.CreateDate, b.CreateDate_OUT, b.CreateDate_IN,b.FileName_Out
) a


select * from #CardBenefitLoad_CI_Error_Report order by InsCarrierID, InsHealthPlanID, FileTrackID_OUT, ClientCode
select count(distinct FileTrackID_OUT) from  #CardBenefitLoad_CI_Error_Report
select distinct InsCarrierID, InsHealthPlanID, FileTrackID_OUT from #CardBenefitLoad_CI_Error_Report


declare @ClientCode varchar(50) = 'H438_500K'
declare @insCarrierID varchar(50) = '16'
declare @insHealthPlanID varchar(50) = '5666'

select * from otcfunds.CardBenefitLoad_CI where ClientCode = @ClientCode and InsCarrierID = @insCarrierID and InsHealthPlanID = @insHealthPlanID and RequestRecordStatus = 'SUCCESS' and ResponseRecordStatus = 'ERROR' 
select * from [otcfunds].[FileTrack] where ClientCode = @ClientCode
select * from elig.ClientCodes where ClientCode = @ClientCode
select * from insurance.InsuranceCarriers where InsuranceCarrierID = @insCarrierID
select * from insurance.InsuranceHealthPlans where InsuranceHealthPlanID = @insHealthPlanID
select * from otcfunds.CardBenefitLoad_CI where RequestRecordStatus = 'SUCCESS' and ResponseRecordStatus = 'ERROR'