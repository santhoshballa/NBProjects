-- =========================================================================================================================
-- NB - FIS - Information Interchange Report
-- =========================================================================================================================
DECLAre @RecCount AS INT
DROP TABLE IF EXISTS #BaseInfo
SELECT 
			  [FileTrackID]			=	[FTRK].[FileTrackID]
			, [FileInfoID]			=	[FTRK].[FileInfoID]
			, [ClientCode]			=	CASE 
											WHEN [FTRK].[ClientCode] IS NULL 
												THEN (SELECT [ClientCode] FROM [otcfunds].[FileTrack] [FTR1] WHERE [FTR1].[RefFileTrackID] = [FTRK].[FileTrackID])
											ELSE [FTRK].[ClientCode]
										END
			, [DataSource]			=	CASE 
											WHEN [FTRK].[DataSource] IS NULL 
												THEN (SELECT [DataSource] FROM [otcfunds].[FileTrack] [FTR1] WHERE [FTR1].[RefFileTrackID] = [FTRK].[FileTrackID])
											ELSE [FTRK].[DataSource]
										END
			, [DirectionCode]		=	[FTRK].[DirectionCode]
			, [FileName]			=	[FTRK].[FileName]
			, [FileSentDate]		=	CASE WHEN [DirectionCode] = 'OUT' THEN	[FTRK].[CreateDate] ELSE NULL END
			, [FileSentDateFrm]		=	CASE WHEN [DirectionCode] = 'OUT' THEN	CAST([FTRK].[CreateDate] AS DATE) ELSE NULL END
			, [FileReceivedDate]	=	[FTRK].[DateReceived]
			, [FileReceivedDateFrm]	=	CAST([FTRK].[DateReceived] AS DATE)
			, [StatusCode]			=	[FTRK].[StatusCode]
			, [SnapshotFlag]		=	[FTRK].[SnapshotFlag]
			, [CreateDate]			=	[FTRK].[CreateDate]
			, [CreateDateFrm]		=	CAST([FTRK].[CreateDate] AS DATE)
			, [RefFileTrackID]		=	CASE WHEN [FTRK].[RefFileTrackID] IS NULL THEN [FTRK].[FileTrackID] ELSE [FTRK].[RefFileTrackID] END
INTO		#BaseInfo
FROM		[otcfunds].[FileTrack]		[FTRK]

SET @RecCount = (SELECT COUNT(1) FROM #BaseInfo AS VARCHAR)
PRINT '#BaseInfo created, ' + CAST(@RecCount AS VARCHAR) + ' Rows'

-- Populate #CardBenefit with informationm from [otcfunds].[CardBenefitLoad_CI]
DROP TABLE IF EXISTS #CardBenefit
SELECT	DISTINCT
			  [CardBenefitLoadID]
			, [NHLinkID]
			, [ClientCode]					=	[CBDS].[ClientCode]
			, [InsCarrierID]				=	[CBDS].[InsCarrierID]
			, [RequestRecordStatus]			=	[CBDS].[RequestRecordStatus]
			, [RequestProcessedDate]		=	[CBDS].[RequestProcessedDate]
			, [ResponseRecordStatus]		=	[CBDS].[ResponseRecordStatus]
			, [ResponseRecordStatusCode]	=	[CBDS].[ResponseRecordStatusCode]
			, [ResponseProcessedDate]		=	[CBDS].[ResponseProcessedDate]
			, [CreateDate]					=	[CBDS].[CreateDate]
			, [CreateDateFrm]				=	CAST([CBDS].[CreateDate] AS DATE)
			, [Resent]						=	ROW_NUMBER () OVER (PARTITION BY	[ClientCode], [NHLinkID]
																	ORDER BY		[ClientCode], [NHLinkID], [CreateDate] DESC)
INTO		#CardBenefit
FROM		[otcfunds].[CardBenefitLoad_CI]		[CBDS]
WHERE		[NHLinkID] IS NOT NULL
ORDER BY	[ClientCode], [CreateDate]

SET @RecCount = (SELECT COUNT(1) FROM #CardBenefit AS VARCHAR)
PRINT '#CardBenefit created, ' + CAST(@RecCount AS VARCHAR) + ' Rows'

-- Populate #Results Table from #BaseInfo ([otcfunds].[FileTrack]) for Destination Codes 'OUT' and 'IN'
DROP TABLE IF EXISTS #Results
CREATE TABLE #Results
		(
				  [ClientCode]			VARCHAR(20)
				, [ClientName]			VARCHAR(120)
				, [DataSource]			VARCHAR(20)
				, [OutDirection]		VARCHAR(3)
				, [OutFileTrackID]		BIGINT
				, [OutFileInfoID]		BIGINT
				, [OutFileName]			VARCHAR(60)
				, [OUTFileStatus]		VARCHAR(20)
				, [SentDate]			DATETIME
				, [SentDateFrm]			DATE
				, [InDirection]			VARCHAR(3)
				, [InFileTrackID]		BIGINT
				, [InFileInfoID]		BIGINT
				, [InFileName]			VARCHAR(60)
				, [InFileStatus]		VARCHAR(20)
				, [InReceivedDate]		DATETIME
				, [InReceivedDateFrm]	DATE
				, [InFileStatusCode]	INT
				, [SnapshotFlag]		VARCHAR(3)
				, [CreateDate]			DATETIME
				, [CreateDateFrm]		DATE
				, [DifferenceDays]		TINYINT
				, [RefFileTrackID]		BIGINT
				, [ReportedError]		BIT
				, [TimesSent]			TINYINT
		)
INSERT INTO #Results
		(
			  [ClientCode]
			, [DataSource]
			, [OutDirection]
			, [OutFileTrackID]
			, [OutFileInfoID]
			, [OutFileName]
			, [SentDate]
			, [SentDateFrm]
			, [SnapshotFlag]
			, [CreateDate]
			, [CreateDateFrm]
			, [RefFileTrackID]
			, [DifferenceDays]
			, [TimesSent]
)
SELECT		  [ClientCode]
			, [DataSource]
			, [DirectionCode]
			, [FileTrackID]
			, [FileInfoID]
			, [FileName]
			, [FileSentDate]
			, [FileSentDateFrm]
			, [SnapshotFlag]
			, [CreateDate]
			, [CreateDateFrm]
			, [RefFileTrackID]
			, ''
			, 1
FROM		#BaseInfo	[BASE]
WHERE		[DirectionCode]	=	'OUT'
		AND	[ClientCode] IS NOT NULL

SET @RecCount = (SELECT COUNT(1) FROM #Results AS VARCHAR)
PRINT '#Results created, ' + CAST(@RecCount AS VARCHAR) + ' Rows'

UPDATE	[RSLT]
SET		  [ClientName]			=	[CLNT].[ClientName] 
		, [InDirection]			=	[RECEIVED].[DirectionCode] 
		, [InFileTrackId]		=	[RECEIVED].[FileTrackID] 
		, [InFileInfoID]		=	[RECEIVED].[FileInfoID] 
		, [InFileName]			=	[RECEIVED].[FileName] 
		, [InReceivedDate]		=	[RECEIVED].[FileReceivedDate]
		, [InReceivedDateFrm]	=	[RECEIVED].[FileReceivedDateFrm]
FROM		#Results		[RSLT]
INNER JOIN	[elig].[ClientCodes]	[CLNT]
	ON		[RSLT].[ClientCode] = [CLNT].[ClientCode] 
INNER JOIN	(
				SELECT		  [ClientCode]
							, [DataSource]
							, [DirectionCode]
							, [FileTrackID]
							, [FileInfoID]
							, [FileName]
							, [FileReceivedDate]
							, [FileReceivedDateFrm]
							, [SnapshotFlag]
							, [CreateDate]
							, [RefFileTrackID]
				FROM	#BaseInfo
				WHERE	[DirectionCode]	=	'IN'
			) [RECEIVED]
	ON		[RSLT].[ClientCode]		= [RECEIVED].[ClientCode] 
		AND	[RSLT].[DataSource]		= [RECEIVED].[DataSource] 
		AND	[RSLT].[RefFileTrackID]	= [RECEIVED].[RefFileTrackID] 

-- Calculate Difference days between sent date and receivie date
UPDATE	  #Results
SET		  [DifferenceDays]		=	CASE
										WHEN [SentDate] IS NOT NULL AND [InReceivedDate] IS NOT NULL
											THEN DATEDIFF(DAY, [SentDate], [InReceivedDate])
										ELSE ''
									END

-- Update #Results "FileStatus" information regarding Sent Files from [otcfunds].[CardBenefitLoad_CI]
-- Select Status in table [otcfunds].[CardBenefitLoad_CI] equal or less than the date in [otcfunds].[FileTrack] - Takes time 3 minutes
UPDATE	  [RSLT]
SET		  [OUTFileStatus]		=	ISNULL([CBEN].[RequestRecordStatus],'')
FROM		#Results		[RSLT]
OUTER APPLY	(
				SELECT TOP 1
						  [RequestRecordStatus]			=	[CBEN].[RequestRecordStatus]
				FROM		#CardBenefit	[CBEN]
				WHERE		[RSLT].[ClientCode]		=	[CBEN].[ClientCode] 
						AND	[CBEN].[CreateDate]	   <=	[RSLT].[CreateDate]
						AND [CBEN].[RequestRecordStatus] IS NOT NULL
				ORDER BY	  [CBEN].[CreateDate]	DESC
							, [CBEN].[RequestRecordStatus]
			) [CBEN]

-- Update #Results "FileStatus" information regarding Received Files from [otcfunds].[CardBenefitLoad_CI]
-- Select Status in table [otcfunds].[CardBenefitLoad_CI] equal or less than the date in [otcfunds].[FileTrack] - Takes time 3:20 minutes
UPDATE	  [RSLT]
SET		  [INFileStatus]		=	ISNULL([CBEN].[ResponseRecordStatus],'')
		, [INFileStatusCode]	=	ISNULL([CBEN].[ResponseRecordStatusCode],'') 
FROM		#Results		[RSLT]
OUTER APPLY	(
				SELECT TOP 1
						  [ResponseRecordStatus]		=	[CBEN].[ResponseRecordStatus]
						, [ResponseRecordStatusCode]	=	[CBEN].[ResponseRecordStatusCode]
				FROM		#CardBenefit	[CBEN]
				WHERE		[RSLT].[ClientCode]		=	[CBEN].[ClientCode] 
						AND	[CBEN].[CreateDate]	   <=	[RSLT].[CreateDate]
						AND [CBEN].[ResponseRecordStatus] IS NOT NULL
				ORDER BY	  [CBEN].[CreateDate]	DESC
							, [CBEN].[ResponseRecordStatus]
			) [CBEN]

-- Update the [ReportedError] flag
UPDATE	#Results
SET		[ReportedError]		=	CASE 
									WHEN [OUTFileStatus] = 'ERROR' OR [INFileStatus] = 'ERROR'
										THEN 1
									ELSE
										0
								END

-- Update the Times Sent
UPDATE		[RSLT]
SET			[RSLT].[TimesSent]	=	[CBNF].[Resent]
FROM		#Results		[RSLT]
INNER JOIN	#CardBenefit	[CBNF]
	ON		[RSLT].[ClientCode]		=	[CBNF].[ClientCode] 
		AND	[RSLT].[CreateDateFrm]	=	[CBNF].[CreateDateFrm] 
WHERE		[CBNF].[Resent]			=	2

UPDATE	#Results SET [TimesSent] = 1 WHERE [TimesSent] IS NULL

-- ==============================================================================
-- Select all rows from the #Results Table
-- ==============================================================================
SELECT
			  [ClientCode]
			, [ClientName]
			, [SentFileName]			=	[OutFileName]
			, [SentFileStatus]			=	[OUTFileStatus]
			, [SentDate]
			, [ReceivedFileName]		=	[InFileName]
			, [ReceivedFileStatus]		=	[InFileStatus]
			, [ReceivedFileStatusCode]	=	[InFileStatusCode]
			, [ReceivedDate]			=	[InReceivedDate]
			, [DaysDifference]			=	[DifferenceDays]
			, [TimesSent]
FROM		#Results
ORDER BY	[ReportedError] DESC, [ClientCode], [RefFileTrackID]

-- ==============================================================================
-- Select Information about sent files
-- ==============================================================================
SELECT	
			  [SentDate]		=	[RSLT].[SentDate]
			, [ClientCode]		=	[RSLT].[ClientCode] 
			, [ClientName]		=	[RSLT].[ClientName] 
			, [SentFileName]	=	[RSLT].[OutFileName] 
			, [SentFileStatus]	=	[RSLT].[OUTFileStatus] 
			, [TimesSent]
FROM	#Results	[RSLT]
ORDER BY	[OUTFileStatus], [ClientCode], [RefFileTrackID]

-- ==============================================================================
-- Select Information about received files
-- ==============================================================================
SELECT	
			  [ReceivedDate]			=	[RSLT].[InReceivedDate]
			, [ClientCode]				=	[RSLT].[ClientCode] 
			, [ClientName]				=	[RSLT].[ClientName] 
			, [ReceivedFileName]		=	[RSLT].[InFileName] 
			, [ReceivedFileStatus]		=	[RSLT].[InFileStatus] 
			, [ReceivedFileStatusCode]	=	[InFileStatusCode]
			, [TimesSent]
FROM	#Results	[RSLT]
ORDER BY	[INFileStatus], [ClientCode], [RefFileTrackID]
-- =========================================================================================================================
/*
SELECT	TOP 1000 * FROM #Results
SELECT	TOP 1000 * FROM #BaseInfo
SELECT	TOP 1000 * FROM #CardBenefit
SELECT	* FROM #CardBenefit WHERE [Resent] > 1 ORDER BY [CreateDate]
select * from #CardBenefit order by ClientCode, NHLinkID, RequestProcessedDate,  ResponseProcessedDate, CreateDate
WHERE [ClientCode] = 'H474' AND [CreateDate] = '2021-09-05 00:24:14.970

*/

SELECT	* FROM #CardBenefit WHERE [Resent] > 1 ORDER BY [CreateDate]

SELECT		[RSLT].*, [CBNF].[Resent] 
FROM		#Results		[RSLT]
INNER JOIN	#CardBenefit	[CBNF]
	ON		[RSLT].[ClientCode]		=	[CBNF].[ClientCode] 
		AND	[RSLT].[CreateDateFrm]	=	[CBNF].[CreateDateFrm] 
WHERE		[CBNF].[Resent]			=	2

