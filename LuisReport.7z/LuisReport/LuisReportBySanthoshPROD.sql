declare @ClientCode varchar(50) = 'H438_500K'
declare @insCarrierID varchar(50) = '16'
declare @insHealthPlanID varchar(50) = '5666'
declare @FileTrackID varchar(50) = '9926'


drop table if exists #FileTrack
select * into #FileTrack from (
select
'[otcfunds].[FileTrack][OUT]' as TableNameFileTrack_OUT,a.[FileTrackID] as FileTrackID_OUT,a.[FileInfoID] as FileInfoID_OUT,a.[ClientCode] as ClientCode_OUT,a.[DirectionCode] as DirectionCode_OUT,a.[FileName] as FileName_OUT,a.[FileFormat] as FileFormat_OUT,a.[FileType] as FileType_OUT,a.[DataSource] as DataSource_OUT,a.[DateReceived] as DateReceived_OUT,a.[DateProcessed] as DateProcessed_OUT,a.[TotalRecords] as TotalRecords_OUT,a.[RecordsProcessed] as RecordsProcessed_OUT,a.[RecordsErrored] as RecordsErrored_OUT,a.[LoadStartTime] as LoadStartTime_OUT,a.[LoadEndTime] as LoadEndTime_OUT,a.[StatusCode] as StatusCode_OUT,a.[CreateDate] as CreateDate_OUT,a.[CreateUser] as CreateUser_OUT,a.[ModifyDate] as ModifyDate_OUT,a.[ModifyUser] as ModifyUser_OUT,a.[RefFileTrackID] as RefFileTrackID_OUT,a.[SnapshotFlag] as SnapshotFlag_OUT, 
'[otcfunds].[FileTrack][IN}'  as TableNameFileTrack_IN, b.[FileTrackID] as FileTrackID_IN,b.[FileInfoID] as FileInfoID_IN,b.[ClientCode] as ClientCode_IN,b.[DirectionCode] as DirectionCode_IN,b.[FileName] as FileName_IN,b.[FileFormat] as FileFormat_IN,b.[FileType] as FileType_IN,b.[DataSource] as DataSource_IN,b.[DateReceived] as DateReceived_IN,b.[DateProcessed] as DateProcessed_IN,b.[TotalRecords] as TotalRecords_IN,b.[RecordsProcessed] as RecordsProcessed_IN,b.[RecordsErrored] as RecordsErrored_IN,b.[LoadStartTime] as LoadStartTime_IN,b.[LoadEndTime] as LoadEndTime_IN,b.[StatusCode] as StatusCode_IN,b.[CreateDate] as CreateDate_IN,b.[CreateUser] as CreateUser_IN,b.[ModifyDate] as ModifyDate_IN,b.[ModifyUser] as ModifyUser_IN,b.[RefFileTrackID] as RefFileTrackID_IN,b.[SnapshotFlag] as SnapshotFlag_IN,

--(b.DateReceived - a.CreateDate) as DifferenceDate
DATEDIFF(DAY, a.CreateDate,b.DateReceived ) as DifferenceInDays
from [otcfunds].[FileTrack] a left Join [otcfunds].[FileTrack] b on a.RefFileTrackID = b.FileTrackID  where a.ClientCode is not null and a.[SnapshotFlag]= 'CI'
) a
-- where a.ClientCode_OUT = @ClientCode and a.FileTrackID_OUT = @FileTrackID


drop table if exists #CardBenefitLoad_CI
select * into #CardBenefitLoad_CI from (
select  '[otcfunds].[CardBenefitLoad_CI]' as TableName_otcfunds_CardBenefitLoad_CI,[CardBenefitLoadID],[MemberDataID],[ClientCode],[NHLinkID],[RecordType],[MemberDataSource],[InsCarrierID],[InsHealthPlanID],[BenefitCardNumber],[LastName],[MiddleInitial],[FirstName],[DOB],[MailingAddress1],[MailingAddress2],[MailingCity],[MailingState],[MailingZipCode],[MailingCountry],[HomePhoneNbr],[BenefitType],[BenefitSource],[NBWalletCode],[BenefitAmount],[BenefitValidFrom],[BenefitValidTo],[BenefitFreqInMonth],[BenefitYear],[BenefitPeriod],[IsActive],[RequestRecordStatus],[RequestToBeProcessed],[RequestProcessedFileID],[RequestProcessedDate],[ResponseRecordStatus],[ResponseRecordStatusCode],[ResponseProcessedFileID],[ResponseProcessedDate],[FirstTimeCardIssued],[CreateDate],[CreateUser],[ModifyDate],[ModifyUser],[RefCardBenefitLoadID],[ErrorProcessed],[Language],[DiscretionaryData1],[FourthLine],[CarrierMessage],[ClientID],[ProgramID],[SubProgramID],[PackageID],[FileGenInd],[Level1ClientID],[BenefitCardMappingID],
ROW_NUMBER () OVER (PARTITION BY [ClientCode], isnull([NHLinkID], MemberDataID) ORDER BY [ClientCode], isnull([NHLinkID], MemberDataID), [CreateDate] asc) as rn
from [otcfunds].[CardBenefitLoad_CI] 
where 1=1 
----nhlinkID is not null or 
--NHLinkID = '101546780100'
) a
where a.rn > 1


drop table if exists #FileTrackCardBenefitLoad_CI
select * into #FileTrackCardBenefitLoad_CI from (
select  a.*, b.*
from #CardBenefitLoad_CI a join #FileTrack b on a.RequestProcessedFileID = FileTrackID_OUT and a.ResponseProcessedFileID = FileTrackID_IN
-- where RN > 1
) a



-- and ClientCode = @ClientCode and InsCarrierID = @insCarrierID and InsHealthPlanID = @insHealthPlanID and RequestRecordStatus = 'SUCCESS' and ResponseRecordStatus = 'ERROR' 
-- select NHLinkID, count(*) from #CardBenefitLoad_CI group by NHLINKID order by 2 desc
-- select * from #CardBenefitLoad_CI order by rn desc

drop table if exists #ClientCodesCarriersHealthPlans
select * into #ClientCodesCarriersHealthPlans from (
select distinct 
a.ClientCode, a.ClientName,a.InsuranceCarrierID,a.InsuranceHealthPlanID as InsuranceHealthPlanID_ClientCode , a.IsActive,
--b.InsuranceCarrierID, 
b.InsuranceCarrierName, b.IsActive as IsActive_Ins,
--c.InsuranceCarrierID, 
c.InsuranceHealthPlanID, c.HealthPlanName, c.IsActive as IsActive_HealthPlan
from
elig.ClientCodes a 
left join insurance.InsuranceCarriers b on a.InsuranceCarrierID = b.InsuranceCarrierID
left join insurance.InsuranceHealthPlans c on a.InsuranceCarrierID = c.InsuranceCarrierID
where a.InsuranceCarrierID is not null and c.IsActive = 1
) a
--where  ClientCode = @ClientCode and InsuranceCarrierID= @insCarrierID and InsuranceHealthPlanID = @insHealthPlanID



drop table if exists #FileTrackClientCodesCarriersHealthPlans
select * into #FileTrackClientCodesCarriersHealthPlans from (
Select distinct a.*, b.* from 
#FileTrack a left join #ClientCodesCarriersHealthPlans b on a.ClientCode_OUT = b.ClientCode
) a
where a.SnapshotFlag_OUT = 'CI' 
--and clientCode = @ClientCode


drop table if exists #CardBenefitLoad_CI_Error
select * into #CardBenefitLoad_CI_Error from (
select distinct ClientCode as ClientCode_Error, InsCarrierID , InsHealthPlanID, try_cast(CreateDate as date) as CreateDate, RecordType, RequestRecordStatus, ResponseRecordStatus, ResponseRecordStatusCode, RequestProcessedFileID, ResponseProcessedFileID from otcfunds.CardBenefitLoad_CI 
where InsCarrierID is not null and (RequestRecordStatus = 'SUCCESS' and ResponseRecordStatus = 'ERROR'  )
-- order by ClientCode,InsCarrierID, InsHealthPlanID, 4 asc
) a
--where a.ClientCode_Error = @ClientCode and InsCarrierID = @insCarrierID and InsHealthPlanID = @insHealthPlanID


drop table if exists #CardBenefitLoad_CI_Error_Report
select * into #CardBenefitLoad_CI_Error_Report from (
select distinct
a.ClientCode_Error as ClientCode_Error1 , a.InsCarrierID as InsCarrierID_Error, a.InsHealthPlanID as InsHealthPlanID_Error, FileName_OUT as FileName_OUT1, FileName_IN as FileName_IN1, FileTrackID_OUT as FileTrackID_OUT1, a.CreateDate as CreateDate_ERROR, DATEDIFF(DAY, a.CreateDate, b.CreateDate_OUT) as DifferenceInDaysCIandOUT, b.CreateDate_OUT as CreateDate_Out1, b.CreateDate_IN as CreateDate_IN1, DifferenceInDays as DifferenceInDays1,
a.* , b.* from
#CardBenefitLoad_CI_Error a left join #FileTrackClientCodesCarriersHealthPlans b
on a.ClientCode_Error = b.ClientCode and a.InsCarrierID = b.InsuranceCarrierID and a.InsHealthPlanID = b.InsuranceHealthPlanID and a.CreateDate < b.CreateDate_OUT and b.CreateDate_OUT < b.CreateDate_IN
where a.CreateDate <= CreateDate_OUT and CreateDate_OUT <= CreateDate_IN and FileTrackID_OUT = RequestProcessedFileID and FileTrackID_IN = ResponseProcessedFileID
-- order by  a.ClientCode_Error, b.FileTrackID_OUT,  a.CreateDate, b.CreateDate_OUT, b.CreateDate_IN,b.FileName_Out
) a
--where a.ClientCode = @ClientCode and InsCarrierID = @insCarrierID and InsHealthPlanID = @insHealthPlanID and RequestRecordStatus = 'SUCCESS' and ResponseRecordStatus = 'ERROR' 



select * from #FileTrack
select * from #CardBenefitLoad_CI
select * from #ClientCodesCarriersHealthPlans
select * from #FileTrackClientCodesCarriersHealthPlans
select * from #CardBenefitLoad_CI_Error order by ClientCode_Error, CreateDate
select * from #CardBenefitLoad_CI_Error_Report order by ClientCode_Error, CreateDate

/*

declare @ClientCode varchar(50) = 'H438_500K'
declare @insCarrierID varchar(50) = '16'
declare @insHealthPlanID varchar(50) = '5666'
declare @FileTrackID varchar(50) = '9926'


select 
distinct ClientCode as ClientCode_Error, InsCarrierID , InsHealthPlanID, try_cast(CreateDate as date) as CreateDate, 
RecordType, RequestRecordStatus, ResponseRecordStatus, ResponseRecordStatusCode, * from otcfunds.CardBenefitLoad_CI 
where ClientCode = @ClientCode and InsCarrierID = @insCarrierID and InsHealthPlanID = @insHealthPlanID
and RequestRecordStatus = 'SUCCESS' and ResponseRecordStatus = 'ERROR' order by 4, NHLInkID


*/
/*
select FileName_OUT, Count(*) as rc from #CardBenefitLoad_CI_Error_Report group by FileName_OUT having count(*) > 1 order by 2 desc 
select * from #CardBenefitLoad_CI_Error_Report where FileName_OUT = 'CI2213441214202201.txt'

declare @ClientCode varchar(50) = 'H438_500K'
declare @insCarrierID varchar(50) = '16'
declare @insHealthPlanID varchar(50) = '5666'
declare @FileTrackID varchar(50) = '9926'


select * from otcfunds.CardBenefitLoad_CI where ClientCode = @ClientCode and InsCarrierID = @insCarrierID and InsHealthPlanID = @insHealthPlanID and RequestRecordStatus = 'SUCCESS' and ResponseRecordStatus = 'ERROR' 
select * from [otcfunds].[FileTrack] where ClientCode = @ClientCode and FileTrackID = @FileTrackID
select * from elig.ClientCodes where ClientCode = @ClientCode
select * from insurance.InsuranceCarriers where InsuranceCarrierID = @insCarrierID
select * from insurance.InsuranceHealthPlans where InsuranceHealthPlanID = @insHealthPlanID
select * from otcfunds.CardBenefitLoad_CI where RequestRecordStatus = 'SUCCESS' and ResponseRecordStatus = 'ERROR' and InsCarrierID = @insCarrierID and InsHealthPlanID = @insHealthPlanID
*/

/*
ClientCode_Error1	InsCarrierID_Error	InsHealthPlanID_Error	FileName_OUT1	FileName_IN1	FileTrackID_OUT1	CreateDate_ERROR	DifferenceInDaysCIandOUT	CreateDate_Out1	CreateDate_IN1	DifferenceInDays1	ClientCode_Error	InsCarrierID	InsHealthPlanID	CreateDate	RecordType	RequestRecordStatus	ResponseRecordStatus	ResponseRecordStatusCode	TableNameFileTrack_OUT	FileTrackID_OUT	FileInfoID_OUT	ClientCode_OUT	DirectionCode_OUT	FileName_OUT	FileFormat_OUT	FileType_OUT	DataSource_OUT	DateReceived_OUT	DateProcessed_OUT	TotalRecords_OUT	RecordsProcessed_OUT	RecordsErrored_OUT	LoadStartTime_OUT	LoadEndTime_OUT	StatusCode_OUT	CreateDate_OUT	CreateUser_OUT	ModifyDate_OUT	ModifyUser_OUT	RefFileTrackID_OUT	SnapshotFlag_OUT	TableNameFileTrack_IN	FileTrackID_IN	FileInfoID_IN	ClientCode_IN	DirectionCode_IN	FileName_IN	FileFormat_IN	FileType_IN	DataSource_IN	DateReceived_IN	DateProcessed_IN	TotalRecords_IN	RecordsProcessed_IN	RecordsErrored_IN	LoadStartTime_IN	LoadEndTime_IN	StatusCode_IN	CreateDate_IN	CreateUser_IN	ModifyDate_IN	ModifyUser_IN	RefFileTrackID_IN	SnapshotFlag_IN	DifferenceInDays	ClientCode	ClientName	InsuranceCarrierID	InsuranceHealthPlanID_ClientCode	IsActive	InsuranceCarrierName	IsActive_Ins	InsuranceHealthPlanID	HealthPlanName	IsActive_HealthPlan
H438_500K	16	5666	CI2213441214202201.txt	CI2213441214202201.log.pgp	9926	2022-12-15	0	2022-12-15 03:13:44.453	2022-12-15 07:26:16.597	0	H438_500K	16	5666	2022-12-15	CI	SUCCESS	ERROR	14	[otcfunds].[FileTrack][OUT]	9926	219	H438_500K	OUT	CI2213441214202201.txt	Fixed Width	FLEX	Aetna_500K	NULL	NULL	0	0	0	NULL	NULL	999	2022-12-15 03:13:44.453	appuser	2022-12-15 02:27:25.083	appuser	9935	CI	[otcfunds].[FileTrack][IN}	9935	104	NULL	IN	CI2213441214202201.log.pgp	Fixed Width	FLEX	NULL	2022-12-15 07:26:16.597	NULL	0	0	0	NULL	NULL	999	2022-12-15 07:26:16.597	appuser	2022-12-15 07:26:16.597	appuser	NULL	CI	0	H438_500K	Aetna_500K	16	NULL	1	Aetna	1	5666	Aetna Flex 22 $100	1
*/
/*
FileName_OUT	rc
CI0809060905202101.txt	16
CI1641151129202101.txt	16
CI1703560908202101.txt	16
CI1839151019202101.txt	16
CI1942311110202101.txt	16
CI2213441214202201.txt	10
CI2308281219202201.txt	10
CI0813511219202201.txt	10
CI0814041219202201.txt	10
CI0814191219202201.txt	10
CI0814321219202201.txt	10
CI0814451219202201.txt	10
CI0814571219202201.txt	10
CI0815101219202201.txt	10
CI0815241219202201.txt	10
CI0815341219202201.txt	10
CI0815471219202201.txt	10
CI0815591219202201.txt	10
CI0816121219202201.txt	10
CI0816221219202201.txt	10
CI0816351219202201.txt	10
CI0816451219202201.txt	10
CI0816571219202201.txt	10
CI0817091219202201.txt	10
CI0817201219202201.txt	10
CI0817301219202201.txt	10
CI0817411219202201.txt	10
CI0817521219202201.txt	10
CI0818041219202201.txt	10
CI0818151219202201.txt	10
CI0818241219202201.txt	10
CI0818321219202201.txt	10
CI0818451219202201.txt	10
CI0818561219202201.txt	10
CI0819041219202201.txt	10
CI0819141219202201.txt	10
CI0956101204202201.txt	9
CI1949091205202201.txt	9
CI1759061202202201.txt	9
CI2256441107202201.txt	7
CI2307161107202201.txt	7
CI1031311005202201.txt	2
CI1303391005202201.txt	2
CI1356251005202201.txt	2
CI1358001005202201.txt	2
CI1400431005202201.txt	2
CI1403141005202201.txt	2
CI1406551005202201.txt	2
CI1410181005202201.txt	2
CI1413501005202201.txt	2
CI1417401005202201.txt	2
CI1534521005202201.txt	2
CI1536261005202201.txt	2
CI1550261005202201.txt	2
CI1553071005202201.txt	2
CI1620551005202201.txt	2



select * from otcfunds.Filetrack where FileName = 'CI2213441214202201.txt'
*/