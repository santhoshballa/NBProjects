alter procedure [dbo].[sp_FileTrackCardBenefitReport]
/*
exec [dbo].[sp_FileTrackCardBenefitReport] 'CI',NULL, NULL,'NH202005650528'
exec [dbo].[sp_FileTrackCardBenefitReport] 'FD',NULL, NULL,'NH202005650528'
exec [dbo].[sp_FileTrackCardBenefitReport] 'CI',302, 2694,NULL
exec [dbo].[sp_FileTrackCardBenefitReport] 'FD',302, 2694,NULL

Author		| Santhosh Balla
Description | Provides an audit report for records sent to FIS for Card Iniitated and Fund Disbursement
Execution	| The procedure takes in the Snapshot flag, InsuranceCarrierID and InsuranceHealthPlanID and the NHMemberID. The snapshot flag is required and other are optional (NULL's)
Date		| Dec 2022
*/


(
@SnapshotFlag varchar(20), 
@InsuranceCarrierID int, 
@InsuranceHealthPlanID int, 
@NHMemberID varchar(20)
)
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
SET NOCOUNT ON
SET XACT_ABORT ON

BEGIN TRY

declare @vWhereCondition varchar(1000) = ''
declare @vSnapshotFlag varchar(20) = '' 
declare @vInsuranceCarrierID int
declare @vInsuranceHealthPlanID int
declare @vNHMemberID varchar(20) = ''
declare @vSQL nvarchar(4000) = ''

set @vSnapshotFlag = @SnapshotFlag
set @vInsuranceCarrierID = @InsuranceCarrierID
set @vInsuranceHealthPlanID = @InsuranceHealthPlanID
set @vNHMemberID = @NHMemberID

if @vSnapshotFlag = 'CI' or  @vSnapshotFlag = 'FD'
	begin
		if @vInsuranceCarrierID is not null and @vInsuranceCarrierID <> ''
			begin
			set @vWhereCondition = 'insCarrierID ' + ' = ' + cast(@vInsuranceCarrierID as varchar) + ' and '
			select @vWhereCondition
			end
		if @vInsuranceHealthPlanID is not null and @vInsuranceHealthPlanID <> ''
			begin
			set @vWhereCondition = @vWhereCondition + 'insHealthPlanId ' + ' = ' + cast(@vInsuranceHealthPlanID as varchar) + ' and '
			select @vWhereCondition
			end
		if @vNHMemberID is not null and @vNHMemberID <> ''
			begin
			set @vWhereCondition = @vWhereCondition + 'NHLinkID ' + ' = ' + ''''+ (select top 1 cast(isnull(NHLInkID, '') as varchar)+'''' from Master.Members where NHMemberID = @vNHMemberID and  isActive =1) + ' and '
			select @vWhereCondition
		end
	end

if @vWhereCondition is null or @vWhereCondition = ''
	begin
	set  @vWhereCondition = isnull(@vWhereCondition, '2=2 and ')
	end

if @vSnapshotFlag = 'CI'
	begin 

		drop table if exists #FileTrack_CI
		select * into #FileTrack_CI from (
		select
		'[otcfunds].[FileTrack][OUT]' as TableNameFileTrack_OUT,a.[FileTrackID] as FileTrackID_OUT,a.[FileInfoID] as FileInfoID_OUT,a.[ClientCode] as ClientCode_OUT,a.[DirectionCode] as DirectionCode_OUT,a.[FileName] as FileName_OUT,a.[FileFormat] as FileFormat_OUT,a.[FileType] as FileType_OUT,a.[DataSource] as DataSource_OUT,a.[DateReceived] as DateReceived_OUT,a.[DateProcessed] as DateProcessed_OUT,a.[TotalRecords] as TotalRecords_OUT,a.[RecordsProcessed] as RecordsProcessed_OUT,a.[RecordsErrored] as RecordsErrored_OUT,a.[LoadStartTime] as LoadStartTime_OUT,a.[LoadEndTime] as LoadEndTime_OUT,a.[StatusCode] as StatusCode_OUT,a.[CreateDate] as CreateDate_OUT,a.[CreateUser] as CreateUser_OUT,a.[ModifyDate] as ModifyDate_OUT,a.[ModifyUser] as ModifyUser_OUT,a.[RefFileTrackID] as RefFileTrackID_OUT,a.[SnapshotFlag] as SnapshotFlag_OUT, 
		'[otcfunds].[FileTrack][IN]'  as TableNameFileTrack_IN, b.[FileTrackID] as FileTrackID_IN,b.[FileInfoID] as FileInfoID_IN,b.[ClientCode] as ClientCode_IN,b.[DirectionCode] as DirectionCode_IN,b.[FileName] as FileName_IN,b.[FileFormat] as FileFormat_IN,b.[FileType] as FileType_IN,b.[DataSource] as DataSource_IN,b.[DateReceived] as DateReceived_IN,b.[DateProcessed] as DateProcessed_IN,b.[TotalRecords] as TotalRecords_IN,b.[RecordsProcessed] as RecordsProcessed_IN,b.[RecordsErrored] as RecordsErrored_IN,b.[LoadStartTime] as LoadStartTime_IN,b.[LoadEndTime] as LoadEndTime_IN,b.[StatusCode] as StatusCode_IN,b.[CreateDate] as CreateDate_IN,b.[CreateUser] as CreateUser_IN,b.[ModifyDate] as ModifyDate_IN,b.[ModifyUser] as ModifyUser_IN,b.[RefFileTrackID] as RefFileTrackID_IN,b.[SnapshotFlag] as SnapshotFlag_IN,
		--(b.DateReceived - a.CreateDate) as DifferenceDate
		DATEDIFF(DAY, a.CreateDate,b.DateReceived ) as DifferenceInDays
		from [otcfunds].[FileTrack] a left Join [otcfunds].[FileTrack] b on a.RefFileTrackID = b.FileTrackID  where a.ClientCode is not null and a.[SnapshotFlag]= @vSnapshotFlag
		) a

		drop table if exists #CardBenefitLoad_CI
		select * into #CardBenefitLoad_CI from (
		select  '[otcfunds].[CardBenefitLoad_CI]' as TableName_otcfunds_CardBenefitLoad_CI,[CardBenefitLoadID],[MemberDataID],[ClientCode],[NHLinkID],[RecordType],[MemberDataSource],[InsCarrierID],[InsHealthPlanID],[BenefitCardNumber],[LastName],[MiddleInitial],[FirstName],[DOB],[MailingAddress1],[MailingAddress2],[MailingCity],[MailingState],[MailingZipCode],[MailingCountry],[HomePhoneNbr],[BenefitType],[BenefitSource],[NBWalletCode],[BenefitAmount],[BenefitValidFrom],[BenefitValidTo],[BenefitFreqInMonth],[BenefitYear],[BenefitPeriod],[IsActive],[RequestRecordStatus],[RequestToBeProcessed],[RequestProcessedFileID],[RequestProcessedDate],[ResponseRecordStatus],[ResponseRecordStatusCode],[ResponseProcessedFileID],[ResponseProcessedDate],[FirstTimeCardIssued],[CreateDate],[CreateUser],[ModifyDate],[ModifyUser],[RefCardBenefitLoadID],[ErrorProcessed],[Language],[DiscretionaryData1],[FourthLine],[CarrierMessage],[ClientID],[ProgramID],[SubProgramID],[PackageID],[FileGenInd],[Level1ClientID],[BenefitCardMappingID],
		ROW_NUMBER () OVER (PARTITION BY [ClientCode], isnull([NHLinkID], MemberDataID) ORDER BY [ClientCode], isnull([NHLinkID], MemberDataID), [CreateDate] asc) as rn
		from [otcfunds].[CardBenefitLoad_CI] 
		where 1=1 
		) a

		drop table if exists #FileTrackCardBenefitLoad_CI
		select * into #FileTrackCardBenefitLoad_CI from (
		select  a.*, b.*
		from #CardBenefitLoad_CI a join #FileTrack_CI b on a.RequestProcessedFileID = FileTrackID_OUT and a.ResponseProcessedFileID = FileTrackID_IN
		where RN > 0
		--and (RequestRecordStatus = 'SUCCESS' and ResponseRecordStatus = 'ERROR') 
		) a

		select @vSQL = 'select SnapshotFlag_OUT, a.ClientCode,
		ClientName = (select ClientName from elig.ClientCodes b where b.ClientCode = a.ClientCode),
		NHLinkID, 
		insCarrierID,
		InsCarrierName = (select InsuranceCarrierName from insurance.InsuranceCarriers b where b.InsuranceCarrierID = a.InsCarrierID), 
		InsHealthPlanID, 
		InsHealthPlanName = (select HealthPlanName from insurance.InsuranceHealthPlans b where b.InsuranceHealthPlanID = a.InsHealthPlanID), 
		IsActive, DirectionCode_OUT, FileName_OUT, DirectionCode_IN, FileName_IN,RequestRecordStatus, ResponseRecordStatus, ResponseRecordStatusCode, rn as NoOfTimesSent,
		CreateDate as CIRecordCreateDate, CreateDate_OUT as ToFISDateSent, DateReceived_IN FromFISDateReceived, DIfferenceInDays as DifferenceInDaysFISRequestResponse,
		RequestProcessedDate, ResponseProcessedDate, DATEDIFF(DAY, RequestProcessedDate,ResponseProcessedDate ) as DifferenceInDaysProcessedDateRequestResponse

		from #FileTrackCardBenefitLoad_CI a
		where 1 = 1 and ' + @vWhereCondition + '3 = 3 order by NHLInkID, NoOfTimesSent'

		select 2, @vSQL
		EXEC sp_executesql @vSQL;
	end

if @vSnapshotFlag = 'FD'
begin
	
	drop table if exists #FileTrack_FD
	select * into #FileTrack_FD from (
	select
	'[otcfunds].[FileTrack][OUT]' as TableNameFileTrack_OUT,a.[FileTrackID] as FileTrackID_OUT,a.[FileInfoID] as FileInfoID_OUT,a.[ClientCode] as ClientCode_OUT,a.[DirectionCode] as DirectionCode_OUT,a.[FileName] as FileName_OUT,a.[FileFormat] as FileFormat_OUT,a.[FileType] as FileType_OUT,a.[DataSource] as DataSource_OUT,a.[DateReceived] as DateReceived_OUT,a.[DateProcessed] as DateProcessed_OUT,a.[TotalRecords] as TotalRecords_OUT,a.[RecordsProcessed] as RecordsProcessed_OUT,a.[RecordsErrored] as RecordsErrored_OUT,a.[LoadStartTime] as LoadStartTime_OUT,a.[LoadEndTime] as LoadEndTime_OUT,a.[StatusCode] as StatusCode_OUT,a.[CreateDate] as CreateDate_OUT,a.[CreateUser] as CreateUser_OUT,a.[ModifyDate] as ModifyDate_OUT,a.[ModifyUser] as ModifyUser_OUT,a.[RefFileTrackID] as RefFileTrackID_OUT,a.[SnapshotFlag] as SnapshotFlag_OUT, 
	'[otcfunds].[FileTrack][IN]'  as TableNameFileTrack_IN, b.[FileTrackID] as FileTrackID_IN,b.[FileInfoID] as FileInfoID_IN,b.[ClientCode] as ClientCode_IN,b.[DirectionCode] as DirectionCode_IN,b.[FileName] as FileName_IN,b.[FileFormat] as FileFormat_IN,b.[FileType] as FileType_IN,b.[DataSource] as DataSource_IN,b.[DateReceived] as DateReceived_IN,b.[DateProcessed] as DateProcessed_IN,b.[TotalRecords] as TotalRecords_IN,b.[RecordsProcessed] as RecordsProcessed_IN,b.[RecordsErrored] as RecordsErrored_IN,b.[LoadStartTime] as LoadStartTime_IN,b.[LoadEndTime] as LoadEndTime_IN,b.[StatusCode] as StatusCode_IN,b.[CreateDate] as CreateDate_IN,b.[CreateUser] as CreateUser_IN,b.[ModifyDate] as ModifyDate_IN,b.[ModifyUser] as ModifyUser_IN,b.[RefFileTrackID] as RefFileTrackID_IN,b.[SnapshotFlag] as SnapshotFlag_IN,
	--(b.DateReceived - a.CreateDate) as DifferenceDate
	DATEDIFF(DAY, a.CreateDate,b.DateReceived ) as DifferenceInDays
	from [otcfunds].[FileTrack] a left Join [otcfunds].[FileTrack] b on a.RefFileTrackID = b.FileTrackID  where a.ClientCode is not null and a.[SnapshotFlag]= @vSnapshotFlag
	) a

	drop table if exists #CardBenefitLoad_FD
	select * into #CardBenefitLoad_FD from (
	select  '[otcfunds].[CardBenefitLoad_FD]' as TableName_otcfunds_CardBenefitLoad_FD,[CardBenefitLoadID],[MemberDataID],[ClientCode],[NHLinkID],[RecordType],[MemberDataSource],[InsCarrierID],[InsHealthPlanID],[BenefitCardNumber],[LastName],[MiddleInitial],[FirstName],[DOB],[MailingAddress1],[MailingAddress2],[MailingCity],[MailingState],[MailingZipCode],[MailingCountry],[HomePhoneNbr],[BenefitType],[BenefitSource],[NBWalletCode],[BenefitAmount],[BenefitValidFrom],[BenefitValidTo],[BenefitFreqInMonth],[BenefitYear],[BenefitPeriod],[IsActive],[RequestRecordStatus],[RequestToBeProcessed],[RequestProcessedFileID],[RequestProcessedDate],[ResponseRecordStatus],[ResponseRecordStatusCode],[ResponseProcessedFileID],[ResponseProcessedDate],[FirstTimeCardIssued],[CreateDate],[CreateUser],[ModifyDate],[ModifyUser],[RefCardBenefitLoadID],[ErrorProcessed],[Language],[MemberDataSourceFile],[Level1ClientID],[ClientID],[SubProgramID],[PackageID],[FIS_PurseSlot],
	ROW_NUMBER () OVER (PARTITION BY [ClientCode], isnull([NHLinkID], MemberDataID) ORDER BY [ClientCode], isnull([NHLinkID], MemberDataID), [CreateDate] asc) as rn
	from [otcfunds].[CardBenefitLoad_FD] 
	where 1=1 
	) a

	drop table if exists #FileTrackCardBenefitLoad_FD
	select * into #FileTrackCardBenefitLoad_FD from (
	select  a.*, b.*
	from #CardBenefitLoad_FD a join #FileTrack_FD b on a.RequestProcessedFileID = FileTrackID_OUT and a.ResponseProcessedFileID = FileTrackID_IN
	where RN > 0
	-- and (RequestRecordStatus = 'SUCCESS' and ResponseRecordStatus = 'ERROR') 
	) a

	select @vSQL = 'select SnapshotFlag_OUT, ClientCode, 
	ClientName = (select ClientName from elig.ClientCodes b where b.ClientCode = a.ClientCode),
	NHLinkID, 
	insCarrierID,
	InsCarrierName = (select InsuranceCarrierName from insurance.InsuranceCarriers b where b.InsuranceCarrierID = a.InsCarrierID), 
	InsHealthPlanID, 
	InsHealthPlanName = (select HealthPlanName from insurance.InsuranceHealthPlans b where b.InsuranceHealthPlanID = a.InsHealthPlanID), 
	IsActive, DirectionCode_OUT, FileName_OUT, DirectionCode_IN, FileName_IN, RequestRecordStatus, ResponseRecordStatus,ResponseRecordStatusCode, rn as NoOfTimesSent,
	CreateDate as CIRecordCreateDate, CreateDate_OUT as ToFISDateSent, DateReceived_IN FromFISDateReceived, DIfferenceInDays as DifferenceInDaysFISRequestResponse,
	RequestProcessedDate, ResponseProcessedDate, DATEDIFF(DAY, RequestProcessedDate,ResponseProcessedDate ) as DifferenceInDaysProcessedDateRequestResponse,
	BenefitType, BenefitSource, NBWalletCode, BenefitAmount, BenefitValidFrom, BenefitValidTo, BenefitFreqInMonth, BenefitYear, IsActive as IsActive_Benefit
	from #FileTrackCardBenefitLoad_FD a
	where 1 = 1 and ' + @vWhereCondition + ' 3 = 3 order by NHLInkID, NoOfTimesSent'

	select 3, @vSQL
	EXEC sp_executesql @vSQL;

end




/*
select SnapshotFlag_OUT,ClientCode,NHLinkID, ClientID,  InsCarrierID, InsHealthPlanID, IsActive, RequestRecordStatus, ResponseRecordStatus ResponseRecordCode, rn as NoOfTimesSent, CreateDate, CreateDate_OUT, DateReceived_IN, DIfferenceInDays from #FileTrackCardBenefitLoad_CI
where 1 = 1 
and (RequestRecordStatus = 'SUCCESS' and ResponseRecordStatus = 'ERROR') 
and NHLinkID = '00000103561'
order by NHLInkID, NoOfTimesSent

select SnapshotFlag_OUT, ClientCode, NHLinkID, InsCarrierID, InsHealthPlanID, IsActive, RequestRecordStatus, ResponseRecordStatus, rn as NoOfTimesSent,CreateDate, CreateDate_OUT, DateReceived_IN, DIfferenceInDays from #FileTrackCardBenefitLoad_FD
where 1 = 1 
and (RequestRecordStatus = 'SUCCESS' and ResponseRecordStatus = 'ERROR')
and NHLinkID = '00000103561'
order by NHLInkID, NoOfTimesSent


select SnapshotFlag_OUT,ClientCode,NHLinkID, ClientID,  InsCarrierID, InsHealthPlanID, IsActive, RequestRecordStatus, ResponseRecordStatus ResponseRecordCode, rn as NoOfTimesSent, CreateDate, CreateDate_OUT, DateReceived_IN, DIfferenceInDays from #FileTrackCardBenefitLoad_CI
where 1 = 1 
and (RequestRecordStatus = 'SUCCESS' and ResponseRecordStatus = 'ERROR') 
order by NHLInkID, NoOfTimesSent

select SnapshotFlag_OUT, ClientCode, NHLinkID, InsCarrierID, InsHealthPlanID, IsActive, RequestRecordStatus, ResponseRecordStatus, rn as NoOfTimesSent,CreateDate, CreateDate_OUT, DateReceived_IN, DIfferenceInDays from #FileTrackCardBenefitLoad_FD
where 1 = 1 
and (RequestRecordStatus = 'SUCCESS' and ResponseRecordStatus = 'ERROR')
order by NHLInkID, NoOfTimesSent



-- zero records
select SnapshotFlag_OUT,ClientCode,NHLinkID, ClientID,  InsCarrierID, InsHealthPlanID, IsActive, DirectionCode_OUT, FileName_OUT, DirectionCode_IN, FileName_IN,RequestRecordStatus, ResponseRecordStatus ResponseRecordCode, rn as NoOfTimesSent, CreateDate, CreateDate_OUT, DateReceived_IN, DIfferenceInDays from #FileTrackCardBenefitLoad_CI
where 1 = 1 
and (ResponseRecordStatus is NULL or ResponseRecordStatus = '') 
order by NHLInkID, NoOfTimesSent

select SnapshotFlag_IN, ClientCode, NHLinkID, InsCarrierID, InsHealthPlanID, IsActive, DirectionCode_OUT, FileName_OUT, DirectionCode_IN, FileName_IN, RequestRecordStatus, ResponseRecordStatus, rn as NoOfTimesSent,CreateDate, CreateDate_OUT, DateReceived_IN, DIfferenceInDays from #FileTrackCardBenefitLoad_FD
where 1 = 1 
and (ResponseRecordStatus is NULL or ResponseRecordStatus = '') 
order by NHLInkID, NoOfTimesSent


--zero records
select SnapshotFlag_OUT,ClientCode,NHLinkID, ClientID,  InsCarrierID, InsHealthPlanID, IsActive, RequestRecordStatus, ResponseRecordStatus ResponseRecordCode, rn as NoOfTimesSent, CreateDate, CreateDate_OUT, DateReceived_IN, DIfferenceInDays from #FileTrackCardBenefitLoad_CI
where 1 = 1 
and (RequestRecordStatus = '' and ResponseRecordStatus = 'ERROR') 
order by NHLInkID, NoOfTimesSent

select SnapshotFlag_IN, ClientCode, NHLinkID, InsCarrierID, InsHealthPlanID, IsActive, RequestRecordStatus, ResponseRecordStatus, rn as NoOfTimesSent,CreateDate, CreateDate_OUT, DateReceived_IN, DIfferenceInDays from #FileTrackCardBenefitLoad_FD
where 1 = 1 
and (RequestRecordStatus ='' and ResponseRecordStatus = 'ERROR')
order by NHLInkID, NoOfTimesSent


-- Zero Records 
select SnapshotFlag_OUT,ClientCode,NHLinkID, ClientID,  InsCarrierID, InsHealthPlanID, IsActive, RequestRecordStatus, ResponseRecordStatus ResponseRecordCode, rn as NoOfTimesSent, CreateDate, CreateDate_OUT, DateReceived_IN, DIfferenceInDays from #FileTrackCardBenefitLoad_CI
where 1 = 1 
and (isnull(RequestRecordStatus,'') = '' and ResponseRecordStatus = 'ERROR') 
order by NHLInkID, NoOfTimesSent

select SnapshotFlag_IN, ClientCode, NHLinkID, InsCarrierID, InsHealthPlanID, IsActive, RequestRecordStatus, ResponseRecordStatus, rn as NoOfTimesSent,CreateDate, CreateDate_OUT, DateReceived_IN, DIfferenceInDays from #FileTrackCardBenefitLoad_FD
where 1 = 1 
and (isnull(RequestRecordStatus,'') = '' and ResponseRecordStatus = 'ERROR')
order by NHLInkID, NoOfTimesSent

-- Zero Records 
select SnapshotFlag_OUT,ClientCode,NHLinkID, ClientID,  InsCarrierID, InsHealthPlanID, IsActive, RequestRecordStatus, ResponseRecordStatus ResponseRecordCode, rn as NoOfTimesSent, CreateDate, CreateDate_OUT, DateReceived_IN, DIfferenceInDays from #FileTrackCardBenefitLoad_CI
where 1 = 1 
and (RequestRecordStatus is NULL and ResponseRecordStatus = 'ERROR') 
order by NHLInkID, NoOfTimesSent

select SnapshotFlag_IN, ClientCode, NHLinkID, InsCarrierID, InsHealthPlanID, IsActive, RequestRecordStatus, ResponseRecordStatus, rn as NoOfTimesSent,CreateDate, CreateDate_OUT, DateReceived_IN, DIfferenceInDays from #FileTrackCardBenefitLoad_FD
where 1 = 1 
and (RequestRecordStatus is NULL and ResponseRecordStatus = 'ERROR')
order by NHLInkID, NoOfTimesSent

--should get zero records
select SnapshotFlag_OUT,ClientCode,NHLinkID, ClientID,  InsCarrierID, InsHealthPlanID, IsActive, RequestRecordStatus, ResponseRecordStatus ResponseRecordCode, rn as NoOfTimesSent, CreateDate, CreateDate_OUT, DateReceived_IN, DIfferenceInDays from #FileTrackCardBenefitLoad_CI
where 1 = 1 
and (RequestRecordStatus = 'ERROR' and ResponseRecordStatus = 'ERROR') 
order by NHLInkID, NoOfTimesSent

select SnapshotFlag_IN, ClientCode, NHLinkID, InsCarrierID, InsHealthPlanID, IsActive, RequestRecordStatus, ResponseRecordStatus, rn as NoOfTimesSent,CreateDate, CreateDate_OUT, DateReceived_IN, DIfferenceInDays from #FileTrackCardBenefitLoad_FD
where 1 = 1 
and (RequestRecordStatus = 'ERROR' and ResponseRecordStatus = 'ERROR')
order by NHLInkID, NoOfTimesSent

-- should get zero records
select SnapshotFlag_OUT,ClientCode,NHLinkID, ClientID,  InsCarrierID, InsHealthPlanID, IsActive, RequestRecordStatus, ResponseRecordStatus ResponseRecordCode, rn as NoOfTimesSent, CreateDate, CreateDate_OUT, DateReceived_IN, DIfferenceInDays from #FileTrackCardBenefitLoad_CI
where 1 = 1 
and (RequestRecordStatus = 'ERROR' and ResponseRecordStatus = 'SUCCESS') 
order by NHLInkID, NoOfTimesSent

select SnapshotFlag_IN, ClientCode, NHLinkID, InsCarrierID, InsHealthPlanID, IsActive, RequestRecordStatus, ResponseRecordStatus, rn as NoOfTimesSent,CreateDate, CreateDate_OUT, DateReceived_IN, DIfferenceInDays from #FileTrackCardBenefitLoad_FD
where 1 = 1 
and (RequestRecordStatus = 'ERROR' and ResponseRecordStatus = 'SUCCESS')
order by NHLInkID, NoOfTimesSent
*/

 

END TRY

BEGIN CATCH
		IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'Logs' AND TABLE_SCHEMA = N'dbo')
				CREATE TABLE Logs
				(
				ERROR_PROCEDURE_NAME nvarchar(200),
				ERROR_NUMBER nvarchar(200), 
				ERROR_SEVERITY nvarchar(200), 
				ERROR_STATE nvarchar(200), 
				ERROR_PROCEDURE nvarchar(200), 
				ERROR_LINE nvarchar(200), 
				ERROR_MESSAGE nvarchar(200),
				ERROR_DATE datetime default CURRENT_TIMESTAMP
				)

		INSERT INTO Logs (ERROR_PROCEDURE_NAME,ERROR_NUMBER, ERROR_SEVERITY, ERROR_STATE, ERROR_PROCEDURE, ERROR_LINE, ERROR_MESSAGE) 
		VALUES ('dbo.sp_FileTrackCardBenefitLoadReport', ERROR_NUMBER(),ERROR_SEVERITY(),ERROR_STATE(),ERROR_PROCEDURE(),ERROR_LINE(),ERROR_MESSAGE())
		END CATCH

END
GO