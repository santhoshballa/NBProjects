select top 10 * from otcfunds.CardBenefitLoad_CI where ResponseRecordStatus = 'Error'
select * from otcfunds.CardBenefitLoad_CI where ResponseRecordStatus = 'Error'
select distinct ClientCode from otcfunds.CardBenefitLoad_CI
select distinct insCarrierID from otcfunds.CardBenefitLoad_CI where insCarrierID is not null-- all carriers

-- Insurance Carriers and Health Plans that have are sent to FIS for Card initiated
select
ins.InsuranceCarrierID, ins.InsuranceCarrierName, ihp.InsuranceHealthPlanID, ihp.HealthPlanName
from Insurance.InsuranceHealthPlans ihp left join insurance.InsuranceCarriers ins on ihp.InsuranceCarrierID = ins.InsuranceCarrierID
where ins.InsuranceCarrierID in (select distinct insCarrierID from otcfunds.CardBenefitLoad_CI)
and ihp.InsuranceHealthPlanID in (select distinct insHealthPlanId from otcfunds.CardBenefitLoad_CI)



select * from elig.mstrEligBenefitData where insCarrierID in (select distinct insCarrierID from otcfunds.CardBenefitLoad_CI) and IsActive =1 and getdate between RecordEffDate and RecordEndDate

select NHLinkID, Count(*) rc from otcfunds.CardBenefitLoad_CI group by NHLinkID order by 2 desc

Select * from otcfunds.CardBenefitLoad_CI  where NHLinkID = '00000120517'
select * from elig.mstrEligBenefitData where NHlinkID = '00000120517' and IsActive =1

-- All Cards Initiated and sent to FIS
select insCarrierID as CI_insCarrierID, 
InsuranceCarrierName = (select InsuranceCarrierName from insurance.InsuranceCarriers where otcfunds.CardBenefitLoad_CI.insCarrierID = insurance.InsuranceCarriers.InsuranceCarrierID)
,InsHealthPlanID as CI_InsHealthPlanID
,InsuranceHealthPlanName = (select HealthPlanName from insurance.InsuranceHealthPlans where otcfunds.CardBenefitLoad_CI.InsHealthPlanID = insurance.InsuranceHealthPlans.InsuranceHealthPlanID)


,RequestRecordStatus as CI_RequestRecordStatus, ResponseRecordStatus as CI_ResponseRecordStatus,
--BenefitValidFrom,
--BenefitValidTo,
--BenefitFreqInMonth,
--BenefitYear,
--BenefitPeriod,

Count(*) as CI_NumberOfRecords from  otcfunds.CardBenefitLoad_CI 
group by insCarrierID, InsHealthPlanID, RequestRecordStatus, ResponseRecordStatus
--,BenefitValidFrom,BenefitValidTo,BenefitFreqInMonth,BenefitYear,BenefitPeriod
Order by RequestRecordStatus, ResponseRecordStatus,insCarrierID, InsHealthPlanID


-- All Funds Added and sent to FIS
select insCarrierID as FD_insCarrierID, 
InsuranceCarrierName = (select InsuranceCarrierName from insurance.InsuranceCarriers where otcfunds.CardBenefitLoad_FD.insCarrierID = insurance.InsuranceCarriers.InsuranceCarrierID)
,InsHealthPlanID as FD_InsHealthPlanID
,InsuranceHealthPlanName = (select HealthPlanName from insurance.InsuranceHealthPlans where otcfunds.CardBenefitLoad_FD.InsHealthPlanID = insurance.InsuranceHealthPlans.InsuranceHealthPlanID)
,RequestRecordStatus as FD_RequestRecordStatus, ResponseRecordStatus as FD_ResponseRecordStatus, 

BenefitValidFrom,
BenefitValidTo,
BenefitFreqInMonth,
BenefitYear,
BenefitPeriod,

Count(*) as FD_NoOfRecords from  otcfunds.CardBenefitLoad_FD
where getdate() between BenefitValidFrom and BenefitValidTo
group by insCarrierID, InsHealthPlanID, RequestRecordStatus, ResponseRecordStatus,BenefitValidFrom,BenefitValidTo,BenefitFreqInMonth,BenefitYear,BenefitPeriod
Order by insCarrierID, InsHealthPlanID, RequestRecordStatus, ResponseRecordStatus



select top 10 * from fisxtract.NonMonetary
select top 10 * from fisxtract.Monetary
select top 10 * from fisxtract.[Authorization]

select CardNumberProxy, count(*) as rc from fisxtract.NonMonetary group by CardNumberProxy having count(*) > 20 order by 2 desc


select top 10 * from fisxtract.NonMonetary where CardNumberProxy = '5971157678487'
select top 10 * from fisxtract.Monetary where CardNumberProxy = '5971157678487'
select top 10 * from fisxtract.[Authorization] where CardNumberProxy = '5971157678487'