-- Please investigate PANProxyNumber | 5911048866287

select IsActive, BenefitCardNumber, RequestRecordStatus, ResponseRecordStatus, RequestProcessedFileID, ResponseProcessedFileID, ResponseProcessedDate, RequestProcessedDate, ResponseProcessedDate, * from otcfunds.CardBenefitLoad_CI where BenefitCardNumber = '5911048866287'
select IsActive, BenefitCardNumber, RequestRecordStatus, ResponseRecordStatus, RequestProcessedFileID,ResponseProcessedFileID, ResponseProcessedDate, RequestProcessedDate, ResponseProcessedDate, * from otcfunds.CardBenefitLoad_FD where BenefitCardNumber = '5911048866287'

select * from information_schema.columns where table_name = 'CardBenefitLoad_CI'

select top 10 * from otcfunds.CardBenefitLoad_CI where InsCarrierID = 417 and InsHealthPlanID = 6882
select top 10 * from otcfunds.CardBenefitLoad_FD where InsCarrierID = 417 and InsHealthPlanID = 6882

