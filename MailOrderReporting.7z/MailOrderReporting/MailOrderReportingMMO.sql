/*
select top 10 * from orders.orders
select top 10 * from orders.OrderItems
select top 10 * from orders.OrderTransactionDetails
select * from insurance.InsuranceCarriers where insurancecarriername like '%Medical%Mutual%of%Ohio%' 129
select * from master.members where NHMemberID  = 'NH202212071645'
select * from elig.mstrEligBenefitData where NHLinkId in (select NHLinkID from master.members where NHMemberID = 'NH202212071645' and IsActive =1)
select * from #Orders
select * from #OrderTransactionDetails
select * from orders.OrderTransactionDetails where OrderTransactionData like '%OrderDate%' and OrderID = 22300001108
*/

drop table if exists #InsuranceCarrierID
Create table #InsuranceCarrierID
(InsuranceCarrierID varchar(20))
--insert into #InsuranceCarrierID (InsuranceCarrierID) values ('129')
insert into #InsuranceCarrierID (InsuranceCarrierID) values ('149')

drop table if exists #Orders
select * into #Orders from (
select distinct
 a.OrderID as Orders_OrderID
,a.NHMemberID
,json_value(a.MemberData, '$.insCarrierId') as InsCarrierID
,json_value(a.MemberData, '$.insPlanId') as InsHealthPlanID
,json_value(a.MemberData, '$.insuranceNbr') as SubscriberID
from Orders.orders a
where json_value(a.MemberData, '$.insCarrierId') in (select distinct InsuranceCarrierID from #InsuranceCarrierID)
) a


drop table if exists #OrderTransactionDetails
select * into #OrderTransactionDetails from (
select distinct
OrderID
,json_value(b.OrderTransactionData, '$[0].orderDate') as OrderDate
,json_value(b.OrderTransactionData, '$[0].shipDate') as ShippingDate
,json_value(b.OrderTransactionData, '$[0].trackingNumber') as TrackingNumber
from 
Orders.OrderTransactionDetails b 
where OrderStatusCode ='SHI'
and OrderID in (select a.OrderID from Orders.orders a where json_value(a.MemberData, '$.insCarrierId') in  (select distinct InsuranceCarrierID from #InsuranceCarrierID))
) a

select InsuranceCarrierID, InsuranceCarrierName from insurance.insuranceCarriers where InsuranceCarrierID in (select distinct InsuranceCarrierID from #InsuranceCarrierID)
select insuranceHealthPlanID, HealthPlanName from insurance.InsuranceHealthPlans where InsuranceCarrierID in (select distinct InsuranceCarrierID from #InsuranceCarrierID)

drop table if exists #InsuranceHealthPlans
select * into #InsuranceHealthPlans from (
select a.InsuranceCarrierID, a.InsuranceCarrierName, b.InsuranceHealthPlanID, b.HealthPlanName 
from insurance.InsuranceCarriers a left join Insurance.InsuranceHealthPlans b on a.InsuranceCarrierID = b.InsuranceCarrierID 
where a.InsuranceCarrierID in (select distinct InsuranceCarrierID from #InsuranceCarrierID)
) a

drop table if exists #MailOrderReportingMMO
select * into #MailOrderReportingMMO from (
select a.*, b.*,c.*
from #Orders a 
left join #OrderTransactionDetails b on a.Orders_OrderID = b.OrderID
left join #InsuranceHealthPlans c on a.InsCarrierID = c.InsuranceCarrierID and a.InsHealthPlanID = c.InsuranceHealthPlanID
) a

select * from #MailOrderReportingMMO order by shippingDate,  TrackingNumber
select Orders_OrderID as OrderID, NHMemberID, SubscriberID, InsuranceCarrierName, HealthPlanName, OrderDate, ShippingDate, (''''+TrackingNumber+'''') as TrackingNumber from #MailOrderReportingMMO order by OrderDate desc, ShippingDate desc

