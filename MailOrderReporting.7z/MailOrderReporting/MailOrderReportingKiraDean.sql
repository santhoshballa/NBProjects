
IF OBJECT_ID('tempdb..#NHMemberIDTemp') IS NOT NULL DROP TABLE #NHMemberIDTemp
Create table #NHMemberIDTemp 
(
NHMemberID varchar(20),
OrderID bigint,
MemberID varchar(20)
)

insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982986',22300011485)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982954',22300022306)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982731',22300025100)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982456',22300025538)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982624',22300026890)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982593',22300037939)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982743',22300039470)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982950',22300040169)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982706',22300040582)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982835',22300040867)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982835',22300040868)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982485',22300041063)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982577',22300041484)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211983024',22300041923)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982759',22300043055)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982676',22300045107)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982668',22300047377)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982495',22300048509)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982756',22300052419)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982683',22300052436)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982665',22300053028)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982717',22300055859)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982491',22300058008)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982521',22300062630)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982479',22300064033)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982509',22300068953)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211983039',22300069836)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211983039',22300069837)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982407',22300072863)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982957',22300073675)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982491',22300076930)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982566',22300079888)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982843',22300080118)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982911',22300080432)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982615',22300080814)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982815',22300083444)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982676',22300083766)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211983030',22300084165)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982456',22300084342)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982743',22300086842)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982642',22300086883)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982431',22300090006)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211983024',22300091708)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982868',22300093594)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982678',22300095990)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982992',22300098985)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982588',22300099842)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982814',22300099998)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982814',22300099999)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982868',22300101131)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982868',22300102711)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982599',22300111069)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982705',22300111397)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982946',22300112922)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982708',22300117241)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982708',22300117255)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982625',22300120593)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982626',22300126978)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982626',22300126979)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982599',22300130970)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982783',22300131993)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982815',22300132372)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982864',22300133667)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982559',22300134400)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982675',22300140810)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982675',22300140811)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982723',22300143648)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982838',22300144306)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982894',22300146133)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982514',22300149213)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982674',22300150257)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982691',22300151891)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982675',22300151897)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982717',22300152774)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211983029',22300155083)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982455',22300155903)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982803',22300156815)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982492',22300161471)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982492',22300161472)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982668',22300162621)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982815',22300166758)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982815',22300167240)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982815',22300167718)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982815',22300168397)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982650',22300174433)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982588',22300177962)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982815',22300179704)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982826',22300180492)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982738',22300188711)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982461',22300190081)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982482',22300198338)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982488',22300199360)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982488',22300199374)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982642',22300205710)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982534',22300205958)
insert into #NHMemberIDTemp (NHMemberID, OrderID) values ('NH202211982995',22300206466)



select * from #NHMemberIDTemp order by OrderID asc
select count(*) from #NHMemberIDTemp -- 96

update #NHMemberIDTemp set NHMemberID  = ltrim(rtrim(NHMemberID))

update a set a.MemberID =  b.NHLinkID from master.Members b join #NHMemberIDTemp a on  a.NHMemberID = b.NHMemberID

select * from master.members where NHMemberID = 'NH202211982986' -- 4500002258515


select distinct
a.IsActive, b.IsActive, a.NHMemberID,  a.NHLinkID, b.SubscriberID,
ROW_NUMBER() OVER (PARTITION BY a.NHMemberID ORDER BY a.NHMemberID, a.CreateDate DESC) AS rowid
from 
master.members a join elig.mstrEligbenefitData b on a.NHLinkID = b.NhLinkid
where a.NHMemberID in (Select distinct NHMemberID from #NHMemberIDTemp) 
order by NHMemberID, 6, a.Isactive desc, b.IsActive desc

select * from master.Members where NHMemberID in (Select distinct NHMemberID from #NHMemberIDTemp)
select * from elig.mstrEligBenefitData where NHLinkID = '6163124'

