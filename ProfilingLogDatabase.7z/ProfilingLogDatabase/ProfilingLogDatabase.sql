
select * from information_schema.TABLES
select * from sys.schemas

select top 100  '[logs].[FISReqResponses]' as TableName_logs_FISReqResponses,[ID],[aauid],[ReqObject],[ResObject],[STATUS],[ErrorMessage],[CreateUser],[CreateDate],[ModifyUser],[ModifyDate],[MethodName],[Source],[ProxyID] from [logs].[FISReqResponses] order by CreateDate Desc
--select top 100  '[logs].[FISReqResponses_BCK12062022]' as TableName_logs_FISReqResponses_BCK12062022,[ID],[aauid],[ReqObject],[ResObject],[STATUS],[ErrorMessage],[CreateUser],[CreateDate],[ModifyUser],[ModifyDate],[MethodName],[Source] from [logs].[FISReqResponses_BCK12062022]

select count(*) from [logs].[FISReqResponses]
select distinct MethodName from [logs].[FISReqResponses] order by MethodName