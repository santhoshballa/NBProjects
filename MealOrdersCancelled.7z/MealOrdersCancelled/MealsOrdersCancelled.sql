
/*
The Below queries are for querying all cancelled orders for OTC Meals. The tables to look at are
the following
Orders.Orders
Orders.OrderItems
Orders.OrderTransactionDetails
Insurance.InsuranceCarrier
Insurance.InsuranceHealthPlans



*/





/*

select top 10 * from orders.orders

select top 10 * from otccatalog.ItemMaster
select * from  otccatalog.ItemMaster
select * from information_schema.columns where column_name like '%Item%master%'


select NHMemberID, * from orders.orders where OrderType = 'OTC' and IsActive =1 and Source = 'OTC_MEAL' and OrderStatusCode = 'CAN' order by ModifyDate Asc

select NHMemberID, * from orders.orders where OrderType = 'OTC' and IsActive =1 and Source = 'OTC_MEAL'  order by ModifyDate Asc

select distinct OrderStatusCode from orders.orders where OrderType = 'OTC' and IsActive =1 and Source = 'OTC_MEAL'
/*
SHI
INI
CAN
ACK
VOI
*/

select * from orders.orders where OrderType = 'OTC' and IsActive =1 and Source = 'OTC_MEAL' and OrderStatusCode = 'SHI'
select * from orders.orders where OrderType = 'OTC' and IsActive =1 and Source = 'OTC_MEAL' and OrderStatusCode = 'INI'
select * from orders.orders where OrderType = 'OTC' and IsActive =1 and Source = 'OTC_MEAL' and OrderStatusCode = 'CAN'
select * from orders.orders where OrderType = 'OTC' and IsActive =1 and Source = 'OTC_MEAL' and OrderStatusCode = 'ACK'
select * from orders.orders where OrderType = 'OTC' and IsActive =1 and Source = 'OTC_MEAL' and OrderStatusCode = 'VOI' -- This indicator is for shipping


select count(*) as RecordCount_SHI from orders.orders where OrderType = 'OTC' and IsActive =1 and Source = 'OTC_MEAL' and OrderStatusCode = 'SHI'
select count(*) as RecordCount_INI from orders.orders where OrderType = 'OTC' and IsActive =1 and Source = 'OTC_MEAL' and OrderStatusCode = 'INI'
select count(*) as RecordCount_CAN from orders.orders where OrderType = 'OTC' and IsActive =1 and Source = 'OTC_MEAL' and OrderStatusCode = 'CAN'
select count(*) as RecordCount_ACK from orders.orders where OrderType = 'OTC' and IsActive =1 and Source = 'OTC_MEAL' and OrderStatusCode = 'ACK'
select count(*) as RecordCount_VOI from orders.orders where OrderType = 'OTC' and IsActive =1 and Source = 'OTC_MEAL' and OrderStatusCode = 'VOI'

select RefOrderId, Count(*) as RecordCount from orders.orders where OrderType = 'OTC' and IsActive =1 and Source = 'OTC_MEAL' and OrderStatusCode in ('SHI', 'INI',  'CAN' ,  'ACK' , 'VOI') group by RefOrderId order by 2 desc


select * from orders.orders where RefOrderID = 202364114 or OrderID in (202364114)
select * from information_schema.columns where table_name like '%OrderStatus%'
select * from Orders.OrderStatusTypes where OrderStatusCode  = 'VOI'

select top 10 * from orders.orders where OrderType = 'OTC' and IsActive =1 and Source = 'OTC_MEAL' order by CreateDate desc

select * from orders.orders where OrderID in (203546122)
select * from orders.OrderItems where OrderID in (203546122)
select * from orders.OrderTransactionDetails where OrderID in (203546122)

select * from orders.orders where OrderID in (select OrderID from orders.orders where OrderType = 'OTC' and IsActive =1 and Source = 'OTC_MEAL' and OrderStatusCode = 'VOI') order by CreateDate desc
select * from orders.OrderItems where OrderID in (select OrderID from orders.orders where OrderType = 'OTC' and IsActive =1 and Source = 'OTC_MEAL' and OrderStatusCode = 'VOI')  order by CreateDate desc
-- select * from orders.OrderItemDetails where OrderID in (select OrderID from orders.orders where OrderType = 'OTC' and IsActive =1 and Source = 'OTC_MEAL' and OrderStatusCode = 'VOI')  order by CreateDate desc
select * from orders.OrderTransactionDetails  where OrderID in (select OrderID from orders.orders where OrderType = 'OTC' and IsActive =1 and Source = 'OTC_MEAL' and OrderStatusCode = 'VOI')  order by CreateDate desc


select * from orders.orders where OrderID in (select OrderID from orders.orders where OrderType = 'OTC' and IsActive =1 and Source = 'OTC_MEAL' and OrderStatusCode = 'SHI') order by CreateDate desc
select * from orders.OrderItems where OrderID in (select OrderID from orders.orders where OrderType = 'OTC' and IsActive =1 and Source = 'OTC_MEAL' and OrderStatusCode = 'SHI')  order by CreateDate desc
--select * from orders.OrderItemDetails where OrderID in (select OrderID from orders.orders where OrderType = 'OTC' and IsActive =1 and Source = 'OTC_MEAL' and OrderStatusCode = 'VOI')  order by CreateDate desc
select * from orders.OrderTransactionDetails  where OrderID in (select OrderID from orders.orders where OrderType = 'OTC' and IsActive =1 and Source = 'OTC_MEAL' and OrderStatusCode = 'SHI')  order by CreateDate desc


select distinct table_name from information_schema.columns where table_schema = 'orders' order by table_name

203680833 -- orderID
203680832 -- RefOrderID

select * from orders.orders where OrderID in (203680833,203680832 )
select * from orders.OrderItems where OrderID in (203680833,203680832 )
select * from orders.OrderTransactionDetails where OrderID in(203680833,203680832 )


select * from orders.orders where OrderID in (select OrderID from orders.orders where OrderType = 'OTC' and IsActive =1 and Source = 'OTC_MEAL' and OrderStatusCode = 'CAN' )
select * from orders.OrderItems where OrderID in (select OrderID from orders.orders where OrderType = 'OTC' and IsActive =1 and Source = 'OTC_MEAL' and OrderStatusCode = 'CAN' )
select * from orders.OrderTransactionDetails where OrderID in (select OrderID from orders.orders where OrderType = 'OTC' and IsActive =1 and Source = 'OTC_MEAL' and OrderStatusCode = 'CAN')


select * from orders.orders where OrderID in (select OrderID from orders.orders where OrderType = 'OTC' and IsActive =1 and Source = 'OTC_MEAL' and OrderStatusCode = 'CAN' )
select * from Orders.Orders where RefOrderID in (select OrderID from orders.orders where OrderType = 'OTC' and IsActive =1 and Source = 'OTC_MEAL' and OrderStatusCode = 'CAN' )


select * from orders.orders where OrderID in (202207521,203680832 )
select * from orders.OrderItems where OrderID in (202207521,203680832 )
select * from orders.OrderTransactionDetails where OrderID in(202207521,203680832 )



select OrderID from Orders.Orders where RefOrderID is null and OrderID in (select OrderID from orders.orders where OrderType = 'OTC' and IsActive =1 and Source = 'OTC_MEAL' and OrderStatusCode = 'CAN' ) and DateOrderReceived > '01-01-2022' order by CreateDate Desc

select * from Orders.Orders where RefOrderID in (select OrderID from Orders.Orders where RefOrderID is null and OrderID in (select OrderID from orders.orders where OrderType = 'OTC' and IsActive =1 and Source = 'OTC_MEAL' and OrderStatusCode = 'CAN' ) and DateOrderReceived > '01-01-2022'  )

select * from orders.orders where RefOrderID in (202245313,202245314,202245315,202245316)


select top 10 * from orders.orders

select top 10 * from otccatalog.ItemMaster
select * from  otccatalog.ItemMaster
select * from information_schema.columns where column_name like '%Item%master%'


select NHMemberID, * from orders.orders where OrderType = 'OTC' and IsActive =1 and Source = 'OTC_MEAL' and OrderStatusCode = 'CAN' order by ModifyDate Asc

select NHMemberID, * from orders.orders where OrderType = 'OTC' and IsActive =1 and Source = 'OTC_MEAL'  order by ModifyDate Asc

select distinct OrderStatusCode from orders.orders where OrderType = 'OTC' and IsActive =1 and Source = 'OTC_MEAL'
/*
SHI
INI
CAN
ACK
VOI
*/

select * from orders.orders where OrderType = 'OTC' and IsActive =1 and Source = 'OTC_MEAL' and OrderStatusCode = 'SHI'
select * from orders.orders where OrderType = 'OTC' and IsActive =1 and Source = 'OTC_MEAL' and OrderStatusCode = 'INI'
select * from orders.orders where OrderType = 'OTC' and IsActive =1 and Source = 'OTC_MEAL' and OrderStatusCode = 'CAN' order by RefOrderID
select * from orders.orders where OrderType = 'OTC' and IsActive =1 and Source = 'OTC_MEAL' and OrderStatusCode = 'ACK'
select * from orders.orders where OrderType = 'OTC' and IsActive =1 and Source = 'OTC_MEAL' and OrderStatusCode = 'VOI' 


select count(*) as RecordCount_SHI from orders.orders where OrderType = 'OTC' and IsActive =1 and Source = 'OTC_MEAL' and OrderStatusCode = 'SHI'
select count(*) as RecordCount_INI from orders.orders where OrderType = 'OTC' and IsActive =1 and Source = 'OTC_MEAL' and OrderStatusCode = 'INI'
select count(*) as RecordCount_CAN from orders.orders where OrderType = 'OTC' and IsActive =1 and Source = 'OTC_MEAL' and OrderStatusCode = 'CAN'
select count(*) as RecordCount_ACK from orders.orders where OrderType = 'OTC' and IsActive =1 and Source = 'OTC_MEAL' and OrderStatusCode = 'ACK'
select count(*) as RecordCount_VOI from orders.orders where OrderType = 'OTC' and IsActive =1 and Source = 'OTC_MEAL' and OrderStatusCode = 'VOI'

select RefOrderId, Count(*) as RecordCount from orders.orders where OrderType = 'OTC' and IsActive =1 and Source = 'OTC_MEAL' and OrderStatusCode in ('SHI', 'INI',  'CAN' ,  'ACK' , 'VOI') group by RefOrderId order by 2 desc


select * from orders.orders where RefOrderID = 202364114 or OrderID in (202364114)
select * from information_schema.columns where table_name like '%OrderStatus%'
select * from Orders.OrderStatusTypes where OrderStatusCode  = 'VOI'

select top 10 * from orders.orders where OrderType = 'OTC' and IsActive =1 and Source = 'OTC_MEAL' order by CreateDate desc

select * from orders.orders where OrderID in (203546122)
select * from orders.OrderItems where OrderID in (203546122)
select * from orders.OrderTransactionDetails where OrderID in (203546122)

select * from orders.orders where OrderID in (select OrderID from orders.orders where OrderType = 'OTC' and IsActive =1 and Source = 'OTC_MEAL' and OrderStatusCode = 'VOI') order by CreateDate desc
select * from orders.OrderItems where OrderID in (select OrderID from orders.orders where OrderType = 'OTC' and IsActive =1 and Source = 'OTC_MEAL' and OrderStatusCode = 'VOI')  order by CreateDate desc
select * from orders.OrderTransactionDetails  where OrderID in (select OrderID from orders.orders where OrderType = 'OTC' and IsActive =1 and Source = 'OTC_MEAL' and OrderStatusCode = 'VOI')  order by CreateDate desc


select * from orders.orders where OrderID in (select OrderID from orders.orders where OrderType = 'OTC' and IsActive =1 and Source = 'OTC_MEAL' and OrderStatusCode = 'SHI') order by CreateDate desc
select * from orders.orders where OrderID in (select OrderID from orders.orders where OrderType = 'OTC' and IsActive =1 and Source = 'OTC_MEAL' ) order by CreateDate desc


select * from orders.OrderItems where OrderID in (select OrderID from orders.orders where OrderType = 'OTC' and IsActive =1 and Source = 'OTC_MEAL' and OrderStatusCode = 'SHI')  order by CreateDate desc
select * from orders.OrderTransactionDetails  where OrderID in (select OrderID from orders.orders where OrderType = 'OTC' and IsActive =1 and Source = 'OTC_MEAL' and OrderStatusCode = 'SHI')  order by CreateDate desc



select RefOrderId, count(*) as RecordCount from Orders.Orders group by RefOrderId order by 2 desc
/*
select * from orders.orders where OrderID in (200412040) or RefOrderID in (200412040)
*/

select OrderType, Status, Source, OrderStatusCode, Count(*) as RecordCount from Orders.Orders group by OrderType, Status, Source, OrderStatusCode order by OrderType, Status, Source, OrderStatusCode


select 
a.orderID, a.OrderType, a.Status, a.OrderStatusCode, a.RefOrderID, '  ' as Blank,
b.RefOrderID, b.orderID, b.OrderType, b.Status, b.OrderStatusCode

from 
Orders.Orders a join Orders.orders b on a.OrderID = b.RefOrderID
where a.OrderType = 'OTC' and a.IsActive =1 and a.Source = 'OTC_MEAL' and b.OrderType = 'OTC' and b.IsActive =1 and b.Source = 'OTC_MEAL' and a.OrderStatusCode = 'CAN' and  b.OrderStatusCode = 'CAN'


-- NEW
select * from orders.orders where OrderID = 203697132
select * from orders.orderItems where OrderID = 203697132

-- Shipped
select * from orders.orders where OrderID = 203678670
select * from orders.orderItems where OrderID = 203678670

-- Cancelled |203120388
select * from orders.orders where OrderID = 203120388
select * from orders.orderItems where OrderID = 203120388


select * from orders.orders where OrderStatusCode = 'CAN' and Source = 'OTC_MEAL' and OrderType = 'OTC' and DateOrderReceived > '09-20-2022' order by NHMemberID, RefORderID
select * from orders.orders where OrderStatusCode = 'CAN' and Source = 'OTC_MEAL' and OrderType = 'OTC' and DateOrderReceived > '09-01-2022' order by DateOrderReceived desc, NHMemberID, RefORderID
select * from orders.orders where NHMemberID = 'NH202107345337' and Source = 'OTC_MEAL' and OrderType = 'OTC'  order by DateOrderReceived desc, NHMemberID, RefORderID
select * from orders.orders where OrderID in ( 203679157, 203678484)
select * from orders.orderItems where OrderID in ( 203679157, 203678484)
select * from orders.OrderTransactionDetails where OrderID in ( 203679157, 203678484)


select o.orderID, o.OrderStatusCode, o.Status from Orders.Orders o where  o.OrderStatusCode = 'CAN' and o.Source = 'OTC_MEAL' and o.OrderType = 'OTC' and o.IsActive =1 order by OrderID asc


select 
 a.IsActive as IsActive_CAN, a.OrderTransactionID as OrderTransactionID_CAN, a.OrderID as OrderID_CAN, a.OrderStatusCode as OrderStatusCode_CAN , a.OrderTransactionData as OrderTransactionData_CAN

,json_value(a.OrderTransactionData, '$.CancelledDate') as OrderTransactionData_CancelledDate_CAN
,json_value(a.OrderTransactionData, '$.Reason') as OrderTransactionData_Reason_CAN
,json_value(a.OrderTransactionData, '$.AdditionalComments') as OrderTransactionData_AdditionalComments_CAN

from Orders.OrderTransactionDetails a
where a.OrderStatusCode = 'CAN' and orderID = 203678484


select 
 b.IsActive as IsActive_VOI, b.OrderTransactionID as OrderTransactionID_VOI, b.OrderID as OrderID_VOI, b.OrderStatusCode as OrderStatusCode_VOI , b.OrderTransactionData as OrderTransactionData_VOI

,json_value(b.OrderTransactionData, '$.CancelledDate') as OrderTransactionData_CancelledDate_VOI
,json_value(b.OrderTransactionData, '$.Reason') as OrderTransactionData_Reason_VOI
,json_value(b.OrderTransactionData, '$.AdditionalComments') as OrderTransactionData_AdditionalComments_VOI

from Orders.OrderTransactionDetails b
where b.OrderStatusCode = 'VOI' and orderID = 203678484


select
o.orderID as OrderID_Orders, o.OrderStatusCode as OrderStatusCode_Orders, o.Status as Status_Orders,

a.IsActive as IsActive_CAN, a.OrderTransactionID as OrderTransactionID_CAN, a.OrderID as OrderID_CAN, a.OrderStatusCode as OrderStatusCode_CAN , a.OrderTransactionData as OrderTransactionData_CAN

,json_value(a.OrderTransactionData, '$.CancelledDate') as OrderTransactionData_CancelledDate_CAN
,json_value(a.OrderTransactionData, '$.Reason') as OrderTransactionData_Reason_CAN
,json_value(a.OrderTransactionData, '$.AdditionalComments') as OrderTransactionData_AdditionalComments_CAN,

b.IsActive as IsActive_VOI, b.OrderTransactionID as OrderTransactionID_VOI, b.OrderID as OrderID_VOI, b.OrderStatusCode as OrderStatusCode_VOI, b.OrderTransactionData as OrderTransactionData_VOI

,json_value(b.OrderTransactionData, '$.orderId') as OrderTransactionData_orderId_VOI
,json_value(b.OrderTransactionData, '$.orderDate') as OrderTransactionData_orderDate_VOI
,json_value(b.OrderTransactionData, '$.orderGroupId') as OrderTransactionData_orderGroupId_VOI

from
orders.orders o
left join Orders.OrderTransactionDetails a on o.OrderID = a.OrderID
left join Orders.OrderTransactionDetails b on a.OrderID = b.OrderID

where 1=1 
and o.OrderStatusCode = 'CAN' and o.Source = 'OTC_MEAL' and o.OrderType = 'OTC' and o.IsActive =1
and a.OrderStatusCode = 'CAN' and a.IsActive = 1
and b.OrderStatusCode = 'VOI' and b.IsActive = 1
order by o.OrderID asc

*/

DROP TABLE IF EXISTS #Orders
select * into #Orders from (
select o.*,

json_value(o.MemberData, '$.MemberName') as MemberData_MemberName
,json_value(o.MemberData, '$.insCarrierId') as MemberData_insCarrierId
,json_value(o.MemberData, '$.insPlanId') as MemberData_insPlanId
,json_value(o.MemberData, '$.insuranceNbr') as MemberData_insuranceNbr

,o.orderID as OrderID_Orders, o.OrderStatusCode as OrderStatusCode_Orders, o.Status as Status_Orders 
from orders.orders o  where o.OrderStatusCode = 'CAN' and o.Source = 'OTC_MEAL' and o.OrderType = 'OTC' and o.IsActive =1
) a



DROP TABLE IF EXISTS #OrderTransactionData_CAN
select * into #OrderTransactionData_CAN from 
(
select
a.IsActive as IsActive_CAN, a.OrderTransactionID as OrderTransactionID_CAN, a.OrderID as OrderID_CAN, a.OrderStatusCode as OrderStatusCode_CAN , a.OrderTransactionData as OrderTransactionData_CAN
,json_value(a.OrderTransactionData, '$.CancelledDate') as OrderTransactionData_CancelledDate_CAN
,json_value(a.OrderTransactionData, '$.Reason') as OrderTransactionData_Reason_CAN
,json_value(a.OrderTransactionData, '$.AdditionalComments') as OrderTransactionData_AdditionalComments_CAN
from Orders.OrderTransactionDetails a where a.OrderStatusCode = 'CAN' and a.IsActive = 1 and 
a.orderID in (Select o.OrderID from Orders.Orders o where o.OrderStatusCode = 'CAN' and o.Source = 'OTC_MEAL' and o.OrderType = 'OTC' and o.IsActive =1)

) a


DROP TABLE IF EXISTS #OrderTransactionData_VOI
select * into #OrderTransactionData_VOI from
(
select 
b.IsActive as IsActive_VOI, b.OrderTransactionID as OrderTransactionID_VOI, b.OrderID as OrderID_VOI, b.OrderStatusCode as OrderStatusCode_VOI, b.OrderTransactionData as OrderTransactionData_VOI

,json_value(b.OrderTransactionData, '$.orderId') as OrderTransactionData_orderId_VOI
,json_value(b.OrderTransactionData, '$.orderDate') as OrderTransactionData_orderDate_VOI
,json_value(b.OrderTransactionData, '$.orderGroupId') as OrderTransactionData_orderGroupId_VOI
from Orders.OrderTransactionDetails b
where b.OrderStatusCode in ( 'VOI', 'INI') and b.IsActive = 1 and
b.orderID in (Select o.OrderID from Orders.Orders o where o.OrderStatusCode = 'CAN' and o.Source = 'OTC_MEAL' and o.OrderType = 'OTC' and o.IsActive =1)
) a



DROP TABLE IF EXISTS #InsuranceHealthPlans
select * into #InsuranceHealthPlans from
(
select 
ic.InsuranceCarrierID, ic.InsuranceCarrierName, ic.IsActive as IsActive_InsuranceCarrier  
,hp.InsuranceHealthPlanID, hp.HealthPlanName, hp.IsActive as IsActive_InsuranceHealthPlan
from insurance.InsuranceCarriers ic join insurance.InsuranceHealthPlans hp on ic.InsuranceCarrierID = hp.InsuranceCarrierID
where ic.IsActive =1 and hp.isActive = 1 and
ic.InsuranceCarrierID in (select distinct MemberData_insCarrierId from #Orders) and
hp.InsuranceHealthPlanID in (select distinct MemberData_insPlanId from #Orders) 
) a


DROP TABLE IF EXISTS #CancelledMealOrders
select * into #CancelledMealOrders from (
select o.*, ihp.*, a.*, b.*
from 
#Orders o 
left join #OrderTransactionData_CAN a on o.OrderID_Orders = a.OrderID_CAN
left join #OrderTransactionData_VOI b on a.OrderID_CAN = b.OrderID_VOI
left join #InsuranceHealthPlans ihp on (ihp.InsuranceCarrierID = o.MemberData_insCarrierId and ihp.InsuranceHealthPlanID = o.MemberData_insPlanId)
) a

/*
select * from #CancelledMealOrders


Select
OrderID, Ordertype, NHMemberID, OrderStatusCode, MemberData_MemberName as MemberName, InsuranceCarrierID, InsuranceCarrierName, InsuranceHealthPlanID, HealthPlanName as InsuranceHealthPlanName, 
OrderTransactionData_OrderDate_VOI as OrderDate, OrderTransactionData_CancelledDate_CAN as CancelledDate, 
OrderTransactionData_Reason_CAN as ReasonForCancellation, OrderTransactionData_AdditionalComments_CAN as ReasonAdditionalComments
from #CancelledMealOrders
where OrderTransactionData_OrderDate_VOI is not null
Order by cast(OrderTransactionData_CancelledDate_CAN as date) desc, InsuranceCarrierName


Select
OrderID, 
-- Ordertype, NHMemberID, OrderStatusCode, MemberData_MemberName as MemberName, InsuranceCarrierID, InsuranceCarrierName, InsuranceHealthPlanID, HealthPlanName as InsuranceHealthPlanName, 
OrderTransactionData_OrderDate_VOI as OrderDate, OrderTransactionData_CancelledDate_CAN as CancelledDate 
--OrderTransactionData_Reason_CAN as ReasonForCancellation, OrderTransactionData_AdditionalComments_CAN as ReasonAdditionalComments
from #CancelledMealOrders
where OrderTransactionData_OrderDate_VOI is not null
Order by cast(OrderTransactionData_CancelledDate_CAN as date) desc, InsuranceCarrierName
*/

DROP TABLE IF EXISTS #CancelledMealOrdersFinal
select * into #CancelledMealOrdersFinal from (
Select
OrderID, 
-- Ordertype, NHMemberID, OrderStatusCode, MemberData_MemberName as MemberName, InsuranceCarrierID, InsuranceCarrierName, InsuranceHealthPlanID, HealthPlanName as InsuranceHealthPlanName, 
Cast(OrderTransactionData_OrderDate_VOI as Date) as OrderDate, Cast(OrderTransactionData_CancelledDate_CAN as Date) as CancelledDate 
--OrderTransactionData_Reason_CAN as ReasonForCancellation, OrderTransactionData_AdditionalComments_CAN as ReasonAdditionalComments
from #CancelledMealOrders
-- where OrderTransactionData_OrderDate_VOI is not null
--Order by cast(OrderTransactionData_OrderDate_VOI as Date) desc, cast(OrderTransactionData_CancelledDate_CAN as date) desc, InsuranceCarrierName
) a

select * from #CancelledMealOrdersFinal Order by OrderID asc, OrderDate asc, CancelledDate desc

/*
select * from orders.orders where orderid in (203678484, 203678208)
select * from orders.orderItems where orderid in (203678484, 203678208)
select * from orders.orderTransactionDetails where orderid in (203678484, 203678208)

select * from orders.orders where orderid in (203678484, 203678487, 203678488, 203678485, 203678486)
select * from orders.orderItems where orderid in (203678484, 203678487, 203678488, 203678485, 203678486)
select * from orders.orderTransactionDetails where orderid in (203678484, 203678487, 203678488, 203678485, 203678486)
*/

/*
OrderID	OrderDate	CancelledDate
203678484	2022-09-23	2022-09-23
203678485	2022-09-23	2022-09-23
203678486	2022-09-23	2022-09-23
203678487	2022-09-23	2022-09-23
203678488	2022-09-23	2022-09-23

*/


select * from orders.orders where RefOrderID in (203678484, 203678487, 203678488, 203678485, 203678486)
select * from orders.orderItems where orderid in (203678484, 203678487, 203678488, 203678485, 203678486)
select * from orders.orderTransactionDetails where orderid in (203678484, 203678487, 203678488, 203678485, 203678486)

/*
For OTC Meals, The first order ( OrderID 203678484) is created with RefOderId is null, This has dependent Orders ( Order ID 203678485,203678486,203678487,203678488 ) where the RefOrderID is the same as the Initial Order that was created.

*/




-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


IF OBJECT_ID('tempdb..#Orders') IS NOT NULL DROP TABLE #Orders
select * into #Orders from (
select o.*,

json_value(o.MemberData, '$.MemberName') as MemberData_MemberName
,json_value(o.MemberData, '$.insCarrierId') as MemberData_insCarrierId
,json_value(o.MemberData, '$.insPlanId') as MemberData_insPlanId
,json_value(o.MemberData, '$.insuranceNbr') as MemberData_insuranceNbr

,o.orderID as OrderID_Orders, o.OrderStatusCode as OrderStatusCode_Orders, o.Status as Status_Orders 
from orders.orders o  where o.OrderStatusCode = 'CAN' and o.Source = 'OTC_MEAL' and o.OrderType = 'OTC' and o.IsActive =1
) a

IF OBJECT_ID('tempdb..#OrderTransactionData_CAN') IS NOT NULL DROP TABLE #OrderTransactionData_CAN
select * into #OrderTransactionData_CAN from 
(
select
a.IsActive as IsActive_CAN, a.OrderTransactionID as OrderTransactionID_CAN, a.OrderID as OrderID_CAN, a.OrderStatusCode as OrderStatusCode_CAN , a.OrderTransactionData as OrderTransactionData_CAN
,json_value(a.OrderTransactionData, '$.CancelledDate') as OrderTransactionData_CancelledDate_CAN
,json_value(a.OrderTransactionData, '$.Reason') as OrderTransactionData_Reason_CAN
,json_value(a.OrderTransactionData, '$.AdditionalComments') as OrderTransactionData_AdditionalComments_CAN
from Orders.OrderTransactionDetails a where a.OrderStatusCode = 'CAN' and a.IsActive = 1 and 
a.orderID in (Select o.OrderID from Orders.Orders o where o.OrderStatusCode = 'CAN' and o.Source = 'OTC_MEAL' and o.OrderType = 'OTC' and o.IsActive =1)

) a


IF OBJECT_ID('tempdb..#OrderTransactionData_VOI') IS NOT NULL DROP TABLE #OrderTransactionData_VOI
select * into #OrderTransactionData_VOI from
(
select 
b.IsActive as IsActive_VOI, b.OrderTransactionID as OrderTransactionID_VOI, b.OrderID as OrderID_VOI, b.OrderStatusCode as OrderStatusCode_VOI, b.OrderTransactionData as OrderTransactionData_VOI

,json_value(b.OrderTransactionData, '$.orderId') as OrderTransactionData_orderId_VOI
,json_value(b.OrderTransactionData, '$.orderDate') as OrderTransactionData_orderDate_VOI
,json_value(b.OrderTransactionData, '$.orderGroupId') as OrderTransactionData_orderGroupId_VOI
from Orders.OrderTransactionDetails b
where b.OrderStatusCode in ( 'VOI', 'INI') and b.IsActive = 1 and
b.orderID in (Select o.OrderID from Orders.Orders o where o.OrderStatusCode = 'CAN' and o.Source = 'OTC_MEAL' and o.OrderType = 'OTC' and o.IsActive =1)
) a


IF OBJECT_ID('tempdb..#InsuranceHealthPlans') IS NOT NULL DROP TABLE #InsuranceHealthPlans
select * into #InsuranceHealthPlans from
(
select 
ic.InsuranceCarrierID, ic.InsuranceCarrierName, ic.IsActive as IsActive_InsuranceCarrier  
,hp.InsuranceHealthPlanID, hp.HealthPlanName, hp.IsActive as IsActive_InsuranceHealthPlan
from insurance.InsuranceCarriers ic join insurance.InsuranceHealthPlans hp on ic.InsuranceCarrierID = hp.InsuranceCarrierID
where ic.IsActive =1 and hp.isActive = 1 and
ic.InsuranceCarrierID in (select distinct MemberData_insCarrierId from #Orders) and
hp.InsuranceHealthPlanID in (select distinct MemberData_insPlanId from #Orders) 
) a


IF OBJECT_ID('tempdb..#CancelledMealOrders') IS NOT NULL DROP TABLE #CancelledMealOrders
select * into #CancelledMealOrders from (
select o.*, ihp.*, a.*, b.*
from 
#Orders o 
left join #OrderTransactionData_CAN a on o.OrderID_Orders = a.OrderID_CAN
left join #OrderTransactionData_VOI b on a.OrderID_CAN = b.OrderID_VOI
left join #InsuranceHealthPlans ihp on (ihp.InsuranceCarrierID = o.MemberData_insCarrierId and ihp.InsuranceHealthPlanID = o.MemberData_insPlanId)
) a


IF OBJECT_ID('tempdb..#CancelledMealOrdersFinal') IS NOT NULL DROP TABLE #CancelledMealOrdersFinal
select * into #CancelledMealOrdersFinal from (
Select
OrderID, 
-- Ordertype, NHMemberID, OrderStatusCode, MemberData_MemberName as MemberName, InsuranceCarrierID, InsuranceCarrierName, InsuranceHealthPlanID, HealthPlanName as InsuranceHealthPlanName, 
Cast(OrderTransactionData_OrderDate_VOI as Date) as OrderDate, Cast(OrderTransactionData_CancelledDate_CAN as Date) as CancelledDate 
--OrderTransactionData_Reason_CAN as ReasonForCancellation, OrderTransactionData_AdditionalComments_CAN as ReasonAdditionalComments
from #CancelledMealOrders
-- where OrderTransactionData_OrderDate_VOI is not null
--Order by cast(OrderTransactionData_OrderDate_VOI as Date) desc, cast(OrderTransactionData_CancelledDate_CAN as date) desc, InsuranceCarrierName
) a



select * from #CancelledMealOrders

Select
OrderID, Ordertype, NHMemberID, OrderStatusCode, MemberData_MemberName as MemberName, InsuranceCarrierID, InsuranceCarrierName, InsuranceHealthPlanID, HealthPlanName as InsuranceHealthPlanName, 
OrderTransactionData_OrderDate_VOI as OrderDate, OrderTransactionData_CancelledDate_CAN as CancelledDate, 
OrderTransactionData_Reason_CAN as ReasonForCancellation, OrderTransactionData_AdditionalComments_CAN as ReasonAdditionalComments
from #CancelledMealOrders
where OrderTransactionData_OrderDate_VOI is not null
Order by cast(OrderTransactionData_CancelledDate_CAN as date) desc, InsuranceCarrierName


Select
OrderID, 
-- Ordertype, NHMemberID, OrderStatusCode, MemberData_MemberName as MemberName, InsuranceCarrierID, InsuranceCarrierName, InsuranceHealthPlanID, HealthPlanName as InsuranceHealthPlanName, 
OrderTransactionData_OrderDate_VOI as OrderDate, OrderTransactionData_CancelledDate_CAN as CancelledDate 
--OrderTransactionData_Reason_CAN as ReasonForCancellation, OrderTransactionData_AdditionalComments_CAN as ReasonAdditionalComments
from #CancelledMealOrders
where OrderTransactionData_OrderDate_VOI is not null
Order by cast(OrderTransactionData_CancelledDate_CAN as date) desc, InsuranceCarrierName


IF OBJECT_ID('tempdb..#CancelledMealOrdersFinal') IS NOT NULL DROP TABLE #CancelledMealOrdersFinal
select * into #CancelledMealOrdersFinal from (
Select
OrderID, 
-- Ordertype, NHMemberID, OrderStatusCode, MemberData_MemberName as MemberName, InsuranceCarrierID, InsuranceCarrierName, InsuranceHealthPlanID, HealthPlanName as InsuranceHealthPlanName, 
Cast(OrderTransactionData_OrderDate_VOI as Date) as OrderDate, Cast(OrderTransactionData_CancelledDate_CAN as Date) as CancelledDate,
OrderTransactionData_Reason_CAN as ReasonForCancellation, OrderTransactionData_AdditionalComments_CAN as ReasonAdditionalComments
from #CancelledMealOrders
-- where OrderTransactionData_OrderDate_VOI is not null
--Order by cast(OrderTransactionData_OrderDate_VOI as Date) desc, cast(OrderTransactionData_CancelledDate_CAN as date) desc, InsuranceCarrierName
) a

select * from #CancelledMealOrdersFinal Order by OrderID asc, OrderDate asc, CancelledDate desc

select * from orders.orders where orderid in (203678484, 203678208)
select * from orders.orderItems where orderid in (203678484, 203678208)
select * from orders.orderTransactionDetails where orderid in (203678484, 203678208)

select * from orders.orders where orderid in (203678484, 203678487, 203678488, 203678485, 203678486)
select * from orders.orderItems where orderid in (203678484, 203678487, 203678488, 203678485, 203678486)
select * from orders.orderTransactionDetails where orderid in (203678484, 203678487, 203678488, 203678485, 203678486)

/*
OrderID	OrderDate	CancelledDate
203678484	2022-09-23	2022-09-23
203678485	2022-09-23	2022-09-23
203678486	2022-09-23	2022-09-23
203678487	2022-09-23	2022-09-23
203678488	2022-09-23	2022-09-23

*/


select * from orders.orders where RefOrderID in (203678484, 203678487, 203678488, 203678485, 203678486)
select * from orders.orderItems where orderid in (203678484, 203678487, 203678488, 203678485, 203678486)
select * from orders.orderTransactionDetails where orderid in (203678484, 203678487, 203678488, 203678485, 203678486)

/*
For OTC Meals, The first order ( OrderID 203678484) is created with RefOderId is null, This has dependent Orders ( Order ID 203678485,203678486,203678487,203678488 ) where the RefOrderID is the same as the Initial Order that was created.

*/



-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------