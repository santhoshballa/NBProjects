select * from elig.clientcodes where ClientName like '%bc%'
select * from elig.mstrEligBenefitData where datasource like '%ELIG_BCBSKC%' order by MasterMemberID desc,MemberInsuranceID, InsCarrierID, insHealthPlanID

DROP TABLE IF EXISTS #TMasterMemberID
select * into #TMasterMemberID from (
select MasterMemberID from elig.mstrEligBenefitData where datasource like '%ELIG_BCBSKC%' and CreateDate >= '01-01-2022' group by MasterMemberID  having count(*) > 1
) a

select distinct MasterMemberID from #TMasterMemberID

DROP TABLE IF EXISTS #TElig
select * into #TElig from (
select * from elig.mstrEligBenefitData where datasource like '%ELIG_BCBSKC%' and CreateDate >= '01-01-2022'  and MasterMemberID in (select MasterMemberID from #TMasterMemberID)
) a


DROP TABLE IF EXISTS #TPlanChanged

select * into #TPlanChanged from (
select distinct SubscriberID
--IsActive,FirstName, Lastname, SubscriberID, insCarrierID, insHealthPlanID, Address1, Address2, City, State, ZipCode, CreateDate,ModifyDate
--,case when rowidPlan > 1 then 1 else 0
--end as PlanChangedFlag
--,case when rowidAddress > 1 then 1 else 0
--end as AddressChangedFlag
from
(
select 
IsActive,
FirstName, Lastname, SubscriberID, MasterMemberID, insCarrierID, insHealthPlanID, Address1, Address2, City, State, ZipCode, CreateDate,ModifyDate
,DENSE_RANK() OVER (PARTITION BY MasterMemberID order by insHealthPlanID ) AS rowidPlan
,DENSE_RANK() over (PARTITION BY MasterMemberID order by Address1,Address2, City, State, ZipCode) as rowidAddress
from #TElig 
--order by SubscriberID, CreateDate Desc
) a
where Rowidplan >1 
--order by SubscriberID,CreateDate Desc,ISActive desc --PlanChangedFlag
) a




DROP TABLE IF EXISTS #TAddressChanged

select * into #TAddressChanged from (
select distinct SubscriberID
--IsActive,FirstName, Lastname, SubscriberID, insCarrierID, insHealthPlanID, Address1, Address2, City, State, ZipCode, CreateDate,ModifyDate
--,case when rowidPlan > 1 then 1 else 0
--end as PlanChangedFlag
--,case when rowidAddress > 1 then 1 else 0
--end as AddressChangedFlag
from
(
select 
IsActive,
FirstName, Lastname, SubscriberID, MasterMemberID, insCarrierID, insHealthPlanID, Address1, Address2, City, State, ZipCode, CreateDate,ModifyDate
,DENSE_RANK() OVER (PARTITION BY MasterMemberID order by insHealthPlanID ) AS rowidPlan
,DENSE_RANK() over (PARTITION BY MasterMemberID order by Address1,Address2, City, State, ZipCode) as rowidAddress
from #TElig 
--order by SubscriberID, CreateDate Desc
) a
where RowidAddress >1 
--order by SubscriberID,CreateDate Desc,ISActive desc --PlanChangedFlag
) a



select * from #TElig where SubscriberID in (select subscriberID from #TPlanChanged) order by SubscriberID, CreateDate Desc
select * from #TElig where SubscriberID in (select subscriberID from #TAddressChanged) order by SubscriberID, CreateDate Desc


select IsActive, SubscriberID, FirstName, LastName, insCarrierID, insHealthPlanID,  CreateDate, ModifyDate, RecordEffDate, RecordEndDate from #TElig where SubscriberID in (select subscriberID from #TPlanChanged) order by SubscriberID, CreateDate Desc, IsActive
select IsActive, SubscriberID, FirstName, LastName, Address1, Address2, City, State, ZipCode, CreateDate, ModifyDate, RecordEffDate, RecordEndDate  from #TElig where SubscriberID in (select subscriberID from #TAddressChanged) order by SubscriberID, CreateDate Desc, IsActive