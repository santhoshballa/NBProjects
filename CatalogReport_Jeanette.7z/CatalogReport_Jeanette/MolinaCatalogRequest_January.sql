 -- Ticket # 57353 | Molina catalog request for the month of January
IF OBJECT_ID('tempdb..#TCatalogs') IS NOT NULL DROP TABLE #TCatalogs 
select * into #TCatalogs from (
select distinct
oi.IsActive OrderItems_IsActive, o.IsActive as Orders_IsActive, ins.IsActive as Insurance_IsActive, ihp.IsActive as HealthPlans_IsActive, im.IsActive as ItemMaster_IsActive

,'SuppleOrders.OrderItems' as OrderItems_TableName, oi.OrderItemID, oi.OrderID as OrderItem_OrderID, oi.ItemCode as OrderItems_ItemCode, oi.Price, oi.Quantity  -- SupplOrders.OrderItems

,'SuppleOrders.Orders' as Orders_TableName, o.OrderID as Orders_OrderID, o.NHMemberID as Orders_NHMemberID, o.InsuranceCarrierID as Orders_InsuranceCarrierID, o.InsuranceHealthPlanID as Orders_InsuranceHealthPlanID, o.OrderType, o.Amount, o.Status  --SupplOrders.Orders

,Upper(JSON_VALUE(o.ShippingAddress,'$.firstName')) Ship_FirstName
,Upper(JSON_VALUE(o.ShippingAddress,'$.lastName')) Ship_LastName
,JSON_VALUE(o.ShippingAddress,'$.phoneNumber') Ship_PhoneNumber
,JSON_VALUE(o.ShippingAddress,'$.address.addressType') Ship_AddressType
,Upper(JSON_VALUE(o.ShippingAddress,'$.address.address1')) Ship_Address1
,Upper(JSON_VALUE(o.ShippingAddress,'$.address.address2')) Ship_Address2
--,JSON_VALUE(o.ShippingAddress,'$.address.address1') Ship_Address1
--,JSON_VALUE(o.ShippingAddress,'$.address.address2') Ship_Address2
,upper(JSON_VALUE(o.ShippingAddress,'$.address.city')) Ship_City
,upper(JSON_VALUE(o.ShippingAddress,'$.address.state')) Ship_State
,JSON_VALUE(o.ShippingAddress,'$.address.zipCode') Ship_ZipCode
, o.CreateDate
, o.ModifyDate

,'Insurance.InsuranceCarriers' as InsuranceCarriers_TableName, ins.InsuranceCarrierID, ins.InsuranceCarrierName  -- Insurance.InsuranceCarriers
,'Insurance.InsuranceHealthPlans' as InsuranceHealthPlans_TableName, ihp.InsuranceHealthPlanID, ihp.HealthPlanName  -- Insurance.InsuranceHealthPlans
,'SupplOrders.ItemMaster' as ItemMaster_TableName, im.ItemMasterID, im.ItemCode, im.ItemDisplayName, im.ItemDescription, im.ItemType-- SupplOrders.ItemMaster

from 
SupplOrders.orderItems oi 
left join SupplOrders.Orders o on oi.OrderID = o.OrderID
left join Insurance.InsuranceCarriers Ins on  o.InsuranceCarrierID = Ins.InsuranceCarrierID
left Join Insurance.InsuranceHealthPlans Ihp on o.InsuranceHealthPlanID = ihp.InsuranceHealthPlanID
left join SupplOrders.ItemMaster im on oi.ItemCode = im.ItemCode
where 1=1
and ins.insuranceCarrierID in  (380, 400, 138)
and o.CreateDate between '01-01-2022' and '02-01-2022'   --'01-31-2022' -- All catalogs that were shipped and requested during the month of January
--Order by o.CreateDate desc
) a


select OrderITem_OrderID, count(*) as RecordCount from #TCatalogs group by OrderITem_OrderID having count(*) > 1 order by 2 desc -- zero records returned

select * from #TCatalogs where status = 'Shipped'
select * from #TCatalogs where status = 'Requested'

IF OBJECT_ID('tempdb..#TeligMember') IS NOT NULL DROP TABLE #TeligMember
select * into #TeligMember from (
select m.MemberID, m.NHMemberID, e.subscriberID, e.MasterMemberID, e.BenefitStartDate, e.BenefitEndDate, e.InsCarrierID, e.insHealthPlanID, e.FirstName, e.LastName, e.dob, e.Address1, e.Address2, e.city, e.ZipCode
,row_number() over ( partition by SubscriberID, MasterMemberID, NHMemberID, InsCarrierID, insHealthPlanID order by SubscriberID, MasterMemberID, NHMemberID, InsCarrierID, insHealthPlanID ) as rowid
from elig.mstrEligBenefitData e join master.Members m
on e.MasterMemberID = m.MemberID
where insCarrierID in (380, 400, 138) and m.IsActive = 1 and e.isActive = 1 and Cast('01-01-2022' as Date)  between BenefitStartDate and BenefitEndDate and  Cast('01-31-2022' as Date)  between BenefitStartDate and BenefitEndDate
) a
where a.rowid = 1

/*
select NHMemberID, insHealthPlanID, count(*) as RecordCount from #TeligMember group by NHMemberID, insHealthPlanID having count(*) > 1
select * from #TeligMember where rowid = 2
select * from #TeligMember where NHMemberID = 'NH202209136616'
*/

IF OBJECT_ID('tempdb..#TCatalogsElig') IS NOT NULL DROP TABLE #TCatalogsElig
select * into #TCatalogsElig from (
select a.*, b.* from
#TCatalogs a join #TeligMember b on (a.Orders_NHMemberID = b.NHMemberID and a.InsuranceCarrierID = b.insCarrierID and a.InsuranceHealthPlanID = b.insHealthPlanID)
) a

select * from #TCatalogsElig



select 
 Cast(CreateDate as Date) as DateOfRequest
,Status
,SubscriberID,  Orders_NHMemberID as NHMemberID 
,Orders_InsuranceCarrierID as InsuranceCarrierID, InsuranceCarrierName,  Orders_InsuranceHealthPlanID as InsuranceHealthPlanID, HealthPlanName as InsuranceHealthPlanName 
,OrderItems_ItemCode as ItemCode, ItemDisplayName, ItemDescription, ItemType
,BenefitStartDate, BenefitEndDate,  
Ship_FirstName as FirstName, Ship_LastName as LastName, Ship_AddressType as AddressType, Ship_Address1 as Address1, Ship_Address2 as Address2, Ship_City as City, Ship_State as State, Ship_ZipCode as ZipCode
from #TCatalogsElig order by Status