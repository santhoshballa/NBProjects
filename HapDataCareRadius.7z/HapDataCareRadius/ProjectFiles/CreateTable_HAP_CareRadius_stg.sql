/****** Object:  Table [dbo].[HAP_CareRadius_stg]    Script Date: 7/28/2022 1:57:32 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[HAP_CareRadius_stg](
	[HAPCareRadiusID] [int] IDENTITY(1,1) NOT NULL,
	[NHMemberID] [varchar](1000) NOT NULL,
	[BenefitType] [varchar](1000) NOT NULL,
	[EnrollmentDate] [varchar](1000) NULL,
	[IsActive] [int] NULL,
	[MemberID] [varchar](10) NULL,
	[AlternateID] [varchar](10) NULL,
	[NHLinkID] [varchar](20) NULL,
	[MasterMemberID] [varchar](20) NULL,
	[MemberIsActive] [int] NULL,
	[EligIsActive] [int] NULL,
	[SubscriberID] [varchar](1000) NULL,
	[CaseManagementProgram] [varchar](1000) NULL,
	[EnrollmentType] [varchar](1000) NULL,
	[ProgramBeginDate] [varchar](1000) NULL,
	[ProgramEndDate] [varchar](1000) NULL,
	[ProgramInitiationDate] [varchar](1000) NULL,
	[ProgramStatus] [varchar](1000) NULL,
	[ProgramDisenrollmentReasonCode] [varchar](1000) NULL,
	[AcuityLevel] [varchar](1000) NULL,
	[ReferralSourceorSourceofData] [varchar](1000) NULL,
	[PrimaryCondition] [varchar](1000) NULL,
	[DiagnosisCode1] [varchar](1000) NULL,
	[DiagnosisCode2] [varchar](1000) NULL,
	[DiagnosisCode3] [varchar](1000) NULL,
	[MemberAccepted] [varchar](1000) NULL,
	[MemberReason] [varchar](1000) NULL,
	[MemberResponseByMR] [varchar](1000) NULL,
	[MemberContactedBy] [varchar](1000) NULL,
	[DateMemberAcceptedVerbal] [varchar](1000) NULL,
	[DateMemberDeclinedVerbal] [varchar](1000) NULL,
	[DateMemberAcceptedWritten] [varchar](1000) NULL,
	[DateMemberDeclinedWritten] [varchar](1000) NULL,
	[DateMemberAcceptedElectronic] [varchar](1000) NULL,
	[DateMemberDeclinedElectronic] [varchar](1000) NULL,
	[CaseManagerAccepted] [varchar](1000) NULL,
	[CaseManagerReason] [varchar](1000) NULL,
	[ContactedbyStaffID] [varchar](1000) NULL,
	[DateCaseManagerAccepted] [varchar](1000) NULL,
	[DateCaseManagerDeclined] [varchar](1000) NULL,
	[AcceptanceNotes] [varchar](1000) NULL,
	[CaseManagerStaffID] [varchar](1000) NULL,
	[CaseManagerBeginDate] [varchar](1000) NULL,
	[CaseManagerEndDate] [varchar](1000) NULL,
	[PrimaryCaseManager] [varchar](1000) NULL,
	[TasktoCaseManagerorWorkGroup] [varchar](1000) NULL,
	[WorkgrouptoGetTask] [varchar](1000) NULL,
	[TaskDueDate] [varchar](1000) NULL,
	[TaskDueTime] [varchar](1000) NULL,
	[TaskOwnerUserID] [varchar](1000) NULL,
	[NoteType] [varchar](1000) NULL,
	[GeneralNote] [varchar](1000) NULL
) ON [PRIMARY]
GO


