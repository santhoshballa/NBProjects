/*
IF OBJECT_ID('dbo.HAPTestFile') IS NOT NULL DROP TABLE dbo.HAPTestFile
CREATE TABLE dbo.HAPTestFile (
HAPTestFileID int IDENTITY(1,1), 
BusinessType varchar(20) NOT NULL,
NHmemberID varchar(50) NOT NULL,
EnrollmentDate nvarchar(20) ,
IsActive int,  -- This is to filter records if needed
MemberID nvarchar(10),
AlternateID nvarchar(10),
NHLinkID nvarchar(20),
MasterMemberID nvarchar(20),
MemberIsActive int,
EligIsActive int,
SubscriberID nvarchar(1000),
CaseManagementProgram	nvarchar(1000),
EnrollmentType	nvarchar(1000),
ProgramBeginDate	nvarchar(1000),
ProgramEndDate	nvarchar(1000)		,
ProgramInitiationDate	nvarchar(1000)		,
ProgramStatus	nvarchar(1000),
ProgramDisenrollmentReasonCode	nvarchar(1000)		,
AcuityLevel	nvarchar(1000)		,
ReferralSourceorSourceofData	nvarchar(1000),
PrimaryCondition	nvarchar(1000)		,
DiagnosisCode1	nvarchar(1000)		,
DiagnosisCode2	nvarchar(1000)		,
DiagnosisCode3	nvarchar(1000)		,
MemberAccepted	nvarchar(1000)		,
MemberReason	nvarchar(1000)		,
MemberResponseByMR	nvarchar(1000)		,
MemberContactedBy	nvarchar(1000)		,
DateMemberAcceptedVerbal	nvarchar(1000)		,
DateMemberDeclinedVerbal	nvarchar(1000)		,
DateMemberAcceptedWritten	nvarchar(1000)		,
DateMemberDeclinedWritten	nvarchar(1000)		,
DateMemberAcceptedElectronic	nvarchar(1000)		,
DateMemberDeclinedElectronic	nvarchar(1000)		,
CaseManagerAccepted	nvarchar(1000)		,
CaseManagerReason	nvarchar(1000)		,
ContactedbyStaffID	nvarchar(1000)		,
DateCaseManagerAccepted	nvarchar(1000)		,
DateCaseManagerDeclined	nvarchar(1000)		,
AcceptanceNotes	nvarchar(1000)		,
CaseManagerStaffID	nvarchar(1000)		,
CaseManagerBeginDate	nvarchar(1000)		,
CaseManagerEndDate	nvarchar(1000)		,
PrimaryCaseManager	nvarchar(1000)		,
TasktoCaseManagerorWorkGroup	nvarchar(1000)		,
WorkgrouptoGetTask	nvarchar(1000)		,
TaskDueDate	nvarchar(1000)		,
TaskDueTime	nvarchar(1000)		,
TaskOwnerUserID	nvarchar(1000)		,
NoteType	nvarchar(1000)		,
GeneralNote	nvarchar(1000)		,
	)
*/
-- Temp Table to filter the alternateID which is the SubscriberID
select distinct a.IsActive Member_IsActive, b.IsActive elig_IsActive, a.NHMemberID, a.MemberID, b.alternateID, b.NHLinkID,  b.MasterMemberID
into #MasterElig 
from master.Members a join elig.mstrEligBenefitData b on a.MemberID = b.MasterMemberID and a.IsActive = 1 and b.IsActive =1
where a.NHMemberID in (select distinct NHMemberID from dbo.HAPTestFile)

/*
select * from #MasterElig
select NHMemberID from dbo.HAPTestFile where NHmemberID not in (select distinct NHMemberID from #MasterElig)
select NHMemberID, count(*) from dbo.HAPTestFile group by NHMemberID having count(*) > 1
select * from dbo.HAPTestFile where NHMemberID in (select NHMemberID from dbo.HAPTestFile group by NHMemberID having count(*) > 1)
*/


update dbo.HAPTestFile set EnrollmentDate = '20220617'
update dbo.HAPTestFile set 
 MemberID =  me.MemberID
,AlternateID = me.AlternateID
,NHLinkID = me.NHLinkID
,MasterMemberID = me.MasterMemberID
,EligIsActive = me.elig_IsActive
,MemberIsActive = me.Member_IsActive
,IsActive = 1

from
dbo.HAPTestFile h join #MasterElig me on h.NHMemberID = me.NHMemberID

update dbo.HAPTestFile set SubscriberID = AlternateID where BusinessType in ('PERS', 'Ccare') and IsActive = 1
update dbo.HAPTestFile set CaseManagementProgram = 'NBPERS' where BusinessType = 'PERS'  and IsActive = 1
update dbo.HAPTestFile set CaseManagementProgram = 'NBCOMP' where BusinessType = 'Ccare'  and IsActive = 1
update dbo.HAPTestFile set EnrollmentType = 'CE' where BusinessType in ('PERS', 'Ccare')  and IsActive = 1
update dbo.HAPTestFile set ProgramStatus = 'ACT' where BusinessType in ('PERS', 'Ccare')  and IsActive = 1
update dbo.HAPTestFile set ReferralSourceorSourceofData = 'RFS086' where BusinessType in ('PERS', 'Ccare')  and IsActive = 1

