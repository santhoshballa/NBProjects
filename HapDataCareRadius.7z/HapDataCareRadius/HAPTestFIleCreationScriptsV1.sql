
select top 40 * from elig.mstrEligBenefitData where DataSource = 'ELIG_HAP' and isActive =1 and getdate() between BenefitStartDate and BenefitEndDate


IF OBJECT_ID('tempdb..#HAPTestFile') IS NOT NULL DROP TABLE #HAPTestFile

CREATE TABLE HAPTestFile (		
SubscriberID	nvarchar(1000)	NOT NULL	,
CaseManagementProgram	nvarchar(1000)	NOT NULL	,
EnrollmentType	nvarchar(1000)	NOT NULL	,
ProgramBeginDate	nvarchar(1000)	NOT NULL	,
ProgramEndDate	nvarchar(1000)		,
ProgramInitiationDate	nvarchar(1000)		,
ProgramStatus	nvarchar(1000)	NOT NULL	,
ProgramDisenrollmentReasonCode	nvarchar(1000)		,
AcuityLevel	nvarchar(1000)		,
ReferralSourceorSourceofData	nvarchar(1000)	NOT NULL	,
PrimaryCondition	nvarchar(1000)		,
DiagnosisCode1	nvarchar(1000)		,
DiagnosisCode2	nvarchar(1000)		,
DiagnosisCode3	nvarchar(1000)		,
MemberAccepted	nvarchar(1000)		,
MemberReason	nvarchar(1000)		,
MemberResponseByMR	nvarchar(1000)		,
MemberContactedBy	nvarchar(1000)		,
DateMemberAcceptedVerbal	nvarchar(1000)		,
DateMemberDeclinedVerbal	nvarchar(1000)		,
DateMemberAcceptedWritten	nvarchar(1000)		,
DateMemberDeclinedWritten	nvarchar(1000)		,
DateMemberAcceptedElectronic	nvarchar(1000)		,
DateMemberDeclinedElectronic	nvarchar(1000)		,
CaseManagerAccepted	nvarchar(1000)		,
CaseManagerReason	nvarchar(1000)		,
ContactedbyStaffID	nvarchar(1000)		,
DateCaseManagerAccepted	nvarchar(1000)		,
DateCaseManagerDeclined	nvarchar(1000)		,
AcceptanceNotes	nvarchar(1000)		,
CaseManagerStaffID	nvarchar(1000)		,
CaseManagerBeginDate	nvarchar(1000)		,
CaseManagerEndDate	nvarchar(1000)		,
PrimaryCaseManager	nvarchar(1000)		,
TasktoCaseManagerorWorkGroup	nvarchar(1000)		,
WorkgrouptoGetTask	nvarchar(1000)		,
TaskDueDate	nvarchar(1000)		,
TaskDueTime	nvarchar(1000)		,
TaskOwnerUserID	nvarchar(1000)		,
NoteType	nvarchar(1000)		,
GeneralNote	nvarchar(1000)		,
	)

-- Version 1
/*
insert into HAPTestFile	(SubscriberID,CaseManagementProgram,EnrollmentType,ProgramBeginDate,ProgramEndDate,ProgramInitiationDate,ProgramStatus,ProgramDisenrollmentReasonCode,AcuityLevel,ReferralSourceorSourceofData,PrimaryCondition,DiagnosisCode1,DiagnosisCode2,DiagnosisCode3,MemberAccepted,MemberReason,MemberResponseByMR,MemberContactedBy,DateMemberAcceptedVerbal,DateMemberDeclinedVerbal,DateMemberAcceptedWritten,DateMemberDeclinedWritten,DateMemberAcceptedElectronic,DateMemberDeclinedElectronic,CaseManagerAccepted,CaseManagerReason,ContactedbyStaffID,DateCaseManagerAccepted,DateCaseManagerDeclined,AcceptanceNotes,CaseManagerStaffID,CaseManagerBeginDate,CaseManagerEndDate,PrimaryCaseManager,TasktoCaseManagerorWorkGroup,WorkgrouptoGetTask,TaskDueDate,TaskDueTime,TaskOwnerUserID,NoteType,GeneralNote)
values	
	(	'101374940',	'NBCOMP',	'CE',	'20211201',	NULL,	NULL,	'ACT',	NULL,	NULL,	'RFS085',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'100841599',	'NBCOMP',	'CE',	'20211201',	NULL,	NULL,	'ACT',	NULL,	NULL,	'RFS085',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'100868854',	'NBCOMP',	'CE',	'20211201',	NULL,	NULL,	'ACT',	NULL,	NULL,	'RFS085',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'100640250',	'NBCOMP',	'CE',	'20211201',	NULL,	NULL,	'ACT',	NULL,	NULL,	'RFS085',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'100737640',	'NBCOMP',	'CE',	'20211201',	NULL,	NULL,	'ACT',	NULL,	NULL,	'RFS085',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'100029057',	'NBCOMP',	'CE',	'20211201',	NULL,	NULL,	'ACT',	NULL,	NULL,	'RFS085',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'100380897',	'NBCOMP',	'CE',	'20211201',	NULL,	NULL,	'ACT',	NULL,	NULL,	'RFS085',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'100795310',	'NBCOMP',	'CE',	'20211201',	NULL,	NULL,	'ACT',	NULL,	NULL,	'RFS085',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'100937655',	'NBCOMP',	'CE',	'20211201',	NULL,	NULL,	'ACT',	NULL,	NULL,	'RFS085',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'101020203',	'NBCOMP',	'CE',	'20211201',	NULL,	NULL,	'ACT',	NULL,	NULL,	'RFS085',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'100464209',	'NBCOMP',	'CE',	'20211201',	NULL,	NULL,	'ACT',	NULL,	NULL,	'RFS085',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'100850098',	'NBCOMP',	'CE',	'20211201',	NULL,	NULL,	'ACT',	NULL,	NULL,	'RFS086',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'100922358',	'NBCOMP',	'CE',	'20211201',	NULL,	NULL,	'CLS',	NULL,	NULL,	'RFS086',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'100070738',	'NBCOMP',	'CE',	'20211201',	NULL,	NULL,	'CLS',	NULL,	NULL,	'RFS086',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'101301064',	'NBPERS',	'CE',	'20211201',	NULL,	NULL,	'CLS',	NULL,	NULL,	'RFS086',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'100068116',	'NBPERS',	'CE',	'20211201',	NULL,	NULL,	'CLS',	NULL,	NULL,	'RFS086',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'100057024',	'NBPERS',	'CE',	'20211201',	NULL,	NULL,	'CLS',	NULL,	NULL,	'RFS086',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'100577351',	'NBPERS',	'CE',	'20211201',	NULL,	NULL,	'CLS',	NULL,	NULL,	'RFS086',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'100849085',	'NBPERS',	'CE',	'20211201',	NULL,	NULL,	'ACT',	NULL,	NULL,	'RFS086',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'100243099',	'NBPERS',	'CE',	'20211201',	NULL,	NULL,	'ACT',	NULL,	NULL,	'RFS086',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'100929371',	'NBPERS',	'CE',	'20211201',	NULL,	NULL,	'ACT',	NULL,	NULL,	'RFS086',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'100492080',	'NBPERS',	'CE',	'20211201',	NULL,	NULL,	'ACT',	NULL,	NULL,	'RFS086',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'100328651',	'NBPERS',	'CE',	'20211201',	NULL,	NULL,	'CLS',	NULL,	NULL,	'RFS086',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'100102024',	'NBPERS',	'CE',	'20211201',	NULL,	NULL,	'CLS',	NULL,	NULL,	'RFS086',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'100791570',	'NBPERS',	'CE',	'20211201',	NULL,	NULL,	'CLS',	NULL,	NULL,	'RFS086',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'101092973',	'NBPERS',	'CE',	'20211201',	NULL,	NULL,	'ACT',	NULL,	NULL,	'RFS086',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'100454150',	'NBPERS',	'CE',	'20211201',	NULL,	NULL,	'ACT',	NULL,	NULL,	'RFS086',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'100708338',	'NBPERS',	'CE',	'20211201',	NULL,	NULL,	'ACT',	NULL,	NULL,	'RFS086',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	)

*/

-- Version 2 | 12-16-2021
/*
Sent the SUbscriberID, with duplicates. The correct ID according to the team is the alternate or the NHLinkID.
truncate table HAPTestFile
go
insert into HAPTestFile	(	SubscriberID,	CaseManagementProgram,	EnrollmentType,	ProgramBeginDate,	ProgramEndDate,	ProgramInitiationDate,	ProgramStatus,	ProgramDisenrollmentReasonCode,	AcuityLevel,	ReferralSourceorSourceofData,	PrimaryCondition,	DiagnosisCode1,	DiagnosisCode2,	DiagnosisCode3,	MemberAccepted,	MemberReason,	MemberResponseByMR,	MemberContactedBy,	DateMemberAcceptedVerbal,	DateMemberDeclinedVerbal,	DateMemberAcceptedWritten,	DateMemberDeclinedWritten,	DateMemberAcceptedElectronic,	DateMemberDeclinedElectronic,	CaseManagerAccepted,	CaseManagerReason,	ContactedbyStaffID,	DateCaseManagerAccepted,	DateCaseManagerDeclined,	AcceptanceNotes,	CaseManagerStaffID,	CaseManagerBeginDate,	CaseManagerEndDate,	PrimaryCaseManager,	TasktoCaseManagerorWorkGroup,	WorkgrouptoGetTask,	TaskDueDate,	TaskDueTime,	TaskOwnerUserID,	NoteType,	GeneralNote	)
values	
    (	'100621940',	'NBCOMP',	'CE',	'20211201',	NULL,	NULL,	'ACT',	NULL,	NULL,	'RFS085',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'101644428',	'NBCOMP',	'CE',	'20211201',	NULL,	NULL,	'ACT',	NULL,	NULL,	'RFS085',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'101644432',	'NBCOMP',	'CE',	'20211201',	NULL,	NULL,	'ACT',	NULL,	NULL,	'RFS085',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'100836444',	'NBCOMP',	'CE',	'20211201',	NULL,	NULL,	'ACT',	NULL,	NULL,	'RFS085',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'101546803',	'NBCOMP',	'CE',	'20211201',	NULL,	NULL,	'ACT',	NULL,	NULL,	'RFS085',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'100725449',	'NBCOMP',	'CE',	'20211201',	NULL,	NULL,	'ACT',	NULL,	NULL,	'RFS085',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'101642494',	'NBCOMP',	'CE',	'20211201',	NULL,	NULL,	'ACT',	NULL,	NULL,	'RFS085',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'101642494',	'NBCOMP',	'CE',	'20211201',	NULL,	NULL,	'ACT',	NULL,	NULL,	'RFS085',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'101600798',	'NBCOMP',	'CE',	'20211201',	NULL,	NULL,	'ACT',	NULL,	NULL,	'RFS085',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'100855660',	'NBCOMP',	'CE',	'20211201',	NULL,	NULL,	'ACT',	NULL,	NULL,	'RFS085',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'100472861',	'NBCOMP',	'CE',	'20211201',	NULL,	NULL,	'ACT',	NULL,	NULL,	'RFS085',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'101565888',	'NBCOMP',	'CE',	'20211201',	NULL,	NULL,	'ACT',	NULL,	NULL,	'RFS086',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'101612388',	'NBCOMP',	'CE',	'20211201',	'20211214',	NULL,	'CLS',	NULL,	NULL,	'RFS086',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'101643978',	'NBCOMP',	'CE',	'20211201',	'20211214',	NULL,	'CLS',	NULL,	NULL,	'RFS086',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'100847115',	'NBPERS',	'CE',	'20211201',	'20211214',	NULL,	'CLS',	NULL,	NULL,	'RFS086',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'100847115',	'NBPERS',	'CE',	'20211201',	'20211214',	NULL,	'CLS',	NULL,	NULL,	'RFS086',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'100847115',	'NBPERS',	'CE',	'20211201',	'20211214',	NULL,	'CLS',	NULL,	NULL,	'RFS086',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'100847115',	'NBPERS',	'CE',	'20211201',	'20211214',	NULL,	'CLS',	NULL,	NULL,	'RFS086',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'100847115',	'NBPERS',	'CE',	'20211201',	NULL,	NULL,	'ACT',	NULL,	NULL,	'RFS086',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'100847115',	'NBPERS',	'CE',	'20211201',	NULL,	NULL,	'ACT',	NULL,	NULL,	'RFS086',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'100853560',	'NBPERS',	'CE',	'20211201',	NULL,	NULL,	'ACT',	NULL,	NULL,	'RFS086',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'100448482',	'NBPERS',	'CE',	'20211201',	NULL,	NULL,	'ACT',	NULL,	NULL,	'RFS086',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'101604465',	'NBPERS',	'CE',	'20211201',	'20211214',	NULL,	'CLS',	NULL,	NULL,	'RFS086',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'101351406',	'NBPERS',	'CE',	'20211201',	'20211214',	NULL,	'CLS',	NULL,	NULL,	'RFS086',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'101631667',	'NBPERS',	'CE',	'20211201',	'20211214',	NULL,	'CLS',	NULL,	NULL,	'RFS086',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'101604455',	'NBPERS',	'CE',	'20211201',	NULL,	NULL,	'ACT',	NULL,	NULL,	'RFS086',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'101604455',	'NBPERS',	'CE',	'20211201',	NULL,	NULL,	'ACT',	NULL,	NULL,	'RFS086',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'101604455',	'NBPERS',	'CE',	'20211201',	NULL,	NULL,	'ACT',	NULL,	NULL,	'RFS086',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	)
*/

-- version 3 | 12-16-2021

truncate table HAPTestFile
insert into HAPTestFile	(	SubscriberID,	CaseManagementProgram,	EnrollmentType,	ProgramBeginDate,	ProgramEndDate,	ProgramInitiationDate,	ProgramStatus,	ProgramDisenrollmentReasonCode,	AcuityLevel,	ReferralSourceorSourceofData,	PrimaryCondition,	DiagnosisCode1,	DiagnosisCode2,	DiagnosisCode3,	MemberAccepted,	MemberReason,	MemberResponseByMR,	MemberContactedBy,	DateMemberAcceptedVerbal,	DateMemberDeclinedVerbal,	DateMemberAcceptedWritten,	DateMemberDeclinedWritten,	DateMemberAcceptedElectronic,	DateMemberDeclinedElectronic,	CaseManagerAccepted,	CaseManagerReason,	ContactedbyStaffID,	DateCaseManagerAccepted,	DateCaseManagerDeclined,	AcceptanceNotes,	CaseManagerStaffID,	CaseManagerBeginDate,	CaseManagerEndDate,	PrimaryCaseManager,	TasktoCaseManagerorWorkGroup,	WorkgrouptoGetTask,	TaskDueDate,	TaskDueTime,	TaskOwnerUserID,	NoteType,	GeneralNote	)
values	
	(	'1280370',	'NBCOMP',	'CE',	'20211201',	NULL,	NULL,	'ACT',	NULL,	NULL,	'RFS085',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'1315583',	'NBCOMP',	'CE',	'20211201',	NULL,	NULL,	'ACT',	NULL,	NULL,	'RFS085',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'1464035',	'NBCOMP',	'CE',	'20211201',	NULL,	NULL,	'ACT',	NULL,	NULL,	'RFS085',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'1469898',	'NBCOMP',	'CE',	'20211201',	NULL,	NULL,	'ACT',	NULL,	NULL,	'RFS085',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'1479290',	'NBCOMP',	'CE',	'20211201',	NULL,	NULL,	'ACT',	NULL,	NULL,	'RFS085',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'1633452',	'NBCOMP',	'CE',	'20211201',	NULL,	NULL,	'ACT',	NULL,	NULL,	'RFS085',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'1633453',	'NBCOMP',	'CE',	'20211201',	NULL,	NULL,	'ACT',	NULL,	NULL,	'RFS085',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'1633457',	'NBCOMP',	'CE',	'20211201',	NULL,	NULL,	'ACT',	NULL,	NULL,	'RFS085',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'1773644',	'NBCOMP',	'CE',	'20211201',	NULL,	NULL,	'ACT',	NULL,	NULL,	'RFS085',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'1800030',	'NBCOMP',	'CE',	'20211201',	NULL,	NULL,	'ACT',	NULL,	NULL,	'RFS085',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'2153717',	'NBCOMP',	'CE',	'20211201',	NULL,	NULL,	'ACT',	NULL,	NULL,	'RFS085',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'2349361',	'NBCOMP',	'CE',	'20211201',	NULL,	NULL,	'ACT',	NULL,	NULL,	'RFS086',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'2349365',	'NBCOMP',	'CE',	'20211201',	'20211214',	NULL,	'CLS',	NULL,	NULL,	'RFS086',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'2462574',	'NBCOMP',	'CE',	'20211201',	'20211214',	NULL,	'CLS',	NULL,	NULL,	'RFS086',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'2632207',	'NBPERS',	'CE',	'20211201',	'20211214',	NULL,	'CLS',	NULL,	NULL,	'RFS086',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'3126643',	'NBPERS',	'CE',	'20211201',	'20211214',	NULL,	'CLS',	NULL,	NULL,	'RFS086',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'347821',	'NBPERS',	'CE',	'20211201',	'20211214',	NULL,	'CLS',	NULL,	NULL,	'RFS086',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'3801046',	'NBPERS',	'CE',	'20211201',	'20211214',	NULL,	'CLS',	NULL,	NULL,	'RFS086',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'3801047',	'NBPERS',	'CE',	'20211201',	NULL,	NULL,	'ACT',	NULL,	NULL,	'RFS086',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'3944080',	'NBPERS',	'CE',	'20211201',	NULL,	NULL,	'ACT',	NULL,	NULL,	'RFS086',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'3984982',	'NBPERS',	'CE',	'20211201',	NULL,	NULL,	'ACT',	NULL,	NULL,	'RFS086',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'4107799',	'NBPERS',	'CE',	'20211201',	NULL,	NULL,	'ACT',	NULL,	NULL,	'RFS086',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'4222102',	'NBPERS',	'CE',	'20211201',	'20211214',	NULL,	'CLS',	NULL,	NULL,	'RFS086',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'4222105',	'NBPERS',	'CE',	'20211201',	'20211214',	NULL,	'CLS',	NULL,	NULL,	'RFS086',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'4222738',	'NBPERS',	'CE',	'20211201',	'20211214',	NULL,	'CLS',	NULL,	NULL,	'RFS086',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'4222740',	'NBPERS',	'CE',	'20211201',	NULL,	NULL,	'ACT',	NULL,	NULL,	'RFS086',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'4222744',	'NBPERS',	'CE',	'20211201',	NULL,	NULL,	'ACT',	NULL,	NULL,	'RFS086',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'4222745',	'NBPERS',	'CE',	'20211201',	NULL,	NULL,	'ACT',	NULL,	NULL,	'RFS086',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	)

select * from dbo.HAPTestFile

select subscriberID from dbo.HAPTestFile where subscriberID in (select distinct a.alternateID from elig.mstrEligBenefitData a where a.isActive =1 and a.DataSource = 'ELIG_HAP')




select 
cast(SubscriberID as char(25)),
cast(CaseManagementProgram as char(6)),
cast(EnrollmentType as char(2)),
cast(ProgramBeginDate as char(8)),
cast(ProgramEndDate as char(8)),
cast(ProgramInitiationDate as char(8)),
cast(ProgramStatus as char(6)),
cast(ProgramDisenrollmentReasonCode as char(6)),
cast(AcuityLevel as char(6)),
cast(ReferralSourceorSourceofData as char(6)),
cast(PrimaryCondition as char(6)),
cast(DiagnosisCode1 as char(11)),
cast(DiagnosisCode2 as char(11)),
cast(DiagnosisCode3 as char(11)),
cast(MemberAccepted as char(1)),
cast(MemberReason as char(6)),
cast(MemberResponseByMR as char(1)),
cast(MemberContactedBy as char(12)),
cast(DateMemberAcceptedVerbal as char(8)),
cast(DateMemberDeclinedVerbal as char(8)),
cast(DateMemberAcceptedWritten as char(8)),
cast(DateMemberDeclinedWritten as char(8)),
cast(DateMemberAcceptedElectronic as char(8)),
cast(DateMemberDeclinedElectronic as char(8)),
cast(CaseManagerAccepted as char(1)),
cast(CaseManagerReason as char(6)),
cast(ContactedbyStaffID as char(12)),
cast(DateCaseManagerAccepted as char(8)),
cast(DateCaseManagerDeclined as char(8)),
cast(AcceptanceNotes as char(250)),
cast(CaseManagerStaffID as char(12)),
cast(CaseManagerBeginDate as char(8)),
cast(CaseManagerEndDate as char(8)),
cast(PrimaryCaseManager as char(1)),
cast(TasktoCaseManagerorWorkGroup as char(1)),
cast(WorkgrouptoGetTask as char(6)),
cast(TaskDueDate as char(8)),
cast(TaskDueTime as char(4)),
cast(TaskOwnerUserID as char(32)),
cast(NoteType as char(6)),
cast(GeneralNote as char(2000))
from HAPTestFile



select 
cast(SubscriberID as char(25))SubscriberID,
cast(CaseManagementProgram as char(6))CaseManagementProgram,
cast(EnrollmentType as char(2))EnrollmentType,
cast(ProgramBeginDate as char(8))ProgramBeginDate,
cast(ProgramEndDate as char(8))ProgramEndDate,
cast(ProgramInitiationDate as char(8))ProgramInitiationDate,
cast(ProgramStatus as char(6))ProgramStatus,
cast(ProgramDisenrollmentReasonCode as char(6))ProgramDisenrollmentReasonCode,
cast(AcuityLevel as char(6))AcuityLevel,
cast(ReferralSourceorSourceofData as char(6))ReferralSourceorSourceofData,
cast(PrimaryCondition as char(6))PrimaryCondition,
cast(DiagnosisCode1 as char(11))DiagnosisCode1,
cast(DiagnosisCode2 as char(11))DiagnosisCode2,
cast(DiagnosisCode3 as char(11))DiagnosisCode3,
cast(MemberAccepted as char(1))MemberAccepted,
cast(MemberReason as char(6))MemberReason,
cast(MemberResponseByMR as char(1))MemberResponseByMR,
cast(MemberContactedBy as char(12))MemberContactedBy,
cast(DateMemberAcceptedVerbal as char(8))DateMemberAcceptedVerbal,
cast(DateMemberDeclinedVerbal as char(8))DateMemberDeclinedVerbal,
cast(DateMemberAcceptedWritten as char(8))DateMemberAcceptedWritten,
cast(DateMemberDeclinedWritten as char(8))DateMemberDeclinedWritten,
cast(DateMemberAcceptedElectronic as char(8))DateMemberAcceptedElectronic,
cast(DateMemberDeclinedElectronic as char(8))DateMemberDeclinedElectronic,
cast(CaseManagerAccepted as char(1))CaseManagerAccepted,
cast(CaseManagerReason as char(6))CaseManagerReason,
cast(ContactedbyStaffID as char(12))ContactedbyStaffID,
cast(DateCaseManagerAccepted as char(8))DateCaseManagerAccepted,
cast(DateCaseManagerDeclined as char(8))DateCaseManagerDeclined,
cast(AcceptanceNotes as char(250))AcceptanceNotes,
cast(CaseManagerStaffID as char(12))CaseManagerStaffID,
cast(CaseManagerBeginDate as char(8))CaseManagerBeginDate,
cast(CaseManagerEndDate as char(8))CaseManagerEndDate,
cast(PrimaryCaseManager as char(1))PrimaryCaseManager,
cast(TasktoCaseManagerorWorkGroup as char(1))TasktoCaseManagerorWorkGroup,
cast(WorkgrouptoGetTask as char(6))WorkgrouptoGetTask,
cast(TaskDueDate as char(8))TaskDueDate,
cast(TaskDueTime as char(4))TaskDueTime,
cast(TaskOwnerUserID as char(32))TaskOwnerUserID,
cast(NoteType as char(6))NoteType,
cast(GeneralNote as char(2000))GeneralNote
from HAPTestFile

-- The correct SQL for SSIS
select 
cast(SubscriberID as char(25)) as SubscriberID,
cast(CaseManagementProgram as char(6)) as CaseManagementProgram,
cast(EnrollmentType as char(2)) as EnrollmentType,
cast(ProgramBeginDate as char(8)) as ProgramBeginDate,
cast(ProgramEndDate as char(8)) as ProgramEndDate,
cast(ProgramInitiationDate as char(8)) as ProgramInitiationDate,
cast(ProgramStatus as char(6)) as ProgramStatus,
cast(ProgramDisenrollmentReasonCode as char(6)) as ProgramDisenrollmentReasonCode,
cast(AcuityLevel as char(6)) as AcuityLevel,
cast(ReferralSourceorSourceofData as char(6)) as ReferralSourceorSourceofData,
cast(PrimaryCondition as char(6)) as PrimaryCondition,
cast(DiagnosisCode1 as char(11)) as DiagnosisCode1,
cast(DiagnosisCode2 as char(11)) as DiagnosisCode2,
cast(DiagnosisCode3 as char(11)) as DiagnosisCode3,
cast(MemberAccepted as char(1)) as MemberAccepted,
cast(MemberReason as char(6)) as MemberReason,
cast(MemberResponseByMR as char(1)) as MemberResponseByMR,
cast(MemberContactedBy as char(12)) as MemberContactedBy,
cast(DateMemberAcceptedVerbal as char(8)) as DateMemberAcceptedVerbal,
cast(DateMemberDeclinedVerbal as char(8)) as DateMemberDeclinedVerbal,
cast(DateMemberAcceptedWritten as char(8)) as DateMemberAcceptedWritten,
cast(DateMemberDeclinedWritten as char(8)) as DateMemberDeclinedWritten,
cast(DateMemberAcceptedElectronic as char(8)) as DateMemberAcceptedElectronic,
cast(DateMemberDeclinedElectronic as char(8)) as DateMemberDeclinedElectronic,
cast(CaseManagerAccepted as char(1)) as CaseManagerAccepted,
cast(CaseManagerReason as char(6)) as CaseManagerReason,
cast(ContactedbyStaffID as char(12)) as ContactedbyStaffID,
cast(DateCaseManagerAccepted as char(8)) as DateCaseManagerAccepted,
cast(DateCaseManagerDeclined as char(8)) as DateCaseManagerDeclined,
cast(AcceptanceNotes as char(250)) as AcceptanceNotes,
cast(CaseManagerStaffID as char(12)) as CaseManagerStaffID,
cast(CaseManagerBeginDate as char(8)) as CaseManagerBeginDate,
cast(CaseManagerEndDate as char(8)) as CaseManagerEndDate,
cast(PrimaryCaseManager as char(1)) as PrimaryCaseManager,
cast(TasktoCaseManagerorWorkGroup as char(1)) as TasktoCaseManagerorWorkGroup,
cast(WorkgrouptoGetTask as char(6)) as WorkgrouptoGetTask,
cast(TaskDueDate as char(8)) as TaskDueDate,
cast(TaskDueTime as char(4)) as TaskDueTime,
cast(TaskOwnerUserID as char(32)) as TaskOwnerUserID,
cast(NoteType as char(6)) as NoteType,
cast(GeneralNote as char(2000)) as GeneralNote
from HAPTestFile

select * from information_schema.columns where table_name like 'mstrEligBenefitData' 
select top 25 * from elig.mstrEligBenefitData where datasource = 'ELIG_HAP' and isActive =1 and  CreateDate > getdate() - 90
select * from elig.clientcodes where datasource like '%HAP%'

select top 100 * from elig.mstrEligBenefitData where datasource = 'ELIG_HAP' and isActive =1 and  CreateDate > getdate() - 90
select mstrEligID, NHLinkID, MasterMemberID, MemberInsuranceID, SubscriberID, GroupNbr, AlternateID from elig.mstrELigBenefitData where
NHLinkID in ('3722478','1917897', '625157') or MasterMemberID in ('3722478','1917897', '625157') or MemberInsuranceID in ('3722478','1917897', '625157') or SubscriberID in ('3722478','1917897', '625157') or GroupNbr in  ('3722478','1917897', '625157')
or AlternateID in  ('3722478','1917897', '625157')
select distinct alternateID from (
select top 100 alternateID from elig.mstrEligBenefitData where datasource = 'ELIG_HAP' and isActive = 1 and  CreateDate > getdate() - 180
) a

