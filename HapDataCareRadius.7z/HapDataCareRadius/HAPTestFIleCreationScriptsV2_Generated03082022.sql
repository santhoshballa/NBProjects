select * from master.Members where NHMemberID  = 'NH202002395165'
select * from elig.mstrEligBenefitData where MasterMemberID  = '2395165'
select * from elig.mstrEligBenefitData where FirstName like 'MICHEL' and lastName like 'MOORE' and datasource = 'ELIG_HAP' and IsActive = 1
select * from master.members where MemberID = 7144104

select distinct
a.IsActive Member_IsActive, b.IsActive elig_IsActive, a.NHMemberID, a.MemberID, b.alternateID, b.NHLinkID,  b.MasterMemberID
from master.Members a join elig.mstrEligBenefitData b on a.MemberID = b.MasterMemberID and a.IsActive = 1 and b.IsActive =1
where 
a.NHMemberID in 
(
-- COMP
-----'NH202002395165', -- This was provided and was not found, instead use NH202107144104
--'NH202107144104',   -- This is the correct NHMemberID for Michel Moore
--'NH201901368703', -- yes
--'NH202002392414', -- yes
--'NH202106767503', -- yes
--'NH202106583023', -- yes
--'NH202210324872'  -- yes

-- PERS
'NH202210316104',
'NH202107144104',
'NH202002392414',
'NH201901491239',
'NH202106583023',
'NH202106580868',
'NH202210324872',
'NH201800557434' 
)
order by a.NHMemberID


select * from elig.mstrEligBenefitData where alternateID = '101374940'

CREATE TABLE HAPTestFile (		
SubscriberID	nvarchar(1000)	NOT NULL	,
CaseManagementProgram	nvarchar(1000)	NOT NULL	,
EnrollmentType	nvarchar(1000)	NOT NULL	,
ProgramBeginDate	nvarchar(1000)	NOT NULL	,
ProgramEndDate	nvarchar(1000)		,
ProgramInitiationDate	nvarchar(1000)		,
ProgramStatus	nvarchar(1000)	NOT NULL	,
ProgramDisenrollmentReasonCode	nvarchar(1000)		,
AcuityLevel	nvarchar(1000)		,
ReferralSourceorSourceofData	nvarchar(1000)	NOT NULL	,
PrimaryCondition	nvarchar(1000)		,
DiagnosisCode1	nvarchar(1000)		,
DiagnosisCode2	nvarchar(1000)		,
DiagnosisCode3	nvarchar(1000)		,
MemberAccepted	nvarchar(1000)		,
MemberReason	nvarchar(1000)		,
MemberResponseByMR	nvarchar(1000)		,
MemberContactedBy	nvarchar(1000)		,
DateMemberAcceptedVerbal	nvarchar(1000)		,
DateMemberDeclinedVerbal	nvarchar(1000)		,
DateMemberAcceptedWritten	nvarchar(1000)		,
DateMemberDeclinedWritten	nvarchar(1000)		,
DateMemberAcceptedElectronic	nvarchar(1000)		,
DateMemberDeclinedElectronic	nvarchar(1000)		,
CaseManagerAccepted	nvarchar(1000)		,
CaseManagerReason	nvarchar(1000)		,
ContactedbyStaffID	nvarchar(1000)		,
DateCaseManagerAccepted	nvarchar(1000)		,
DateCaseManagerDeclined	nvarchar(1000)		,
AcceptanceNotes	nvarchar(1000)		,
CaseManagerStaffID	nvarchar(1000)		,
CaseManagerBeginDate	nvarchar(1000)		,
CaseManagerEndDate	nvarchar(1000)		,
PrimaryCaseManager	nvarchar(1000)		,
TasktoCaseManagerorWorkGroup	nvarchar(1000)		,
WorkgrouptoGetTask	nvarchar(1000)		,
TaskDueDate	nvarchar(1000)		,
TaskDueTime	nvarchar(1000)		,
TaskOwnerUserID	nvarchar(1000)		,
NoteType	nvarchar(1000)		,
GeneralNote	nvarchar(1000)		,
	)



truncate table HAPTestFile
insert into HAPTestFile	(	SubscriberID,	CaseManagementProgram,	EnrollmentType,	ProgramBeginDate,	ProgramEndDate,	ProgramInitiationDate,	ProgramStatus,	ProgramDisenrollmentReasonCode,	AcuityLevel,	ReferralSourceorSourceofData,	PrimaryCondition,	DiagnosisCode1,	DiagnosisCode2,	DiagnosisCode3,	MemberAccepted,	MemberReason,	MemberResponseByMR,	MemberContactedBy,	DateMemberAcceptedVerbal,	DateMemberDeclinedVerbal,	DateMemberAcceptedWritten,	DateMemberDeclinedWritten,	DateMemberAcceptedElectronic,	DateMemberDeclinedElectronic,	CaseManagerAccepted,	CaseManagerReason,	ContactedbyStaffID,	DateCaseManagerAccepted,	DateCaseManagerDeclined,	AcceptanceNotes,	CaseManagerStaffID,	CaseManagerBeginDate,	CaseManagerEndDate,	PrimaryCaseManager,	TasktoCaseManagerorWorkGroup,	WorkgrouptoGetTask,	TaskDueDate,	TaskDueTime,	TaskOwnerUserID,	NoteType,	GeneralNote	)
values	
    (	'10955529',	'NBPERS',	'CE',	'20220215',	NULL,	NULL,	'ACT',	NULL,	NULL,	'RFS086',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'1960664',	'NBPERS',	'CE',	'20220215',	NULL,	NULL,	'ACT',	NULL,	NULL,	'RFS086',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'11391869',	'NBPERS',	'CE',	'20220215',	NULL,	NULL,	'ACT',	NULL,	NULL,	'RFS086',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'11686111',	'NBPERS',	'CE',	'20220215',	NULL,	NULL,	'ACT',	NULL,	NULL,	'RFS086',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'11683177',	'NBPERS',	'CE',	'20220215',	NULL,	NULL,	'ACT',	NULL,	NULL,	'RFS086',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'11378220',	'NBPERS',	'CE',	'20220215',	NULL,	NULL,	'ACT',	NULL,	NULL,	'RFS086',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'11806432',	'NBPERS',	'CE',	'20220215',	NULL,	NULL,	'ACT',	NULL,	NULL,	'RFS086',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'11798684',	'NBPERS',	'CE',	'20220307',	NULL,	NULL,	'ACT',	NULL,	NULL,	'RFS086',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'10765175',	'NBCOMP',	'CE',	'20220215',	NULL,	NULL,	'ACT',	NULL,	NULL,	'RFS086',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'11391869',	'NBCOMP',	'CE',	'20220215',	NULL,	NULL,	'ACT',	NULL,	NULL,	'RFS086',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'11683177',	'NBCOMP',	'CE',	'20220215',	NULL,	NULL,	'ACT',	NULL,	NULL,	'RFS086',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'11731607',	'NBCOMP',	'CE',	'20220215',	NULL,	NULL,	'ACT',	NULL,	NULL,	'RFS086',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'11378220',	'NBCOMP',	'CE',	'20220215',	NULL,	NULL,	'ACT',	NULL,	NULL,	'RFS086',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	),
	(	'11798684',	'NBCOMP',	'CE',	'20220307',	NULL,	NULL,	'ACT',	NULL,	NULL,	'RFS086',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL	)


select * from HAPTestFile