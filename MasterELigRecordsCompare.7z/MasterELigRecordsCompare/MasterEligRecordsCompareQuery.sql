select distinct datasource from elig.mstrEligBenefitData
select distinct datasource from master.members

-- To check if the datasource are present in both elig and master
select distinct a.Datasource as DataSourceMaster, b.Datasource as DataSourceElig , a.IsActive as IsActiveMaster, b.isActive as IsActiveElig
from master.members a full outer join elig.mstrEligBenefitData b on isnull(a.Datasource,'Null') = isnull(b.Datasource, 'Null')
Order by 1,2

select distinct isnull(a.Datasource, 'NullValue') as DataSourceMaster, isNull(b.Datasource, 'NullValue') as DataSourceElig 
from master.members a full outer join elig.mstrEligBenefitData b on isnull(a.Datasource,'Null') = isnull(b.Datasource, 'Null')
Order by 1 asc,2 asc

drop table if exists #DataSourceMasterElig
select * into #DataSourceMasterElig from (
select distinct a.Datasource as DataSourceMaster, b.Datasource as DataSourceElig , a.IsActive as IsActiveMaster, b.isActive as IsActiveElig
from master.members a full outer join elig.mstrEligBenefitData b on isnull(a.Datasource,'Null') = isnull(b.Datasource, 'Null')
) a
Order by 1,2


Create table #ExceptionList
(
DataSource varchar(30)
)

--Exception List
insert into #ExceptionList (DataSource ) values ('Test_212')
insert into #ExceptionList (DataSource ) values ('Test_267')
insert into #ExceptionList (DataSource ) values ('Test_269')
insert into #ExceptionList (DataSource ) values ('Test_270')
insert into #ExceptionList (DataSource ) values ('Test_271')
insert into #ExceptionList (DataSource ) values ('Test_273')
insert into #ExceptionList (DataSource ) values ('Test_274')
insert into #ExceptionList (DataSource ) values ('Test_278')
insert into #ExceptionList (DataSource ) values ('Test_280')
insert into #ExceptionList (DataSource ) values ('Test_281')
insert into #ExceptionList (DataSource ) values ('Test_302')
insert into #ExceptionList (DataSource ) values ('Test_34')
insert into #ExceptionList (DataSource ) values ('Test_345')
insert into #ExceptionList (DataSource ) values ('Test_382')
insert into #ExceptionList (DataSource ) values ('Test_387')
insert into #ExceptionList (DataSource ) values ('Test_395')
insert into #ExceptionList (DataSource ) values ('Test_405')

-- Datasource in Master not in Elig
select * from #DataSourceMasterElig where DataSourceElig is null and IsActiveMaster = 1 and DataSourceMaster not in ( select Datasource from  #ExceptionList )
select distinct DataSourceMaster from #DataSourceMasterElig where DataSourceElig is null and IsActiveMaster = 1 and DataSourceMaster not in ( select Datasource from  #ExceptionList )

-- Datasource in Elig not in Master
select * from #DataSourceMasterElig where DataSourceMaster is null and IsActiveElig = 1 


drop table if exists #ExceptionList 
Create table #ExceptionList 
(
DataSource varchar(30)
)

--Exception List
insert into #ExceptionList (DataSource ) values ('Test_141')
insert into #ExceptionList (DataSource ) values ('Test_212')
insert into #ExceptionList (DataSource ) values ('Test_267')
insert into #ExceptionList (DataSource ) values ('Test_269')
insert into #ExceptionList (DataSource ) values ('Test_270')
insert into #ExceptionList (DataSource ) values ('Test_271')
insert into #ExceptionList (DataSource ) values ('Test_273')
insert into #ExceptionList (DataSource ) values ('Test_274')
insert into #ExceptionList (DataSource ) values ('Test_278')
insert into #ExceptionList (DataSource ) values ('Test_280')
insert into #ExceptionList (DataSource ) values ('Test_281')
insert into #ExceptionList (DataSource ) values ('Test_302')
insert into #ExceptionList (DataSource ) values ('Test_34')
insert into #ExceptionList (DataSource ) values ('Test_345')
insert into #ExceptionList (DataSource ) values ('Test_382')
insert into #ExceptionList (DataSource ) values ('Test_387')
insert into #ExceptionList (DataSource ) values ('Test_395')
insert into #ExceptionList (DataSource ) values ('Test_405')


select count( NHMemberID) from master.members where DataSource in (select distinct DataSourceMaster from #DataSourceMasterElig where DataSourceElig is null and IsActiveMaster = 1 and DataSourceMaster not in ( select Datasource from  #ExceptionList ))
select top 10 NHMemberID from master.members where DataSource in (select distinct DataSourceMaster from #DataSourceMasterElig where DataSourceElig is null and IsActiveMaster = 1 and DataSourceMaster not in ( select Datasource from  #ExceptionList ))

--5519652


drop table if exists #Insurance
select * into #Insurance from (
Select distinct a.InsuranceCarrierID, a.InsuranceCarrierName, b.insuranceHealthPlanID, b.HealthPlanName, a.IsActive as IsActiveInsurance, b.IsActive as InActiveHealthPlan
from insurance.InsuranceCarriers a join insurance.InsuranceHealthPlans b on a.InsuranceCarrierID = b.InsuranceCarrierID
) a

-- Distinct insurance Carrier ID and Insurance Health Plan ID from Eligibility
drop table if exists #InsuranceElig
select * into #InsuranceElig from (
select distinct insCarrierID, insHealthPlanID, IsActive from elig.mstrEligBenefitData
) a

-- Distinct Insurance Carrier ID and Insurance Health Plan Id from Master.MemberInsurances
drop table if exists #InsuranceMaster
select * into #InsuranceMaster from (
select distinct InsuranceCarrierID, InsuranceHealthPlanID, IsActive, CreateUser, CreateDate, ModifyUser, ModifyDate from master.MemberInsurances
) a

-- MemberDetails where NHLinkId is Null, which means there is no record in the eligibility table
drop table if exists #MemberDetails
select * into #MemberDetails from (
select distinct a.NHMemberID, a.NHLinkID, a.Datasource, isnull(b.InsuranceCarrierID,999) InsuranceCarrierID , isnull(b.InsuranceHealthPlanID, 9999) InsuranceHealthPlanID, a.CreateDate, a.CreateUser, a.ModifyDate, a.ModifyUser
from 
master.Members a left join master.MemberInsurances b on a.MemberID = b.MemberID
) a
where a.NHLinkID is null


select distinct NHMemberID, Datasource, InsuranceCarrierId, InsuranceHealthPlanId from #MemberDetails order by 1

select distinct Datasource from #MemberDetails order by 1

select top 10 * from master.members where isnull(NHLinkID, 'abc123') not in ( select distinct NHLinkID from elig.mstrEligBenefitData)

select * from master.members where NHMemberID = 'NH201700006298'
select * from elig.mstrEligBenefitData where NHLinkId in ( select NHLinkId from master.members where NHMemberID = 'NH201700006298')

select NHMemberID, count(*) as RecordCount from #MemberDetails group by NHMemberID order by 2 desc
select * from master.MemberInsurances where MemberId in ( select memberid from master.Members where NHMemberID = 'NH202314541774')




drop table if exists #ExceptionList 
Create table #ExceptionList 
(
DataSource varchar(30)
)

--Exception List
insert into #ExceptionList (DataSource ) values ('Test_141')
insert into #ExceptionList (DataSource ) values ('Test_212')
insert into #ExceptionList (DataSource ) values ('Test_267')
insert into #ExceptionList (DataSource ) values ('Test_269')
insert into #ExceptionList (DataSource ) values ('Test_270')
insert into #ExceptionList (DataSource ) values ('Test_271')
insert into #ExceptionList (DataSource ) values ('Test_273')
insert into #ExceptionList (DataSource ) values ('Test_274')
insert into #ExceptionList (DataSource ) values ('Test_278')
insert into #ExceptionList (DataSource ) values ('Test_280')
insert into #ExceptionList (DataSource ) values ('Test_281')
insert into #ExceptionList (DataSource ) values ('Test_302')
insert into #ExceptionList (DataSource ) values ('Test_34')
insert into #ExceptionList (DataSource ) values ('Test_345')
insert into #ExceptionList (DataSource ) values ('Test_382')
insert into #ExceptionList (DataSource ) values ('Test_387')
insert into #ExceptionList (DataSource ) values ('Test_395')
insert into #ExceptionList (DataSource ) values ('Test_405')
insert into #ExceptionList (DataSource ) values ('OTC_STORE')
insert into #ExceptionList (DataSource ) values ('CallCenterPortal')
insert into #ExceptionList (DataSource ) values ('Others')

drop table if exists #MemberDetailsNoNHLinkID
select * into #MemberDetailsNoNHLinkID from (
select distinct a.MemberID as MemberIDMember, NHMemberID, a.NHLinkID,  a.DataSOurce as DataSourceMember, b.DataSource as DataSourceMemberInsurance, a.FirstName, a.LastName, a.Gender, a.IsActive as IsActiveMember, a.MiddleInitial, a.CreateDate as CreateDateMember, a.CreateUser as CreateUserMember , b.* from master.Members a join master.MemberInsurances b on a.MemberID = b.MemberID where a.NHLinkId is null and a.DataSource not in (select DataSource from #ExceptionList)
) a

select * from  #MemberDetailsNoNHLinkID where CreateDate > '01-01-2023' order by CreateDateMember desc



select distinct datasourceMember from #MemberDetailsNoNHLinkID
select * from elig.mstrEligBenefitdata where datasource = 'ELIG_AETNACT'
