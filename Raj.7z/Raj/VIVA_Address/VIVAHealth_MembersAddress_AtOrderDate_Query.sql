

-- Request from Raj
/*
Hi Santosh,Need  the following information.
For VIVA we need Orders shipped to a different address than the latest mailing/perm address at the time of placing the order on eligibility file.
-- Request from Raj
*/

select * from elig.ClientCodes where ClientName like '%viva%'
/*
ClientCode	ClientName		DataSource		InsuranceCarrierID
H496		VIVA Health		ELIG_VIVA		394
*/

select * from insurance.insuranceCarriers where InsuranceCarrierName like '%viva%'
select * from insurance.insurancehealthplans where InsuranceCarrierID = '394'
--(4124,4125,4126,4127,4128,4129,4130,4131,4132,4133)

select top 10 * from orders.Orders

select * from elig.mstrEligBenefitData where datasource = 'ELIG_VIVA' or inscarrierID = 394
select (ltrim(rtrim(address1)) +' | ' + ltrim(rtrim(address2)) +' | ' + ltrim(rtrim(city))) as Address, Count(*) as RecordCount from elig.mstrEligBenefitData where inscarrierID = 394 group by (ltrim(rtrim(address1)) +' | ' + ltrim(rtrim(address2)) +' | ' + ltrim(rtrim(city))) order by 2 desc

select * from elig.mstrEligBenefitData where Address1 = '3309 STONYBROOK LN' and inscarrierID = 394


select IsActive, DataSource, SubscriberID, GroupNbr, BenefitStartDate, BenefitStartDate, AlternateID, MedicareID, ContractNbr, PBPID, LineOfBusiness, NHLinkID, MasterMemberID, insCarrierID, insHealthPlanID, FirstName, MiddleInitial,Address1, Address2, City, State, Zipcode,  LastName, DOB, RecordEffDate, RecordEnddate, CreateDate, ModifyDate from elig.mstrEligBenefitData where InsCarrierID = '394'

select MedicareID, count(*) as RecordCount from elig.mstrEligBenefitData where InsCarrierID = '394' group by MedicareID order by 2 desc

select IsActive, DataSource, SubscriberID, GroupNbr, BenefitStartDate, BenefitStartDate, AlternateID, MedicareID, ContractNbr, PBPID, LineOfBusiness, NHLinkID, MasterMemberID, insCarrierID, insHealthPlanID, FirstName, MiddleInitial,Address1, Address2, City, State, Zipcode,  LastName, DOB, RecordEffDate, RecordEnddate, CreateDate, ModifyDate 
from elig.mstrEligBenefitData where InsCarrierID = '394'
and MedicareID = '4HG6R09NM43'

select distinct (ltrim(rtrim(address1)) +' | ' + ltrim(rtrim(address2)) +' | ' + ltrim(rtrim(city))) as Address
from elig.mstrEligBenefitData where InsCarrierID = '394'  -- 48272

select (ltrim(rtrim(address1)) +' | ' + ltrim(rtrim(address2)) +' | ' + ltrim(rtrim(city))) as Address
from elig.mstrEligBenefitData where InsCarrierID = '394'  -- 68268


drop table #TEligMaster
select * into #TEligMaster from (
select a.NHmemberID, a.IsActive as Member_IsActive, b.IsActive as elig_IsActive, b.DataSource, b.SubscriberID, b.GroupNbr, b.BenefitStartDate, b.BenefitEndDate, b.AlternateID, b.MedicareID, b.ContractNbr, b.PBPID, b.LineOfBusiness, b.NHLinkID, b.MasterMemberID, b.insCarrierID, b.insHealthPlanID, b.FirstName, b.MiddleInitial,b.Address1, b.Address2, b.City, b.State, b.Zipcode,  b.LastName, b.DOB, b.RecordEffDate, b.RecordEnddate, b.CreateDate, b.ModifyDate 
from elig.mstrEligBenefitData b left join master.Members a on a.MemberID = MasterMemberID 
where a.IsActive = 1  and b.InsCarrierID = '394'
) a 

select * from #TEligMaster

drop table 
select * from orders.orders where NHMemberID in (select distinct NHmemberID from #TEligMaster) and SpecialInstructions not like '%Voucher%added%'


drop table #TOrders
select * into #TOrders from (
select 
'Orders.Orders' as TableName
--*, -- all columns
 ,NHMemberID
 ,OrderID
 ,DateOrderReceived
 ,DateOrderInitiated
 ,CreateDate,ModifyDate
--MemberData

,MemberData
,json_value(orders.MemberData, '$.firstName') as MemberData_firstName
,json_value(orders.MemberData, '$.lastName') as MemberData_lastName 
,json_value(orders.MemberData, '$.phoneNumber') as MemberData_phoneNumber 
,json_value(orders.MemberData, '$.dob') as MemberData_dob

--MemberData | address
,json_value(orders.MemberData, '$.address.address') as MemberData_address
,json_value(orders.MemberData, '$.address.city') as MemberData_city
,json_value(orders.MemberData, '$.address.state') as MemberData_state 
,json_value(orders.MemberData, '$.address.zip') as MemberData_zip


--MemberData | insurance
,json_value(orders.MemberData, '$.insurance.carrierName') as MemberData_carrierName
,json_value(orders.MemberData, '$.insurance.planName') as MemberData_planName
,json_value(orders.MemberData, '$.insurance.programeName') as MemberData_programeName
,json_value(orders.MemberData, '$.insurance.insuranceMemberId') as MemberData_insuranceMemberId
,json_value(orders.MemberData, '$.insurance.nhMemberId') as MemberData_nhMemberId
,json_value(orders.MemberData, '$.insurance.insuranceBenefit') as MemberData_insuranceBenefit
,json_value(orders.MemberData, '$.insurance.benefitUsed') as MemberData_benefitUsed
,json_value(orders.MemberData, '$.insurance.lastBenefitUsedDate') as MemberData_lastBenefitUsedDate
,json_value(orders.MemberData, '$.insCarrierId') as MemberData_insCarrierId
,json_value(orders.MemberData, '$.insPlanId') as MemberData_insPlanId


--OrderAmountData
,OrderAmountData
,json_value(orders.OrderAmountData, '$.productPrice') as OrderAmountData_productPrice
,json_value(orders.OrderAmountData, '$.insuranceBenefit') as OrderAmountData_insuranceBenefit
,json_value(orders.OrderAmountData, '$.benefitUsed') as OrderAmountData_benefitUsed
,json_value(orders.OrderAmountData, '$.benefitAvailable') as OrderAmountData_benefitAvailable
,json_value(orders.OrderAmountData, '$.memberResponsibility') as OrderAmountData_memberResponsibility
,json_value(orders.OrderAmountData, '$.itemcode') as OrderAmountData_itemcode
,json_value(orders.OrderAmountData, '$.vsPrice') as OrderAmountData_vsPrice
,json_value(orders.OrderAmountData, '$.vsTechLevel') as OrderAmountData_vsTechLevel

,'OTC_OrderAmountData' as OTC_LineOfBusiness
,json_value(orders.OrderAmountData, '$.price') as OrderAmountData_price
,json_value(orders.OrderAmountData, '$.amountCovered') as OrderAmountData_amountCovered
,json_value(orders.OrderAmountData, '$.outOfPocket') as OrderAmountData_outOfPocket
,json_value(orders.OrderAmountData, '$.benefitTransactions[0]') as OrderAmountData_benefitTransactions0_catalogName0
,json_value(orders.OrderAmountData, '$.benefitTransactions[0].catalogName') as OrderAmountData_benefitTransactions0_catalogName
,json_value(orders.OrderAmountData, '$.benefitTransactions[0].originalWalletCode') as OrderAmountData_benefitTransactions0_originalWalletCode
,json_value(orders.OrderAmountData, '$.benefitTransactions[0].benefitType') as OrderAmountData_benefitTransactions0_benefitType
,json_value(orders.OrderAmountData, '$.benefitTransactions[0].acctLast4Digits') as OrderAmountData_benefitTransactions0_acctLast4Digits
,json_value(orders.OrderAmountData, '$.benefitTransactions[0].amountCovered') as OrderAmountData_benefitTransactions0_amountCovered
,json_value(orders.OrderAmountData, '$.benefitTransactions[0].amountRemaining') as OrderAmountData_benefitTransactions0_amountRemaining
,json_value(orders.OrderAmountData, '$.benefitTransactions[0].transactionId') as OrderAmountData_benefitTransactions0_transactionId
,json_value(orders.OrderAmountData, '$.benefitTransactions[0].outOfPocket') as OrderAmountData_benefitTransactions0_outOfPocket
,json_value(orders.OrderAmountData, '$.benefitTransactions[0].source') as OrderAmountData_benefitTransactions0_source
,json_value(orders.OrderAmountData, '$.benefitTransactions[0].emiData') as OrderAmountData_benefitTransactions0_emiData
,json_value(orders.OrderAmountData, '$.benefitTransactions[0]') as OrderAmountData_benefitTransactions1_catalogName1
,json_value(orders.OrderAmountData, '$.benefitTransactions[1].catalogName') as OrderAmountData_benefitTransactions1_catalogName
,json_value(orders.OrderAmountData, '$.benefitTransactions[1].originalWalletCode') as OrderAmountData_benefitTransactions1_originalWalletCode
,json_value(orders.OrderAmountData, '$.benefitTransactions[1].benefitType') as OrderAmountData_benefitTransactions1_benefitType
,json_value(orders.OrderAmountData, '$.benefitTransactions[1].acctLast4Digits') as OrderAmountData_benefitTransactions1_acctLast4Digits
,json_value(orders.OrderAmountData, '$.benefitTransactions[1].amountCovered') as OrderAmountData_benefitTransactions1_amountCovered
,json_value(orders.OrderAmountData, '$.benefitTransactions[1].amountRemaining') as OrderAmountData_benefitTransactions1_amountRemaining
,json_value(orders.OrderAmountData, '$.benefitTransactions[1].transactionId') as OrderAmountData_benefitTransactions1_transactionId
,json_value(orders.OrderAmountData, '$.benefitTransactions[1].outOfPocket') as OrderAmountData_benefitTransactions1_outOfPocket
,json_value(orders.OrderAmountData, '$.benefitTransactions[1].source') as OrderAmountData_benefitTransactions1_source
,json_value(orders.OrderAmountData, '$.benefitTransactions[1].emiData') as OrderAmountData_benefitTransactions1_emiData



--ShippingData
,ShippingData
,json_value(orders.ShippingData, '$.providerBusinessName') as ShippingData_providerBusinessName
,json_value(orders.ShippingData, '$.dispenser') as ShippingData_dispenser
,json_value(orders.ShippingData, '$.dba') as ShippingData_dba -- What is this column used for?

--ShippingData | address
,json_value(orders.ShippingData, '$.address.address') as ShippingData_address
,json_value(orders.ShippingData, '$.address.address1') as ShippingData_address1
,json_value(orders.ShippingData, '$.address.address2') as ShippingData_address2

,json_value(orders.ShippingData, '$.address.city') as ShippingData_city
,json_value(orders.ShippingData, '$.address.state') as ShippingData_state
,json_value(orders.ShippingData, '$.address.zip') as ShippingData_zip
,json_value(orders.ShippingData, '$.address.country') as ShippingData_country

,json_value(orders.ShippingData, '$.email') as ShippingData_email
,json_value(orders.ShippingData, '$.shippingInstructions') as ShippingData_shippingInstructions
,json_value(orders.ShippingData, '$.manufacturer') as ShippingData_manufacturer
,json_value(orders.ShippingData, '$.phoneNumber') as ShippingData_phoneNumber
,json_value(orders.ShippingData, '$.faxNumber') as ShippingData_faxNumber




,'OTC_ShippingData' as OTC_LineOfBusiness_ShippingData
--ShippingData | address


,json_value(orders.ShippingData, '$.firstName') as ShippingData_firstName
,json_value(orders.ShippingData, '$.lastName') as ShippingData_lastName
--,json_value(orders.ShippingData, '$.phoneNumber') as ShippingData_phoneNumber
--,json_value(orders.ShippingData, '$.email') as ShippingData_email
--,json_value(orders.ShippingData, '$.address') as ShippingData_address
,json_value(orders.ShippingData, '$.address.address1') as ShippingData_address_address1
,json_value(orders.ShippingData, '$.address.address2') as ShippingData_address_address2
,json_value(orders.ShippingData, '$.address.city') as ShippingData_address_city
,json_value(orders.ShippingData, '$.address.state') as ShippingData_address_state
,json_value(orders.ShippingData, '$.address.zip') as ShippingData_address_zip
,json_value(orders.ShippingData, '$.address.county') as ShippingData_address_county
,json_value(orders.ShippingData, '$.address.country') as ShippingData_address_country
,json_value(orders.ShippingData, '$.shippingInstructions') as ShippingData_address_shippingInstructions
,json_value(orders.ShippingData, '$.verifyShippingAddress') as ShippingData_address_verifyShippingAddress


--ProviderData
--dba (doing business as)
,ProviderData
,json_value(orders.ProviderData, '$.providerLeagalBusinessName') as ProviderData_providerLeagalBusinessName
,json_value(orders.ProviderData, '$.dba') as ProviderData_dba
,json_value(orders.ProviderData, '$.dispenser') as ProviderData_dispenser
,json_value(orders.ProviderData, '$.emailId') as ProviderData_emailId

--ProviderData | address
,json_value(orders.ProviderData, '$.address.address') as ProviderData_address_address
,json_value(orders.ProviderData, '$.address.address1') as ProviderData_address_address1
,json_value(orders.ProviderData, '$.address.city') as ProviderData_address_city
,json_value(orders.ProviderData, '$.address.state') as ProviderData_address_state
,json_value(orders.ProviderData, '$.address.zip') as ProviderData_address_zip
,json_value(orders.ProviderData, '$.address.locationId') as ProviderData_address_locationId


--ProviderData | hcp
,json_value(orders.ProviderData, '$.hcp.firstName') as ProviderData_hcp_firstName
,json_value(orders.ProviderData, '$.hcp.lastName') as ProviderData_hcp_lastName
,json_value(orders.ProviderData, '$.hcp.npiNumber') as ProviderData_hcp_npinumber
,json_value(orders.ProviderData, '$.hcp.phoneNumber') as ProviderData_hcp_phoneNumber
,json_value(orders.ProviderData, '$.hcp.hcpid') as ProviderData_hcp_hcpid
,json_value(orders.ProviderData, '$.hcp.faxNumber') as ProviderData_hcp_faxNumber
,json_value(orders.ProviderData, '$.providerId') as ProviderData_providerId



-- BenefitsData
,json_value(orders.BenefitsData, '$.applied.benefitsLeft') as BenefitsData_applied_benefitsLeft
,json_value(orders.BenefitsData, '$.applied.benefitsRight') as BenefitsData_applied_benefitsRight
,json_value(orders.BenefitsData, '$.eligible.benefitsLeft') as BenefitsData_eligible_benefitsLeft
,json_value(orders.BenefitsData, '$.eligible.benefitsRight') as BenefitsData_eligible_benefitsRight
,json_value(orders.BenefitsData, '$.used.benefitsLeft') as BenefitsData_used_benefitsLeft
,json_value(orders.BenefitsData, '$.used.benefitsRight') as BenefitsData_used_benefitsRight
,json_value(orders.BenefitsData, '$.available.benefitsLeft') as BenefitsData_available_benefitsLeft
,json_value(orders.BenefitsData, '$.available.benefitsRight') as BenefitsData_available_benefitsRight
,json_value(orders.BenefitsData, '$.remaining.benefitsLeft') as BenefitsData_remaining_benefitsLeft
,json_value(orders.BenefitsData, '$.remaining.benefitsRight') as BenefitsData_remaining_benefitsRight
,json_value(orders.BenefitsData, '$.benefitAppliedAmount') as BenefitsData_benefitAppliedAmount
,json_value(orders.BenefitsData, '$.outOfPocket') as BenefitsData_outOfPocket
,json_value(orders.BenefitsData, '$.bencat') as BenefitsData_bencat
,json_value(orders.BenefitsData, '$.technologyLevel') as BenefitsData_technologyLevel
,json_value(orders.BenefitsData, '$.benfortype') as BenefitsData_benfortype
,json_value(orders.BenefitsData, '$.terminationDate') as BenefitsData_terminationDate
,json_value(orders.BenefitsData, '$.benfreqtype') as BenefitsData_benfreqtype



,json_value(orders.BenefitsData, '$.applied.devicesCount') as BenefitsData_applied_devicesCount
,json_value(orders.BenefitsData, '$.eligible.devicesCount') as BenefitsData_eligible_devicesCount
,json_value(orders.BenefitsData, '$.used.devicesCount') as BenefitsData_used_devicesCount
,json_value(orders.BenefitsData, '$.available.devicesCount') as BenefitsData_available_devicesCount
,json_value(orders.BenefitsData, '$.remaining.devicesCount') as BenefitsData_remaining_devicesCount


from orders.orders where NHMemberID in (select distinct NHmemberID from #TEligMaster) and SpecialInstructions not like '%Voucher%added%'
) a

select * from #TOrders


select
  o.NHMemberID
 ,o.Orderid
 ,o.CreateDate as OrderCreateDate
 ,o.ModifyDate as OrderModifyDate
 ,o.DateOrderInitiated
 ,o.DateOrderReceived
 ,b.RecordEffDate, b.RecordEnddate, b.CreateDate, b.ModifyDate
 ,b.SubscriberID, b.BenefitStartDate, b.BenefitEndDate, b.FirstName, b.LastName
 
 ,'Member Address at time of Order' as AddressAtOrder
--,MemberData_address
,rtrim (ltrim(replace(o.MemberData_address, ',',''))) as MemberData_addressNew
,rtrim (ltrim(o.MemberData_city)) as MemberData_city
,rtrim (ltrim(o.MemberData_state)) as MemberData_state
,rtrim (ltrim(o.MemberData_zip)) as MemberData_zip

,b.Address1, b.Address2, b.City, b.State, b.ZipCode

,o.ShippingData_address
,rtrim (ltrim(replace(o.ShippingData_address1, ',',''))) as ShippingData_address1
,rtrim (ltrim(replace(o.ShippingData_address2, ',',''))) as ShippingData_address2
,rtrim (ltrim(o.ShippingData_city)) as ShippingData_City
,rtrim (ltrim(o.ShippingData_state)) as ShippingData_State
,rtrim (ltrim(o.ShippingData_zip)) as ShippingData_ZipCode

--elig and Member Address


from  #TOrders o join #TEligMaster b on b.NHMemberID = o.NHMemberID 
where o.DateOrderReceived between RecordEffDate and RecordEndDate

--and o.NHMemberID = 'NH202107443798'
order by o.NHMemberID


select * from #TEligMaster where NHmemberID in (select distinct NHMemberID from #TOrders)