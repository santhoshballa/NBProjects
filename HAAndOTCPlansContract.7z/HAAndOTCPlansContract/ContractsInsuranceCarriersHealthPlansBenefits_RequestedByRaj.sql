select
              ic.InsuranceCarrierName  Carrier
              ,ihp.HealthPlanName PlanName
              ,ihp.HealthPlanNumber ContactPBP
              ,JSON_VALUE(BenefitRuleData, '$.BENCAT')        [Benfit Cat]
              ,JSON_VALUE(BenefitRuleData, '$.BENCATVALUE')    [Benfit Value]
              ,JSON_VALUE(BenefitRuleData, '$.BENTYPE')        [Benfit Type]
              ,JSON_VALUE(BenefitRuleData, '$.BENBEHV')        [Benfit Reset]
              ,JSON_VALUE(BenefitRuleData, '$.BENFREQMONTHS') [No of Reset Months]
              ,JSON_VALUE(BenefitRuleData, '$.BENFREQTYPE')    [FREQ TYPE]
              ,JSON_VALUE(BenefitRuleData, '$.BENFORTYPE')     [BenfitFORTYPE]
              ,JSON_VALUE(BenefitRuleData, '$.BENVALUESRC')    [Benfit Source]
              ,JSON_VALUE(BenefitRuleData, '$.WALCODE')        [Wallet Code]
              ,JSON_VALUE(BenefitRuleData, '$.APPLYMEMBERCOPAY')        [Member Copay]
              ,cast(hpc.EffectiveFromDate as date) as [Contract Effective From]
              ,cast(hpc.EffectiveToDate as date) as [Contract Effective To]
              ,cast(cr.EffectiveFrom as date) as [Contract Rule Effective From]
              ,cast(cr.EffectiveTo as date) as [Contract Rule Effective To]
              ,br.BenefitRuleData
              ,ihp.InsuranceHealthPlanID
              ,ihp.IsActive 
              ,hpc.HealthPlanContractID
              ,cr.ContractRuleId
              ,cr.BenefitRuleDataId
              ,ihp.InsuranceCarrierID
              
              From insurance.InsuranceCarriers ic
              inner join insurance.InsuranceHealthPlans ihp on (ic.InsuranceCarrierID = ihp.InsuranceCarrierID)
              left outer join insurance.HealthPlanContracts hpc on (ihp.InsuranceHealthPlanID = hpc.InsuranceHealthPlanID and hpc.IsActive = 1 and cast(getdate() as date) between cast(hpc.EffectiveFromDate as date) and cast(hpc.EffectiveToDate as date))
              left outer join insurance.ContractRules cr on (cr.HealthPlanContractId = hpc.HealthPlanContractId)-- and cr.IsActive=1 and cast(getdate() as date) between cast(cr.EffectiveFrom as date) and cast(cr.EffectiveTo as date))
              left outer join rulesengine.BenefitRulesData br on (cr.BenefitRuleDataId = br.BenefitRuleDataId and br.IsActive = 1) --and br.BenefitRuleId = 2)
              where 1=1
              --and ic.InsuranceCarrierID not in (16)
			  and ic.InsuranceCarrierID = 270
              and ic.IsActive = 1 and ihp.IsActive=1



select * from insurance.InsuranceCarriers where insuranceCarrierid = 270 and isactive = 1
select * from insurance.InsuranceHealthPlans where insuranceCarrierID =  270 and isactive = 1
select * from insurance.HealthPlanContracts where InsuranceCarrierID = 270 and isactive =1
select * from insurance.ContractRules where HealthPlanContractID in ( select HealthPlanContractID from insurance.HealthPlanContracts where InsuranceCarrierID = 270 and isactive =1 ) and IsActive = 1
select * from rulesengine.BenefitRulesData

-- Query to find all contracts for Insurance Carriers and Plans
select 
a.ContractRuleID, a.BenefitRuleDataID, a.HealthPlanContractID, a.EffectiveFrom, a.EffectiveTo, a.IsActive,
b.HealthPlanContractID, b.ContractName, b.Description, b.EffectiveFromDate, b.EffectiveToDate, b.InsuranceCarrierID, b.InsuranceHealthPlanID, b.IsActive,
c.BenefitRuleDataID, c.BenefitRuleID, c.BenefitRuleData, c.IsActive

from insurance.ContractRules a join insurance.HealthPlanContracts b on a.HealthPlanContractId = b.HealthPlanContractID
join rulesengine.BenefitRulesData c on a.BenefitRuleDataId = c.BenefitRuleDataId
where 
a.IsActive = 1 and b.IsActive =1 and c.IsActive = 1 and
b.InsuranceCarrierID in (select d.insuranceCarrierid from insurance.InsuranceCarriers d where IsActive =1 and InsuranceCarrierID = 270) and
b.InsuranceHealthPlanID in (select e.InsuranceHealthPlanID from insurance.InsuranceHealthPlans e where IsActive =1 and InsuranceCarrierID = 270 )
and cast(getdate() as date) between cast(b.EffectiveFromDate as date) and cast(b.EffectiveToDate as date)
and JSON_VALUE(c.BenefitRuleData, '$.BENTYPE') = 'HA'






/*
There are some OTC Plans that have Hearing Aid Benefits
*/

select a.Carrier, a.PlanName, a.ContactPBP, a.InsuranceHealthPlanID, a.InsuranceCarrierID,
b.[Benfit Value], b.[Benfit Type], b.[No of Reset Months], b.[Benfit Source], b.[Wallet Code] ,b.[Benfit Cat] ,b.[Member Copay], b.[Benfit Reset], b.[FREQ TYPE], b.BenfitFORTYPE, b.BenefitRuleData, 
b.[Contract Effective From], b.[Contract Effective To], b.[Contract Rule Effective From], b.[Contract Rule Effective To],
b.HealthPlanContractID, b.ContractRuleId ,b.BenefitRuleDataId
             
from (
			select 
			 ic.InsuranceCarrierName  Carrier
			,ihp.HealthPlanName PlanName
			,ihp.HealthPlanNumber ContactPBP
			,ihp.InsuranceHealthPlanID
			,ic.InsuranceCarrierID
			From insurance.InsuranceCarriers ic
			inner join insurance.InsuranceHealthPlans ihp on (ic.InsuranceCarrierID = ihp.InsuranceCarrierID)
			where ic.IsActive = 1 and ihp.IsActive = 1 and ic.InsuranceCarrierID = 270
			) a
			
			left outer join 
			
			(
              select
              ic.InsuranceCarrierName  Carrier
              ,ihp.HealthPlanName PlanName
              ,ihp.HealthPlanNumber ContactPBP
              ,JSON_VALUE(BenefitRuleData, '$.BENCAT')        [Benfit Cat]
              ,JSON_VALUE(BenefitRuleData, '$.BENCATVALUE')    [Benfit Value]
              ,JSON_VALUE(BenefitRuleData, '$.BENTYPE')        [Benfit Type]
              ,JSON_VALUE(BenefitRuleData, '$.BENBEHV')        [Benfit Reset]
              ,JSON_VALUE(BenefitRuleData, '$.BENFREQMONTHS') [No of Reset Months]
              ,JSON_VALUE(BenefitRuleData, '$.BENFREQTYPE')    [FREQ TYPE]
              ,JSON_VALUE(BenefitRuleData, '$.BENFORTYPE')     [BenfitFORTYPE]
              ,JSON_VALUE(BenefitRuleData, '$.BENVALUESRC')    [Benfit Source]
              ,JSON_VALUE(BenefitRuleData, '$.WALCODE')        [Wallet Code]
              ,JSON_VALUE(BenefitRuleData, '$.APPLYMEMBERCOPAY')        [Member Copay]
              ,cast(hpc.EffectiveFromDate as date) as [Contract Effective From]
              ,cast(hpc.EffectiveToDate as date) as [Contract Effective To]
              ,cast(cr.EffectiveFrom as date) as [Contract Rule Effective From]
              ,cast(cr.EffectiveTo as date) as [Contract Rule Effective To]
              ,br.BenefitRuleData
              ,ihp.InsuranceHealthPlanID
              ,ihp.IsActive 
              ,hpc.HealthPlanContractID
              ,cr.ContractRuleId
              ,cr.BenefitRuleDataId
              ,ihp.InsuranceCarrierID
              
              From insurance.InsuranceCarriers ic
              inner join insurance.InsuranceHealthPlans ihp on (ic.InsuranceCarrierID = ihp.InsuranceCarrierID)
              left outer join insurance.HealthPlanContracts hpc on (ihp.InsuranceHealthPlanID = hpc.InsuranceHealthPlanID and hpc.IsActive = 1 and cast(getdate() as date) between cast(hpc.EffectiveFromDate as date) and cast(hpc.EffectiveToDate as date))
              left outer join insurance.ContractRules cr on (cr.HealthPlanContractId = hpc.HealthPlanContractId)-- and cr.IsActive=1 and cast(getdate() as date) between cast(cr.EffectiveFrom as date) and cast(cr.EffectiveTo as date))
              left outer join rulesengine.BenefitRulesData br on (cr.BenefitRuleDataId = br.BenefitRuleDataId and br.IsActive = 1) --and br.BenefitRuleId = 2)
              where 1=1
              --and ic.InsuranceCarrierID not in (16)
              and ic.IsActive = 1
              and ihp.IsActive=1 
			) b 
			
			on (a.InsuranceCarrierID = b.InsuranceCarrierID and a.InsuranceHealthPlanID = b.InsuranceHealthPlanID and b.[Benfit Type] = 'HA' 
)
--where a.InsuranceCarrierID = 358






/*
There are some OTC Plans that have Hearing Aid Benefits
*/

select a.Carrier, a.PlanName, a.ContactPBP, a.InsuranceHealthPlanID, a.InsuranceCarrierID,
b.[Benfit Value], b.[Benfit Type], b.[No of Reset Months], b.[Benfit Source], b.[Wallet Code] ,b.[Benfit Cat] ,b.[Member Copay], b.[Benfit Reset], b.[FREQ TYPE], b.BenfitFORTYPE, b.BenefitRuleData, 
b.[Contract Effective From], b.[Contract Effective To], b.[Contract Rule Effective From], b.[Contract Rule Effective To],
b.HealthPlanContractID, b.ContractRuleId ,b.BenefitRuleDataId
             
from (
			select 
			 ic.InsuranceCarrierName  Carrier
			,ihp.HealthPlanName PlanName
			,ihp.HealthPlanNumber ContactPBP
			,ihp.InsuranceHealthPlanID
			,ic.InsuranceCarrierID
			From insurance.InsuranceCarriers ic
			inner join insurance.InsuranceHealthPlans ihp on (ic.InsuranceCarrierID = ihp.InsuranceCarrierID)
			where ic.IsActive = 1 and ihp.IsActive = 1 and ic.InsuranceCarrierID = 270
			) a
			
			left outer join 
			
			(
              select
              ic.InsuranceCarrierName  Carrier
              ,ihp.HealthPlanName PlanName
              ,ihp.HealthPlanNumber ContactPBP
              ,JSON_VALUE(BenefitRuleData, '$.BENCAT')        [Benfit Cat]
              ,JSON_VALUE(BenefitRuleData, '$.BENCATVALUE')    [Benfit Value]
              ,JSON_VALUE(BenefitRuleData, '$.BENTYPE')        [Benfit Type]
              ,JSON_VALUE(BenefitRuleData, '$.BENBEHV')        [Benfit Reset]
              ,JSON_VALUE(BenefitRuleData, '$.BENFREQMONTHS') [No of Reset Months]
              ,JSON_VALUE(BenefitRuleData, '$.BENFREQTYPE')    [FREQ TYPE]
              ,JSON_VALUE(BenefitRuleData, '$.BENFORTYPE')     [BenfitFORTYPE]
              ,JSON_VALUE(BenefitRuleData, '$.BENVALUESRC')    [Benfit Source]
              ,JSON_VALUE(BenefitRuleData, '$.WALCODE')        [Wallet Code]
              ,JSON_VALUE(BenefitRuleData, '$.APPLYMEMBERCOPAY')        [Member Copay]
              ,cast(hpc.EffectiveFromDate as date) as [Contract Effective From]
              ,cast(hpc.EffectiveToDate as date) as [Contract Effective To]
              ,cast(cr.EffectiveFrom as date) as [Contract Rule Effective From]
              ,cast(cr.EffectiveTo as date) as [Contract Rule Effective To]
              ,br.BenefitRuleData
              ,ihp.InsuranceHealthPlanID
              ,ihp.IsActive 
              ,hpc.HealthPlanContractID
              ,cr.ContractRuleId
              ,cr.BenefitRuleDataId
              ,ihp.InsuranceCarrierID
              
              From insurance.InsuranceCarriers ic
              inner join insurance.InsuranceHealthPlans ihp on (ic.InsuranceCarrierID = ihp.InsuranceCarrierID)
			  join insurance.HealthPlanContracts hpc on (ihp.InsuranceHealthPlanID = hpc.InsuranceHealthPlanID and hpc.IsActive = 1 and cast(getdate() as date) between cast(hpc.EffectiveFromDate as date) and cast(hpc.EffectiveToDate as date))
              join insurance.ContractRules cr on (cr.HealthPlanContractId = hpc.HealthPlanContractId)-- and cr.IsActive=1 and cast(getdate() as date) between cast(cr.EffectiveFrom as date) and cast(cr.EffectiveTo as date))
              join rulesengine.BenefitRulesData br on  (cr.BenefitRuleDataId = br.BenefitRuleDataId and br.IsActive = 1) --and br.BenefitRuleId = 2)


              --left outer join insurance.HealthPlanContracts hpc on (ihp.InsuranceHealthPlanID = hpc.InsuranceHealthPlanID and hpc.IsActive = 1 and cast(getdate() as date) between cast(hpc.EffectiveFromDate as date) and cast(hpc.EffectiveToDate as date))
              --left outer join insurance.ContractRules cr on (cr.HealthPlanContractId = hpc.HealthPlanContractId)-- and cr.IsActive=1 and cast(getdate() as date) between cast(cr.EffectiveFrom as date) and cast(cr.EffectiveTo as date))
              --left outer join rulesengine.BenefitRulesData br on (cr.BenefitRuleDataId = br.BenefitRuleDataId and br.IsActive = 1) --and br.BenefitRuleId = 2)
              where 1=1
              --and ic.InsuranceCarrierID not in (16)
			  and ic.InsuranceCarrierID = 270
              and ic.IsActive = 1
              and ihp.IsActive=1 
			) b 
			
			on (a.InsuranceCarrierID = b.InsuranceCarrierID and a.InsuranceHealthPlanID = b.InsuranceHealthPlanID and b.[Benfit Type] = 'HA' 
)
--where a.InsuranceCarrierID = 358




select a.Carrier, a.PlanName, a.ContactPBP, a.InsuranceHealthPlanID, a.InsuranceCarrierID,
b.[Benfit Value], b.[Benfit Type], b.[No of Reset Months], b.[Benfit Source], b.[Wallet Code] ,b.[Benfit Cat] ,b.[Member Copay], b.[Benfit Reset], b.[FREQ TYPE], b.BenfitFORTYPE, b.BenefitRuleData, 
b.[Contract Effective From], b.[Contract Effective To], b.[Contract Rule Effective From], b.[Contract Rule Effective To],
b.HealthPlanContractID, b.ContractRuleId ,b.BenefitRuleDataId
             
from (
			select 
			 ic.InsuranceCarrierName  Carrier
			,ihp.HealthPlanName PlanName
			,ihp.HealthPlanNumber ContactPBP
			,ihp.InsuranceHealthPlanID
			,ic.InsuranceCarrierID
			From insurance.InsuranceCarriers ic
			inner join insurance.InsuranceHealthPlans ihp on (ic.InsuranceCarrierID = ihp.InsuranceCarrierID)
			where ic.IsActive = 1 and ihp.IsActive = 1 and ic.InsuranceCarrierID = 270
			) a
			
			join 
			
			(
              select
              ic.InsuranceCarrierName  Carrier
              ,ihp.HealthPlanName PlanName
              ,ihp.HealthPlanNumber ContactPBP
              ,JSON_VALUE(BenefitRuleData, '$.BENCAT')        [Benfit Cat]
              ,JSON_VALUE(BenefitRuleData, '$.BENCATVALUE')    [Benfit Value]
              ,JSON_VALUE(BenefitRuleData, '$.BENTYPE')        [Benfit Type]
              ,JSON_VALUE(BenefitRuleData, '$.BENBEHV')        [Benfit Reset]
              ,JSON_VALUE(BenefitRuleData, '$.BENFREQMONTHS') [No of Reset Months]
              ,JSON_VALUE(BenefitRuleData, '$.BENFREQTYPE')    [FREQ TYPE]
              ,JSON_VALUE(BenefitRuleData, '$.BENFORTYPE')     [BenfitFORTYPE]
              ,JSON_VALUE(BenefitRuleData, '$.BENVALUESRC')    [Benfit Source]
              ,JSON_VALUE(BenefitRuleData, '$.WALCODE')        [Wallet Code]
              ,JSON_VALUE(BenefitRuleData, '$.APPLYMEMBERCOPAY')        [Member Copay]
              ,cast(hpc.EffectiveFromDate as date) as [Contract Effective From]
              ,cast(hpc.EffectiveToDate as date) as [Contract Effective To]
              ,cast(cr.EffectiveFrom as date) as [Contract Rule Effective From]
              ,cast(cr.EffectiveTo as date) as [Contract Rule Effective To]
              ,br.BenefitRuleData
              ,ihp.InsuranceHealthPlanID
              ,ihp.IsActive 
              ,hpc.HealthPlanContractID
              ,cr.ContractRuleId
              ,cr.BenefitRuleDataId
              ,ihp.InsuranceCarrierID
              
              From insurance.InsuranceCarriers ic
              inner join insurance.InsuranceHealthPlans ihp on (ic.InsuranceCarrierID = ihp.InsuranceCarrierID)
			  join insurance.HealthPlanContracts hpc on (ihp.InsuranceHealthPlanID = hpc.InsuranceHealthPlanID and hpc.IsActive = 1 and cast(getdate() as date) between cast(hpc.EffectiveFromDate as date) and cast(hpc.EffectiveToDate as date))
              join insurance.ContractRules cr on (cr.HealthPlanContractId = hpc.HealthPlanContractId)-- and cr.IsActive=1 and cast(getdate() as date) between cast(cr.EffectiveFrom as date) and cast(cr.EffectiveTo as date))
              join rulesengine.BenefitRulesData br on  (cr.BenefitRuleDataId = br.BenefitRuleDataId and br.IsActive = 1) --and br.BenefitRuleId = 2)


              --left outer join insurance.HealthPlanContracts hpc on (ihp.InsuranceHealthPlanID = hpc.InsuranceHealthPlanID and hpc.IsActive = 1 and cast(getdate() as date) between cast(hpc.EffectiveFromDate as date) and cast(hpc.EffectiveToDate as date))
              --left outer join insurance.ContractRules cr on (cr.HealthPlanContractId = hpc.HealthPlanContractId)-- and cr.IsActive=1 and cast(getdate() as date) between cast(cr.EffectiveFrom as date) and cast(cr.EffectiveTo as date))
              --left outer join rulesengine.BenefitRulesData br on (cr.BenefitRuleDataId = br.BenefitRuleDataId and br.IsActive = 1) --and br.BenefitRuleId = 2)
              where 1=1
              --and ic.InsuranceCarrierID not in (16)
			  and ic.InsuranceCarrierID = 270
              and ic.IsActive = 1
              and ihp.IsActive=1
			  and cr.IsActive =1
			) b 
			
			on (a.InsuranceCarrierID = b.InsuranceCarrierID and a.InsuranceHealthPlanID = b.InsuranceHealthPlanID and b.[Benfit Type] = 'HA' 
)





     select
              ic.InsuranceCarrierName  Carrier
              ,ihp.HealthPlanName PlanName
              ,ihp.HealthPlanNumber ContactPBP
              ,JSON_VALUE(BenefitRuleData, '$.BENCAT')        [Benfit Cat]
              ,JSON_VALUE(BenefitRuleData, '$.BENCATVALUE')    [Benfit Value]
              ,JSON_VALUE(BenefitRuleData, '$.BENTYPE')        [Benfit Type]
              ,JSON_VALUE(BenefitRuleData, '$.BENBEHV')        [Benfit Reset]
              ,JSON_VALUE(BenefitRuleData, '$.BENFREQMONTHS') [No of Reset Months]
              ,JSON_VALUE(BenefitRuleData, '$.BENFREQTYPE')    [FREQ TYPE]
              ,JSON_VALUE(BenefitRuleData, '$.BENFORTYPE')     [BenfitFORTYPE]
              ,JSON_VALUE(BenefitRuleData, '$.BENVALUESRC')    [Benfit Source]
              ,JSON_VALUE(BenefitRuleData, '$.WALCODE')        [Wallet Code]
              ,JSON_VALUE(BenefitRuleData, '$.APPLYMEMBERCOPAY')        [Member Copay]
              ,cast(hpc.EffectiveFromDate as date) as [Contract Effective From]
              ,cast(hpc.EffectiveToDate as date) as [Contract Effective To]
              ,cast(cr.EffectiveFrom as date) as [Contract Rule Effective From]
              ,cast(cr.EffectiveTo as date) as [Contract Rule Effective To]
              ,br.BenefitRuleData
              ,ihp.InsuranceHealthPlanID
              ,ihp.IsActive 
              ,hpc.HealthPlanContractID
              ,cr.ContractRuleId
              ,cr.BenefitRuleDataId
              ,ihp.InsuranceCarrierID
              
              From insurance.InsuranceCarriers ic
              inner join insurance.InsuranceHealthPlans ihp on (ic.InsuranceCarrierID = ihp.InsuranceCarrierID)
			  --join insurance.HealthPlanContracts hpc on (ihp.InsuranceHealthPlanID = hpc.InsuranceHealthPlanID and hpc.IsActive = 1 and cast(getdate() as date) between cast(hpc.EffectiveFromDate as date) and cast(hpc.EffectiveToDate as date))
              --join insurance.ContractRules cr on (cr.HealthPlanContractId = hpc.HealthPlanContractId)-- and cr.IsActive=1 and cast(getdate() as date) between cast(cr.EffectiveFrom as date) and cast(cr.EffectiveTo as date))
              --join rulesengine.BenefitRulesData br on  (cr.BenefitRuleDataId = br.BenefitRuleDataId and br.IsActive = 1) --and br.BenefitRuleId = 2)


				left outer join insurance.HealthPlanContracts hpc on (ihp.InsuranceHealthPlanID = hpc.InsuranceHealthPlanID and hpc.IsActive = 1 and cast(getdate() as date) between cast(hpc.EffectiveFromDate as date) and cast(hpc.EffectiveToDate as date))
				left outer join insurance.ContractRules cr on (cr.HealthPlanContractId = hpc.HealthPlanContractId)-- and cr.IsActive=1 and cast(getdate() as date) between cast(cr.EffectiveFrom as date) and cast(cr.EffectiveTo as date))
				left outer join rulesengine.BenefitRulesData br on (cr.BenefitRuleDataId = br.BenefitRuleDataId and br.IsActive = 1) --and br.BenefitRuleId = 2)
              where 1=1
              --and ic.InsuranceCarrierID not in (16)
			  and ic.InsuranceCarrierID = 270
              and ic.IsActive = 1
              and ihp.IsActive=1 
	 
	 except
	 
	 
	 select
              ic.InsuranceCarrierName  Carrier
              ,ihp.HealthPlanName PlanName
              ,ihp.HealthPlanNumber ContactPBP
              ,JSON_VALUE(BenefitRuleData, '$.BENCAT')        [Benfit Cat]
              ,JSON_VALUE(BenefitRuleData, '$.BENCATVALUE')    [Benfit Value]
              ,JSON_VALUE(BenefitRuleData, '$.BENTYPE')        [Benfit Type]
              ,JSON_VALUE(BenefitRuleData, '$.BENBEHV')        [Benfit Reset]
              ,JSON_VALUE(BenefitRuleData, '$.BENFREQMONTHS') [No of Reset Months]
              ,JSON_VALUE(BenefitRuleData, '$.BENFREQTYPE')    [FREQ TYPE]
              ,JSON_VALUE(BenefitRuleData, '$.BENFORTYPE')     [BenfitFORTYPE]
              ,JSON_VALUE(BenefitRuleData, '$.BENVALUESRC')    [Benfit Source]
              ,JSON_VALUE(BenefitRuleData, '$.WALCODE')        [Wallet Code]
              ,JSON_VALUE(BenefitRuleData, '$.APPLYMEMBERCOPAY')        [Member Copay]
              ,cast(hpc.EffectiveFromDate as date) as [Contract Effective From]
              ,cast(hpc.EffectiveToDate as date) as [Contract Effective To]
              ,cast(cr.EffectiveFrom as date) as [Contract Rule Effective From]
              ,cast(cr.EffectiveTo as date) as [Contract Rule Effective To]
              ,br.BenefitRuleData
              ,ihp.InsuranceHealthPlanID
              ,ihp.IsActive 
              ,hpc.HealthPlanContractID
              ,cr.ContractRuleId
              ,cr.BenefitRuleDataId
              ,ihp.InsuranceCarrierID
              
              From insurance.InsuranceCarriers ic
              inner join insurance.InsuranceHealthPlans ihp on (ic.InsuranceCarrierID = ihp.InsuranceCarrierID)
			  join insurance.HealthPlanContracts hpc on (ihp.InsuranceHealthPlanID = hpc.InsuranceHealthPlanID and hpc.IsActive = 1 and cast(getdate() as date) between cast(hpc.EffectiveFromDate as date) and cast(hpc.EffectiveToDate as date))
              join insurance.ContractRules cr on (cr.HealthPlanContractId = hpc.HealthPlanContractId)-- and cr.IsActive=1 and cast(getdate() as date) between cast(cr.EffectiveFrom as date) and cast(cr.EffectiveTo as date))
              join rulesengine.BenefitRulesData br on  (cr.BenefitRuleDataId = br.BenefitRuleDataId and br.IsActive = 1) --and br.BenefitRuleId = 2)


              --left outer join insurance.HealthPlanContracts hpc on (ihp.InsuranceHealthPlanID = hpc.InsuranceHealthPlanID and hpc.IsActive = 1 and cast(getdate() as date) between cast(hpc.EffectiveFromDate as date) and cast(hpc.EffectiveToDate as date))
              --left outer join insurance.ContractRules cr on (cr.HealthPlanContractId = hpc.HealthPlanContractId)-- and cr.IsActive=1 and cast(getdate() as date) between cast(cr.EffectiveFrom as date) and cast(cr.EffectiveTo as date))
              --left outer join rulesengine.BenefitRulesData br on (cr.BenefitRuleDataId = br.BenefitRuleDataId and br.IsActive = 1) --and br.BenefitRuleId = 2)
              where 1=1
              --and ic.InsuranceCarrierID not in (16)
			  and ic.InsuranceCarrierID = 270
              and ic.IsActive = 1
              and ihp.IsActive=1 



select a.Carrier, a.PlanName, a.ContactPBP, a.InsuranceHealthPlanID, a.InsuranceCarrierID,
b.[Benfit Value], b.[Benfit Type], b.[No of Reset Months], b.[Benfit Source], b.[Wallet Code] ,b.[Benfit Cat] ,b.[Member Copay], b.[Benfit Reset], b.[FREQ TYPE], b.BenfitFORTYPE, b.BenefitRuleData, 
b.[Contract Effective From], b.[Contract Effective To], b.[Contract Rule Effective From], b.[Contract Rule Effective To],
b.HealthPlanContractID, b.ContractRuleId ,b.BenefitRuleDataId
             
from (
			select 
			 ic.InsuranceCarrierName  Carrier
			,ihp.HealthPlanName PlanName
			,ihp.HealthPlanNumber ContactPBP
			,ihp.InsuranceHealthPlanID
			,ic.InsuranceCarrierID
			From insurance.InsuranceCarriers ic
			inner join insurance.InsuranceHealthPlans ihp on (ic.InsuranceCarrierID = ihp.InsuranceCarrierID)
			where ic.IsActive = 1 and ihp.IsActive = 1 and ic.InsuranceCarrierID = 270
			) a
			
			left outer join 
			
			(
              select
              ic.InsuranceCarrierName  Carrier
              ,ihp.HealthPlanName PlanName
              ,ihp.HealthPlanNumber ContactPBP
              ,JSON_VALUE(BenefitRuleData, '$.BENCAT')        [Benfit Cat]
              ,JSON_VALUE(BenefitRuleData, '$.BENCATVALUE')    [Benfit Value]
              ,JSON_VALUE(BenefitRuleData, '$.BENTYPE')        [Benfit Type]
              ,JSON_VALUE(BenefitRuleData, '$.BENBEHV')        [Benfit Reset]
              ,JSON_VALUE(BenefitRuleData, '$.BENFREQMONTHS') [No of Reset Months]
              ,JSON_VALUE(BenefitRuleData, '$.BENFREQTYPE')    [FREQ TYPE]
              ,JSON_VALUE(BenefitRuleData, '$.BENFORTYPE')     [BenfitFORTYPE]
              ,JSON_VALUE(BenefitRuleData, '$.BENVALUESRC')    [Benfit Source]
              ,JSON_VALUE(BenefitRuleData, '$.WALCODE')        [Wallet Code]
              ,JSON_VALUE(BenefitRuleData, '$.APPLYMEMBERCOPAY')        [Member Copay]
              ,cast(hpc.EffectiveFromDate as date) as [Contract Effective From]
              ,cast(hpc.EffectiveToDate as date) as [Contract Effective To]
              ,cast(cr.EffectiveFrom as date) as [Contract Rule Effective From]
              ,cast(cr.EffectiveTo as date) as [Contract Rule Effective To]
              ,br.BenefitRuleData
              ,ihp.InsuranceHealthPlanID
              ,ihp.IsActive 
              ,hpc.HealthPlanContractID
              ,cr.ContractRuleId
              ,cr.BenefitRuleDataId
              ,ihp.InsuranceCarrierID
              
              From insurance.InsuranceCarriers ic
              inner join insurance.InsuranceHealthPlans ihp on (ic.InsuranceCarrierID = ihp.InsuranceCarrierID)
			  join insurance.HealthPlanContracts hpc on (ihp.InsuranceHealthPlanID = hpc.InsuranceHealthPlanID and hpc.IsActive = 1 and cast(getdate() as date) between cast(hpc.EffectiveFromDate as date) and cast(hpc.EffectiveToDate as date))
              join insurance.ContractRules cr on (cr.HealthPlanContractId = hpc.HealthPlanContractId)-- and cr.IsActive=1 and cast(getdate() as date) between cast(cr.EffectiveFrom as date) and cast(cr.EffectiveTo as date))
              join rulesengine.BenefitRulesData br on  (cr.BenefitRuleDataId = br.BenefitRuleDataId and br.IsActive = 1) --and br.BenefitRuleId = 2)


              --left outer join insurance.HealthPlanContracts hpc on (ihp.InsuranceHealthPlanID = hpc.InsuranceHealthPlanID and hpc.IsActive = 1 and cast(getdate() as date) between cast(hpc.EffectiveFromDate as date) and cast(hpc.EffectiveToDate as date))
              --left outer join insurance.ContractRules cr on (cr.HealthPlanContractId = hpc.HealthPlanContractId)-- and cr.IsActive=1 and cast(getdate() as date) between cast(cr.EffectiveFrom as date) and cast(cr.EffectiveTo as date))
              --left outer join rulesengine.BenefitRulesData br on (cr.BenefitRuleDataId = br.BenefitRuleDataId and br.IsActive = 1) --and br.BenefitRuleId = 2)
              where 1=1
              --and ic.InsuranceCarrierID not in (16)
			  and ic.InsuranceCarrierID = 270
              and ic.IsActive = 1
              and ihp.IsActive=1 
			) b 
			
			on (a.InsuranceCarrierID = b.InsuranceCarrierID and a.InsuranceHealthPlanID = b.InsuranceHealthPlanID and b.[Benfit Type] = 'HA' 
)