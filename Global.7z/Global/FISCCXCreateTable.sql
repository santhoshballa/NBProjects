USE [NHCRM_STG]
GO

/****** Object:  Table [dbo].[FISCCXStg]    Script Date: 12/5/2022 6:16:18 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
drop table [dbo].[FISCCXStg]
CREATE TABLE [dbo].[FISCCXStg](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[F1] [varchar](max) NULL,
	[F2] [varchar](max) NULL,
	[F3] [varchar](max) NULL,
	[F4] [varchar](max) NULL,
	[F5] [varchar](max) NULL,
	[F6] [varchar](max) NULL,
	[F7] [varchar](max) NULL,
	[F8] [varchar](max) NULL,
	[F9] [varchar](max) NULL,
	[F10] [varchar](max) NULL,
	[F11] [varchar](max) NULL,
	[F12] [varchar](max) NULL,
	[F13] [varchar](max) NULL,
	[F14] [varchar](max) NULL,
	[F15] [varchar](max) NULL,
	[F16] [varchar](max) NULL,
	[F17] [varchar](max) NULL,
	[F18] [varchar](max) NULL,
	[F19] [varchar](max) NULL,
	[F20] [varchar](max) NULL,
	[F21] [varchar](max) NULL,
	[F22] [varchar](max) NULL,
	[F23] [varchar](max) NULL,
	[F24] [varchar](max) NULL,
	[F25] [varchar](max) NULL,
	[F26] [varchar](max) NULL,
	[F27] [varchar](max) NULL,
	[F28] [varchar](max) NULL,
	[F29] [varchar](max) NULL,
	[F30] [varchar](max) NULL,
	[F31] [varchar](max) NULL,
	[F32] [varchar](max) NULL,
	[F33] [varchar](max) NULL,
	[F34] [varchar](max) NULL,
	[F35] [varchar](max) NULL,
	[F36] [varchar](max) NULL,
	[F37] [varchar](max) NULL,
	[F38] [varchar](max) NULL,
	[F39] [varchar](max) NULL,
	[F40] [varchar](max) NULL,
	[F41] [varchar](max) NULL,
	[F42] [varchar](max) NULL,
	[F43] [varchar](max) NULL,
	[F44] [varchar](max) NULL,
	[F45] [varchar](max) NULL,
	[F46] [varchar](max) NULL,
	[F47] [varchar](max) NULL,
	[F48] [varchar](max) NULL,
	[F49] [varchar](max) NULL,
	[F50] [varchar](max) NULL,
	[F51] [varchar](max) NULL,
	[F52] [varchar](max) NULL,
	[F53] [varchar](max) NULL,
	[F54] [varchar](max) NULL,
	[F55] [varchar](max) NULL,
	[F56] [varchar](max) NULL,
	[F57] [varchar](max) NULL,
	[F58] [varchar](max) NULL,
	[F59] [varchar](max) NULL,
	[F60] [varchar](max) NULL,
	[F61] [varchar](max) NULL,
	[F62] [varchar](max) NULL,
	[F63] [varchar](max) NULL,
	[F64] [varchar](max) NULL,
	[F65] [varchar](max) NULL,
	[F66] [varchar](max) NULL,
	[F67] [varchar](max) NULL,
	[F68] [varchar](max) NULL,
	[F69] [varchar](max) NULL,
	[F70] [varchar](max) NULL,
	[F71] [varchar](max) NULL,
	[F72] [varchar](max) NULL,
	[F73] [varchar](max) NULL,
	[F74] [varchar](max) NULL,
	[F75] [varchar](max) NULL,
	[F76] [varchar](max) NULL,
	[F77] [varchar](max) NULL,
	[F78] [varchar](max) NULL,
	[F79] [varchar](max) NULL,
	[F80] [varchar](max) NULL,
	[F81] [varchar](max) NULL,
	[F82] [varchar](max) NULL,
	[F83] [varchar](max) NULL,
	[F84] [varchar](max) NULL,
	[F85] [varchar](max) NULL,
	[F86] [varchar](max) NULL,
	[F87] [varchar](max) NULL,
	[F88] [varchar](max) NULL,
	[F89] [varchar](max) NULL,
	[F90] [varchar](max) NULL,
	[F91] [varchar](max) NULL,
	[F92] [varchar](max) NULL,
	[F93] [varchar](max) NULL,
	[F94] [varchar](max) NULL,
	[F95] [varchar](max) NULL,
	[F96] [varchar](max) NULL,
	[F97] [varchar](max) NULL,
	[F98] [varchar](max) NULL,
	[F99] [varchar](max) NULL,
	[F100] [varchar](max) NULL,
	[F101] [varchar](max) NULL,
	[F102] [varchar](max) NULL,
	[F103] [varchar](max) NULL,
	[F104] [varchar](max) NULL,
	[F105] [varchar](max) NULL,
	[F106] [varchar](max) NULL,
	[F107] [varchar](max) NULL,
	[F108] [varchar](max) NULL,
	[F109] [varchar](max) NULL,
	[F110] [varchar](max) NULL,
	[F111] [varchar](max) NULL,
	[F112] [varchar](max) NULL,
	[F113] [varchar](max) NULL,
	[F114] [varchar](max) NULL,
	[F115] [varchar](max) NULL,
	[F116] [varchar](max) NULL,
	[F117] [varchar](max) NULL,
	[F118] [varchar](max) NULL,
	[F119] [varchar](max) NULL,
	[F120] [varchar](max) NULL,
	[F121] [varchar](max) NULL,
	[F122] [varchar](max) NULL,
	[F123] [varchar](max) NULL,
	[F124] [varchar](max) NULL,
	[F125] [varchar](max) NULL,
	[F126] [varchar](max) NULL,
	[F127] [varchar](max) NULL,
	[F128] [varchar](max) NULL,
	[F129] [varchar](max) NULL,
	[F130] [varchar](max) NULL,
	[F131] [varchar](max) NULL,
	[F132] [varchar](max) NULL,
	[F133] [varchar](max) NULL,
	[F134] [varchar](max) NULL,
	[F135] [varchar](max) NULL,
	[F136] [varchar](max) NULL,
	[F137] [varchar](max) NULL,
	[F138] [varchar](max) NULL,
	[F139] [varchar](max) NULL,
	[F140] [varchar](max) NULL,
	[F141] [varchar](max) NULL,
	[F142] [varchar](max) NULL,
	[F143] [varchar](max) NULL,
	[F144] [varchar](max) NULL,
	[F145] [varchar](max) NULL,
	[F146] [varchar](max) NULL,
	[F147] [varchar](max) NULL,
	[F148] [varchar](max) NULL,
	[F149] [varchar](max) NULL,
	[F150] [varchar](max) NULL,
	[F151] [varchar](max) NULL,
	[F152] [varchar](max) NULL,
	[F153] [varchar](max) NULL,
	[F154] [varchar](max) NULL,
	[F155] [varchar](max) NULL,
	[F156] [varchar](max) NULL,
	[F157] [varchar](max) NULL,
	[F158] [varchar](max) NULL,
	[F159] [varchar](max) NULL,
	[F160] [varchar](max) NULL,
	[F161] [varchar](max) NULL,
	[F162] [varchar](max) NULL,
	[F163] [varchar](max) NULL,
	[F164] [varchar](max) NULL,
	[F165] [varchar](max) NULL,
	[F166] [varchar](max) NULL,
	[F167] [varchar](max) NULL,
	[F168] [varchar](max) NULL,
	[F169] [varchar](max) NULL,
	[F170] [varchar](max) NULL,
	[F171] [varchar](max) NULL,
	[F172] [varchar](max) NULL,
	[F173] [varchar](max) NULL,
	[F174] [varchar](max) NULL,
	[F175] [varchar](max) NULL,
	[F176] [varchar](max) NULL,
	[F177] [varchar](max) NULL,
	[F178] [varchar](max) NULL,
	[F179] [varchar](max) NULL,
	[F180] [varchar](max) NULL,
	[F181] [varchar](max) NULL,
	[F182] [varchar](max) NULL,
	[F183] [varchar](max) NULL,
	[F184] [varchar](max) NULL,
	[F185] [varchar](max) NULL,
	[F186] [varchar](max) NULL,
	[F187] [varchar](max) NULL,
	[F188] [varchar](max) NULL,
	[F189] [varchar](max) NULL,
	[F190] [varchar](max) NULL,
	[F191] [varchar](max) NULL,
	[F192] [varchar](max) NULL,
	[F193] [varchar](max) NULL,
	[F194] [varchar](max) NULL,
	[F195] [varchar](max) NULL,
	[F196] [varchar](max) NULL,
	[F197] [varchar](max) NULL,
	[F198] [varchar](max) NULL,
	[F199] [varchar](max) NULL,
	[F200] [varchar](max) NULL,
	[F201] [varchar](max) NULL,
	[F202] [varchar](max) NULL,
	[F203] [varchar](max) NULL,
	[F204] [varchar](max) NULL,
	[F205] [varchar](max) NULL,
	[F206] [varchar](max) NULL,
	[F207] [varchar](max) NULL,
	[F208] [varchar](max) NULL,
	[F209] [varchar](max) NULL,
	[F210] [varchar](max) NULL,
	[F211] [varchar](max) NULL,
	[F212] [varchar](max) NULL,
	[F213] [varchar](max) NULL,
	[F214] [varchar](max) NULL,
	[F215] [varchar](max) NULL,
	[F216] [varchar](max) NULL,
	[F217] [varchar](max) NULL,
	[F218] [varchar](max) NULL,
	[F219] [varchar](max) NULL,
	[F220] [varchar](max) NULL,
	[F221] [varchar](max) NULL,
	[F222] [varchar](max) NULL,
	[F223] [varchar](max) NULL,
	[F224] [varchar](max) NULL,
	[F225] [varchar](max) NULL,
	[F226] [varchar](max) NULL,
	[F227] [varchar](max) NULL,
	[F228] [varchar](max) NULL,
	[F229] [varchar](max) NULL,
	[F230] [varchar](max) NULL,
	[F231] [varchar](max) NULL,
	[F232] [varchar](max) NULL,
	[F233] [varchar](max) NULL,
	[F234] [varchar](max) NULL,
	[F235] [varchar](max) NULL,
	[F236] [varchar](max) NULL,
	[F237] [varchar](max) NULL,
	[F238] [varchar](max) NULL,
	[F239] [varchar](max) NULL,
	[F240] [varchar](max) NULL,
	[F241] [varchar](max) NULL,
	[F242] [varchar](max) NULL,
	[F243] [varchar](max) NULL,
	[F244] [varchar](max) NULL,
	[F245] [varchar](max) NULL,
	[F246] [varchar](max) NULL,
	[F247] [varchar](max) NULL,
	[F248] [varchar](max) NULL,
	[F249] [varchar](max) NULL,
	[F250] [varchar](max) NULL,
	[FileName] [varchar](max) NULL,
	[IsActive] int default 1,
	[CreateUser] [varchar](max) NULL,
	[CreateDate] [datetime] NULL,
	[ModifyUser] [varchar](max) NULL,
	[ModifyDate] [datetime] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [dbo].[FISCCXStg] ADD  DEFAULT (suser_sname()) FOR [CreateUser]
GO

ALTER TABLE [dbo].[FISCCXStg] ADD  DEFAULT (getdate()) FOR [CreateDate]
GO

ALTER TABLE [dbo].[FISCCXStg] ADD  DEFAULT (suser_sname()) FOR [ModifyUser]
GO

ALTER TABLE [dbo].[FISCCXStg] ADD  DEFAULT (getdate()) FOR [ModifyDate]
GO

select distinct FileName from [dbo].[FISCCXStg]
select * from [dbo].[FISCCXStg]
select distinct F1 from [dbo].[FISCCXStg]
/*
DODL
H
DPUR
DPKG
DCST
DPRY
DUSR
T
DSPG
DIIA
*/

Select * from [dbo].[FISCCXStg] where F1 = 'H'
Select * from [dbo].[FISCCXStg] where F1 = 'DODL'
Select * from [dbo].[FISCCXStg] where F1 = 'DPUR'
Select * from [dbo].[FISCCXStg] where F1 = 'DPKG'
Select * from [dbo].[FISCCXStg] where F1 = 'DCST'
Select * from [dbo].[FISCCXStg] where F1 = 'DPRY'
Select * from [dbo].[FISCCXStg] where F1 = 'DUSR'
Select * from [dbo].[FISCCXStg] where F1 = 'DSPG'
Select * from [dbo].[FISCCXStg] where F1 = 'DIIA'
Select * from [dbo].[FISCCXStg] where F1 = 'T'




select
'select top 100 * from
(' +
'select distinct  ' 
+''''+TABLE_SCHEMA+''''+' as TABLE_SCHEMA,' 
+''''+ TABLE_NAME+'''' + ' as TABLE_NAME,' 
+''''+ COLUMN_NAME +''''+ ' as COLUMN_NAME,' 
+ 'F1 as Category,'
+ 'QUOTENAME(ltrim(rtrim(cast(' +'['+ COLUMN_NAME+']' + ' as nvarchar))),' + '''"'''+') as VALUE from ' 
+ TABLE_SCHEMA +'.'+ '['+TABLE_NAME+']' +
') a union '
from  information_Schema.COLUMNS
where table_schema = 'dbo' and data_type not in ('image', 'varbinary','text' )
and table_name in ('FISCCXStg')

select * from (
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'ID' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([ID] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F1' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F1] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F2' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F2] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F3' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F3] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F4' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F4] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F5' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F5] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F6' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F6] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F7' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F7] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F8' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F8] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F9' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F9] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F10' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F10] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F11' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F11] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F12' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F12] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F13' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F13] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F14' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F14] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F15' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F15] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F16' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F16] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F17' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F17] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F18' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F18] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F19' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F19] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F20' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F20] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F21' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F21] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F22' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F22] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F23' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F23] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F24' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F24] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F25' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F25] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F26' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F26] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F27' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F27] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F28' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F28] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F29' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F29] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F30' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F30] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F31' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F31] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F32' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F32] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F33' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F33] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F34' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F34] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F35' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F35] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F36' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F36] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F37' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F37] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F38' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F38] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F39' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F39] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F40' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F40] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F41' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F41] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F42' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F42] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F43' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F43] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F44' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F44] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F45' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F45] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F46' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F46] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F47' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F47] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F48' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F48] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F49' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F49] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F50' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F50] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F51' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F51] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F52' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F52] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F53' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F53] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F54' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F54] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F55' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F55] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F56' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F56] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F57' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F57] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F58' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F58] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F59' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F59] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F60' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F60] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F61' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F61] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F62' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F62] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F63' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F63] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F64' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F64] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F65' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F65] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F66' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F66] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F67' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F67] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F68' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F68] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F69' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F69] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F70' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F70] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F71' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F71] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F72' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F72] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F73' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F73] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F74' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F74] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F75' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F75] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F76' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F76] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F77' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F77] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F78' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F78] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F79' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F79] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F80' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F80] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F81' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F81] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F82' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F82] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F83' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F83] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F84' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F84] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F85' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F85] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F86' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F86] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F87' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F87] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F88' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F88] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F89' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F89] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F90' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F90] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F91' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F91] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F92' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F92] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F93' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F93] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F94' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F94] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F95' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F95] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F96' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F96] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F97' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F97] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F98' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F98] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F99' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F99] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F100' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F100] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F101' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F101] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F102' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F102] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F103' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F103] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F104' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F104] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F105' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F105] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F106' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F106] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F107' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F107] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F108' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F108] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F109' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F109] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F110' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F110] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F111' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F111] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F112' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F112] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F113' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F113] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F114' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F114] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F115' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F115] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F116' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F116] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F117' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F117] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F118' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F118] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F119' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F119] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F120' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F120] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F121' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F121] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F122' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F122] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F123' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F123] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F124' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F124] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F125' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F125] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F126' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F126] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F127' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F127] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F128' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F128] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F129' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F129] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F130' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F130] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F131' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F131] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F132' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F132] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F133' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F133] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F134' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F134] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F135' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F135] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F136' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F136] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F137' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F137] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F138' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F138] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F139' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F139] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F140' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F140] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F141' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F141] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F142' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F142] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F143' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F143] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F144' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F144] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F145' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F145] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F146' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F146] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F147' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F147] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F148' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F148] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F149' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F149] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F150' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F150] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F151' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F151] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F152' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F152] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F153' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F153] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F154' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F154] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F155' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F155] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F156' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F156] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F157' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F157] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F158' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F158] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F159' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F159] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F160' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F160] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F161' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F161] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F162' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F162] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F163' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F163] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F164' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F164] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F165' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F165] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F166' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F166] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F167' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F167] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F168' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F168] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F169' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F169] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F170' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F170] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F171' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F171] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F172' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F172] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F173' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F173] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F174' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F174] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F175' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F175] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F176' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F176] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F177' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F177] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F178' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F178] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F179' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F179] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F180' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F180] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F181' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F181] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F182' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F182] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F183' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F183] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F184' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F184] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F185' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F185] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F186' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F186] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F187' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F187] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F188' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F188] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F189' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F189] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F190' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F190] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F191' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F191] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F192' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F192] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F193' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F193] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F194' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F194] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F195' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F195] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F196' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F196] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F197' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F197] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F198' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F198] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F199' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F199] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F200' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F200] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F201' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F201] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F202' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F202] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F203' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F203] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F204' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F204] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F205' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F205] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F206' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F206] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F207' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F207] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F208' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F208] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F209' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F209] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F210' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F210] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F211' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F211] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F212' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F212] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F213' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F213] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F214' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F214] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F215' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F215] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F216' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F216] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F217' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F217] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F218' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F218] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F219' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F219] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F220' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F220] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F221' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F221] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F222' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F222] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F223' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F223] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F224' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F224] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F225' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F225] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F226' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F226] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F227' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F227] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F228' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F228] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F229' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F229] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F230' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F230] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F231' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F231] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F232' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F232] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F233' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F233] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F234' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F234] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F235' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F235] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F236' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F236] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F237' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F237] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F238' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F238] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F239' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F239] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F240' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F240] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F241' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F241] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F242' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F242] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F243' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F243] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F244' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F244] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F245' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F245] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F246' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F246] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F247' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F247] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F248' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F248] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F249' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F249] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'F250' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([F250] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'FileName' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([FileName] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'IsActive' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([IsActive] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'CreateUser' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([CreateUser] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'CreateDate' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([CreateDate] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'ModifyUser' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([ModifyUser] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a union 
select top 100 * from  (select distinct  'dbo' as TABLE_SCHEMA,'FISCCXStg' as TABLE_NAME,'ModifyDate' as COLUMN_NAME,F1 as Category,QUOTENAME(ltrim(rtrim(cast([ModifyDate] as nvarchar))),'"') as VALUE from dbo.[FISCCXStg]) a
) a