USE [NHCRM_STG]
GO

/****** Object:  StoredProcedure [dbo].[sp_FISCCXDataLoad]    Script Date: 12/15/2022 12:50:03 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Santhosh Balla
-- Create date: December 2022
-- Description:	This procedure extracts the different categories into separate tables
-- =============================================
/*
EXEC sp_FISCCXDataLoad

*/

create PROCEDURE [dbo].[sp_FISCCXDataLoad]
	
AS
BEGIN
SET NOCOUNT ON;

/*

-- To verify to check if all the records have been accounted for
select 'AllTables' as TableName, sum(RecordCount) as RecordCount from (
select 'FISCCX_DCST' as TableName,count(*) as RecordCount from FISCCX_DCST union 
select 'FISCCX_DIIA' as TableName,count(*) as RecordCount from FISCCX_DIIA union 
select 'FISCCX_DODL' as TableName,count(*) as RecordCount from FISCCX_DODL union 
select 'FISCCX_DPKG' as TableName,count(*) as RecordCount from FISCCX_DPKG union 
select 'FISCCX_DPRY' as TableName,count(*) as RecordCount from FISCCX_DPRY union 
select 'FISCCX_DPUR' as TableName,count(*) as RecordCount from FISCCX_DPUR union 
select 'FISCCX_DSPG' as TableName,count(*) as RecordCount from FISCCX_DSPG union 
select 'FISCCX_DUSR' as TableName,count(*) as RecordCount from FISCCX_DUSR union 
select 'FISCCX_Header' as TableName,count(*) as RecordCount from FISCCX_Header union 
select 'FISCCX_Trailer' as TableName,count(*) as RecordCount from FISCCX_Trailer
) a
union
select 'StageTable' as TableName, count(*) as RecordCount from [FISCCXStg]
union
select 'FISCCX_Trailer' as TableName, (sum(cast(RecordCount as int)) + count(FileName)*2 ) from FISCCX_Trailer


IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='FISCCX_Header_Action' and xtype='U')
CREATE TABLE FISCCX_Header_Action  
    (ExistingCode nchar(3),  
     ExistingName nvarchar(50),  
     ExistingDate datetime,  
     ActionTaken nvarchar(10),  
     NewCode nchar(3),  
     NewName nvarchar(50),  
     NewDate datetime  
    );  
*/

-- Header --
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='FISCCX_Header' and xtype='U')
CREATE TABLE FISCCX_Header 
(
ID int Identity (1,1),
StgID int not null,
RecordType varchar(max),
ProcessorName varchar(max),
ReportDataFeedName varchar(max),
FileDate varchar(max),
WorkOfDate varchar(max),
ClientID varchar(max),
BankID varchar(max),
[FileName] [varchar](max) NULL,
[IsActive] int default 1,
[CreateUser] [varchar](max) default system_user,
[CreateDate] [datetime] default getdate(),
[ModifyUser] [varchar](max) default system_user,
[ModifyDate] [datetime] default getdate()
)

-- Trailer --
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='FISCCX_Trailer' and xtype='U')
CREATE TABLE FISCCX_Trailer
(
ID int Identity (1,1),
StgID int not null,
RecordType [varchar](max) NULL,
RecordCount [varchar](max) NULL,
[FileName] [varchar](max) NULL,
[IsActive] int default 1,
[CreateUser] [varchar](max) default system_user,
[CreateDate] [datetime] default getdate(),
[ModifyUser] [varchar](max) default system_user,
[ModifyDate] [datetime] default getdate()
)

-- DODL | Tolerance and Overdraft
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='FISCCX_DODL' and xtype='U')
CREATE TABLE FISCCX_DODL
(
ID int Identity (1,1),
StgID int not null,
RecordType [varchar](max) NULL,
SubProgramID [varchar](max) NULL,
MCCGroup [varchar](max) NULL,
Fudge [varchar](max) NULL,
IncAuthHoldTimeMCCGroup [varchar](max) NULL,
AuthHoldTimeDays [varchar](max) NULL,
[FileName] [varchar](max) NULL,
[IsActive] int default 1,
[CreateUser] [varchar](max) default system_user,
[CreateDate] [datetime] default getdate(),
[ModifyUser] [varchar](max) default system_user,
[ModifyDate] [datetime] default getdate()
)

-- DPUR | Purse setup
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='FISCCX_DPUR' and xtype='U')
CREATE TABLE FISCCX_DPUR
(
ID int Identity (1,1),
StgID int not null,
RecordType					varchar(max) NULL,
SubProgramID			    varchar(max) NULL,
PurseID			        varchar(max) NULL,
PurseName			        varchar(max) NULL,
PurseStrategy			    varchar(max) NULL,
AllowedMCCGroups			varchar(max) NULL,
NetworkName			    varchar(max) NULL,
PurseValueLimits			varchar(max) NULL,
MinimumValue			    varchar(max) NULL,
MaximumValue			    varchar(max) NULL,
MinimumLoad			    varchar(max) NULL,
MaximumLoad			    varchar(max) NULL,
[Status]			            varchar(max) NULL,
EffectiveDate			    varchar(max) NULL,
ExpirationDate			    varchar(max) NULL,
ExtensionDate			    varchar(max) NULL,
ExtensionFlagName			varchar(max) NULL,
IsDeleted			        varchar(max) NULL,
PurseHandle			    varchar(max) NULL,
DefaultPurseForAuth	    varchar(max) NULL,
[FileName] [varchar](max) NULL,
[IsActive] int default 1,
[CreateUser] [varchar](max) default system_user,
[CreateDate] [datetime] default getdate(),
[ModifyUser] [varchar](max) default system_user,
[ModifyDate] [datetime] default getdate()
)


-- DCST | Cash Attribute Parameters
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='FISCCX_DCST' and xtype='U')
CREATE TABLE FISCCX_DCST
(
ID int Identity (1,1),
StgID int not null,
RecordType varchar(max) NULL,
SubProgramID varchar(max) NULL,
PurseID varchar(max) NULL,
CashType varchar(max) NULL,
TotalAmountLimit varchar(max) NULL,
TotalCountLimit varchar(max) NULL,
MaxAmountPerTrans varchar(max) NULL,
MinAmountPerTrans varchar(max) NULL,
CycleAmountLimit varchar(max) NULL,
CycleCountLimit varchar(max) NULL,
CycleDays varchar(max) NULL,
IsDeleted varchar(max) NULL,
[FileName] [varchar](max) NULL,
[IsActive] int default 1,
[CreateUser] [varchar](max) default system_user,
[CreateDate] [datetime] default getdate(),
[ModifyUser] [varchar](max) default system_user,
[ModifyDate] [datetime] default getdate()
)

-- DPRY | MCC Purse priority
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='FISCCX_DPRY' and xtype='U')
CREATE TABLE FISCCX_DPRY			
(			
ID	int	Identity(1,1),
StgID	int	not null,
RecordType	varchar	(max),
SubProgramID	varchar	(max),
PurseID	varchar	(max),
GroupID	varchar	(max),
MCCGroup	varchar	(max),
MCCDesc	varchar	(max),
Priority	varchar	(max),
IsDeleted	varchar	(max),
[FileName]	varchar	(max),	
[IsActive] 	int	default 1,
[CreateUser]	varchar	(max),
[CreateDate]	datetime	default getdate(),
[ModifyUser] 	varchar	(max)	,
[ModifyDate]	datetime	default getdate()
)


-- DUSR | Application Users
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='FISCCX_DUSR' and xtype='U')
CREATE TABLE FISCCX_DUSR			
(			
ID	int	Identity(1,1),
StgID	int	not null,
RecordType	varchar	(max),
ClientID	varchar	(max),
ClientIDName	varchar	(max),
SourceName	varchar	(max),
Username	varchar	(max),
SecurityLevelName	varchar	(max),
Active	varchar	(max),
[FileName]	varchar	(max),
[IsActive] 	int	default 1,
[CreateUser]	varchar	(max) default system_user,
[CreateDate]	datetime	default getdate(),
[ModifyUser] 	varchar	(max) default system_user,
[ModifyDate]	datetime	default getdate(),
)

/*
-- DSPG | Category,General Program Information,Card Parameters,Card Expiration,Auto Renewal,Account Value Limits,Card Fulfillment Embossing,Embossing Options,Additional Attributes,Value Load Velocity Limits,Address Change Velocity Limits,Negative Balance and Dispute Processing,Auto -Chargeback Process,Statement Setup,Direct Access Setup,ACH Trial Deposit Verification,Client Sponsored Consumer ACH File,Private Label ACH Enrollment,Remote Data Capture,PPDB Number,Account to Account Transfer,MCC Restrictions,New additional Attributes,Statement Setup Extended,Direct Access Setup Extended,Copay Configuration,Pay & Chase Configuration,PBM Configuration,
*/

IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='FISCCX_DSPG' and xtype='U')
CREATE TABLE FISCCX_DSPG			
(			
ID	int	Identity(1,1)	,
StgID	int	not null	,
RecordType	varchar	(max)	,
SubProgramID	varchar	(max)	,
SubProgramName	varchar	(max)	,
SubProgramActiveFlag	varchar	(max)	,
ProgramID	varchar	(max)	,
ProgramName	varchar	(max)	,
ClientID	varchar	(max)	,
ClientName	varchar	(max)	,
ClientAltValue	varchar	(max)	,
TemplateSubProgramID	varchar	(max)	,
FISAssumeFraudLiability	varchar	(max)	,
ProxyName	varchar	(max)	,
AKAName	varchar	(max)	,
PseudoBIN	varchar	(max)	,
MarketSegment	varchar	(max)	,
ProgramLevel	varchar	(max)	,
ProgramUseProxyNumbers	varchar	(max)	,
ProxyType	varchar	(max)	,
IVRAuthenticationMethod	varchar	(max)	,
CardType	varchar	(max)	,
ProgramType	varchar	(max)	,
PINBased	varchar	(max)	,
PINTries	varchar	(max)	,
NumberOfDaysPINLocked	varchar	(max)	,
RePlastic	varchar	(max)	,
AdvanceExpire	varchar	(max)	,
PrivacyOptOut	varchar	(max)	,
LoadSuspend	varchar	(max)	,
ApproveMissingTransaction	varchar	(max)	,
SkipExpiredClosedCardDDA	varchar	(max)	,
AreCardsReloadable	varchar	(max)	,
InitialCardStatus	varchar	(max)	,
ActiveMethod	varchar	(max)	,
HowWillCardsBeActivated	varchar	(max)	,
PhysicalExpirationMethod	varchar	(max)	,
PhysicalExpirationDate	varchar	(max)	,
PhysicalExpirationMonth	varchar	(max)	,
Logical	varchar	(max)	,
LogicalDynamic	varchar	(max)	,
LogicalExpireEvent	varchar	(max)	,
AutoRenewal	varchar	(max)	,
RenewalWindow	varchar	(max)	,
RenewalMonths	varchar	(max)	,
RenewalCardStatus	varchar	(max)	,
BalanceThreshold	varchar	(max)	,
FinancialActivityWindowInDays	varchar	(max)	,
PositiveFinancialActivityWindow	varchar	(max)	,
UtilizeReplacementPackage	varchar	(max)	,
AccountValueLimits	varchar	(max)	,
FixedValue	varchar	(max)	,
MinValue	varchar	(max)	,
MaxValue	varchar	(max)	,
MinLoadOnCard	varchar	(max)	,
MaxLoadOnCard	varchar	(max)	,
ThirdLineEmbossing	varchar	(max)	,
ThirdLineEmbossStaticName	varchar	(max)	,
FourthLineEmbossing	varchar	(max)	,
FourthLineEmbossStaticName	varchar	(max)	,
EmbossOrPrintBeginDates	varchar	(max)	,
EmbossOrPrintExpireDates	varchar	(max)	,
EmbossOrPrintSecurityCode	varchar	(max)	,
SendPIN	varchar	(max)	,
PINMailerLag	varchar	(max)	,
PINMethod	varchar	(max)	,
CarrierSlotType	varchar	(max)	,
ReturnAddress1	varchar	(max)	,
ReturnAddress2	varchar	(max)	,
ReturnAddress3	varchar	(max)	,
ReturnAddress4	varchar	(max)	,
PrintLine1AccountNumber	varchar	(max)	,
PrintLine2ExpirationDate	varchar	(max)	,
PrintLine3CardholderName	varchar	(max)	,
PrintLine4	varchar	(max)	,
PrintProxy	varchar	(max)	,
PrintIndentCardNumber	varchar	(max)	,
PrintSecurityCodeOnIndent	varchar	(max)	,
IssueDuplicateCard	varchar	(max)	,
EmbossFullDate	varchar	(max)	,
SortBySequentialProxyNumber	varchar	(max)	,
PassCardHolderPhoneNumber	varchar	(max)	,
PassCardholderEmail	varchar	(max)	,
PassCardholderDARoutingInfo	varchar	(max)	,
PassCountry	varchar	(max)	,
PassOtherInformation	varchar	(max)	,
PassClientAltValue	varchar	(max)	,
ParsingRulesToAddress	varchar	(max)	,
ShipmentRecordsFlag	varchar	(max)	,
MagName	varchar	(max)	,
FulfillmentInstructions1	varchar	(max)	,
FulfillmentInstructions2	varchar	(max)	,
DiscretionaryData1	varchar	(max)	,
DiscretionaryData2	varchar	(max)	,
DiscretionaryData3	varchar	(max)	,
CardNumberEmbossingMask	varchar	(max)	,
SecondaryCardsFlag	varchar	(max)	,
NumberOfSecondaryCards	varchar	(max)	,
MaxActivationAttempts	varchar	(max)	,
AllowBillPayFunctionality	varchar	(max)	,
BlockBillingTransactionFlag	varchar	(max)	,
ValueLoadUponActivation	varchar	(max)	,
ExpiredCardConfig	varchar	(max)	,
RetailReloadNetworkServices	varchar	(max)	,
MoneyTransferSetupFlag	varchar	(max)	,
SetupMasterCardMoneySend	varchar	(max)	,
PFraudConfig	varchar	(max)	,
EnableOpenToBuyBalanceAtPOS	varchar	(max)	,
BlockCountry	varchar	(max)	,
UnblockCountry	varchar	(max)	,
IncludeCountry	varchar	(max)	,
VelocityLimitPeriodInDays	varchar	(max)	,
ValueLoadNumberPerPeriod	varchar	(max)	,
ValueLoadAmountPerPeriod	varchar	(max)	,
FrozenFromActivationInDays	varchar	(max)	,
FreqLimitForAddressChange	varchar	(max)	,
MaxNumberOfAddressChanges	varchar	(max)	,
ApplNotConsideredForAddressVelocity	varchar	(max)	,
ClearNegativeBalances	varchar	(max)	,
LiabilityOnNegativeBalances	varchar	(max)	,
MaxNegativeBalanceAutoCleared	varchar	(max)	,
AccountStatusNotAutoCleared	varchar	(max)	,
MaxNegativeBalanceManuallyCleared	varchar	(max)	,
ClearNegativeBalancesAfterEventInDays	varchar	(max)	,
DisputeResolutionServiceFlag	varchar	(max)	,
DisputeProcessGuideLine	varchar	(max)	,
TempCreditToApplyInDays	varchar	(max)	,
TempCreditDisputeToApplyInDays	varchar	(max)	,
DisputeLettersMailed	varchar	(max)	,
SettleServiceAndMoneyMove	varchar	(max)	,
CustomerServicePhoneNumber	varchar	(max)	,
MinAutoChargeBackReviewInDays	varchar	(max)	,
AccountWithPositiveBalance	varchar	(max)	,
Statements	varchar	(max)	,
OnlineStatements	varchar	(max)	,
PaperStatements	varchar	(max)	,
PrintBydefaultOrCHOption	varchar	(max)	,
StatementCycle	varchar	(max)	,
TransactionActivity	varchar	(max)	,
BalanceGreaterThan	varchar	(max)	,
BalanceLessThan	varchar	(max)	,
AccountStatus	varchar	(max)	,
StatementPaper	varchar	(max)	,
StatementTemplate	varchar	(max)	,
StatementFileFormat	varchar	(max)	,
DirectAccessConfig	varchar	(max)	,
DDASponsorBank	varchar	(max)	,
RoutingTransitNumber	varchar	(max)	,
BankPrefix	varchar	(max)	,
Withdrawal	varchar	(max)	,
ValueLoadDirectDepositLimitCheck	varchar	(max)	,
CardStatusUpdate	varchar	(max)	,
CardStatusToPFraud	varchar	(max)	,
FAXNumber	varchar	(max)	,
NameMatchForIRSTaxRefunds	varchar	(max)	,
ACHTrialDepositVerificationConfig	varchar	(max)	,
UserInputAttemptsPermitted	varchar	(max)	,
ValidationInDays	varchar	(max)	,
ACHAccountDisplay	varchar	(max)	,
ValueLoadWaitPeriod	varchar	(max)	,
NumberOfExternalBankAccounts	varchar	(max)	,
ClientACHAccountDisplay	varchar	(max)	,
EffectiveEntryDays	varchar	(max)	,
Active	varchar	(max)	,
ReturnCVV2	varchar	(max)	,
ReturnExpirationDate	varchar	(max)	,
InstantConfigured	varchar	(max)	,
StandardConfigured	varchar	(max)	,
StandardWaitPeriodInDays	varchar	(max)	,
PPDBNumber	varchar	(max)	,
AccountToAccountTransferConfig	varchar	(max)	,
SenderMaxNumberOfRecipients	varchar	(max)	,
SenderLengthOfPeriod	varchar	(max)	,
SenderMaxTransfersPerPeriod	varchar	(max)	,
SenderMaxTransferAmountPerPeriod	varchar	(max)	,
SenderTransfersInDays	varchar	(max)	,
SenderMaxTransferAmountPerDay	varchar	(max)	,
SenderMaxAmountPerTransaction	varchar	(max)	,
SenderMinAmountPerTransaction	varchar	(max)	,
SenderAllowFeeReversal	varchar	(max)	,
SenderQualifiedStatus	varchar	(max)	,
SenderDestinationClients	varchar	(max)	,
SearchReceiverCriteria	varchar	(max)	,
TieBreakerRules	varchar	(max)	,
ReceiverLengthOfPeriod	varchar	(max)	,
ReceiverMaxNumberOfTransfersPerPeriod	varchar	(max)	,
ReceiverMaxTransferAmountPerPeriod	varchar	(max)	,
ReceiverMaxNumberOfTransfersPerDay	varchar	(max)	,
ReceiverMaxTransferAmountPerDay	varchar	(max)	,
ReceiverMaxAmountPerTransaction	varchar	(max)	,
ReceiverMinAmountPerTransaction	varchar	(max)	,
ReceiverQualifiedStatus	varchar	(max)	,
ReceiverDestinationClients	varchar	(max)	,
BlockGamblingMerchantsMCC7995	varchar	(max)	,
BlockCashAndQuasiCash	varchar	(max)	,
OtherMCCsRestricted	varchar	(max)	,
AdditionalProxyLength	varchar	(max)	,
IVRSecondaryAuthMethod	varchar	(max)	,
AutoRenewalOnValueLoad	varchar	(max)	,
SetupRegionalNetworkMoneyTransfer	varchar	(max)	,
DisputeFormTempCredit	varchar	(max)	,
TokenizationAllowed	varchar	(max)	,
IsACHFastPayEnabled	varchar	(max)	,
SenderReversalDays	varchar	(max)	,
ReceiverAllowFeeReversal	varchar	(max)	,
ReceiverReversalDays	varchar	(max)	,
IVROrMyAccountPINOptions	varchar	(max)	,
RestrictAdjust	varchar	(max)	,
FulfillmentRequestType	varchar	(max)	,
StatementMessageContents	varchar	(max)	,
StartDate	varchar	(max)	,
EndDate	varchar	(max)	,
DefaultPurseForDirectAccess	varchar	(max)	,
Copay	varchar	(max)	,
MCCGroupCopay	varchar	(max)	,
FutureUse2	varchar	(max)	,
FutureUse3	varchar	(max)	,
PBM	varchar	(max)	,
MCCGroupPayAndChase	varchar	(max)	,
NetworkName	varchar	(max)	,
PurseStatusAutoRenewal	varchar	(max)	,
RandomPINCardGeneration	varchar	(max)	,
[FileName]	varchar	(max)	,
[IsActive] 	int	default 1	,
[CreateUser]	varchar	(max) default system_user	,
[CreateDate]	datetime	default getdate()	,
[ModifyUser] 	varchar	(max) default system_user	,
[ModifyDate]	datetime	default getdate()	,
)

-- DIIA | IIAS Group (Healthcare Program Configuration)
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='FISCCX_DIIA' and xtype='U')
CREATE TABLE FISCCX_DIIA			
(			
ID	int	Identity(1,1)	,
StgID	int	not null	,
RecordType	varchar	(max)	,
SubProgramID	varchar	(max)	,
PurseID	varchar	(max)	,
IIAS	varchar	(max)	,
IIASDesc	varchar	(max)	,
IIASGroupID	varchar	(max)	,
IIASGroupDesc	varchar	(max)	,
[Priority]	varchar	(max)	,
IsDeleted	varchar	(max)	,
IIASGroupPriority	varchar	(max)	,
[FileName]	varchar	(max)	,
[IsActive] 	int	default 1	,
[CreateUser]	varchar	(max) default system_user	,
[CreateDate]	datetime	default getdate()	,
[ModifyUser] 	varchar	(max) default system_user	,
[ModifyDate]	datetime	default getdate()	,
)


-- DPKG | Package Setup, Authorization Parameters
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='FISCCX_DPKG' and xtype='U')
CREATE TABLE FISCCX_DPKG			
(			
ID	int	Identity(1,1)	,
StgID	int	not null	,
RecordType	varchar	(max)	,
SubProgramID	varchar	(max)	,
PackageID	varchar	(max)	,
PackageName	varchar	(max)	,
ArtworkName	varchar	(max)	,
BIN	varchar	(max)	,
PrinAndAgentRange	varchar	(max)	,
FulfillmentHouse	varchar	(max)	,
CardCountThreshold	varchar	(max)	,
CardIssuedSequentFlag	varchar	(max)	,
BarcodeType	varchar	(max)	,
FormFactor	varchar	(max)	,
ReplacementPackageID	varchar	(max)	,
DuplicateSettlementAwaitInDays	varchar	(max)	,
AuthAwaitSettlementInDays	varchar	(max)	,
EncodingMethod	varchar	(max)	,
PartialAuth	varchar	(max)	,
IsDeleted	varchar	(max)	,
ImmediateCredit	varchar	(max)	,
ApprovedProductList	varchar	(max)	,
[FileName]	varchar	(max)	,
[IsActive] 	int	default 1	,
[CreateUser]	varchar	(max) default system_user	,
[CreateDate]	datetime	default getdate()	,
[ModifyUser] 	varchar	(max) default system_user	,
[ModifyDate]	datetime	default getdate()	,
)

BEGIN TRY

BEGIN TRANSACTION FISCCX_Transaction

MERGE [dbo].[FISCCX_Header] AS tgt  
    USING (SELECT ID as STGID, F1, F2, F3, F4, F5, F6, [FileName] from [dbo].[FISCCXStg] where ltrim(rtrim(F1)) = 'H' and IsActive = 1 ) as src 
    ON (tgt.[FileName] = src.[FileName])  
    --WHEN MATCHED THEN
        --UPDATE SET Name = src.Name  
    WHEN NOT MATCHED THEN  
        INSERT (STGID,RecordType,ProcessorName,ReportDataFeedName,FileDate,WorkOfDate, ClientID, [FileName] )  
        VALUES (STGID,F1,F2,F3,F4,F5,F6,[FileName]) ; 
    -- OUTPUT deleted.*, $action, inserted.* INTO FISCCX_Header_Action; 


MERGE [dbo].[FISCCX_Trailer] AS tgt  
    USING (SELECT ID as STGID, F1, F2, [FileName] from [dbo].[FISCCXStg] where ltrim(rtrim(F1)) = 'T' and IsActive = 1 ) as src 
    ON (tgt.[FileName] = src.[FileName] and tgt.RecordType = src.F1 and tgt.RecordCount = src.F2)  
    --WHEN MATCHED THEN
        --UPDATE SET Name = src.Name  
    WHEN NOT MATCHED THEN  
        INSERT (STGID,RecordType, RecordCount, [FileName] )  
        VALUES (STGID,F1,F2,[FileName]) ; 
    -- OUTPUT deleted.*, $action, inserted.* INTO FISCCX_Header_Action; 


MERGE [dbo].[FISCCX_DODL] AS tgt  
    USING (SELECT ID as STGID,F1,F2,F3,F4,F5,F6, [FileName] from [dbo].[FISCCXStg] where ltrim(rtrim(F1)) = 'DODL' and IsActive = 1 ) as src 
    ON (tgt.[FileName] = src.[FileName] and tgt.RecordType= src.F1 and tgt.SubProgramID = src.F2 and tgt.MCCGroup=src.F3 and tgt.Fudge=src.F4 and tgt.IncAuthHoldTimeMCCGroup=src.F5 and  tgt.AuthHoldTimeDays=src.F6 )  
    --WHEN MATCHED THEN
        --UPDATE SET Name = src.Name  
    WHEN NOT MATCHED THEN  
        INSERT (STGID,RecordType,SubProgramID,MCCGroup,Fudge,IncAuthHoldTimeMCCGroup,AuthHoldTimeDays, [FileName] )  
        VALUES (STGID,F1,F2,F3,F4,F5,F6,[FileName]) ; 


MERGE [dbo].[FISCCX_DPUR] AS tgt  
    USING (SELECT ID as STGID,F1,F2,F3,F4,F5,F6,F7,F8,F9,F10,F11,F12,F13,F14,F15,F16,F17,F18,F19,F20, [FileName] from [dbo].[FISCCXStg] where ltrim(rtrim(F1)) = 'DPUR' and IsActive = 1 ) as src 
    ON (tgt.[FileName] = src.[FileName] and tgt.RecordType = src.F1 and tgt.SubProgramID = src.F2 and tgt.PurseID = src.F3 and tgt.PurseName = src.F4 and tgt.PurseStrategy = src.F5 and tgt.AllowedMCCGroups = src.F6 and tgt.NetworkName = src.F7 and tgt.PurseValueLimits = src.F8 and tgt.MinimumValue = src.F9 and tgt.MaximumValue = src.F10 and tgt.MinimumLoad = src.F11 and tgt.MaximumLoad = src.F12 and tgt.[Status] = src.F13 and tgt.EffectiveDate = src.F14 and tgt.ExpirationDate= src.F15 and tgt.ExtensionDate= src.F16 and tgt.ExtensionFlagName= src.F17 and tgt.IsDeleted= src.F18 and tgt.PurseHandle= src.F19 and tgt.DefaultPurseForAuth = src.F20 )
	 --WHEN MATCHED THEN
        --UPDATE SET Name = src.Name  
    WHEN NOT MATCHED THEN  
        INSERT (STGID,RecordType,	SubProgramID,	PurseID,	PurseName,	PurseStrategy,	AllowedMCCGroups,	NetworkName,	PurseValueLimits,	MinimumValue,	MaximumValue,	MinimumLoad,	MaximumLoad,	[Status],	EffectiveDate,	ExpirationDate,	ExtensionDate,	ExtensionFlagName,	IsDeleted,	PurseHandle,	DefaultPurseForAuth,  [FileName] )  
        VALUES (STGID,F1,F2,F3,F4,F5,F6,F7,F8,F9,F10,F11,F12,F13,F14,F15,F16,F17,F18,F19,F20,[FileName]) ; 



/*
(STGID, RecordType,	SubProgramID,	PurseID,	CashType,	TotalAmountLimit,	TotalCountLimit,	MaxAmountPerTrans,	MinAmountPerTrans,	CycleAmountLimit,	CycleCountLimit,	CycleDays,	IsDeleted, [FileName])
src.[FileName]=tgt.[FileName] and	src.F1=tgt.RecordType and	src.F2=tgt.SubProgramID and	src.F3=tgt.PurseID and	src.F4=tgt.CashType and	src.F5=tgt.TotalAmountLimit and	src.F6=tgt.TotalCountLimit and	src.F7=tgt.MaxAmountPerTrans and	src.F8=tgt.MinAmountPerTrans and	src.F9=tgt.CycleAmountLimit and	src.F10=tgt.CycleCountLimit and	src.F11=tgt.CycleDays and	src.F12=tgt.IsDeleted and

*/

MERGE [dbo].[FISCCX_DCST] AS tgt  
    USING (SELECT ID as STGID,F1,F2,F3,F4,F5,F6,F7,F8,F9,F10,F11,F12,[FileName] from [dbo].[FISCCXStg] where ltrim(rtrim(F1)) = 'DCST' and IsActive = 1 ) as src 
    ON (src.[FileName]=tgt.[FileName] and	src.F1=tgt.RecordType and	src.F2=tgt.SubProgramID and	src.F3=tgt.PurseID and	src.F4=tgt.CashType and	src.F5=tgt.TotalAmountLimit and	src.F6=tgt.TotalCountLimit and	src.F7=tgt.MaxAmountPerTrans and	src.F8=tgt.MinAmountPerTrans and	src.F9=tgt.CycleAmountLimit and	src.F10=tgt.CycleCountLimit and	src.F11=tgt.CycleDays and	src.F12=tgt.IsDeleted)
	 --WHEN MATCHED THEN
        --UPDATE SET Name = src.Name  
    WHEN NOT MATCHED THEN  
        INSERT (STGID, RecordType,SubProgramID,PurseID,CashType,TotalAmountLimit,TotalCountLimit,MaxAmountPerTrans,MinAmountPerTrans,CycleAmountLimit,CycleCountLimit,CycleDays,IsDeleted,[FileName])
        VALUES (STGID,F1,F2,F3,F4,F5,F6,F7,F8,F9,F10,F11,F12,[FileName]) ; 

/*
												
[FileName],	RecordType,	SubProgramID,	PurseID,	GroupID,	MCCGroup,	MCCDesc,	Priority,	IsDeleted				
src.[FileName]=tgt.[FileName] and	src.F1=tgt.RecordType and	src.F2=tgt.SubProgramID and	src.F3=tgt.PurseID and	src.F4=tgt.GroupID and	src.F5=tgt.MCCGroup and	src.F6=tgt.MCCDesc and	src.F7=tgt.Priority and	src.F8=tgt.IsDeleted and				
												
*/
MERGE [dbo].[FISCCX_DPRY] AS tgt  
    USING (SELECT ID as STGID,F1,F2,F3,F4,F5,F6,F7,F8,[FileName] from [dbo].[FISCCXStg] where ltrim(rtrim(F1)) = 'DPRY' and IsActive = 1 ) as src 
    ON (src.[FileName]=tgt.[FileName] and	src.F1=tgt.RecordType and	src.F2=tgt.SubProgramID and	src.F3=tgt.PurseID and	src.F4=tgt.GroupID and	src.F5=tgt.MCCGroup and	src.F6=tgt.MCCDesc and	src.F7=tgt.[Priority] and	src.F8=tgt.IsDeleted)
	 --WHEN MATCHED THEN
        --UPDATE SET Name = src.Name  
    WHEN NOT MATCHED THEN  
        INSERT (STGID, RecordType,	SubProgramID,	PurseID,	GroupID,	MCCGroup,	MCCDesc,	Priority,	IsDeleted, [FileName]	)
        VALUES (STGID,F1,F2,F3,F4,F5,F6,F7,F8,[FileName]) ; 


MERGE [dbo].[FISCCX_DUSR] AS tgt  
    USING (SELECT ID as STGID,F1,F2,F3,F4,F5,F6,F7,[FileName] from [dbo].[FISCCXStg] where ltrim(rtrim(F1)) = 'DUSR' and IsActive = 1 ) as src 
    ON (src.[FileName]=tgt.[FileName] and src.F7=tgt.Active and src.F6=tgt.SecurityLevelName and src.F5=tgt.Username and src.F4=tgt.SourceName and src.F3=tgt.ClientIDName and src.F2=tgt.ClientID and src.F1=tgt.RecordType)

	 --WHEN MATCHED THEN
        --UPDATE SET Name = src.Name  
    WHEN NOT MATCHED THEN  
        INSERT (STGID, RecordType,ClientID,ClientIDName,SourceName,Username,SecurityLevelName,Active,[FileName]	)
        VALUES (STGID,F1,F2,F3,F4,F5,F6,F7,[FileName]) ; 

/*
RecordType,ClientID,ClientIDName,SourceName,Username,SecurityLevelName,Active,[FileName]
src.[FileName]=tgt.[FileName] and src.F7=tgt.Active and src.F6=tgt.SecurityLevelName and src.F5=tgt.Username and src.F4=tgt.SourceName and src.F3=tgt.ClientIDName and src.F2=tgt.ClientID and src.F1=tgt.RecordType and 
*/

MERGE [dbo].[FISCCX_DSPG] AS tgt  
USING (SELECT ID as STGID,F1,F2,F3,F4,F5,F6,F7,F8,F9,F10,F11,F12,F13,F14,F15,F16,F17,F18,F19,F20,F21,F22,F23,F24,F25,F26,F27,F28,F29,F30,F31,F32,F33,F34,F35,F36,F37,F38,F39,F40,F41,F42,F43,F44,F45,F46,F47,F48,F49,F50,F51,F52,F53,F54,F55,F56,F57,F58,F59,F60,F61,F62,F63,F64,F65,F66,F67,F68,F69,F70,F71,F72,F73,F74,F75,F76,F77,F78,F79,F80,F81,F82,F83,F84,F85,F86,F87,F88,F89,F90,F91,F92,F93,F94,F95,F96,F97,F98,F99,F100,F101,F102,F103,F104,F105,F106,F107,F108,F109,F110,F111,F112,F113,F114,F115,F116,F117,F118,F119,F120,F121,F122,F123,F124,F125,F126,F127,F128,F129,F130,F131,F132,F133,F134,F135,F136,F137,F138,F139,F140,F141,F142,F143,F144,F145,F146,F147,F148,F149,F150,F151,F152,F153,F154,F155,F156,F157,F158,F159,F160,F161,F162,F163,F164,F165,F166,F167,F168,F169,F170,F171,F172,F173,F174,F175,F176,F177,F178,F179,F180,F181,F182,F183,F184,F185,F186,F187,F188,F189,F190,F191,F192,F193,F194,F195,F196,F197,F198,F199,F200,F201,F202,F203,F204,F205,F206,F207,F208,F209,F210,F211,F212,F213,F214,F215,F216,F217,F218,F219,F220, [FileName] from [dbo].[FISCCXStg] where ltrim(rtrim(F1)) = 'DSPG' and IsActive = 1 ) as src 
    ON (src.[FileName]=tgt.[FileName] and src.F1=tgt.RecordType and src.F2=tgt.SubProgramID and src.F3=tgt.SubProgramName and src.F4=tgt.SubProgramActiveFlag and src.F5=tgt.ProgramID and src.F6=tgt.ProgramName and src.F7=tgt.ClientID and src.F8=tgt.ClientName and src.F9=tgt.ClientAltValue and src.F10=tgt.TemplateSubProgramID and src.F11=tgt.FISAssumeFraudLiability and src.F12=tgt.ProxyName and src.F13=tgt.AKAName and src.F14=tgt.PseudoBIN and src.F15=tgt.MarketSegment and src.F16=tgt.ProgramLevel and src.F17=tgt.ProgramUseProxyNumbers and src.F18=tgt.ProxyType and src.F19=tgt.IVRAuthenticationMethod and src.F20=tgt.CardType and src.F21=tgt.ProgramType and src.F22=tgt.PINBased and src.F23=tgt.PINTries and src.F24=tgt.NumberOfDaysPINLocked and src.F25=tgt.RePlastic and src.F26=tgt.AdvanceExpire and src.F27=tgt.PrivacyOptOut and src.F28=tgt.LoadSuspend and src.F29=tgt.ApproveMissingTransaction and src.F30=tgt.SkipExpiredClosedCardDDA and src.F31=tgt.AreCardsReloadable and src.F32=tgt.InitialCardStatus and src.F33=tgt.ActiveMethod and src.F34=tgt.HowWillCardsBeActivated and src.F35=tgt.PhysicalExpirationMethod and src.F36=tgt.PhysicalExpirationDate and src.F37=tgt.PhysicalExpirationMonth and src.F38=tgt.Logical and src.F39=tgt.LogicalDynamic and src.F40=tgt.LogicalExpireEvent and src.F41=tgt.AutoRenewal and src.F42=tgt.RenewalWindow and src.F43=tgt.RenewalMonths and src.F44=tgt.RenewalCardStatus and src.F45=tgt.BalanceThreshold and src.F46=tgt.FinancialActivityWindowInDays and src.F47=tgt.PositiveFinancialActivityWindow and src.F48=tgt.UtilizeReplacementPackage and src.F49=tgt.AccountValueLimits and src.F50=tgt.FixedValue and src.F51=tgt.MinValue and src.F52=tgt.MaxValue and src.F53=tgt.MinLoadOnCard and src.F54=tgt.MaxLoadOnCard and src.F55=tgt.ThirdLineEmbossing and src.F56=tgt.ThirdLineEmbossStaticName and src.F57=tgt.FourthLineEmbossing and src.F58=tgt.FourthLineEmbossStaticName and src.F59=tgt.EmbossOrPrintBeginDates and src.F60=tgt.EmbossOrPrintExpireDates and src.F61=tgt.EmbossOrPrintSecurityCode and src.F62=tgt.SendPIN and src.F63=tgt.PINMailerLag and src.F64=tgt.PINMethod and src.F65=tgt.CarrierSlotType and src.F66=tgt.ReturnAddress1 and src.F67=tgt.ReturnAddress2 and src.F68=tgt.ReturnAddress3 and src.F69=tgt.ReturnAddress4 and src.F70=tgt.PrintLine1AccountNumber and src.F71=tgt.PrintLine2ExpirationDate and src.F72=tgt.PrintLine3CardholderName and src.F73=tgt.PrintLine4 and src.F74=tgt.PrintProxy and src.F75=tgt.PrintIndentCardNumber and src.F76=tgt.PrintSecurityCodeOnIndent and src.F77=tgt.IssueDuplicateCard and src.F78=tgt.EmbossFullDate and src.F79=tgt.SortBySequentialProxyNumber and src.F80=tgt.PassCardHolderPhoneNumber and src.F81=tgt.PassCardHolderEmail and src.F82=tgt.PassCardHolderDARoutingInfo and src.F83=tgt.PassCountry and src.F84=tgt.PassOtherInformation and src.F85=tgt.PassClientAltValue and src.F86=tgt.ParsingRulesToAddress and src.F87=tgt.ShipmentRecordsFlag and src.F88=tgt.MagName and src.F89=tgt.FulfillmentInstructions1 and src.F90=tgt.FulfillmentInstructions2 and src.F91=tgt.DiscretionaryData1 and src.F92=tgt.DiscretionaryData2 and src.F93=tgt.DiscretionaryData3 and src.F94=tgt.CardNumberEmbossingMask and src.F95=tgt.SecondaryCardsFlag and src.F96=tgt.NumberOfSecondaryCards and src.F97=tgt.MaxActivationAttempts and src.F98=tgt.AllowBillPayFunctionality and src.F99=tgt.BlockBillingTransactionFlag and src.F100=tgt.ValueLoadUponActivation and src.F101=tgt.ExpiredCardConfig and src.F102=tgt.RetailReloadNetworkServices and src.F103=tgt.MoneyTransferSetupFlag and src.F104=tgt.SetupMasterCardMoneySend and src.F105=tgt.PFraudConfig and src.F106=tgt.EnableOpenToBuyBalanceAtPOS and src.F107=tgt.BlockCountry and src.F108=tgt.UnblockCountry and src.F109=tgt.IncludeCountry and src.F110=tgt.VelocityLimitPeriodInDays and src.F111=tgt.ValueLoadNumberPerPeriod and src.F112=tgt.ValueLoadAmountPerPeriod and src.F113=tgt.FrozenFromActivationInDays and src.F114=tgt.FreqLimitForAddressChange and src.F115=tgt.MaxNumberOfAddressChanges and src.F116=tgt.ApplNotConsideredForAddressVelocity and src.F117=tgt.ClearNegativeBalances and src.F118=tgt.LiabilityOnNegativeBalances and src.F119=tgt.MaxNegativeBalanceAutoCleared and src.F120=tgt.AccountStatusNotAutoCleared and src.F121=tgt.MaxNegativeBalanceManuallyCleared and src.F122=tgt.ClearNegativeBalancesAfterEventInDays and src.F123=tgt.DisputeResolutionServiceFlag and src.F124=tgt.DisputeProcessGuideLine and src.F125=tgt.TempCreditToApplyInDays and src.F126=tgt.TempCreditDisputeToApplyInDays and src.F127=tgt.DisputeLettersMailed and src.F128=tgt.SettleServiceAndMoneyMove and src.F129=tgt.CustomerServicePhoneNumber and src.F130=tgt.MinAutoChargeBackReviewInDays and src.F131=tgt.AccountWithPositiveBalance and src.F132=tgt.Statements and src.F133=tgt.OnlineStatements and src.F134=tgt.PaperStatements and src.F135=tgt.PrintBydefaultOrCHOption and src.F136=tgt.StatementCycle and src.F137=tgt.TransactionActivity and src.F138=tgt.BalanceGreaterThan and src.F139=tgt.BalanceLessThan and src.F140=tgt.AccountStatus and src.F141=tgt.StatementPaper and src.F142=tgt.StatementTemplate and src.F143=tgt.StatementFileFormat and src.F144=tgt.DirectAccessConfig and src.F145=tgt.DDASponsorBank and src.F146=tgt.RoutingTransitNumber and src.F147=tgt.BankPrefix and src.F148=tgt.Withdrawal and src.F149=tgt.ValueLoadDirectDepositLimitCheck and src.F150=tgt.CardStatusUpdate and src.F151=tgt.CardStatusToPFraud and src.F152=tgt.FAXNumber and src.F153=tgt.NameMatchForIRSTaxRefunds and src.F154=tgt.ACHTrialDepositVerificationConfig and src.F155=tgt.UserInputAttemptsPermitted and src.F156=tgt.ValidationInDays and src.F157=tgt.ACHAccountDisplay and src.F158=tgt.ValueLoadWaitPeriod and src.F159=tgt.NumberOfExternalBankAccounts and src.F160=tgt.ClientACHAccountDisplay and src.F161=tgt.EffectiveEntryDays and src.F162=tgt.Active and src.F163=tgt.ReturnCVV2 and src.F164=tgt.ReturnExpirationDate and src.F165=tgt.InstantConfigured and src.F166=tgt.StandardConfigured and src.F167=tgt.StandardWaitPeriodInDays and src.F168=tgt.PPDBNumber and src.F169=tgt.AccountToAccountTransferConfig and src.F170=tgt.SenderMaxNumberOfRecipients and src.F171=tgt.SenderLengthOfPeriod and src.F172=tgt.SenderMaxTransfersPerPeriod and src.F173=tgt.SenderMaxTransferAmountPerPeriod and src.F174=tgt.SenderTransfersInDays and src.F175=tgt.SenderMaxTransferAmountPerDay and src.F176=tgt.SenderMaxAmountPerTransaction and src.F177=tgt.SenderMinAmountPerTransaction and src.F178=tgt.SenderAllowFeeReversal and src.F179=tgt.SenderQualifiedStatus and src.F180=tgt.SenderDestinationClients and src.F181=tgt.SearchReceiverCriteria and src.F182=tgt.TieBreakerRules and src.F183=tgt.ReceiverLengthofPeriod and src.F184=tgt.ReceiverMaxNumberOfTransfersPerPeriod and src.F185=tgt.ReceiverMaxTransferAmountPerPeriod and src.F186=tgt.ReceiverMaxNumberofTransfersPerDay and src.F187=tgt.ReceiverMaxTransferAmountPerDay and src.F188=tgt.ReceiverMaxAmountPerTransaction and src.F189=tgt.ReceiverMinAmountPerTransaction and src.F190=tgt.ReceiverQualifiedStatus and src.F191=tgt.ReceiverDestinationClients and src.F192=tgt.BlockGamblingMerchantsMCC7995 and src.F193=tgt.BlockCashandQuasiCash and src.F194=tgt.OtherMCCsRestricted and src.F195=tgt.AdditionalProxyLength and src.F196=tgt.IVRSecondaryAuthMethod and src.F197=tgt.AutoRenewalOnValueLoad and src.F198=tgt.SetupRegionalNetworkMoneyTransfer and src.F199=tgt.DisputeFormTempCredit and src.F200=tgt.TokenizationAllowed and src.F201=tgt.IsACHFastPayEnabled and src.F202=tgt.SenderReversalDays and src.F203=tgt.ReceiverAllowFeeReversal and src.F204=tgt.ReceiverReversalDays and src.F205=tgt.IVROrMyAccountPINOptions and src.F206=tgt.RestrictAdjust and src.F207=tgt.FulfillmentRequestType and src.F208=tgt.StatementMessageContents and src.F209=tgt.StartDate and src.F210=tgt.EndDate and src.F211=tgt.DefaultPurseForDirectAccess and src.F212=tgt.Copay and src.F213=tgt.MCCGroupCopay and src.F214=tgt.FutureUse2 and src.F215=tgt.FutureUse3 and src.F216=tgt.PBM and src.F217=tgt.MCCGroupPayAndChase and src.F218=tgt.NetworkName and src.F219=tgt.PurseStatusAutoRenewal and src.F220=tgt.RandomPINCardGeneration)
	 --WHEN MATCHED THEN
        --UPDATE SET Name = src.Name  
    WHEN NOT MATCHED THEN  
			INSERT (STGID,RecordType,SubProgramID,SubProgramName,SubProgramActiveFlag,ProgramID,ProgramName,ClientID,ClientName,ClientAltValue,TemplateSubProgramID,FISAssumeFraudLiability,ProxyName,AKAName,PseudoBIN,MarketSegment,ProgramLevel,ProgramUseProxyNumbers,ProxyType,IVRAuthenticationMethod,CardType,ProgramType,PINBased,PINTries,NumberOfDaysPINLocked,RePlastic,AdvanceExpire,PrivacyOptOut,LoadSuspend,ApproveMissingTransaction,SkipExpiredClosedCardDDA,AreCardsReloadable,InitialCardStatus,ActiveMethod,HowWillCardsBeActivated,PhysicalExpirationMethod,PhysicalExpirationDate,PhysicalExpirationMonth,Logical,LogicalDynamic,LogicalExpireEvent,AutoRenewal,RenewalWindow,RenewalMonths,RenewalCardStatus,BalanceThreshold,FinancialActivityWindowInDays,PositiveFinancialActivityWindow,UtilizeReplacementPackage,AccountValueLimits,FixedValue,MinValue,MaxValue,MinLoadOnCard,MaxLoadonCard,ThirdLineEmbossing,ThirdLineEmbossStaticName,FourthLineEmbossing,FourthLineEmbossStaticName,EmbossOrPrintBeginDates,EmbossOrPrintExpireDates,EmbossOrPrintSecurityCode,SendPIN,PINMailerLag,PINMethod,CarrierSlotType,ReturnAddress1,ReturnAddress2,ReturnAddress3,ReturnAddress4,PrintLine1AccountNumber,PrintLine2ExpirationDate,PrintLine3CardholderName,PrintLine4,PrintProxy,PrintIndentCardNumber,PrintSecurityCodeOnIndent,IssueDuplicateCard,EmbossFullDate,SortBySequentialProxyNumber,PassCardHolderPhoneNumber,PassCardholderEmail,PassCardholderDARoutingInfo,PassCountry,PassOtherInformation,PassClientAltValue,ParsingRulesToAddress,ShipmentRecordsFlag,MagName,FulfillmentInstructions1,FulfillmentInstructions2,DiscretionaryData1,DiscretionaryData2,DiscretionaryData3,CardNumberEmbossingMask,SecondaryCardsFlag,NumberOfSecondaryCards,MaxActivationAttempts,AllowBillPayFunctionality,BlockBillingTransactionFlag,ValueLoaduponActivation,ExpiredCardConfig,RetailReloadNetworkServices,MoneyTransferSetupFlag,SetupMasterCardMoneySend,PFraudConfig,EnableOpenToBuyBalanceAtPOS,BlockCountry,UnblockCountry,IncludeCountry,VelocityLimitPeriodInDays,ValueLoadNumberPerPeriod,ValueLoadAmountPerPeriod,FrozenFromActivationInDays,FreqLimitForAddressChange,MaxNumberOfAddressChanges,ApplNotConsideredForAddressVelocity,ClearNegativeBalances,LiabilityOnNegativeBalances,MaxNegativeBalanceAutoCleared,AccountStatusNotAutoCleared,MaxNegativeBalanceManuallyCleared,ClearNegativeBalancesAfterEventInDays,DisputeResolutionServiceFlag,DisputeProcessGuideLine,TempCreditToApplyInDays,TempCreditDisputeToApplyInDays,DisputeLettersMailed,SettleServiceAndMoneyMove,CustomerServicePhoneNumber,MinAutoChargeBackReviewInDays,AccountWithPositiveBalance,Statements,OnlineStatements,PaperStatements,PrintBydefaultOrCHOption,StatementCycle,TransactionActivity,BalanceGreaterThan,BalanceLessThan,AccountStatus,StatementPaper,StatementTemplate,StatementFileFormat,DirectAccessConfig,DDASponsorBank,RoutingTransitNumber,BankPrefix,Withdrawal,ValueLoadDirectDepositLimitCheck,CardStatusUpdate,CardStatusToPFraud,FAXNumber,NameMatchForIRSTaxRefunds,ACHTrialDepositVerificationConfig,UserInputAttemptsPermitted,ValidationInDays,ACHAccountDisplay,ValueLoadWaitPeriod,NumberOfExternalBankAccounts,ClientACHAccountDisplay,EffectiveEntryDays,Active,ReturnCVV2,ReturnExpirationDate,InstantConfigured,StandardConfigured,StandardWaitPeriodInDays,PPDBNumber,AccountToAccountTransferConfig,SenderMaxNumberOfRecipients,SenderLengthOfPeriod,SenderMaxTransfersPerPeriod,SenderMaxTransferAmountPerPeriod,SenderTransfersInDays,SenderMaxTransferAmountPerDay,SenderMaxAmountPerTransaction,SenderMinAmountPerTransaction,SenderAllowFeeReversal,SenderQualifiedStatus,SenderDestinationClients,SearchReceiverCriteria,TieBreakerRules,ReceiverLengthofPeriod,ReceiverMaxNumberOfTransfersPerPeriod,ReceiverMaxTransferAmountPerPeriod,ReceiverMaxNumberofTransfersPerDay,ReceiverMaxTransferAmountPerDay,ReceiverMaxAmountPerTransaction,ReceiverMinAmountPerTransaction,ReceiverQualifiedStatus,ReceiverDestinationClients,BlockGamblingMerchantsMCC7995,BlockCashandQuasiCash,OtherMCCsRestricted,AdditionalProxyLength,IVRSecondaryAuthMethod,AutoRenewalOnValueLoad,SetupRegionalNetworkMoneyTransfer,DisputeFormTempCredit,TokenizationAllowed,IsACHFastPayEnabled,SenderReversalDays,ReceiverAllowFeeReversal,ReceiverReversalDays,IVROrMyAccountPINOptions,RestrictAdjust,FulfillmentRequestType,StatementMessageContents,StartDate,EndDate,DefaultPurseForDirectAccess,Copay,MCCGroupCopay,FutureUse2,FutureUse3,PBM,MCCGroupPayAndChase,NetworkName,PurseStatusAutoRenewal,RandomPINCardGeneration,[FileName]	)
			VALUES (STGID,F1,F2,F3,F4,F5,F6,F7,F8,F9,F10,F11,F12,F13,F14,F15,F16,F17,F18,F19,F20,F21,F22,F23,F24,F25,F26,F27,F28,F29,F30,F31,F32,F33,F34,F35,F36,F37,F38,F39,F40,F41,F42,F43,F44,F45,F46,F47,F48,F49,F50,F51,F52,F53,F54,F55,F56,F57,F58,F59,F60,F61,F62,F63,F64,F65,F66,F67,F68,F69,F70,F71,F72,F73,F74,F75,F76,F77,F78,F79,F80,F81,F82,F83,F84,F85,F86,F87,F88,F89,F90,F91,F92,F93,F94,F95,F96,F97,F98,F99,F100,F101,F102,F103,F104,F105,F106,F107,F108,F109,F110,F111,F112,F113,F114,F115,F116,F117,F118,F119,F120,F121,F122,F123,F124,F125,F126,F127,F128,F129,F130,F131,F132,F133,F134,F135,F136,F137,F138,F139,F140,F141,F142,F143,F144,F145,F146,F147,F148,F149,F150,F151,F152,F153,F154,F155,F156,F157,F158,F159,F160,F161,F162,F163,F164,F165,F166,F167,F168,F169,F170,F171,F172,F173,F174,F175,F176,F177,F178,F179,F180,F181,F182,F183,F184,F185,F186,F187,F188,F189,F190,F191,F192,F193,F194,F195,F196,F197,F198,F199,F200,F201,F202,F203,F204,F205,F206,F207,F208,F209,F210,F211,F212,F213,F214,F215,F216,F217,F218,F219,F220, [FileName]
) ; 

/* -- DSPG
F1,F2,F3,F4,F5,F6,F7,F8,F9,F10,F11,F12,F13,F14,F15,F16,F17,F18,F19,F20,F21,F22,F23,F24,F25,F26,F27,F28,F29,F30,F31,F32,F33,F34,F35,F36,F37,F38,F39,F40,F41,F42,F43,F44,F45,F46,F47,F48,F49,F50,F51,F52,F53,F54,F55,F56,F57,F58,F59,F60,F61,F62,F63,F64,F65,F66,F67,F68,F69,F70,F71,F72,F73,F74,F75,F76,F77,F78,F79,F80,F81,F82,F83,F84,F85,F86,F87,F88,F89,F90,F91,F92,F93,F94,F95,F96,F97,F98,F99,F100,F101,F102,F103,F104,F105,F106,F107,F108,F109,F110,F111,F112,F113,F114,F115,F116,F117,F118,F119,F120,F121,F122,F123,F124,F125,F126,F127,F128,F129,F130,F131,F132,F133,F134,F135,F136,F137,F138,F139,F140,F141,F142,F143,F144,F145,F146,F147,F148,F149,F150,F151,F152,F153,F154,F155,F156,F157,F158,F159,F160,F161,F162,F163,F164,F165,F166,F167,F168,F169,F170,F171,F172,F173,F174,F175,F176,F177,F178,F179,F180,F181,F182,F183,F184,F185,F186,F187,F188,F189,F190,F191,F192,F193,F194,F195,F196,F197,F198,F199,F200,F201,F202,F203,F204,F205,F206,F207,F208,F209,F210,F211,F212,F213,F214,F215,F216,F217,F218,F219,F220, [FileName]
RecordType,SubProgramID,SubProgramName,SubProgramActiveFlag,ProgramID,ProgramName,ClientID,ClientName,ClientAltValue,TemplateSubProgramID,FISAssumeFraudLiability,ProxyName,AKAName,PseudoBIN,MarketSegment,ProgramLevel,ProgramUseProxyNumbers,ProxyType,IVRAuthenticationMethod,CardType,ProgramType,PINBased,PINTries,NumberOfDaysPINLocked,RePlastic,AdvanceExpire,PrivacyOptOut,LoadSuspend,ApproveMissingTransaction,SkipExpiredClosedCardDDA,AreCardsReloadable,InitialCardStatus,ActiveMethod,HowWillCardsBeActivated,PhysicalExpirationMethod,PhysicalExpirationDate,PhysicalExpirationMonth,Logical,LogicalDynamic,LogicalExpireEvent,AutoRenewal,RenewalWindow,RenewalMonths,RenewalCardStatus,BalanceThreshold,FinancialActivityWindowInDays,PositiveFinancialActivityWindow,UtilizeReplacementPackage,AccountValueLimits,FixedValue,MinValue,MaxValue,MinLoadOnCard,MaxLoadonCard,ThirdLineEmbossing,ThirdLineEmbossStaticName,FourthLineEmbossing,FourthLineEmbossStaticName,EmbossOrPrintBeginDates,EmbossOrPrintExpireDates,EmbossOrPrintSecurityCode,SendPIN,PINMailerLag,PINMethod,CarrierSlotType,ReturnAddress1,ReturnAddress2,ReturnAddress3,ReturnAddress4,PrintLine1AccountNumber,PrintLine2ExpirationDate,PrintLine3CardholderName,PrintLine4,PrintProxy,PrintIndentCardNumber,PrintSecurityCodeOnIndent,IssueDuplicateCard,EmbossFullDate,SortBySequentialProxyNumber,PassCardHolderPhoneNumber,PassCardholderEmail,PassCardholderDARoutingInfo,PassCountry,PassOtherInformation,PassClientAltValue,ParsingRulesToAddress,ShipmentRecordsFlag,MagName,FulfillmentInstructions1,FulfillmentInstructions2,DiscretionaryData1,DiscretionaryData2,DiscretionaryData3,CardNumberEmbossingMask,SecondaryCardsFlag,NumberOfSecondaryCards,MaxActivationAttempts,AllowBillPayFunctionality,BlockBillingTransactionFlag,ValueLoaduponActivation,ExpiredCardConfig,RetailReloadNetworkServices,MoneyTransferSetupFlag,SetupMasterCardMoneySend,PFraudConfig,EnableOpenToBuyBalanceAtPOS,BlockCountry,UnblockCountry,IncludeCountry,VelocityLimitPeriodInDays,ValueLoadNumberPerPeriod,ValueLoadAmountPerPeriod,FrozenFromActivationInDays,FreqLimitForAddressChange,MaxNumberOfAddressChanges,ApplNotConsideredForAddressVelocity,ClearNegativeBalances,LiabilityOnNegativeBalances,MaxNegativeBalanceAutoCleared,AccountStatusNotAutoCleared,MaxNegativeBalanceManuallyCleared,ClearNegativeBalancesAfterEventInDays,DisputeResolutionServiceFlag,DisputeProcessGuideLine,TempCreditToApplyInDays,TempCreditDisputeToApplyInDays,DisputeLettersMailed,SettleServiceAndMoneyMove,CustomerServicePhoneNumber,MinAutoChargeBackReviewInDays,AccountWithPositiveBalance,Statements,OnlineStatements,PaperStatements,PrintBydefaultOrCHOption,StatementCycle,TransactionActivity,BalanceGreaterThan,BalanceLessThan,AccountStatus,StatementPaper,StatementTemplate,StatementFileFormat,DirectAccessConfig,DDASponsorBank,RoutingTransitNumber,BankPrefix,Withdrawal,ValueLoadDirectDepositLimitCheck,CardStatusUpdate,CardStatusToPFraud,FAXNumber,NameMatchForIRSTaxRefunds,ACHTrialDepositVerificationConfig,UserInputAttemptsPermitted,ValidationInDays,ACHAccountDisplay,ValueLoadWaitPeriod,NumberOfExternalBankAccounts,ClientACHAccountDisplay,EffectiveEntryDays,Active,ReturnCVV2,ReturnExpirationDate,InstantConfigured,StandardConfigured,StandardWaitPeriodInDays,PPDBNumber,AccountToAccountTransferConfig,SenderMaxNumberOfRecipients,SenderLengthOffPeriod,SenderMaxTransfersPerPeriod,SenderMaxTransferAmountPerPeriod,SenderTransfersInDays,SenderMaxTransferAmountPerDay,SenderMaxAmountPerTransaction,SenderMinAmountPerTransaction,SenderAllowFeeReversal,SenderQualifiedStatus,SenderDestinationClients,SearchReceiverCriteria,TieBreakerRules,ReceiverLengthofPeriod,ReceiverMaxNumberOfTransfersPerPeriod,ReceiverMaxTransferAmountPerPeriod,ReceiverMaxNumberofTransfersPerDay,ReceiverMaxTransferAmountPerDay,ReceiverMaxAmountPerTransaction,ReceiverMinAmountPerTransaction,ReceiverQualifiedStatus,ReceiverDestinationClients,BlockGamblingMerchantsMCC7995,BlockCashandQuasiCash,OtherMCCsRestricted,AdditionalProxyLength,IVRSecondaryAuthMethod,AutoRenewalOnValueLoad,SetupRegionalNetworkMoneyTransfer,DisputeFormTempCredit,TokenizationAllowed,IsACHFastPayEnabled,SenderReversalDays,ReceiverAllowFeeReversal,ReceiverReversalDays,IVROrMyAccountPINOptions,RestrictAdjust,FulfillmentRequestType,StatementMessageContents,StartDate,EndDate,DefaultPurseForDirectAccess,Copay,MCCGroupCopay,FutureUse2,FutureUse3,PBM,MCCGroupPayAndChase,NetworkName,PurseStatusAutoRenewal,RandomPINCardGeneration,[FileName],
(src.[FileName]=tgt.[FileName] and src.F1=tgt.RecordType and src.F2=tgt.SubProgramID and src.F3=tgt.SubProgramName and src.F4=tgt.SubProgramActiveFlag and src.F5=tgt.ProgramID and src.F6=tgt.ProgramName and src.F7=tgt.ClientID and src.F8=tgt.ClientName and src.F9=tgt.ClientAltValue and src.F10=tgt.TemplateSubProgramID and src.F11=tgt.FISAssumeFraudLiability and src.F12=tgt.ProxyName and src.F13=tgt.AKAName and src.F14=tgt.PseudoBIN and src.F15=tgt.MarketSegment and src.F16=tgt.ProgramLevel and src.F17=tgt.ProgramUseProxyNumbers and src.F18=tgt.ProxyType and src.F19=tgt.IVRAuthenticationMethod and src.F20=tgt.CardType and src.F21=tgt.ProgramType and src.F22=tgt.PINBased and src.F23=tgt.PINTries and src.F24=tgt.NumberOfDaysPINLocked and src.F25=tgt.RePlastic and src.F26=tgt.AdvanceExpire and src.F27=tgt.PrivacyOptOut and src.F28=tgt.LoadSuspend and src.F29=tgt.ApproveMissingTransaction and src.F30=tgt.SkipExpiredClosedCardDDA and src.F31=tgt.AreCardsReloadable and src.F32=tgt.InitialCardStatus and src.F33=tgt.ActiveMethod and src.F34=tgt.HowWillCardsBeActivated and src.F35=tgt.PhysicalExpirationMethod and src.F36=tgt.PhysicalExpirationDate and src.F37=tgt.PhysicalExpirationMonth and src.F38=tgt.Logical and src.F39=tgt.LogicalDynamic and src.F40=tgt.LogicalExpireEvent and src.F41=tgt.AutoRenewal and src.F42=tgt.RenewalWindow and src.F43=tgt.RenewalMonths and src.F44=tgt.RenewalCardStatus and src.F45=tgt.BalanceThreshold and src.F46=tgt.FinancialActivityWindowInDays and src.F47=tgt.PositiveFinancialActivityWindow and src.F48=tgt.UtilizeReplacementPackage and src.F49=tgt.AccountValueLimits and src.F50=tgt.FixedValue and src.F51=tgt.MinValue and src.F52=tgt.MaxValue and src.F53=tgt.MinLoadOnCard and src.F54=tgt.MaxLoadonCard and src.F55=tgt.ThirdLineEmbossing and src.F56=tgt.ThirdLineEmbossStaticName and src.F57=tgt.FourthLineEmbossing and src.F58=tgt.FourthLineEmbossStaticName and src.F59=tgt.EmbossOrPrintBeginDates and src.F60=tgt.EmbossOrPrintExpireDates and src.F61=tgt.EmbossOrPrintSecurityCode and src.F62=tgt.SendPIN and src.F63=tgt.PINMailerLag and src.F64=tgt.PINMethod and src.F65=tgt.CarrierSlotType and src.F66=tgt.ReturnAddress1 and src.F67=tgt.ReturnAddress2 and src.F68=tgt.ReturnAddress3 and src.F69=tgt.ReturnAddress4 and src.F70=tgt.PrintLine1AccountNumber and src.F71=tgt.PrintLine2ExpirationDate and src.F72=tgt.PrintLine3CardholderName and src.F73=tgt.PrintLine4 and src.F74=tgt.PrintProxy and src.F75=tgt.PrintIndentCardNumber and src.F76=tgt.PrintSecurityCodeOnIndent and src.F77=tgt.IssueDuplicateCard and src.F78=tgt.EmbossFullDate and src.F79=tgt.SortBySequentialProxyNumber and src.F80=tgt.PassCardHolderPhoneNumber and src.F81=tgt.PassCardholderEmail and src.F82=tgt.PassCardholderDARoutingInfo and src.F83=tgt.PassCountry and src.F84=tgt.PassOtherInformation and src.F85=tgt.PassClientAltValue and src.F86=tgt.ParsingRulesToAddress and src.F87=tgt.ShipmentRecordsFlag and src.F88=tgt.MagName and src.F89=tgt.FulfillmentInstructions1 and src.F90=tgt.FulfillmentInstructions2 and src.F91=tgt.DiscretionaryData1 and src.F92=tgt.DiscretionaryData2 and src.F93=tgt.DiscretionaryData3 and src.F94=tgt.CardNumberEmbossingMask and src.F95=tgt.SecondaryCardsFlag and src.F96=tgt.NumberOfSecondaryCards and src.F97=tgt.MaxActivationAttempts and src.F98=tgt.AllowBillPayFunctionality and src.F99=tgt.BlockBillingTransactionFlag and src.F100=tgt.ValueLoaduponActivation and src.F101=tgt.ExpiredCardConfig and src.F102=tgt.RetailReloadNetworkServices and src.F103=tgt.MoneyTransferSetupFlag and src.F104=tgt.SetupMasterCardMoneySend and src.F105=tgt.PFraudConfig and src.F106=tgt.EnableOpenToBuyBalanceAtPOS and src.F107=tgt.BlockCountry and src.F108=tgt.UnblockCountry and src.F109=tgt.IncludeCountry and src.F110=tgt.VelocityLimitPeriodInDays and src.F111=tgt.ValueLoadNumberPerPeriod and src.F112=tgt.ValueLoadAmountPerPeriod and src.F113=tgt.FrozenFromActivationInDays and src.F114=tgt.FreqLimitForAddressChange and src.F115=tgt.MaxNumberOfAddressChanges and src.F116=tgt.ApplNotConsideredForAddressVelocity and src.F117=tgt.ClearNegativeBalances and src.F118=tgt.LiabilityOnNegativeBalances and src.F119=tgt.MaxNegativeBalanceAutoCleared and src.F120=tgt.AccountStatusNotAutoCleared and src.F121=tgt.MaxNegativeBalanceManuallyCleared and src.F122=tgt.ClearNegativeBalancesAfterEventInDays and src.F123=tgt.DisputeResolutionServiceFlag and src.F124=tgt.DisputeProcessGuideLine and src.F125=tgt.TempCreditToApplyInDays and src.F126=tgt.TempCreditDisputeToApplyInDays and src.F127=tgt.DisputeLettersMailed and src.F128=tgt.SettleServiceAndMoneyMove and src.F129=tgt.CustomerServicePhoneNumber and src.F130=tgt.MinAutoChargeBackReviewInDays and src.F131=tgt.AccountWithPositiveBalance and src.F132=tgt.Statements and src.F133=tgt.OnlineStatements and src.F134=tgt.PaperStatements and src.F135=tgt.PrintBydefaultOrCHOption and src.F136=tgt.StatementCycle and src.F137=tgt.TransactionActivity and src.F138=tgt.BalanceGreaterThan and src.F139=tgt.BalanceLessThan and src.F140=tgt.AccountStatus and src.F141=tgt.StatementPaper and src.F142=tgt.StatementTemplate and src.F143=tgt.StatementFileFormat and src.F144=tgt.DirectAccessConfig and src.F145=tgt.DDASponsorBank and src.F146=tgt.RoutingTransitNumber and src.F147=tgt.BankPrefix and src.F148=tgt.Withdrawal and src.F149=tgt.ValueLoadDirectDepositLimitCheck and src.F150=tgt.CardStatusUpdate and src.F151=tgt.CardStatusToPFraud and src.F152=tgt.FAXNumber and src.F153=tgt.NameMatchForIRSTaxRefunds and src.F154=tgt.ACHTrialDepositVerificationConfig and src.F155=tgt.UserInputAttemptsPermitted and src.F156=tgt.ValidationInDays and src.F157=tgt.ACHAccountDisplay and src.F158=tgt.ValueLoadWaitPeriod and src.F159=tgt.NumberOfExternalBankAccounts and src.F160=tgt.ClientACHAccountDisplay and src.F161=tgt.EffectiveEntryDays and src.F162=tgt.Active and src.F163=tgt.ReturnCVV2 and src.F164=tgt.ReturnExpirationDate and src.F165=tgt.InstantConfigured and src.F166=tgt.StandardConfigured and src.F167=tgt.StandardWaitPeriodInDays and src.F168=tgt.PPDBNumber and src.F169=tgt.AccountToAccountTransferConfig and src.F170=tgt.SenderMaxNumberOfRecipients and src.F171=tgt.SenderLengthOfPeriod and src.F172=tgt.SenderMaxTransfersPerPeriod and src.F173=tgt.SenderMaxTransferAmountPerPeriod and src.F174=tgt.SenderTransfersInDays and src.F175=tgt.SenderMaxTransferAmountPerDay and src.F176=tgt.SenderMaxAmountPerTransaction and src.F177=tgt.SenderMinAmountPerTransaction and src.F178=tgt.SenderAllowFeeReversal and src.F179=tgt.SenderQualifiedStatus and src.F180=tgt.SenderDestinationClients and src.F181=tgt.SearchReceiverCriteria and src.F182=tgt.TieBreakerRules and src.F183=tgt.ReceiverLengthofPeriod and src.F184=tgt.ReceiverMaxNumberOfTransfersPerPeriod and src.F185=tgt.ReceiverMaxTransferAmountPerPeriod and src.F186=tgt.ReceiverMaxNumberofTransfersPerDay and src.F187=tgt.ReceiverMaxTransferAmountPerDay and src.F188=tgt.ReceiverMaxAmountPerTransaction and src.F189=tgt.ReceiverMinAmountPerTransaction and src.F190=tgt.ReceiverQualifiedStatus and src.F191=tgt.ReceiverDestinationClients and src.F192=tgt.BlockGamblingMerchantsMCC7995 and src.F193=tgt.BlockCashandQuasiCash and src.F194=tgt.OtherMCCsRestricted and src.F195=tgt.AdditionalProxyLength and src.F196=tgt.IVRSecondaryAuthMethod and src.F197=tgt.AutoRenewalOnValueLoad and src.F198=tgt.SetupRegionalNetworkMoneyTransfer and src.F199=tgt.DisputeFormTempCredit and src.F200=tgt.TokenizationAllowed and src.F201=tgt.IsACHFastPayEnabled and src.F202=tgt.SenderReversalDays and src.F203=tgt.ReceiverAllowFeeReversal and src.F204=tgt.ReceiverReversalDays and src.F205=tgt.IVROrMyAccountPINOptions and src.F206=tgt.RestrictAdjust and src.F207=tgt.FulfillmentRequestType and src.F208=tgt.StatementMessageContents and src.F209=tgt.StartDate and src.F210=tgt.EndDate and src.F211=tgt.DefaultPurseForDirectAccess and src.F212=tgt.Copay and src.F213=tgt.MCCGroupCopay and src.F214=tgt.FutureUse2 and src.F215=tgt.FutureUse3 and src.F216=tgt.PBM and src.F217=tgt.MCCGroupPayAndChase and src.F218=tgt.NetworkName and src.F219=tgt.PurseStatusAutoRenewal and src.F220=tgt.RandomPINCardGeneration)
*/


MERGE [dbo].[FISCCX_DIIA] AS tgt  
USING (SELECT ID as STGID,F1,F2,F3,F4,F5,F6,F7,F8,F9,F10,[FileName] from [dbo].[FISCCXStg] where ltrim(rtrim(F1)) = 'DIIA' and IsActive = 1 ) as src 
    ON (src.F1=tgt.RecordType and src.F2=tgt.SubProgramID and src.F3=tgt.PurseID and src.F4=tgt.IIAS and src.F5=tgt.IIASDesc and src.F6=tgt.IIASGroupID and src.F7=tgt.IIASGroupDesc and src.F8=tgt.Priority and src.F9=tgt.IsDeleted and src.F10=tgt.IIASGroupPriority and src.[FileName]=tgt.[FileName] )
	 --WHEN MATCHED THEN
        --UPDATE SET Name = src.Name  
    WHEN NOT MATCHED THEN  
			INSERT (STGID,RecordType,SubProgramID,PurseID,IIAS,IIASDesc,IIASGroupID,IIASGroupDesc,[Priority],IsDeleted,IIASGroupPriority,[FileName])	
			VALUES (STGID,F1,F2,F3,F4,F5,F6,F7,F8,F9,F10,[FileName]) ; 

/*
RecordType,SubProgramID,PurseID,IIAS,IIASDesc,IIASGroupID,IIASGroupDesc,Priority,IsDeleted,IIASGroupPriority,[FileName]		
src.F1=tgt.RecordType and src.F2=tgt.SubProgramID and src.F3=tgt.PurseID and src.F4=tgt.IIAS and src.F5=tgt.IIASDesc and src.F6=tgt.IIASGroupID and src.F7=tgt.IIASGroupDesc and src.F8=tgt.Priority and src.F9=tgt.IsDeleted and src.F10=tgt.IIASGroupPriority and src.[FileName]=tgt.[FileName] and 
*/

MERGE [dbo].[FISCCX_DPKG] AS tgt  
USING (SELECT ID as STGID,F1,F2,F3,F4,F5,F6,F7,F8,F9,F10,F11,F12,F13,F14,F15,F16,F17,F18,F19,F20,[FileName] from [dbo].[FISCCXStg] where ltrim(rtrim(F1)) = 'DPKG' and IsActive = 1 ) as src 
	  ON (src.[FileName]=tgt.[FileName] and src.F1=tgt.RecordType and src.F2=tgt.SubProgramID and src.F3=tgt.PackageID and src.F4=tgt.PackageName and src.F5=tgt.ArtworkName and src.F6=tgt.BIN and src.F7=tgt.PrinAndAgentRange and src.F8=tgt.FulfillmentHouse and src.F9=tgt.CardCountThreshold and src.F10=tgt.CardIssuedSequentFlag and src.F11=tgt.BarcodeType and src.F12=tgt.FormFactor and src.F13=tgt.ReplacementPackageID and src.F14=tgt.DuplicateSettlementAwaitInDays and src.F15=tgt.AuthAwaitSettlementInDays and src.F16=tgt.EncodingMethod and src.F17=tgt.PartialAuth and src.F18=tgt.IsDeleted and src.F19=tgt.ImmediateCredit and src.F20=tgt.ApprovedProductList )
	--WHEN MATCHED THEN
        --UPDATE SET Name = src.Name  
    WHEN NOT MATCHED THEN  
			INSERT (STGID,RecordType,SubProgramID,PackageID,PackageName,ArtworkName,BIN,PrinAndAgentRange,FulfillmentHouse,CardCountThreshold,CardIssuedSequentFlag,BarcodeType,FormFactor,ReplacementPackageID,DuplicateSettlementAwaitInDays,AuthAwaitSettlementInDays,EncodingMethod,PartialAuth,IsDeleted,ImmediateCredit,ApprovedProductList,[FileName])	
			VALUES (STGID,F1,F2,F3,F4,F5,F6,F7,F8,F9,F10,F11,F12,F13,F14,F15,F16,F17,F18,F19,F20,[FileName]);

/*
RecordType,SubProgramID,PackageID,PackageName,ArtworkName,BIN,PrinAndAgentRange,FulfillmentHouse,CardCountThreshold,CardIssuedSequentFlag,BarcodeType,FormFactor,ReplacementPackageID,DuplicateSettlementAwaitInDays,AuthAwaitSettlementInDays,EncodingMethod,PartialAuth,IsDeleted,ImmediateCredit,ApprovedProductList,[FileName],
src.F1=tgt.RecordType and src.F2=tgt.SubProgramID and src.F3=tgt.PackageID and src.F4=tgt.PackageName and src.F5=tgt.ArtworkName and src.F6=tgt.BIN and src.F7=tgt.PrinAndAgentRange and src.F8=tgt.FulfillmentHouse and src.F9=tgt.CardCountThreshold and src.F10=tgt.CardIssuedSequentFlag and src.F11=tgt.BarcodeType and src.F12=tgt.FormFactor and src.F13=tgt.ReplacementPackageID and src.F14=tgt.DuplicateSettlementAwaitInDays and src.F15=tgt.AuthAwaitSettlementInDays and src.F16=tgt.EncodingMethod and src.F17=tgt.PartialAuth and src.F18=tgt.IsDeleted and src.F19=tgt.ImmediateCredit and src.F20=tgt.ApprovedProductList and src.[FileName]=tgt.[FileName] and 
*/
COMMIT TRANSACTION FISCCX_Transaction
PRINT 'Success'

END TRY

	BEGIN CATCH
	DECLARE @ErrorMessage NVARCHAR(4000);  
    DECLARE @ErrorSeverity INT;  
    DECLARE @ErrorState INT;  

    SELECT   
        @ErrorMessage = ERROR_MESSAGE(),  
        @ErrorSeverity = ERROR_SEVERITY(),  
        @ErrorState = ERROR_STATE();  
	
		IF (@@TRANCOUNT > 0)
		BEGIN
			ROLLBACK TRANSACTION FISCCX_Transaction
			RAISERROR(@ErrorMessage,@ErrorSeverity,@ErrorState);
			PRINT 'FAILED'
		END

	END CATCH
END



GO


