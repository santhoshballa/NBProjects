drop table [dbo].[FISCCXStg]
truncate table [FISCCXStg]
select distinct 'drop table ' + 'FISCCX' + '_' + F1 from [FISCCXStg]
select distinct 'truncate table ' + 'FISCCX' + '_' + F1 from [FISCCXStg]
select distinct 'select * from ' + 'FISCCX' + '_' + F1 from [FISCCXStg]
select distinct
'select ' + ''''+ table_name + '''' +' as TableName,' +  'FileName,'+  'count(*) as RecordCount from '+ table_name +' group by FileName '+' union ' from information_schema.columns where column_name like 'StgID'

select distinct
'select ' + ''''+ table_name + '''' +' as TableName,'+'count(*) as RecordCount from '+ table_name +' union ' from information_schema.columns where column_name like 'StgID'

select 'FISCCX_DCST' as TableName,FileName,count(*) as RecordCount from FISCCX_DCST group by FileName  union 
select 'FISCCX_DIIA' as TableName,FileName,count(*) as RecordCount from FISCCX_DIIA group by FileName  union 
select 'FISCCX_DODL' as TableName,FileName,count(*) as RecordCount from FISCCX_DODL group by FileName  union 
select 'FISCCX_DPKG' as TableName,FileName,count(*) as RecordCount from FISCCX_DPKG group by FileName  union 
select 'FISCCX_DPRY' as TableName,FileName,count(*) as RecordCount from FISCCX_DPRY group by FileName  union 
select 'FISCCX_DPUR' as TableName,FileName,count(*) as RecordCount from FISCCX_DPUR group by FileName  union 
select 'FISCCX_DSPG' as TableName,FileName,count(*) as RecordCount from FISCCX_DSPG group by FileName  union 
select 'FISCCX_DUSR' as TableName,FileName,count(*) as RecordCount from FISCCX_DUSR group by FileName  union 
select 'FISCCX_Header' as TableName,FileName,count(*) as RecordCount from FISCCX_Header group by FileName  union 
select 'FISCCX_Trailer' as TableName,FileName,count(*) as RecordCount from FISCCX_Trailer group by FileName 


select 'FISCCX_DCST' as TableName,FileName,count(*) as RecordCount from FISCCX_DCST group by FileName  union 
select 'FISCCX_DIIA' as TableName,FileName,count(*) as RecordCount from FISCCX_DIIA group by FileName  union 
select 'FISCCX_DODL' as TableName,FileName,count(*) as RecordCount from FISCCX_DODL group by FileName  union 
select 'FISCCX_DPKG' as TableName,FileName,count(*) as RecordCount from FISCCX_DPKG group by FileName  union 
select 'FISCCX_DPRY' as TableName,FileName,count(*) as RecordCount from FISCCX_DPRY group by FileName  union 
select 'FISCCX_DPUR' as TableName,FileName,count(*) as RecordCount from FISCCX_DPUR group by FileName  union 
select 'FISCCX_DSPG' as TableName,FileName,count(*) as RecordCount from FISCCX_DSPG group by FileName  union 
select 'FISCCX_DUSR' as TableName,FileName,count(*) as RecordCount from FISCCX_DUSR group by FileName  union 
select 'FISCCX_Header' as TableName,FileName,count(*) as RecordCount from FISCCX_Header group by FileName  union 
select 'FISCCX_Trailer' as TableName,FileName,count(*) as RecordCount from FISCCX_Trailer group by FileName 

select count(*) as NoOfColumns from information_schema.columns where table_name like 'FISCCX%'

/*
TableName	RecordCount
FISCCX_DCST	7254
FISCCX_DIIA	7446
FISCCX_DODL	645
FISCCX_DPKG	2424
FISCCX_DPRY	3635
FISCCX_DPUR	8508
FISCCX_DSPG	781
FISCCX_DUSR	42
FISCCX_Header	6
FISCCX_Trailer	6


TableName	RecordCount
FISCCX_DCST	7254
FISCCX_DIIA	7446
FISCCX_DODL	645
FISCCX_DPKG	2424
FISCCX_DPRY	3635
FISCCX_DPUR	8508
FISCCX_DSPG	1562
FISCCX_DUSR	42
FISCCX_Header	6
FISCCX_Trailer	6
*/


drop table FISCCX_DPRY
drop table FISCCX_DODL
drop table FISCCX_DIIA
drop table FISCCX_DCST
drop table FISCCX_TRAILER
drop table FISCCX_DUSR
drop table FISCCX_HEADER
drop table FISCCX_DPUR
drop table FISCCX_DSPG
drop table FISCCX_DPKG

truncate table FISCCX_DODL
truncate table FISCCX_DIIA
truncate table FISCCX_HEADER
truncate table FISCCX_DSPG
truncate table FISCCX_DPUR
truncate table FISCCX_DPRY
truncate table FISCCX_DCST
truncate table FISCCX_DUSR
truncate table FISCCX_DPKG
truncate table FISCCX_TRAILER

select * from FISCCX_DPUR
select * from FISCCX_DUSR
select * from FISCCX_TRAILER
select * from FISCCX_HEADER
select * from FISCCX_DCST
select * from FISCCX_DIIA
select * from FISCCX_DPRY
select * from FISCCX_DODL
select * from FISCCX_DPKG
select * from FISCCX_DSPG

select distinct F1 from [FISCCXStg]
Select * from [dbo].[FISCCXStg] where F1 = 'H' 
Select * from [dbo].[FISCCXStg] where F1 = 'DODL' 
Select * from [dbo].[FISCCXStg] where F1 = 'DPUR' 
Select * from [dbo].[FISCCXStg] where F1 = 'DPKG' 
Select * from [dbo].[FISCCXStg] where F1 = 'DCST' 
Select * from [dbo].[FISCCXStg] where F1 = 'DPRY'
Select * from [dbo].[FISCCXStg] where F1 = 'DUSR'
Select * from [dbo].[FISCCXStg] where F1 = 'DSPG'
Select * from [dbo].[FISCCXStg] where F1 = 'DIIA'
Select * from [dbo].[FISCCXStg] where F1 = 'T'