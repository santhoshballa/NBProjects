-- elig.clientcodes
select  'elig.ClientCodes' as elig_ClientCodes_TableName,* from elig.clientcodes with (nolock) where clientName like '%Health%' and clientName like '%select%' -- H663, carrierID 444
select 'elig.ClientCodes' as elig_ClientCodes_TableName, IsActive, ClientCode, ClientName, DataSource, InsuranceCarrierID, EligStartDate, MasterDataSource, RptClientName from elig.clientcodes with (nolock) where clientName like '%Health%' and clientName like '%select%' -- H663, carrierID 444

IF OBJECT_ID('tempdb..#ClientCodeTemp') IS NOT NULL DROP TABLE #ClientCodeTemp
Create table #ClientCodeTemp 
(ClientCode varchar(20))

insert into #ClientCodeTemp (ClientCode) values ('H663')

-- elig.FileInfo
select 'elig.FileInfo' as FileInfo_TableName,* from elig.FileInfo with (nolock) where direction = 'IN' and ClientCode in (select ClientCode from #ClientCodeTemp) Order by FileInfoID desc

select  'elig.FileTrack' as elig_FileTrack_TableName,  a.CreateDate, a.DateReceived,  a.* from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and 
ClientCode in (select ClientCode from #ClientCodeTemp) 
order by datasource, FiletrackID desc, FileInfoID desc, a.DateReceived Desc

select top 1 'elig.FileTrack | Latest ' as elig_FileTrack_Latest_TableName,a.CreateDate, a.DateReceived,  * from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and 
ClientCode in (select ClientCode from #ClientCodeTemp) 
order by datasource, FiletrackID desc, FileInfoID desc, a.DateReceived Desc

select 'elig.FileTrack | Latest ' as elig_FileTrack_Latest_TableName, max(FileTrackID) as FileTrackIDMax from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and 
ClientCode in (select ClientCode from #ClientCodeTemp)


-- elig.rawEligBenefitData
select top 1 'elig.FileTrack | Latest ' as elig_FileTrack_Latest_TableName, 'RecordsMetrics' as Query, RecordsReceived, RecordsProcessed, RecordsErrored from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and ClientCode in (select ClientCode from #ClientCodeTemp) order by datasource, FiletrackID desc, FileInfoID desc, a.DateReceived Desc
select 'elig.rawEligBenefitData' as elig_rawEligBenefitData_TableName, 'Header' as Query, * from elig.rawEligBenefitData with (nolock) where ClientCode in (select ClientCode from #ClientCodeTemp) and FileTrackID in (select top 1 FileTrackID from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and ClientCode in (select ClientCode from #ClientCodeTemp) order by datasource, FiletrackID desc, FileInfoID desc, a.DateReceived Desc) and rawVCFlex1 like 'MemberID%'
select 'elig.rawEligBenefitData' as elig_rawEligBenefitData_TableName, 'TrailerCountRAW' as Query, rawVCFlex1 as TrailerCountRAW, replace(rawVCFlex1, 'TRL','') as TrailerCountRAW from elig.rawEligBenefitData with (nolock) where ClientCode in (select ClientCode from #ClientCodeTemp) and FileTrackID in (select top 1 FileTrackID from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and ClientCode in (select ClientCode from #ClientCodeTemp) order by datasource, FiletrackID desc, FileInfoID desc, a.DateReceived Desc) and rawVCFlex1 like 'TRL%'
select 'elig.rawEligBenefitData' as elig_rawEligBenefitData_TableName, 'RecordCountRAW' as Query, Count(*) as RecordCountRAW from elig.rawEligBenefitData with (nolock) where ClientCode in (select ClientCode from #ClientCodeTemp) and FileTrackID in (select top 1 FileTrackID from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and ClientCode in (select ClientCode from #ClientCodeTemp) order by datasource, FiletrackID desc, FileInfoID desc, a.DateReceived Desc)
select 'elig.rawEligBenefitData' as elig_rawEligBenefitData_TableName, 'AllRecordsRAW' as Query, * from elig.rawEligBenefitData with (nolock) where ClientCode in (select ClientCode from #ClientCodeTemp) and FileTrackID in (select top 1 FileTrackID from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and ClientCode in (select ClientCode from #ClientCodeTemp) order by datasource, FiletrackID desc, FileInfoID desc, a.DateReceived Desc)
select 'elig.stgEligBenefitData' as elig_stgEligBenefitData_TableName, 'RecordCountSTG' as Query, Count(*) as RecordCount from elig.stgEligBenefitData with (nolock) where FileTrackID in (select top 1 FileTrackID from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and ClientCode in (select ClientCode from #ClientCodeTemp) order by datasource, FiletrackID desc, FileInfoID desc, a.DateReceived Desc )

-- elig.StgEligBenefitData
select 'elig.stgEligBenefitData' as elig_stgEligBenefitData_TableName, 'AllRecordsSTG' as Query, * from elig.stgEligBenefitData with (nolock) where FileTrackID in (select max(FileTrackID) from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and ClientCode in (select ClientCode from #ClientCodeTemp)  )
select 'elig.stgEligBenefitData' as elig_stgEligBenefitData_TableName, Count(*) as RecordCountSTG from elig.stgEligBenefitData with (nolock) where FileTrackID in (select max(FileTrackID) from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and ClientCode in (select ClientCode from #ClientCodeTemp) )

-- elig.StgEligBenefitDataHist
select 'elig.stgEligBenefitDataHist' as elig_stgEligBenefitDataHist_TableName, 'AllRecordsSTGHist' as Query, * from elig.stgEligBenefitDataHist with (nolock) where FileTrackID in (select max(FileTrackID) from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and ClientCode in (select ClientCode from #ClientCodeTemp) )
select 'elig.stgEligBenefitDataHist' as elig_stgEligBenefitDataHist_TableName, Count(*) as RecordCountSTGHist from elig.stgEligBenefitDataHist with (nolock) where FileTrackID in (select max(FileTrackID) from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and ClientCode in (select ClientCode from #ClientCodeTemp) )

-- elig.mstrEligBenefitData
select 'elig.mstrEligBenefitData' as elig_mstrEligBenefitData_TableName, 'AllRecordsMSTR' as Query, * from elig.mstrEligBenefitData with (nolock) where FileTrackID in (select top 1 FileTrackID from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and ClientCode in (select ClientCode from #ClientCodeTemp) order by datasource, FiletrackID desc, FileInfoID desc, a.DateReceived Desc ) and IsActive = 1
select 'elig.mstrEligBenefitData' as elig_mstrEligBenefitData_TableName, Count(*) as RecordCountMSTR from elig.mstrEligBenefitData with (nolock) where FileTrackID in (select top 1 FileTrackID from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and ClientCode in (select ClientCode from #ClientCodeTemp) order by datasource, FiletrackID desc, FileInfoID desc, a.DateReceived Desc )

-- elig.errEligBenefitData
select 'elig.errEligBenefitData' as elig_errEligBenefitData_TableName, 'AllRecordsERR' as Query, * from elig.errEligBenefitData with (nolock) where FileTrackID in (select top 1 FileTrackID from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and ClientCode in (select ClientCode from #ClientCodeTemp) order by datasource, FiletrackID desc, FileInfoID desc, a.DateReceived Desc ) 
select 'elig.errEligBenefitData' as elig_errEligBenefitData_TableName, Count(*) as RecordCountERR from elig.errEligBenefitData with (nolock) where FileTrackID in (select top 1 FileTrackID from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and ClientCode in (select ClientCode from #ClientCodeTemp) order by datasource, FiletrackID desc, FileInfoID desc, a.DateReceived Desc )

-- elig.BenefitCrossWalk
select 'elig.BenefitCrossWalk' as elig_BenefitCrossWalk_TableName,* from elig.BenefitCrossWalk with (nolock) where ClientCode in (select ClientCode from #ClientCodeTemp)
select 'elig.BenefitCrossWalk' as elig_BenefitCrossWalk_TableName,IsActive, ClientCode, ContractNbr, PBPID, HealthPlanNumber, InsuranceCarrierID, InsuranceHealthPlanID from elig.BenefitCrossWalk with (nolock) where ClientCode  in (select ClientCode from #ClientCodeTemp)

-- elig.EligibilityColumnValidation
select 'elig.EligibilityColumnValidation' as elig_EligibilityColumnValidation_TableName, 'AllColumns' as Query, ClientCode, FileType, ClientColumn, rawTableColumn, SourceTable, SourceColumn, TargetTable, TargetColumn, ActiveFlag, UniqueFlag, ChangeFlag, MandatoryFlag, SpanFlag, DateFlag, XWalkFlag, XWalkTable, XWalkColumn from  elig.EligibilityColumnValidation with (nolock) where ClientCode  in (select ClientCode from #ClientCodeTemp) Order by try_cast(replace(rawTableColumn, 'rawVCFlex', '') as int) asc
select 'elig.EligibilityColumnValidation' as elig_EligibilityColumnValidation_TableName, 'ActiveFlag' as Query, ClientCode, FileType, ClientColumn, rawTableColumn, SourceTable, SourceColumn, TargetTable, TargetColumn, ActiveFlag, UniqueFlag, ChangeFlag, MandatoryFlag, SpanFlag, DateFlag, XWalkFlag, XWalkTable, XWalkColumn from  elig.EligibilityColumnValidation with (nolock) where ClientCode  in (select ClientCode from #ClientCodeTemp) and ActiveFlag = 1 Order by try_cast(replace(rawTableColumn, 'rawVCFlex', '') as int) asc
select 'elig.EligibilityColumnValidation' as elig_EligibilityColumnValidation_TableName, 'UniqueFlag' as Query, ClientCode, FileType, ClientColumn, rawTableColumn, SourceTable, SourceColumn, TargetTable, TargetColumn, ActiveFlag, UniqueFlag, ChangeFlag, MandatoryFlag, SpanFlag, DateFlag, XWalkFlag, XWalkTable, XWalkColumn from  elig.EligibilityColumnValidation with (nolock) where ClientCode  in (select ClientCode from #ClientCodeTemp) and UniqueFlag = 1 Order by try_cast(replace(rawTableColumn, 'rawVCFlex', '') as int) asc
select 'elig.EligibilityColumnValidation' as elig_EligibilityColumnValidation_TableName, 'ChangeFlag' as Query, ClientCode, FileType, ClientColumn, rawTableColumn, SourceTable, SourceColumn, TargetTable, TargetColumn, ActiveFlag, UniqueFlag, ChangeFlag, MandatoryFlag, SpanFlag, DateFlag, XWalkFlag, XWalkTable, XWalkColumn from  elig.EligibilityColumnValidation with (nolock) where ClientCode  in (select ClientCode from #ClientCodeTemp) and ChangeFlag = 1 Order by try_cast(replace(rawTableColumn, 'rawVCFlex', '') as int) asc
select 'elig.EligibilityColumnValidation' as elig_EligibilityColumnValidation_TableName, 'MandatoryFlag' as Query, ClientCode, FileType, ClientColumn, rawTableColumn, SourceTable, SourceColumn, TargetTable, TargetColumn, ActiveFlag, UniqueFlag, ChangeFlag, MandatoryFlag, SpanFlag, DateFlag, XWalkFlag, XWalkTable, XWalkColumn from  elig.EligibilityColumnValidation with (nolock) where ClientCode  in (select ClientCode from #ClientCodeTemp) and MandatoryFlag = 1 Order by try_cast(replace(rawTableColumn, 'rawVCFlex', '') as int) asc
select 'elig.EligibilityColumnValidation' as elig_EligibilityColumnValidation_TableName, 'SpanFlag' as Query, ClientCode, FileType, ClientColumn, rawTableColumn, SourceTable, SourceColumn, TargetTable, TargetColumn, ActiveFlag, UniqueFlag, ChangeFlag, MandatoryFlag, SpanFlag, DateFlag, XWalkFlag, XWalkTable, XWalkColumn from  elig.EligibilityColumnValidation with (nolock) where ClientCode  in (select ClientCode from #ClientCodeTemp) and SpanFlag = 1 Order by try_cast(replace(rawTableColumn, 'rawVCFlex', '') as int) asc
select 'elig.EligibilityColumnValidation' as elig_EligibilityColumnValidation_TableName, 'DateFlag' as Query, ClientCode, FileType, ClientColumn, rawTableColumn, SourceTable, SourceColumn, TargetTable, TargetColumn, ActiveFlag, UniqueFlag, ChangeFlag, MandatoryFlag, SpanFlag, DateFlag, XWalkFlag, XWalkTable, XWalkColumn from  elig.EligibilityColumnValidation with (nolock) where ClientCode  in (select ClientCode from #ClientCodeTemp) and DateFlag = 1 Order by try_cast(replace(rawTableColumn, 'rawVCFlex', '') as int) asc
select 'elig.EligibilityColumnValidation' as elig_EligibilityColumnValidation_TableName, 'XWalkFlag' as Query, ClientCode, FileType, ClientColumn, rawTableColumn, SourceTable, SourceColumn, TargetTable, TargetColumn, ActiveFlag, UniqueFlag, ChangeFlag, MandatoryFlag, SpanFlag, DateFlag, XWalkFlag, XWalkTable, XWalkColumn from  elig.EligibilityColumnValidation with (nolock) where ClientCode  in (select ClientCode from #ClientCodeTemp) and XWalkFlag = 1 Order by try_cast(replace(rawTableColumn, 'rawVCFlex', '') as int) asc
select 'elig.EligibilityColumnValidation' as elig_EligibilityColumnValidation_TableName, 'XWalkTable' as Query, ClientCode, FileType, ClientColumn, rawTableColumn, SourceTable, SourceColumn, TargetTable, TargetColumn, ActiveFlag, UniqueFlag, ChangeFlag, MandatoryFlag, SpanFlag, DateFlag, XWalkFlag, XWalkTable, XWalkColumn from  elig.EligibilityColumnValidation with (nolock) where ClientCode  in (select ClientCode from #ClientCodeTemp) and XWalkTable <> '' Order by try_cast(replace(rawTableColumn, 'rawVCFlex', '') as int) asc
select 'elig.EligibilityColumnValidation' as elig_EligibilityColumnValidation_TableName, 'XWalkColumn' as Query, ClientCode, FileType, ClientColumn, rawTableColumn, SourceTable, SourceColumn, TargetTable, TargetColumn, ActiveFlag, UniqueFlag, ChangeFlag, MandatoryFlag, SpanFlag, DateFlag, XWalkFlag, XWalkTable, XWalkColumn from  elig.EligibilityColumnValidation with (nolock) where ClientCode  in (select ClientCode from #ClientCodeTemp) and XWalkColumn <> '' Order by try_cast(replace(rawTableColumn, 'rawVCFlex', '') as int) asc


drop table if exists #rawEligBenefitData -- RAW
drop table if exists #stgEligBenefitData -- STG
drop table if exists #stgEligBenefitDataHist -- STGHist
drop table if exists #BenefitCrossWalk -- CrossWalk
drop table if exists #mstrEligBenefitData  -- MSTR
drop table if exists #errEligBenefitData --ERR

select * into #rawEligBenefitData from (
select distinct 'elig.rawEligBenefitData' as elig_rawEligBenefitData_TableName, rawVCFlex17 as ContractNbr_RAW,rawVCFlex18 as PBPID_RAW from elig.rawEligBenefitData with (nolock) where ClientCode in (select ClientCode from #ClientCodeTemp) and FileTrackID in (select max(FileTrackID) from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and ClientCode in (select ClientCode from #ClientCodeTemp))
) a

select * into #stgEligBenefitData from (
select distinct 'elig.stgEligBenefitData' as elig_stgEligBenefitData_TableName, ContractNbr as ContractNbr_STG,PBPID as PBPID_STG from elig.stgEligBenefitData with (nolock) where FileTrackID in (select max(FileTrackID) from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and ClientCode in (select ClientCode from #ClientCodeTemp))
) a

select * into #stgEligBenefitDataHist from (
select distinct 'elig.stgEligBenefitDataHist' as elig_stgEligBenefitDataHist_TableName, ContractNbr as ContractNbr_STG,PBPID as PBPID_STG from elig.stgEligBenefitDataHist with (nolock) where FileTrackID in (select max(FileTrackID) from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and ClientCode in (select ClientCode from #ClientCodeTemp))
) a

select * into #BenefitCrossWalk from (
select distinct 'elig.BenefitCrossWalk' as elig_BenefitCrossWalk_TableName, ContractNbr as ContractNbr_CrossWalk, PBPID as PBPID_CrossWalk from elig.BenefitCrossWalk with (nolock) where ClientCode in (select ClientCode from #ClientCodeTemp)
) a

select * into #mstrEligBenefitData from (
select distinct 'elig.mstrEligBenefitData' as elig_mstrEligBenefitData_TableName,  ContractNbr as ContractNbr_MSTR,PBPID as PBPID_MSTR from elig.mstrEligBenefitData with (nolock) where FileTrackID in (select max(FileTrackID) from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and ClientCode in (select ClientCode from #ClientCodeTemp) )
) a

select * into #errEligBenefitData from (
select distinct 'elig.errEligBenefitData' as elig_errEligBenefitData_TableName,  ContractNbr as ContractNbr_ERR,PBPID as PBPID_ERR from elig.ErrEligBenefitData with (nolock) where FileTrackID in (select max(FileTrackID) from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and ClientCode in (select ClientCode from #ClientCodeTemp) )
) a


drop table if exists #RawStgCrossWalkMstr 
select * into #RawStgCrossWalkMstr from (
select
a.*, b.*,c.*, d.*, e.*
from #rawEligBenefitData a with (nolock) 
left join #stgEligBenefitData b with (nolock)  on a.ContractNbr_RAW = b.ContractNbr_STG and a.PBPID_RAW = b.PBPID_STG
left join #BenefitCrossWalk c with (nolock) on a.ContractNbr_RAW = c.ContractNbr_CrossWalk and a.PBPID_RAW = c.PBPID_CrossWalk
left join #mstrEligBenefitData d with (nolock) on a.ContractNbr_RAW = d.ContractNbr_MSTR and a.PBPID_RAW = d.PBPID_MSTR
left join #errEligBenefitData e with (nolock) on a.ContractNbr_RAW = e.ContractNbr_ERR and a.PBPID_RAW = e.PBPID_ERR
) a

select * from #RawStgCrossWalkMstr where ContractNbr_RAW like 'H%' order by ContractNBR_CrossWalk, PBPID_CrossWalk


select 'elig.rawEligBenefitData' as elig_rawEligBenefitData_TableName, 'AllRecordsRAW' as Query, * from elig.rawEligBenefitData with (nolock)  where ClientCode in (select ClientCode from #ClientCodeTemp) and FileTrackID in (select max(FileTrackID) from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and ClientCode in (select ClientCode from #ClientCodeTemp) )
and rawVCFlex17 = 'H2246020' and rawVCFlex18 =  '020'

select 'elig.stgEligBenefitData' as elig_stgEligBenefitData_TableName, 'AllRecordsSTG' as Query, * from elig.stgEligBenefitData with (nolock)  where FileTrackID in (select max(FileTrackID) from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and ClientCode in (select ClientCode from #ClientCodeTemp))
and ContractNbr = 'H2246020' and PBPID = '020'

select 'elig.stgEligBenefitDataHist' as elig_errEligBenefitData_TableName, 'AllRecordsSTGHist' as Query, * from elig.stgEligBenefitDataHist with (nolock)  where FileTrackID in (select top 1 FileTrackID from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and ClientCode in (select ClientCode from #ClientCodeTemp) order by datasource, FiletrackID desc, FileInfoID desc, a.DateReceived Desc ) 
and ContractNbr = 'H2246020' and PBPID = '020'

select distinct 'elig.BenefitCrossWalk' as elig_BenefitCrossWalk_TableName,  'CrossWalk' as Query, ContractNbr as ContractNbr_CrossWalk, PBPID as PBPID_CrossWalk from elig.BenefitCrossWalk with (nolock)  where ClientCode in (select ClientCode from #ClientCodeTemp)
and ContractNBr = 'H2246020' and PBPID = '020'

select 'elig.mstrEligBenefitData' as elig_mstrEligBenefitData_TableName, 'AllRecordsMSTR' as Query, * from elig.mstrEligBenefitData with (nolock)  where FileTrackID in (select top 1 FileTrackID from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and ClientCode in (select ClientCode from #ClientCodeTemp) order by datasource, FiletrackID desc, FileInfoID desc, a.DateReceived Desc ) and IsActive = 1
and ContractNbr = 'H2246020' and PBPID = '020'

select 'elig.errEligBenefitData' as elig_errEligBenefitData_TableName, 'AllRecordsERR' as Query, * from elig.errEligBenefitData with (nolock)  where FileTrackID in (select top 1 FileTrackID from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and ClientCode in (select ClientCode from #ClientCodeTemp) order by datasource, FiletrackID desc, FileInfoID desc, a.DateReceived Desc ) 
and ContractNbr = 'H2246020' and PBPID = '020'



/*
select top 10 * from elig.rawEligBenefitData where ClientCode in (select ClientCode from #ClientCodeTemp)
select * from elig.EligibilityColumnValidation where ClientCode in (select ClientCode from #ClientCodeTemp)
select top 10 * from elig.stgEligBenefitData where ClientCode in (select ClientCode from elig.clientcodes  where ClientName like '%Health%' and clientName like '%select%')
select 'elig.ClientCodes' as ClientCodes_TableName, ClientCode from elig.ClientCodes where datasource in (select datasource from elig.mstrEligBenefitData where MasterMemberID in (select MemberID from master.Members where NHMemberID in (select NHmemberID from #NHMemberIDTemp)))
select 'elig.ClientCodes' as ClientCodes_TableName, * from elig.ClientCodes where datasource in (select datasource from elig.mstrEligBenefitData where MasterMemberID in (select MemberID from master.Members where NHMemberID in (select NHmemberID from #NHMemberIDTemp)))
select 'elig.FileInfo' as FileInfo_TableName,* from elig.FileInfo where direction = 'IN' and
ClientCode in (select ClientCode from elig.ClientCodes where datasource in (select datasource from elig.mstrEligBenefitData where MasterMemberID in (select MemberID from master.Members where NHMemberID in (select NHmemberID from #NHMemberIDTemp))))
Order by FileInfoID desc

select top 5 'elig.FileTrack | top 5' as FileTrack_Top5_TableName,a.CreateDate, a.DateReceived,  * from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and 
ClientCode in (select ClientCode from elig.ClientCodes with (nolock)  where datasource in (select datasource from elig.mstrEligBenefitData with (nolock) where MasterMemberID in (select MemberID from master.Members with (nolock) where NHMemberID in (select NHmemberID from #NHMemberIDTemp))))
order by datasource, FiletrackID desc, FileInfoID desc, a.DateReceived Desc

select 'elig.rawEligBenefitData' as rawEligBenefitData_TableName,* from elig.rawEligBenefitData with (nolock)  where 
ClientCode in (select ClientCode from elig.ClientCodes with (nolock)  where datasource in (select datasource from elig.mstrEligBenefitData with (nolock)  where MasterMemberID in (select MemberID from master.Members with (nolock)  where NHMemberID in (select NHmemberID from #NHMemberIDTemp))))
order by FiletrackID desc

select 'elig.stgEligBenefitData' as stgEligBenefitData_TableName,* from elig.stgEligBenefitData with (nolock)  where SubscriberID in (select SubscriberID from elig.mstrEligBenefitData with (nolock)  where MasterMemberID in (select MemberID from master.Members with (nolock)  where NHMemberID in (select NHmemberID from #NHMemberIDTemp)))
order by Filetrackid desc

select 'elig.stgEligBenefitDataHist' as stgEligBenefitDataHist_TableName,* from elig.stgEligBenefitDataHist with (nolock)  where SubscriberID in (select SubscriberID from elig.mstrEligBenefitData with (nolock)  where MasterMemberID in (select MemberID from master.Members with (nolock)  where NHMemberID in (select NHmemberID from #NHMemberIDTemp)))
order by Filetrackid desc

select 'elig.errEligBenefitData' as errEligBenefitData_TableName,* from elig.errEligBenefitData with (nolock)  where SubscriberID in (select SubscriberID from elig.mstrEligBenefitData with (nolock)  where MasterMemberID in (select MemberID from master.Members with (nolock)  where NHMemberID in (select NHmemberID from #NHMemberIDTemp)))
order by Filetrackid desc

select top 1 'elig.FileTrack | Latest ' as elig_FileTrack_Latest_TableName, 'RecordsMetrics' as Query, RecordsReceived, RecordsProcessed, RecordsErrored from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and ClientCode in (select ClientCode from #ClientCodeTemp) order by datasource, FiletrackID desc, FileInfoID desc, a.DateReceived Desc
select 'elig.stgEligBenefitData' as elig_stgEligBenefitData_TableName, 'Header' as AllRecords, * from elig.stgEligBenefitData where FileTrackID in (select top 1 FileTrackID from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and ClientCode in (select ClientCode from #ClientCodeTemp) order by datasource, FiletrackID desc, FileInfoID desc, a.DateReceived Desc)

select 'elig.rawEligBenefitData' as elig_rawEligBenefitData_TableName, 'TrailerCount' as Query,  rawVCFlex1 as TrailerCount from elig.rawEligBenefitData where ClientCode in (select ClientCode from #ClientCodeTemp) and FileTrackID in (select top 1 FileTrackID from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and ClientCode in (select ClientCode from #ClientCodeTemp) order by datasource, FiletrackID desc, FileInfoID desc, a.DateReceived Desc) and rawVCFlex1 like 'TRL%'
select 'elig.rawEligBenefitData' as elig_rawEligBenefitData_TableName, 'RecordCount' as Query, Count(*) as RecordCount from elig.rawEligBenefitData where ClientCode in (select ClientCode from #ClientCodeTemp) and FileTrackID in (select top 1 FileTrackID from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and ClientCode in (select ClientCode from #ClientCodeTemp) order by datasource, FiletrackID desc, FileInfoID desc, a.DateReceived Desc)
select 'elig.rawEligBenefitData' as elig_rawEligBenefitData_TableName, 'AllRecords' as Query, * from elig.rawEligBenefitData where ClientCode in (select ClientCode from #ClientCodeTemp) and FileTrackID in (select top 1 FileTrackID from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and ClientCode in (select ClientCode from #ClientCodeTemp) order by datasource, FiletrackID desc, FileInfoID desc, a.DateReceived Desc)

*/
