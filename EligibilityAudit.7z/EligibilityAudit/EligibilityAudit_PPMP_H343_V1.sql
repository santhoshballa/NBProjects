/*
PPMP Eligibility Audit | Looks good | 3 Account have issues | ('PT3013114','CH3011388','MO3012486') | Duplicate accounts with different benefit dates 

*/

-- elig.clientcodes
select 'elig.ClientCodes' as elig_ClientCodes_TableName,* from elig.clientcodes with (nolock) where clientName like '%PPHP%'  -- H343, carrierID 279 | H343_SSBCI, 279
select 'elig.ClientCodes' as elig_ClientCodes_TableName, IsActive, ClientCode, ClientName, DataSource, InsuranceCarrierID, EligStartDate, MasterDataSource, RptClientName from elig.clientcodes with (nolock) where clientName like '%PPHP%' -- H343, carrierID 279

IF OBJECT_ID('tempdb..#ClientCodeTemp') IS NOT NULL DROP TABLE #ClientCodeTemp
Create table #ClientCodeTemp 
(ClientCode varchar(20))

insert into #ClientCodeTemp (ClientCode) values ('H343')

-- elig.FileInfo
select 'elig.FileInfo' as FileInfo_TableName,* from elig.FileInfo with (nolock) where direction = 'IN' and ClientCode in (select ClientCode from #ClientCodeTemp) Order by FileInfoID desc

select  'elig.FileTrack' as elig_FileTrack_TableName,  a.CreateDate, a.DateReceived,  a.* from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and 
ClientCode in (select ClientCode from #ClientCodeTemp) 
order by datasource, FiletrackID desc, FileInfoID desc, a.DateReceived Desc

select top 1 'elig.FileTrack | Latest ' as elig_FileTrack_Latest_TableName,a.CreateDate, a.DateReceived,  * from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and 
ClientCode in (select ClientCode from #ClientCodeTemp) 
order by datasource, FiletrackID desc, FileInfoID desc, a.DateReceived Desc

select 'elig.FileTrack | Latest ' as elig_FileTrack_Latest_TableName, max(FileTrackID) as FileTrackIDMax from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and 
ClientCode in (select ClientCode from #ClientCodeTemp)


-- elig.rawEligBenefitData | for *34 format, raw contains zero records
select top 1 'elig.FileTrack | Latest ' as elig_FileTrack_Latest_TableName, 'RecordsMetrics' as Query, RecordsReceived, RecordsProcessed, RecordsErrored from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and ClientCode in (select ClientCode from #ClientCodeTemp) order by datasource, FiletrackID desc, FileInfoID desc, a.DateReceived Desc
select 'elig.rawEligBenefitData' as elig_rawEligBenefitData_TableName, 'Header' as Query, * from elig.rawEligBenefitData with (nolock) where ClientCode in (select ClientCode from #ClientCodeTemp) and FileTrackID in (select top 1 FileTrackID from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and ClientCode in (select ClientCode from #ClientCodeTemp) order by datasource, FiletrackID desc, FileInfoID desc, a.DateReceived Desc) and rawVCFlex1 like 'MemberID%'
select 'elig.rawEligBenefitData' as elig_rawEligBenefitData_TableName, 'TrailerCountRAW' as Query, rawVCFlex1 as TrailerCountRAW, replace(rawVCFlex1, 'TRL','') as TrailerCountRAW from elig.rawEligBenefitData with (nolock) where ClientCode in (select ClientCode from #ClientCodeTemp) and FileTrackID in (select top 1 FileTrackID from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and ClientCode in (select ClientCode from #ClientCodeTemp) order by datasource, FiletrackID desc, FileInfoID desc, a.DateReceived Desc) and rawVCFlex1 like 'TRL%'
select 'elig.rawEligBenefitData' as elig_rawEligBenefitData_TableName, 'RecordCountRAW' as Query, Count(*) as RecordCountRAW from elig.rawEligBenefitData with (nolock) where ClientCode in (select ClientCode from #ClientCodeTemp) and FileTrackID in (select top 1 FileTrackID from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and ClientCode in (select ClientCode from #ClientCodeTemp) order by datasource, FiletrackID desc, FileInfoID desc, a.DateReceived Desc)
select 'elig.rawEligBenefitData' as elig_rawEligBenefitData_TableName, 'AllRecordsRAW' as Query, * from elig.rawEligBenefitData with (nolock) where ClientCode in (select ClientCode from #ClientCodeTemp) and FileTrackID in (select top 1 FileTrackID from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and ClientCode in (select ClientCode from #ClientCodeTemp) order by datasource, FiletrackID desc, FileInfoID desc, a.DateReceived Desc)
select 'elig.stgEligBenefitData' as elig_stgEligBenefitData_TableName, 'RecordCountSTG' as Query, Count(*) as RecordCount from elig.stgEligBenefitData with (nolock) where FileTrackID in (select top 1 FileTrackID from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and ClientCode in (select ClientCode from #ClientCodeTemp) order by datasource, FiletrackID desc, FileInfoID desc, a.DateReceived Desc )

-- elig.StgEligBenefitData
select 'elig.stgEligBenefitData' as elig_stgEligBenefitData_TableName, 'AllRecordsSTG' as Query, * from elig.stgEligBenefitData with (nolock) where FileTrackID in (select max(FileTrackID) from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and ClientCode in (select ClientCode from #ClientCodeTemp)  )
select 'elig.stgEligBenefitData' as elig_stgEligBenefitData_TableName, Count(*) as RecordCountSTG from elig.stgEligBenefitData with (nolock) where FileTrackID in (select max(FileTrackID) from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and ClientCode in (select ClientCode from #ClientCodeTemp) )

-- elig.StgEligBenefitDataHist
select 'elig.stgEligBenefitDataHist' as elig_stgEligBenefitDataHist_TableName, 'AllRecordsSTGHist' as Query, * from elig.stgEligBenefitDataHist with (nolock) where FileTrackID in (select max(FileTrackID) from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and ClientCode in (select ClientCode from #ClientCodeTemp) )
select 'elig.stgEligBenefitDataHist' as elig_stgEligBenefitDataHist_TableName, Count(*) as RecordCountSTGHist from elig.stgEligBenefitDataHist with (nolock) where FileTrackID in (select max(FileTrackID) from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and ClientCode in (select ClientCode from #ClientCodeTemp) )

-- elig.mstrEligBenefitData
select 'elig.mstrEligBenefitData' as elig_mstrEligBenefitData_TableName, 'AllRecordsMSTR' as Query, * from elig.mstrEligBenefitData with (nolock) where FileTrackID in (select top 1 FileTrackID from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and ClientCode in (select ClientCode from #ClientCodeTemp) order by datasource, FiletrackID desc, FileInfoID desc, a.DateReceived Desc ) and IsActive = 1
select 'elig.mstrEligBenefitData' as elig_mstrEligBenefitData_TableName, Count(*) as RecordCountMSTR from elig.mstrEligBenefitData with (nolock) where FileTrackID in (select top 1 FileTrackID from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and ClientCode in (select ClientCode from #ClientCodeTemp) order by datasource, FiletrackID desc, FileInfoID desc, a.DateReceived Desc )

-- elig.errEligBenefitData
select 'elig.errEligBenefitData' as elig_errEligBenefitData_TableName, 'AllRecordsERR' as Query, * from elig.errEligBenefitData with (nolock) where FileTrackID in (select top 1 FileTrackID from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and ClientCode in (select ClientCode from #ClientCodeTemp) order by datasource, FiletrackID desc, FileInfoID desc, a.DateReceived Desc ) 
select 'elig.errEligBenefitData' as elig_errEligBenefitData_TableName, Count(*) as RecordCountERR from elig.errEligBenefitData with (nolock) where FileTrackID in (select top 1 FileTrackID from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and ClientCode in (select ClientCode from #ClientCodeTemp) order by datasource, FiletrackID desc, FileInfoID desc, a.DateReceived Desc )

-- elig.BenefitCrossWalk
select 'elig.BenefitCrossWalk' as elig_BenefitCrossWalk_TableName,* from elig.BenefitCrossWalk with (nolock) where ClientCode in (select ClientCode from #ClientCodeTemp)
select 'elig.BenefitCrossWalk' as elig_BenefitCrossWalk_TableName,IsActive, ClientCode,GroupNbr, ContractNbr, PBPID, HealthPlanNumber, InsuranceCarrierID, InsuranceHealthPlanID from elig.BenefitCrossWalk with (nolock) where ClientCode  in (select ClientCode from #ClientCodeTemp)

-- elig.EligibilityColumnValidation
select 'elig.EligibilityColumnValidation' as elig_EligibilityColumnValidation_TableName, 'AllColumns' as Query, ClientCode, FileType, ClientColumn, rawTableColumn, SourceTable, SourceColumn, TargetTable, TargetColumn, ActiveFlag, UniqueFlag, ChangeFlag, MandatoryFlag, SpanFlag, DateFlag, XWalkFlag, XWalkTable, XWalkColumn from  elig.EligibilityColumnValidation with (nolock) where ClientCode  in (select ClientCode from #ClientCodeTemp) Order by try_cast(replace(rawTableColumn, 'rawVCFlex', '') as int) asc
select 'elig.EligibilityColumnValidation' as elig_EligibilityColumnValidation_TableName, 'ActiveFlag' as Query, ClientCode, FileType, ClientColumn, rawTableColumn, SourceTable, SourceColumn, TargetTable, TargetColumn, ActiveFlag, UniqueFlag, ChangeFlag, MandatoryFlag, SpanFlag, DateFlag, XWalkFlag, XWalkTable, XWalkColumn from  elig.EligibilityColumnValidation with (nolock) where ClientCode  in (select ClientCode from #ClientCodeTemp) and ActiveFlag = 1 Order by try_cast(replace(rawTableColumn, 'rawVCFlex', '') as int) asc
select 'elig.EligibilityColumnValidation' as elig_EligibilityColumnValidation_TableName, 'UniqueFlag' as Query, ClientCode, FileType, ClientColumn, rawTableColumn, SourceTable, SourceColumn, TargetTable, TargetColumn, ActiveFlag, UniqueFlag, ChangeFlag, MandatoryFlag, SpanFlag, DateFlag, XWalkFlag, XWalkTable, XWalkColumn from  elig.EligibilityColumnValidation with (nolock) where ClientCode  in (select ClientCode from #ClientCodeTemp) and UniqueFlag = 1 Order by try_cast(replace(rawTableColumn, 'rawVCFlex', '') as int) asc
select 'elig.EligibilityColumnValidation' as elig_EligibilityColumnValidation_TableName, 'ChangeFlag' as Query, ClientCode, FileType, ClientColumn, rawTableColumn, SourceTable, SourceColumn, TargetTable, TargetColumn, ActiveFlag, UniqueFlag, ChangeFlag, MandatoryFlag, SpanFlag, DateFlag, XWalkFlag, XWalkTable, XWalkColumn from  elig.EligibilityColumnValidation with (nolock) where ClientCode  in (select ClientCode from #ClientCodeTemp) and ChangeFlag = 1 Order by try_cast(replace(rawTableColumn, 'rawVCFlex', '') as int) asc
select 'elig.EligibilityColumnValidation' as elig_EligibilityColumnValidation_TableName, 'MandatoryFlag' as Query, ClientCode, FileType, ClientColumn, rawTableColumn, SourceTable, SourceColumn, TargetTable, TargetColumn, ActiveFlag, UniqueFlag, ChangeFlag, MandatoryFlag, SpanFlag, DateFlag, XWalkFlag, XWalkTable, XWalkColumn from  elig.EligibilityColumnValidation with (nolock) where ClientCode  in (select ClientCode from #ClientCodeTemp) and MandatoryFlag = 1 Order by try_cast(replace(rawTableColumn, 'rawVCFlex', '') as int) asc
select 'elig.EligibilityColumnValidation' as elig_EligibilityColumnValidation_TableName, 'SpanFlag' as Query, ClientCode, FileType, ClientColumn, rawTableColumn, SourceTable, SourceColumn, TargetTable, TargetColumn, ActiveFlag, UniqueFlag, ChangeFlag, MandatoryFlag, SpanFlag, DateFlag, XWalkFlag, XWalkTable, XWalkColumn from  elig.EligibilityColumnValidation with (nolock) where ClientCode  in (select ClientCode from #ClientCodeTemp) and SpanFlag = 1 Order by try_cast(replace(rawTableColumn, 'rawVCFlex', '') as int) asc
select 'elig.EligibilityColumnValidation' as elig_EligibilityColumnValidation_TableName, 'DateFlag' as Query, ClientCode, FileType, ClientColumn, rawTableColumn, SourceTable, SourceColumn, TargetTable, TargetColumn, ActiveFlag, UniqueFlag, ChangeFlag, MandatoryFlag, SpanFlag, DateFlag, XWalkFlag, XWalkTable, XWalkColumn from  elig.EligibilityColumnValidation with (nolock) where ClientCode  in (select ClientCode from #ClientCodeTemp) and DateFlag = 1 Order by try_cast(replace(rawTableColumn, 'rawVCFlex', '') as int) asc
select 'elig.EligibilityColumnValidation' as elig_EligibilityColumnValidation_TableName, 'XWalkFlag' as Query, ClientCode, FileType, ClientColumn, rawTableColumn, SourceTable, SourceColumn, TargetTable, TargetColumn, ActiveFlag, UniqueFlag, ChangeFlag, MandatoryFlag, SpanFlag, DateFlag, XWalkFlag, XWalkTable, XWalkColumn from  elig.EligibilityColumnValidation with (nolock) where ClientCode  in (select ClientCode from #ClientCodeTemp) and XWalkFlag = 1 Order by try_cast(replace(rawTableColumn, 'rawVCFlex', '') as int) asc
select 'elig.EligibilityColumnValidation' as elig_EligibilityColumnValidation_TableName, 'XWalkTable' as Query, ClientCode, FileType, ClientColumn, rawTableColumn, SourceTable, SourceColumn, TargetTable, TargetColumn, ActiveFlag, UniqueFlag, ChangeFlag, MandatoryFlag, SpanFlag, DateFlag, XWalkFlag, XWalkTable, XWalkColumn from  elig.EligibilityColumnValidation with (nolock) where ClientCode  in (select ClientCode from #ClientCodeTemp) and XWalkTable <> '' Order by try_cast(replace(rawTableColumn, 'rawVCFlex', '') as int) asc
select 'elig.EligibilityColumnValidation' as elig_EligibilityColumnValidation_TableName, 'XWalkColumn' as Query, ClientCode, FileType, ClientColumn, rawTableColumn, SourceTable, SourceColumn, TargetTable, TargetColumn, ActiveFlag, UniqueFlag, ChangeFlag, MandatoryFlag, SpanFlag, DateFlag, XWalkFlag, XWalkTable, XWalkColumn from  elig.EligibilityColumnValidation with (nolock) where ClientCode  in (select ClientCode from #ClientCodeTemp) and XWalkColumn <> '' Order by try_cast(replace(rawTableColumn, 'rawVCFlex', '') as int) asc


drop table if exists #rawEligBenefitData -- RAW
drop table if exists #stgEligBenefitData -- STG
drop table if exists #stgEligBenefitDataHist -- STGHist
drop table if exists #BenefitCrossWalk -- CrossWalk
drop table if exists #mstrEligBenefitData  -- MSTR
drop table if exists #errEligBenefitData --ERR

/* for 834 format, there is no data in the raw table
select * into #rawEligBenefitData from (
select distinct 'elig.rawEligBenefitData' as elig_rawEligBenefitData_TableName, rawVCFlex17 as ContractNbr_RAW,rawVCFlex18 as PBPID_RAW from elig.rawEligBenefitData with (nolock) where ClientCode in (select ClientCode from #ClientCodeTemp) and FileTrackID in (select max(FileTrackID) from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and ClientCode in (select ClientCode from #ClientCodeTemp))
) a
*/

/* Check Duplicates
drop table if exists #stgEligBenefitData
select * into #stgEligBenefitData from (
select distinct 'elig.stgEligBenefitData' as elig_stgEligBenefitData_TableName, ltrim(rtrim(GroupNbr)) as GroupNbr_STG, SubscriberID as SubscriberID_STG, DataSource as DataSource_STG , format(cast(BenefitStartDate as date), 'MM-dd-yyy') as BenefitStartDate_STG, format(cast(BenefitEndDate as date), 'MM-dd-yyyy') as BenefitEndDate_STG,
(CASE WHEN Getdate() between BenefitStartDate and BenefitEndDate THEN 'Active'
	  WHEN Getdate() not between BenefitStartDate and BenefitEndDate THEN 'Expired'
 ELSE 'Expired' 
end ) as ActiveExpired_STG

,ROW_NUMBER() OVER (PARTITION BY SubscriberID ORDER BY SubscriberID, stgEligID DESC) AS rowid

from elig.stgEligBenefitData with (nolock) 
where 1=1 and
FileTrackID in (select max(FileTrackID) from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and ClientCode in (select ClientCode from #ClientCodeTemp))
--DataSource in (select Datasource from elig.ClientCodes where ClientCode in (select ClientCode from #ClientCodeTemp)) 
) a
where a.rowID > 7

select * from elig.stgEligBenefitData with (nolock) where 1=1 and FileTrackID in (select max(FileTrackID) from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and ClientCode in (select ClientCode from #ClientCodeTemp))
and subscriberID= 'CH3005302'


select SubscriberID_STG, groupNbr_STG, BenefitStartdate_stg, benefitenddate_stg, Count(*) as RC from #stgEligBenefitData 
where GroupNBR_stg in (select ltrim(rtrim(GroupNbr)) from elig.BenefitCrossWalk with (nolock) where ClientCode in (select ClientCode from #ClientCodeTemp))
group by SubscriberID_STG, groupNbr_STG, BenefitStartdate_stg, benefitenddate_stg order by 1,2,3,4

*/


select * into #stgEligBenefitData from (
select distinct 'elig.stgEligBenefitData' as elig_stgEligBenefitData_TableName, FileTrackID as FileTrackID_STG, ltrim(rtrim(GroupNbr)) as GroupNbr_STG, SubscriberID as SubscriberID_STG, DataSource as DataSource_STG , format(cast(BenefitStartDate as date), 'MM-dd-yyy') as BenefitStartDate_STG, format(cast(BenefitEndDate as date), 'MM-dd-yyyy') as BenefitEndDate_STG,
(CASE WHEN Getdate() between BenefitStartDate and BenefitEndDate THEN 'Active'
	  WHEN Getdate() not between BenefitStartDate and BenefitEndDate THEN 'Expired'
 ELSE 'Expired' 
end ) as ActiveExpired_STG
from elig.stgEligBenefitData with (nolock) 
where 1=1 and
FileTrackID in (select max(FileTrackID) from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and ClientCode in (select ClientCode from #ClientCodeTemp)) and 
DataSource in (select Datasource from elig.ClientCodes where ClientCode in (select ClientCode from #ClientCodeTemp)) 
) a


select * into #stgEligBenefitDataHist from (
select distinct 'elig.stgEligBenefitDataHist' as elig_stgEligBenefitDataHist_TableName, FileTrackID as FileTrackID_STGHist, ltrim(rtrim(GroupNbr)) as GroupNbr_STGHist, SubscriberID as SubscriberID_STGHist, DataSource as DataSource_STGHist , format(cast(BenefitStartDate as date), 'MM-dd-yyy') as BenefitStartDate_STGHist, format(cast(BenefitEndDate as date), 'MM-dd-yyyy') as BenefitEndDate_STGHist,
(CASE WHEN Getdate() between BenefitStartDate and BenefitEndDate THEN 'Active'
	  WHEN Getdate() not between BenefitStartDate and BenefitEndDate THEN 'Expired'
 ELSE 'Expired' 
end ) as ActiveExpired_STGHist  from elig.stgEligBenefitDataHist with (nolock) where FileTrackID in (select max(FileTrackID) from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and ClientCode in (select ClientCode from #ClientCodeTemp))
) a

--select * from #stgEligBenefitDataHist

select * into #BenefitCrossWalk from (
select distinct 'elig.BenefitCrossWalk' as elig_BenefitCrossWalk_TableName, IsActive as IsActive_CrossWalk, ltrim(rtrim(GroupNbr)) as GroupNbr_Crosswalk, HealthPlanStartDate, HealthPlanEndDate from elig.BenefitCrossWalk with (nolock) where ClientCode in (select ClientCode from #ClientCodeTemp)
) a

-- select * from #BenefitCrossWalk order by 3

select * into #mstrEligBenefitData from (
select distinct 'elig.mstrEligBenefitData' as elig_mstrEligBenefitData_TableName, FileTrackID as FileTrackID_MSTR,  ltrim(rtrim(GroupNbr)) as GroupNbr_MSTR, IsActive as IsActive_MSTR, SubscriberID as SubscriberID_MSTR, DataSource as DataSource_MSTR, format(cast(BenefitStartDate as date), 'MM-dd-yyy') as BenefitStartDate_MSTR, format(cast(BenefitEndDate as date), 'MM-dd-yyyy') as BenefitEndDate_MSTR,
(CASE WHEN Getdate() between BenefitStartDate and BenefitEndDate THEN 'Active'
	  WHEN Getdate() not between BenefitStartDate and BenefitEndDate THEN 'Expired'
 ELSE 'Expired' 
end ) as ActiveExpired_MSTR
from elig.mstrEligBenefitData with (nolock) where 
DataSource in (select Datasource from elig.ClientCodes where ClientCode in (select ClientCode from #ClientCodeTemp)) 
and IsActive = 1 and  Getdate() between BenefitStartDate and BenefitEndDate
) a

/*
-- PT3013114
select 'elig.mstrEligBenefitData' as elig_mstrEligBenefitData_TableName, FileTrackID , SubscriberID, GroupNbr, BenefitStartDate, BenefitEndDate from elig.mstrEligBenefitData with (nolock) where 
DataSource in (select Datasource from elig.ClientCodes where ClientCode in (select ClientCode from #ClientCodeTemp)) and  SubscriberID = 'PT3013114' order by fileTrackID desc

select 'elig.stgEligBenefitData' as elig_stgEligBenefitData_TableName, FileTrackID , SubscriberID, GroupNbr, BenefitStartDate, BenefitEndDate from elig.stgEligbenefitData with (nolock) where 
DataSource in (select Datasource from elig.ClientCodes where ClientCode in (select ClientCode from #ClientCodeTemp)) and  SubscriberID = 'PT3013114' order by FileTrackID desc

-- CH3011388
select 'elig.mstrEligBenefitData' as elig_mstrEligBenefitData_TableName, FileTrackID , SubscriberID, GroupNbr, BenefitStartDate, BenefitEndDate from elig.mstrEligBenefitData with (nolock) where 
DataSource in (select Datasource from elig.ClientCodes where ClientCode in (select ClientCode from #ClientCodeTemp)) and  SubscriberID = 'CH3011388' order by fileTrackID desc

select 'elig.stgEligBenefitData' as elig_stgEligBenefitData_TableName, FileTrackID , SubscriberID, GroupNbr, BenefitStartDate, BenefitEndDate from elig.stgEligbenefitData with (nolock) where 
DataSource in (select Datasource from elig.ClientCodes where ClientCode in (select ClientCode from #ClientCodeTemp)) and  SubscriberID = 'CH3011388' order by FileTrackID desc

--MO3012486
select 'elig.mstrEligBenefitData' as elig_mstrEligBenefitData_TableName, mstrEligID,FileTrackID , SubscriberID, GroupNbr, BenefitStartDate, BenefitEndDate from elig.mstrEligBenefitData with (nolock) where 
DataSource in (select Datasource from elig.ClientCodes where ClientCode in (select ClientCode from #ClientCodeTemp)) and  SubscriberID = 'MO3012486' order by mstrEligID desc, fileTrackID desc

select 'elig.stgEligBenefitData' as elig_stgEligBenefitData_TableName, stgeligID, FileTrackID , SubscriberID, GroupNbr, BenefitStartDate, BenefitEndDate from elig.stgEligbenefitData with (nolock) where 
DataSource in (select Datasource from elig.ClientCodes where ClientCode in (select ClientCode from #ClientCodeTemp)) and  SubscriberID = 'MO3012486' order by stgEligID desc, FileTrackID desc

*/

select distinct GroupNbr_MSTR,BenefitStartDate_MSTR, BenefitEndDate_MSTR, *  from #mstrEligBenefitData where ActiveExpired_MSTR =  'Active' and SubscriberID_MSTR = 'PT3013114' 


select * into #errEligBenefitData from (
select distinct 'elig.errEligBenefitData' as elig_errEligBenefitData_TableName,  ltrim(rtrim(GroupNbr)) as GroupNbr_ERR, SubscriberID as SubscriberID_ERR, DataSource as DataSource_ERR, format(cast(BenefitStartDate as date), 'MM-dd-yyy') as BenefitStartDate_ERR, format(cast(BenefitEndDate as date), 'MM-dd-yyyy') as BenefitEndDate_ERR,

(CASE WHEN Getdate() between BenefitStartDate and BenefitEndDate THEN 'Active'
	  WHEN Getdate() not between BenefitStartDate and BenefitEndDate THEN 'Expired'
 ELSE 'Expired'
end ) as ActiveExpired_ERR from elig.ErrEligBenefitData with (nolock) where FileTrackID in (select max(FileTrackID) from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and ClientCode in (select ClientCode from #ClientCodeTemp) )
) a


drop table if exists #RawStgCrossWalkMstr 
select * into #RawStgCrossWalkMstr from (
select
a.*
--, b.*
,c.*, d.* , e.*
From #stgEligBenefitData a with (nolock) 
--left join #stgEligBenefitDataHist b with (nolock) on a.GroupNbr_STG = b.GroupNbr_STGHist
left join #BenefitCrossWalk c with (nolock) on a.GroupNbr_STG = c.GroupNbr_Crosswalk
left join #mstrEligBenefitData d with (nolock) on a.GroupNbr_STG= d.GroupNbr_MSTR and cast(a.BenefitStartDate_STG as date) = cast(d.BenefitStartDate_MSTR as date) and cast(a.BenefitEndDate_STG as date) = cast(d.BenefitEndDate_MSTR as date) and a.SubscriberID_STG = d.SubscriberID_MSTR and a.DataSource_STG = d.DataSource_MSTR
left join #errEligBenefitData e with (nolock) on a.GroupNbr_STG = e.GroupNbr_ERR and cast(a.BenefitStartDate_STG as date) = cast(e.BenefitStartDate_ERR as date) and cast(a.BenefitEndDate_STG as date)= cast(e.BenefitEndDate_ERR as date) and a.SubscriberID_STG = e.SubscriberID_ERR and a.DataSource_STG = e.DataSource_ERR
) a

--select * from #RawStgCrossWalkMstr where SubscriberID_stg = 'PT3013114' or SubscriberID_MSTR = 'PT3013114'

select * from #RawStgCrossWalkMstr where 1=1 
--and ActiveExpired_STG = 'Active' 
and GroupNbr_Crosswalk is not null 
and GroupNbr_MSTR is null 
and SubscriberID_STG in ('PT3013114','CH3011388','MO3012486')  -- 'CH3010555' comes from the same file
and ActiveExpired_STG = 'Active'
order by subscriberID_STG, BenefitStartDate_STG, BenefitEndDate_STG

--('PT3013114','CH3011388','MO3012486')
drop table if exists #SubscriberIDTemp
Create table #SubscriberIDTemp 
(SubscriberID varchar(20))

insert into #SubscriberIDTemp (SubscriberID) values ('PT3013114')
insert into #SubscriberIDTemp (SubscriberID) values ('CH3011388')
insert into #SubscriberIDTemp (SubscriberID) values ('MO3012486')

select 'STG' as Environment, SubscriberID, BenefitStartDate, BenefitEndDate, GroupNbr, * from elig.stgEligBenefitData where SubscriberID in (select SubscriberID from #SubscriberIDTemp) and (cast(Getdate() as date) between Try_cast(BenefitStartDate as date) and try_cast(BenefitEndDate as date)) and FileTrackID in (select max(FileTrackID) from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and ClientCode in (select ClientCode from #ClientCodeTemp) ) 
select 'STGHist' as Environment, SubscriberID, BenefitStartDate, BenefitEndDate, GroupNbr,* from elig.stgEligBenefitDataHist where SubscriberID in (select SubscriberID from #SubscriberIDTemp) and cast(Getdate() as date) between  Try_cast(BenefitStartDate as date) and try_cast(BenefitEndDate as date) and FileTrackID in (select max(FileTrackID) from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and ClientCode in (select ClientCode from #ClientCodeTemp) )
select 'ERR' as Environment, SubscriberID, BenefitStartDate, BenefitEndDate, GroupNbr, * from elig.errEligBenefitData where SubscriberID in (select SubscriberID from #SubscriberIDTemp) and cast(Getdate() as date) between  Try_cast(BenefitStartDate as date) and try_cast(BenefitEndDate as date) and FileTrackID in (select max(FileTrackID) from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and ClientCode in (select ClientCode from #ClientCodeTemp) )
select 'MSTR' as Environment, SubscriberID, BenefitStartDate, BenefitEndDate, GroupNbr, * from elig.mstrEligBenefitData where SubscriberID in (select SubscriberID from #SubscriberIDTemp) and IsActive =1 order by NhlinkID --and cast(Getdate() as date) between  Try_cast(BenefitStartDate as date) and try_cast(BenefitEndDate as date) 

select * from (

select 1 as OrderNo, 'STG' as Environment, SubscriberID, BenefitStartDate, BenefitEndDate, GroupNbr, Null as IsActive from elig.stgEligBenefitData where SubscriberID in (select SubscriberID from #SubscriberIDTemp) and (cast(Getdate() as date) between Try_cast(BenefitStartDate as date) and try_cast(BenefitEndDate as date)) and FileTrackID in (select max(FileTrackID) from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and ClientCode in (select ClientCode from #ClientCodeTemp) )  union 
select 2 as OrderNo, 'STGHist' as Environment, SubscriberID, BenefitStartDate, BenefitEndDate, GroupNbr, Null as IsActive   from elig.stgEligBenefitDataHist where SubscriberID in (select SubscriberID from #SubscriberIDTemp) and cast(Getdate() as date) between  Try_cast(BenefitStartDate as date) and try_cast(BenefitEndDate as date) and FileTrackID in (select max(FileTrackID) from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and ClientCode in (select ClientCode from #ClientCodeTemp) ) union 
select 3 as OrderNo, 'ERR' as Environment, SubscriberID, BenefitStartDate, BenefitEndDate, GroupNbr, Null as IsActive  from elig.errEligBenefitData where SubscriberID in (select SubscriberID from #SubscriberIDTemp) and cast(Getdate() as date) between  Try_cast(BenefitStartDate as date) and try_cast(BenefitEndDate as date) and FileTrackID in (select max(FileTrackID) from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and ClientCode in (select ClientCode from #ClientCodeTemp) ) union
select 4 as OrderNo, 'MSTR' as Environment, SubscriberID, BenefitStartDate, BenefitEndDate, GroupNbr, IsActive from elig.mstrEligBenefitData where SubscriberID in (select SubscriberID from #SubscriberIDTemp) and IsActive =1  --and cast(Getdate() as date) between  Try_cast(BenefitStartDate as date) and try_cast(BenefitEndDate as date) 
) a
order by SubscriberID, OrderNo


/*
select * from elig.mstrEligBenefitData where
SubscriberID in ('PT3008340', 'PT3008340','PT3008340','PT3008386','PT3008388','PT3008445','PT3008480','PT3008493') and IsActive = 1


select * from #RawStgCrossWalkMstr 
where ActiveExpired_STG = 'Active'
order by GroupNbr_MSTR desc, GroupNbr_Crosswalk desc,  GroupNbr_ERR, GroupNbr_STG

select * from #RawStgCrossWalkMstr 
where ActiveExpired_STG = 'Active' and ActiveExpired_MSTR = 'Active'
order by GroupNbr_MSTR desc, GroupNbr_Crosswalk desc,  GroupNbr_ERR, GroupNbr_STG

select * from #RawStgCrossWalkMstr 
where ActiveExpired_STG = 'Active' and ActiveExpired_MSTR = 'Active'
order by GroupNbr_MSTR desc, GroupNbr_Crosswalk desc,  GroupNbr_ERR, GroupNbr_STG

select distinct * from #RawStgCrossWalkMstr 
where ActiveExpired_STG = 'Expired' and ActiveExpired_MSTR = 'Expired'
order by GroupNbr_MSTR desc, GroupNbr_Crosswalk desc,  GroupNbr_ERR, GroupNbr_STG

select * from #RawStgCrossWalkMstr 
where ActiveExpired_ERR = 'Active'
order by GroupNbr_MSTR desc, GroupNbr_Crosswalk desc,  GroupNbr_ERR, GroupNbr_STG
*/

/*
drop table if exists #rawEligBenefitData -- RAW
drop table if exists #stgEligBenefitData -- STG
drop table if exists #stgEligBenefitDataHist -- STGHist
drop table if exists #BenefitCrossWalk -- CrossWalk
drop table if exists #mstrEligBenefitData  -- MSTR
drop table if exists #errEligBenefitData --ERR

select * into #rawEligBenefitData from (
select distinct 'elig.rawEligBenefitData' as elig_rawEligBenefitData_TableName, rawVCFlex17 as ContractNbr_RAW,rawVCFlex18 as PBPID_RAW from elig.rawEligBenefitData with (nolock) where ClientCode in (select ClientCode from #ClientCodeTemp) and FileTrackID in (select max(FileTrackID) from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and ClientCode in (select ClientCode from #ClientCodeTemp))
) a

select 'elig.rawEligBenefitData' as elig_rawEligBenefitData_TableName, 'AllRecordsRAW' as Query, * from elig.rawEligBenefitData with (nolock)  where ClientCode in (select ClientCode from #ClientCodeTemp) and FileTrackID in (select max(FileTrackID) from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and ClientCode in (select ClientCode from #ClientCodeTemp) )
and rawVCFlex17 = 'H2246020' and rawVCFlex18 =  '020'


select 'elig.stgEligBenefitData' as elig_stgEligBenefitData_TableName, 'AllRecordsSTG' as Query, * from elig.stgEligBenefitData with (nolock)  where FileTrackID in (select max(FileTrackID) from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and ClientCode in (select ClientCode from #ClientCodeTemp))
and GroupNbr in ('PMD20001','POH21001','PPA20001','PPA23004','PPILS20001','TXS23002','PMD22001','PMD23001','PMO22001','PMO23001','PPA22001','PPA23001','PPILS22001','PPILS23001','TXS22001','TXS23001')

select 'elig.stgEligBenefitDataHist' as elig_stgEligBenefitDataHist, 'AllRecordsSTGHist' as Query, * from elig.stgEligBenefitDataHist with (nolock)  where FileTrackID in (select top 1 FileTrackID from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and ClientCode in (select ClientCode from #ClientCodeTemp) order by datasource, FiletrackID desc, FileInfoID desc, a.DateReceived Desc ) 
and  GroupNbr in ('PMD20001','POH21001','PPA20001','PPA23004','PPILS20001','TXS23002','PMD22001','PMD23001','PMO22001','PMO23001','PPA22001','PPA23001','PPILS22001','PPILS23001','TXS22001','TXS23001')

select distinct 'elig.BenefitCrossWalk' as elig_BenefitCrossWalk_TableName,  'CrossWalk' as Query, ContractNbr as ContractNbr_CrossWalk, PBPID as PBPID_CrossWalk from elig.BenefitCrossWalk with (nolock)  where ClientCode in (select ClientCode from #ClientCodeTemp)
and GroupNbr in ('PMD20001','POH21001','PPA20001','PPA23004','PPILS20001','TXS23002','PMD22001','PMD23001','PMO22001','PMO23001','PPA22001','PPA23001','PPILS22001','PPILS23001','TXS22001','TXS23001')

select 'elig.mstrEligBenefitData' as elig_mstrEligBenefitData_TableName, 'AllRecordsMSTR' as Query, * from elig.mstrEligBenefitData with (nolock)  where FileTrackID in (select top 1 FileTrackID from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and ClientCode in (select ClientCode from #ClientCodeTemp) order by datasource, FiletrackID desc, FileInfoID desc, a.DateReceived Desc ) and IsActive = 1
and GroupNbr in ('PMD20001','POH21001','PPA20001','PPA23004','PPILS20001','TXS23002','PMD22001','PMD23001','PMO22001','PMO23001','PPA22001','PPA23001','PPILS22001','PPILS23001','TXS22001','TXS23001')
and GetDate() between BenefitStartDate and BenefitEndDate and IsActive = 1

select 'elig.errEligBenefitData' as elig_errEligBenefitData_TableName, 'AllRecordsERR' as Query, * from elig.errEligBenefitData with (nolock)  where FileTrackID in (select top 1 FileTrackID from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and ClientCode in (select ClientCode from #ClientCodeTemp) order by datasource, FiletrackID desc, FileInfoID desc, a.DateReceived Desc ) 
and  GroupNbr in ('PMD20001','POH21001','PPA20001','PPA23004','PPILS20001','TXS23002','PMD22001','PMD23001','PMO22001','PMO23001','PPA22001','PPA23001','PPILS22001','PPILS23001','TXS22001','TXS23001')

-- Errors 
select 'elig.errEligBenefitData' as elig_errEligBenefitData_TableName, 'AllRecordsERR' as Query, GroupNbr, BenefitStartDate, BenefitEndDate from elig.errEligBenefitData with (nolock)  where FileTrackID in (select top 1 FileTrackID from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and ClientCode in (select ClientCode from #ClientCodeTemp) order by datasource, FiletrackID desc, FileInfoID desc, a.DateReceived Desc ) 
and  GroupNbr in ('PMD20001','POH21001','PPA20001','PPA23004','PPILS20001','TXS23002','PMD22001','PMD23001','PMO22001','PMO23001','PPA22001','PPA23001','PPILS22001','PPILS23001','TXS22001','TXS23001')
and Getdate() between  BenefitStartDate and BenefitEndDate

-- To Check if the Plans are current but errored out
select distinct 'elig.errEligBenefitData' as elig_errEligBenefitData_TableName, 'AllRecordsERRCurrentPlansInErrorTable' as AllRecordsERRCurrentPlansInErrorTableQuery, GroupNbr, BenefitStartDate, BenefitEndDate from elig.errEligBenefitData with (nolock)  where FileTrackID in (select top 1 FileTrackID from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and ClientCode in (select ClientCode from #ClientCodeTemp) order by datasource, FiletrackID desc, FileInfoID desc, a.DateReceived Desc ) 
and  GroupNbr in ('PMD20001','POH21001','PPA20001','PPA23004','PPILS20001','TXS23002','PMD22001','PMD23001','PMO22001','PMO23001','PPA22001','PPA23001','PPILS22001','PPILS23001','TXS22001','TXS23001')
and Getdate() between  BenefitStartDate and BenefitEndDate

-- expired plans
select distinct 'elig.errEligBenefitData' as elig_errEligBenefitData_TableName, 'AllRecordsExpiredPlans' as Query, GroupNbr, BenefitStartDate, BenefitEndDate from elig.errEligBenefitData with (nolock)  where FileTrackID in (select top 1 FileTrackID from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and ClientCode in (select ClientCode from #ClientCodeTemp) order by datasource, FiletrackID desc, FileInfoID desc, a.DateReceived Desc ) 
and  GroupNbr in ('PMD20001','POH21001','PPA20001','PPA23004','PPILS20001','TXS23002','PMD22001','PMD23001','PMO22001','PMO23001','PPA22001','PPA23001','PPILS22001','PPILS23001','TXS22001','TXS23001')
and Getdate() not between  BenefitStartDate and BenefitEndDate

select distinct 'elig.errEligBenefitData' as elig_errEligBenefitData_TableName, 'AllRecordsDistinctExpiredPlans' as Query, GroupNbr from elig.errEligBenefitData with (nolock)  where FileTrackID in (select top 1 FileTrackID from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and ClientCode in (select ClientCode from #ClientCodeTemp) order by datasource, FiletrackID desc, FileInfoID desc, a.DateReceived Desc ) 
and  GroupNbr in ('PMD20001','POH21001','PPA20001','PPA23004','PPILS20001','TXS23002','PMD22001','PMD23001','PMO22001','PMO23001','PPA22001','PPA23001','PPILS22001','PPILS23001','TXS22001','TXS23001')
and Getdate() not between  BenefitStartDate and BenefitEndDate

select Distinct IsActive, BenefitStartDate, BenefitEndDate, GroupNbr from elig.mstrEligBenefitData where GroupNbr in ( 'TXS22001', 'PPILS23001', 'PPA23001', 'PMO23001', 'PMD23001') and IsActive =1 and  Getdate() between  BenefitStartDate and BenefitEndDate
select Distinct IsActive, BenefitStartDate, BenefitEndDate, GroupNbr from elig.mstrEligBenefitData where GroupNbr in ('TXS23002') and IsActive =1 and ( Getdate() between  BenefitStartDate and BenefitEndDate)
select Distinct  BenefitStartDate, BenefitEndDate, GroupNbr  from elig.stgEligBenefitData where GroupNbr in ( 'TXS23002', 'PPA23004', 'PMD23001') and 
Getdate() between  try_cast(BenefitStartDate as date) and try_cast(BenefitEndDate as date)

select Distinct 'elig.stgEligBenefitDataHist' as elig_stgEligBenefitDataHist_TableName,  BenefitStartDate, cast(BenefitStartDate as date) as BenefitStartDate,
--FORMAT( BenefitStartDate, 'MM/dd/yyyy', 'en-US' ),  
BenefitEndDate, cast(BenefitEndDate as date) as BenefitEndDate
--,format(BenefitEndDate, 'MM/dd/yyyy','en-US' )
,GroupNbr, * from elig.stgEligBenefitDataHist with (nolock) where GroupNbr in ( 'TXS23002', 'PPA23004', 'PMD23001') and cast(Getdate() as date) between  Try_cast(BenefitStartDate as date) and try_cast(BenefitEndDate as date)

-- Stage
select Distinct 'elig.stgEligBenefitData' as elig_stgEligBenefitData_TableName, 'ActivePlans' as 'ActivePlansQuery', BenefitStartDate, BenefitEndDate, 
--FORMAT( BenefitStartDate, 'MM/dd/yyyy', 'en-US' ),  
format(cast(BenefitStartDate as date), 'MM-dd-yyy') as BenefitStartDate,
format(cast(BenefitEndDate as date), 'MM-dd-yyyy') as BenefitEndDate
,GroupNbr
--,format(BenefitEndDate, 'MM/dd/yyyy','en-US' ) GroupNbr,
,(CASE WHEN Getdate() between BenefitStartDate and BenefitEndDate THEN 'Active'
	  WHEN Getdate() not between BenefitStartDate and BenefitEndDate THEN 'Expired'
 ELSE 'Expired' 
end ) as ActiveExpired
from elig.stgEligBenefitData where FileTrackID in (select max(FileTrackID) from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and ClientCode in (select ClientCode from #ClientCodeTemp) )
and Getdate() between  BenefitStartDate and BenefitEndDate

-- Stage
select Distinct 'elig.stgEligBenefitData' as elig_stgEligBenefitData_TableName, 'InActivePlans' as 'InActivePlansQuery', BenefitStartDate, BenefitEndDate, 
--FORMAT( BenefitStartDate, 'MM/dd/yyyy', 'en-US' ),  
format(cast(BenefitStartDate as date), 'MM-dd-yyy') as BenefitStartDate,
format(cast(BenefitEndDate as date), 'MM-dd-yyyy') as BenefitEndDate
,GroupNbr
--,format(BenefitEndDate, 'MM/dd/yyyy','en-US' ) GroupNbr,
,(CASE WHEN Getdate() between BenefitStartDate and BenefitEndDate THEN 'Active'
	  WHEN Getdate() not between BenefitStartDate and BenefitEndDate THEN 'Expired'
 ELSE 'Expired' 
end ) as ActiveExpired
from elig.stgEligBenefitData where FileTrackID in (select max(FileTrackID) from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and ClientCode in (select ClientCode from #ClientCodeTemp) )
and Getdate() not between  BenefitStartDate and BenefitEndDate

-- Stage History
select Distinct 'elig.stgEligBenefitDataHist' as elig_stgEligBenefitDataHist_TableName, 'ActivePlans' as 'ActivePlansQuery', BenefitStartDate, BenefitEndDate, 
--FORMAT( BenefitStartDate, 'MM/dd/yyyy', 'en-US' ),  
format(cast(BenefitStartDate as date), 'MM-dd-yyy') as BenefitStartDate,
format(cast(BenefitEndDate as date), 'MM-dd-yyyy') as BenefitEndDate
,GroupNbr
--,format(BenefitEndDate, 'MM/dd/yyyy','en-US' ) GroupNbr,
,(CASE WHEN Getdate() between BenefitStartDate and BenefitEndDate THEN 'Active'
	  WHEN Getdate() not between BenefitStartDate and BenefitEndDate THEN 'Expired'
 ELSE 'Expired' 
end ) as ActiveExpired

from elig.stgEligBenefitDataHist where FileTrackID in (select max(FileTrackID) from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and ClientCode in (select ClientCode from #ClientCodeTemp) )
and Getdate() between  BenefitStartDate and BenefitEndDate


-- Stage History
select Distinct 'elig.stgEligBenefitDataHist' as elig_stgEligBenefitDataHist_TableName, 'InActivePlans' as 'InActivePlansQuery', BenefitStartDate, BenefitEndDate, 
--FORMAT( BenefitStartDate, 'MM/dd/yyyy', 'en-US' ),  
format(cast(BenefitStartDate as date), 'MM-dd-yyy') as BenefitStartDate,
format(cast(BenefitEndDate as date), 'MM-dd-yyyy') as BenefitEndDate
,GroupNbr
--,format(BenefitEndDate, 'MM/dd/yyyy','en-US' ) GroupNbr,
,(CASE WHEN Getdate() between BenefitStartDate and BenefitEndDate THEN 'Active'
	  WHEN Getdate() not between BenefitStartDate and BenefitEndDate THEN 'Expired'
 ELSE 'Expired' 
end ) as ActiveExpired

from elig.stgEligBenefitDataHist where FileTrackID in (select max(FileTrackID) from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and ClientCode in (select ClientCode from #ClientCodeTemp) )
and Getdate() not between  BenefitStartDate and BenefitEndDate


select  BenefitStartDate, BenefitEndDate, GroupNbr,* from elig.stgEligBenefitData where FileTrackID in (select max(FileTrackID) from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and ClientCode in (select ClientCode from #ClientCodeTemp) )
and Getdate() between  BenefitStartDate and BenefitEndDate and GroupNbr = 'TXS23002'
select  BenefitStartDate, BenefitEndDate, GroupNbr,* from elig.stgEligBenefitDataHist where FileTrackID in (select max(FileTrackID) from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and ClientCode in (select ClientCode from #ClientCodeTemp) )
and Getdate() between  BenefitStartDate and BenefitEndDate and GroupNbr = 'TXS23002'


/*
select top 10 * from elig.rawEligBenefitData where ClientCode in (select ClientCode from #ClientCodeTemp)
select * from elig.EligibilityColumnValidation where ClientCode in (select ClientCode from #ClientCodeTemp)
select top 10 * from elig.stgEligBenefitData where ClientCode in (select ClientCode from elig.clientcodes  where ClientName like '%Health%' and clientName like '%select%')
select 'elig.ClientCodes' as ClientCodes_TableName, ClientCode from elig.ClientCodes where datasource in (select datasource from elig.mstrEligBenefitData where MasterMemberID in (select MemberID from master.Members where NHMemberID in (select NHmemberID from #NHMemberIDTemp)))
select 'elig.ClientCodes' as ClientCodes_TableName, * from elig.ClientCodes where datasource in (select datasource from elig.mstrEligBenefitData where MasterMemberID in (select MemberID from master.Members where NHMemberID in (select NHmemberID from #NHMemberIDTemp)))
select 'elig.FileInfo' as FileInfo_TableName,* from elig.FileInfo where direction = 'IN' and
ClientCode in (select ClientCode from elig.ClientCodes where datasource in (select datasource from elig.mstrEligBenefitData where MasterMemberID in (select MemberID from master.Members where NHMemberID in (select NHmemberID from #NHMemberIDTemp))))
Order by FileInfoID desc

select top 5 'elig.FileTrack | top 5' as FileTrack_Top5_TableName,a.CreateDate, a.DateReceived,  * from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and 
ClientCode in (select ClientCode from elig.ClientCodes with (nolock)  where datasource in (select datasource from elig.mstrEligBenefitData with (nolock) where MasterMemberID in (select MemberID from master.Members with (nolock) where NHMemberID in (select NHmemberID from #NHMemberIDTemp))))
order by datasource, FiletrackID desc, FileInfoID desc, a.DateReceived Desc

select 'elig.rawEligBenefitData' as rawEligBenefitData_TableName,* from elig.rawEligBenefitData with (nolock)  where 
ClientCode in (select ClientCode from elig.ClientCodes with (nolock)  where datasource in (select datasource from elig.mstrEligBenefitData with (nolock)  where MasterMemberID in (select MemberID from master.Members with (nolock)  where NHMemberID in (select NHmemberID from #NHMemberIDTemp))))
order by FiletrackID desc

select 'elig.stgEligBenefitData' as stgEligBenefitData_TableName,* from elig.stgEligBenefitData with (nolock)  where SubscriberID in (select SubscriberID from elig.mstrEligBenefitData with (nolock)  where MasterMemberID in (select MemberID from master.Members with (nolock)  where NHMemberID in (select NHmemberID from #NHMemberIDTemp)))
order by Filetrackid desc

select 'elig.stgEligBenefitDataHist' as stgEligBenefitDataHist_TableName,* from elig.stgEligBenefitDataHist with (nolock)  where SubscriberID in (select SubscriberID from elig.mstrEligBenefitData with (nolock)  where MasterMemberID in (select MemberID from master.Members with (nolock)  where NHMemberID in (select NHmemberID from #NHMemberIDTemp)))
order by Filetrackid desc

select 'elig.errEligBenefitData' as errEligBenefitData_TableName,* from elig.errEligBenefitData with (nolock)  where SubscriberID in (select SubscriberID from elig.mstrEligBenefitData with (nolock)  where MasterMemberID in (select MemberID from master.Members with (nolock)  where NHMemberID in (select NHmemberID from #NHMemberIDTemp)))
order by Filetrackid desc

select top 1 'elig.FileTrack | Latest ' as elig_FileTrack_Latest_TableName, 'RecordsMetrics' as Query, RecordsReceived, RecordsProcessed, RecordsErrored from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and ClientCode in (select ClientCode from #ClientCodeTemp) order by datasource, FiletrackID desc, FileInfoID desc, a.DateReceived Desc
select 'elig.stgEligBenefitData' as elig_stgEligBenefitData_TableName, 'Header' as AllRecords, * from elig.stgEligBenefitData where FileTrackID in (select top 1 FileTrackID from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and ClientCode in (select ClientCode from #ClientCodeTemp) order by datasource, FiletrackID desc, FileInfoID desc, a.DateReceived Desc)

select 'elig.rawEligBenefitData' as elig_rawEligBenefitData_TableName, 'TrailerCount' as Query,  rawVCFlex1 as TrailerCount from elig.rawEligBenefitData where ClientCode in (select ClientCode from #ClientCodeTemp) and FileTrackID in (select top 1 FileTrackID from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and ClientCode in (select ClientCode from #ClientCodeTemp) order by datasource, FiletrackID desc, FileInfoID desc, a.DateReceived Desc) and rawVCFlex1 like 'TRL%'
select 'elig.rawEligBenefitData' as elig_rawEligBenefitData_TableName, 'RecordCount' as Query, Count(*) as RecordCount from elig.rawEligBenefitData where ClientCode in (select ClientCode from #ClientCodeTemp) and FileTrackID in (select top 1 FileTrackID from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and ClientCode in (select ClientCode from #ClientCodeTemp) order by datasource, FiletrackID desc, FileInfoID desc, a.DateReceived Desc)
select 'elig.rawEligBenefitData' as elig_rawEligBenefitData_TableName, 'AllRecords' as Query, * from elig.rawEligBenefitData where ClientCode in (select ClientCode from #ClientCodeTemp) and FileTrackID in (select top 1 FileTrackID from elig.FileTrack a with (nolock)  where DirectionCode = 'IN' and ClientCode in (select ClientCode from #ClientCodeTemp) order by datasource, FiletrackID desc, FileInfoID desc, a.DateReceived Desc)

*/
*/