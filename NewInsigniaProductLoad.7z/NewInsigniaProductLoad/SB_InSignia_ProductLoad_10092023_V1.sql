/*
select * from catalog.ItemTypes
select * from auth.userprofiles where Username like 'sballa' or CreateUser like 'sballa'

*/

begin transaction catalog

insert into catalog.ItemMasterList
(
Itemcode
,[ItemType]
,BrandCode
,FamilyCode
,TechnologyCode
,ModelCode
,StyleCode
, IsActive
, CreateDate
, CreateUser
, ModifyDate
,ModifyUser
,MonauralHCPCSCode
, BinauralHCPCSCode
)

select 'SI_Pure_Charge_And_Go_T_7IX','HA','SIGNIA','T 7IX','SI T 7IX','Pure Charge And Go T 7IX','RIC',1,getdate(),'sballa',getdate(),'sballa','V5257','V5261' UNION ALL
select 'SI_Pure_Charge_And_Go_T_5IX','HA','SIGNIA','T 5IX','SI T 5IX','Pure Charge And Go T 5IX','RIC',1,getdate(),'sballa',getdate(),'sballa','V5257','V5261' UNION ALL
select 'SI_Pure_Charge_And_Go_T_3IX','HA','SIGNIA','T 3IX','SI T 3IX','Pure Charge And Go T 3IX','RIC',1,getdate(),'sballa',getdate(),'sballa','V5257','V5261' UNION ALL
select 'SI_Pure_Charge_And_Go_7IX','HA','SIGNIA','7IX','SI 7IX','Pure Charge And Go 7IX','RIC',1,getdate(),'sballa',getdate(),'sballa','V5257','V5261' UNION ALL
select 'SI_Pure_Charge_And_Go_5IX','HA','SIGNIA','5IX','SI 5IX','Pure Charge And Go 5IX','RIC',1,getdate(),'sballa',getdate(),'sballa','V5257','V5261' UNION ALL
select 'SI_Pure_Charge_And_Go_3IX','HA','SIGNIA','3IX','SI 3IX','Pure Charge And Go 3IX','RIC',1,getdate(),'sballa',getdate(),'sballa','V5257','V5261' UNION ALL
select 'SI_Silk_Charge_And_Go_7IX_L','HA','SIGNIA','7IX L','SI 7IX L','Silk Charge And Go 7IX L','InstantFit',1,getdate(),'sballa',getdate(),'sballa','V5257','V5261' UNION ALL
select 'SI_Silk_Charge_And_Go_7IX_R','HA','SIGNIA','7IX R','SI 7IX R','Silk Charge And Go 7IX R','InstantFit',1,getdate(),'sballa',getdate(),'sballa','V5257','V5261' UNION ALL
select 'SI_Silk_Charge_And_Go_5IX_L','HA','SIGNIA','5IX L','SI 5IX L','Silk Charge And Go 5IX L','InstantFit',1,getdate(),'sballa',getdate(),'sballa','V5257','V5261' UNION ALL
select 'SI_Silk_Charge_And_Go_5IX_R','HA','SIGNIA','5IX R','SI 5IX R','Silk Charge And Go 5IX R','InstantFit',1,getdate(),'sballa',getdate(),'sballa','V5257','V5261' UNION ALL
select 'SI_Silk_Charge_And_Go_3IX_L','HA','SIGNIA','3IX L','SI 3IX L','Silk Charge And Go 3IX L','InstantFit',1,getdate(),'sballa',getdate(),'sballa','V5257','V5261' UNION ALL
select 'SI_Silk_Charge_And_Go_3IX_R','HA','SIGNIA','3IX R','SI 3IX R','Silk Charge And Go 3IX R','InstantFit',1,getdate(),'sballa',getdate(),'sballa','V5257','V5261' UNION ALL
select 'SI_CROS_Pure_Charge_And_Go_IX','CROS','SIGNIA','IX','SI IX','CROS Pure Charge And Go IX','RIC',1,getdate(),'sballa',getdate(),'sballa','V5257','V5261' UNION ALL
select 'SI_CROS_Silk_Charge_And_Go_IX_L','CROS','SIGNIA','IX L','SI IX L','CROS Silk Charge And Go IX L','InstantFit',1,getdate(),'sballa',getdate(),'sballa','V5257','V5261' UNION ALL
select 'SI_CROS_Silk_Charge_And_Go_IX_R','CROS','SIGNIA','IX R','SI IX R','CROS Silk Charge And Go IX R','InstantFit',1,getdate(),'sballa',getdate(),'sballa','V5257','V5261'



insert into catalog.ItemMasterAttributeValues
(AttributeCode
,Itemcode
,ModelAttributeValue
,IsActive
,VendorCode
,Modifier
,ModelAttributeValueDescription
,CreateDate
,CreateUser
,ModifyDate
,ModifyUser
)

select 'COLOR','SI_Pure_Charge_And_Go_T_7IX','SILVER',1,'SI_Pure_Charge_And_Go_T_7IX','NA','SILVER',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_T_7IX','BEIGE',1,'SI_Pure_Charge_And_Go_T_7IX','NA','BEIGE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_T_7IX','BLACK',1,'SI_Pure_Charge_And_Go_T_7IX','NA','BLACK',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_T_7IX','DARK BROWN',1,'SI_Pure_Charge_And_Go_T_7IX','NA','DARK BROWN',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_T_7IX','DARK CHAMPAGNE',1,'SI_Pure_Charge_And_Go_T_7IX','NA','DARK CHAMPAGNE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_T_7IX','FINE GOLD',1,'SI_Pure_Charge_And_Go_T_7IX','NA','FINE GOLD',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_T_7IX','GRAPHITE',1,'SI_Pure_Charge_And_Go_T_7IX','NA','GRAPHITE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_T_7IX','PEARL WHITE',1,'SI_Pure_Charge_And_Go_T_7IX','NA','PEARL WHITE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_T_7IX','ROSE GOLD',1,'SI_Pure_Charge_And_Go_T_7IX','NA','ROSE GOLD',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_T_7IX','DARK BLONDE',1,'SI_Pure_Charge_And_Go_T_7IX','NA','DARK BLONDE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_T_5IX','SILVER',1,'SI_Pure_Charge_And_Go_T_5IX','NA','SILVER',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_T_5IX','BEIGE',1,'SI_Pure_Charge_And_Go_T_5IX','NA','BEIGE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_T_5IX','BLACK',1,'SI_Pure_Charge_And_Go_T_5IX','NA','BLACK',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_T_5IX','DARK BROWN',1,'SI_Pure_Charge_And_Go_T_5IX','NA','DARK BROWN',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_T_5IX','DARK CHAMPAGNE',1,'SI_Pure_Charge_And_Go_T_5IX','NA','DARK CHAMPAGNE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_T_5IX','FINE GOLD',1,'SI_Pure_Charge_And_Go_T_5IX','NA','FINE GOLD',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_T_5IX','GRAPHITE',1,'SI_Pure_Charge_And_Go_T_5IX','NA','GRAPHITE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_T_5IX','PEARL WHITE',1,'SI_Pure_Charge_And_Go_T_5IX','NA','PEARL WHITE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_T_5IX','ROSE GOLD',1,'SI_Pure_Charge_And_Go_T_5IX','NA','ROSE GOLD',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_T_5IX','DARK BLONDE',1,'SI_Pure_Charge_And_Go_T_5IX','NA','DARK BLONDE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_T_3IX','SILVER',1,'SI_Pure_Charge_And_Go_T_3IX','NA','SILVER',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_T_3IX','BEIGE',1,'SI_Pure_Charge_And_Go_T_3IX','NA','BEIGE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_T_3IX','BLACK',1,'SI_Pure_Charge_And_Go_T_3IX','NA','BLACK',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_T_3IX','DARK BROWN',1,'SI_Pure_Charge_And_Go_T_3IX','NA','DARK BROWN',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_T_3IX','DARK CHAMPAGNE',1,'SI_Pure_Charge_And_Go_T_3IX','NA','DARK CHAMPAGNE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_T_3IX','FINE GOLD',1,'SI_Pure_Charge_And_Go_T_3IX','NA','FINE GOLD',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_T_3IX','GRAPHITE',1,'SI_Pure_Charge_And_Go_T_3IX','NA','GRAPHITE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_T_3IX','PEARL WHITE',1,'SI_Pure_Charge_And_Go_T_3IX','NA','PEARL WHITE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_T_3IX','ROSE GOLD',1,'SI_Pure_Charge_And_Go_T_3IX','NA','ROSE GOLD',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_T_3IX','DARK BLONDE',1,'SI_Pure_Charge_And_Go_T_3IX','NA','DARK BLONDE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_7IX','SILVER',1,'SI_Pure_Charge_And_Go_7IX','NA','SILVER',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_7IX','BEIGE',1,'SI_Pure_Charge_And_Go_7IX','NA','BEIGE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_7IX','BLACK',1,'SI_Pure_Charge_And_Go_7IX','NA','BLACK',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_7IX','DARK BROWN',1,'SI_Pure_Charge_And_Go_7IX','NA','DARK BROWN',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_7IX','DARK CHAMPAGNE',1,'SI_Pure_Charge_And_Go_7IX','NA','DARK CHAMPAGNE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_7IX','FINE GOLD',1,'SI_Pure_Charge_And_Go_7IX','NA','FINE GOLD',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_7IX','GRAPHITE',1,'SI_Pure_Charge_And_Go_7IX','NA','GRAPHITE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_7IX','PEARL WHITE',1,'SI_Pure_Charge_And_Go_7IX','NA','PEARL WHITE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_7IX','ROSE GOLD',1,'SI_Pure_Charge_And_Go_7IX','NA','ROSE GOLD',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_7IX','DARK BLONDE',1,'SI_Pure_Charge_And_Go_7IX','NA','DARK BLONDE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_5IX','SILVER',1,'SI_Pure_Charge_And_Go_5IX','NA','SILVER',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_5IX','BEIGE',1,'SI_Pure_Charge_And_Go_5IX','NA','BEIGE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_5IX','BLACK',1,'SI_Pure_Charge_And_Go_5IX','NA','BLACK',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_5IX','DARK BROWN',1,'SI_Pure_Charge_And_Go_5IX','NA','DARK BROWN',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_5IX','DARK CHAMPAGNE',1,'SI_Pure_Charge_And_Go_5IX','NA','DARK CHAMPAGNE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_5IX','FINE GOLD',1,'SI_Pure_Charge_And_Go_5IX','NA','FINE GOLD',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_5IX','GRAPHITE',1,'SI_Pure_Charge_And_Go_5IX','NA','GRAPHITE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_5IX','PEARL WHITE',1,'SI_Pure_Charge_And_Go_5IX','NA','PEARL WHITE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_5IX','ROSE GOLD',1,'SI_Pure_Charge_And_Go_5IX','NA','ROSE GOLD',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_5IX','DARK BLONDE',1,'SI_Pure_Charge_And_Go_5IX','NA','DARK BLONDE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_3IX','SILVER',1,'SI_Pure_Charge_And_Go_3IX','NA','SILVER',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_3IX','BEIGE',1,'SI_Pure_Charge_And_Go_3IX','NA','BEIGE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_3IX','BLACK',1,'SI_Pure_Charge_And_Go_3IX','NA','BLACK',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_3IX','DARK BROWN',1,'SI_Pure_Charge_And_Go_3IX','NA','DARK BROWN',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_3IX','DARK CHAMPAGNE',1,'SI_Pure_Charge_And_Go_3IX','NA','DARK CHAMPAGNE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_3IX','FINE GOLD',1,'SI_Pure_Charge_And_Go_3IX','NA','FINE GOLD',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_3IX','GRAPHITE',1,'SI_Pure_Charge_And_Go_3IX','NA','GRAPHITE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_3IX','PEARL WHITE',1,'SI_Pure_Charge_And_Go_3IX','NA','PEARL WHITE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_3IX','ROSE GOLD',1,'SI_Pure_Charge_And_Go_3IX','NA','ROSE GOLD',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_3IX','DARK BLONDE',1,'SI_Pure_Charge_And_Go_3IX','NA','DARK BLONDE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Silk_Charge_And_Go_7IX_L','BLACK FACEPLATE',1,'SI_Silk_Charge_And_Go_7IX_L','NA','BLACK FACEPLATE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Silk_Charge_And_Go_7IX_L','MOCHA FACEPLATE',1,'SI_Silk_Charge_And_Go_7IX_L','NA','MOCHA FACEPLATE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Silk_Charge_And_Go_7IX_R','BLACK FACEPLATE',1,'SI_Silk_Charge_And_Go_7IX_R','NA','BLACK FACEPLATE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Silk_Charge_And_Go_7IX_R','MOCHA FACEPLATE',1,'SI_Silk_Charge_And_Go_7IX_R','NA','MOCHA FACEPLATE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Silk_Charge_And_Go_5IX_L','BLACK FACEPLATE',1,'SI_Silk_Charge_And_Go_5IX_L','NA','BLACK FACEPLATE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Silk_Charge_And_Go_5IX_L','MOCHA FACEPLATE',1,'SI_Silk_Charge_And_Go_5IX_L','NA','MOCHA FACEPLATE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Silk_Charge_And_Go_5IX_R','BLACK FACEPLATE',1,'SI_Silk_Charge_And_Go_5IX_R','NA','BLACK FACEPLATE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Silk_Charge_And_Go_5IX_R','MOCHA FACEPLATE',1,'SI_Silk_Charge_And_Go_5IX_R','NA','MOCHA FACEPLATE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Silk_Charge_And_Go_3IX_L','BLACK FACEPLATE',1,'SI_Silk_Charge_And_Go_3IX_L','NA','BLACK FACEPLATE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Silk_Charge_And_Go_3IX_L','MOCHA FACEPLATE',1,'SI_Silk_Charge_And_Go_3IX_L','NA','MOCHA FACEPLATE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Silk_Charge_And_Go_3IX_R','BLACK FACEPLATE',1,'SI_Silk_Charge_And_Go_3IX_R','NA','BLACK FACEPLATE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Silk_Charge_And_Go_3IX_R','MOCHA FACEPLATE',1,'SI_Silk_Charge_And_Go_3IX_R','NA','MOCHA FACEPLATE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_CROS_Pure_Charge_And_Go_IX','SILVER',1,'SI_CROS_Pure_Charge_And_Go_IX','NA','SILVER',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_CROS_Pure_Charge_And_Go_IX','BEIGE',1,'SI_CROS_Pure_Charge_And_Go_IX','NA','BEIGE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_CROS_Pure_Charge_And_Go_IX','BLACK',1,'SI_CROS_Pure_Charge_And_Go_IX','NA','BLACK',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_CROS_Pure_Charge_And_Go_IX','DARK BROWN',1,'SI_CROS_Pure_Charge_And_Go_IX','NA','DARK BROWN',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_CROS_Pure_Charge_And_Go_IX','DARK CHAMPAGNE',1,'SI_CROS_Pure_Charge_And_Go_IX','NA','DARK CHAMPAGNE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_CROS_Pure_Charge_And_Go_IX','FINE GOLD',1,'SI_CROS_Pure_Charge_And_Go_IX','NA','FINE GOLD',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_CROS_Pure_Charge_And_Go_IX','GRAPHITE',1,'SI_CROS_Pure_Charge_And_Go_IX','NA','GRAPHITE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_CROS_Pure_Charge_And_Go_IX','PEARL WHITE',1,'SI_CROS_Pure_Charge_And_Go_IX','NA','PEARL WHITE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_CROS_Pure_Charge_And_Go_IX','ROSE GOLD',1,'SI_CROS_Pure_Charge_And_Go_IX','NA','ROSE GOLD',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_CROS_Pure_Charge_And_Go_IX','DARK BLONDE',1,'SI_CROS_Pure_Charge_And_Go_IX','NA','DARK BLONDE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_CROS_Silk_Charge_And_Go_IX_L','BLACK FACEPLATE',1,'SI_CROS_Silk_Charge_And_Go_IX_L','NA','BLACK FACEPLATE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_CROS_Silk_Charge_And_Go_IX_L','MOCHA FACEPLATE',1,'SI_CROS_Silk_Charge_And_Go_IX_L','NA','MOCHA FACEPLATE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_CROS_Silk_Charge_And_Go_IX_R','BLACK FACEPLATE',1,'SI_CROS_Silk_Charge_And_Go_IX_R','NA','BLACK FACEPLATE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_CROS_Silk_Charge_And_Go_IX_R','MOCHA FACEPLATE',1,'SI_CROS_Silk_Charge_And_Go_IX_R','NA','MOCHA FACEPLATE',getdate(),'sballa',getdate(),'sballa'



insert into catalog.ItemMasterAttributeValues
(AttributeCode
,Itemcode
,ModelAttributeValue
,IsActive
,VendorCode
,Modifier
,ModelAttributeValueDescription
,CreateDate
,CreateUser
,ModifyDate
,ModifyUser
)

select 'RECIEVER_POWER','SI_CROS_Pure_Charge_And_Go_IX','HP',1,'SI_CROS_Pure_Charge_And_Go_IX','NA','HP',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_POWER','SI_CROS_Pure_Charge_And_Go_IX','M',1,'SI_CROS_Pure_Charge_And_Go_IX','NA','M',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_POWER','SI_CROS_Pure_Charge_And_Go_IX','P',1,'SI_CROS_Pure_Charge_And_Go_IX','NA','P',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_POWER','SI_CROS_Pure_Charge_And_Go_IX','S',1,'SI_CROS_Pure_Charge_And_Go_IX','NA','S',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_POWER','SI_Pure_Charge_And_Go_3IX','HP',1,'SI_Pure_Charge_And_Go_3IX','NA','HP',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_POWER','SI_Pure_Charge_And_Go_3IX','M',1,'SI_Pure_Charge_And_Go_3IX','NA','M',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_POWER','SI_Pure_Charge_And_Go_3IX','P',1,'SI_Pure_Charge_And_Go_3IX','NA','P',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_POWER','SI_Pure_Charge_And_Go_3IX','S',1,'SI_Pure_Charge_And_Go_3IX','NA','S',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_POWER','SI_Pure_Charge_And_Go_5IX','HP',1,'SI_Pure_Charge_And_Go_5IX','NA','HP',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_POWER','SI_Pure_Charge_And_Go_5IX','M',1,'SI_Pure_Charge_And_Go_5IX','NA','M',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_POWER','SI_Pure_Charge_And_Go_5IX','P',1,'SI_Pure_Charge_And_Go_5IX','NA','P',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_POWER','SI_Pure_Charge_And_Go_5IX','S',1,'SI_Pure_Charge_And_Go_5IX','NA','S',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_POWER','SI_Pure_Charge_And_Go_7IX','HP',1,'SI_Pure_Charge_And_Go_7IX','NA','HP',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_POWER','SI_Pure_Charge_And_Go_7IX','M',1,'SI_Pure_Charge_And_Go_7IX','NA','M',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_POWER','SI_Pure_Charge_And_Go_7IX','P',1,'SI_Pure_Charge_And_Go_7IX','NA','P',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_POWER','SI_Pure_Charge_And_Go_7IX','S',1,'SI_Pure_Charge_And_Go_7IX','NA','S',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_POWER','SI_Pure_Charge_And_Go_T_3IX','HP',1,'SI_Pure_Charge_And_Go_T_3IX','NA','HP',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_POWER','SI_Pure_Charge_And_Go_T_3IX','M',1,'SI_Pure_Charge_And_Go_T_3IX','NA','M',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_POWER','SI_Pure_Charge_And_Go_T_3IX','P',1,'SI_Pure_Charge_And_Go_T_3IX','NA','P',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_POWER','SI_Pure_Charge_And_Go_T_3IX','S',1,'SI_Pure_Charge_And_Go_T_3IX','NA','S',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_POWER','SI_Pure_Charge_And_Go_T_5IX','HP',1,'SI_Pure_Charge_And_Go_T_5IX','NA','HP',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_POWER','SI_Pure_Charge_And_Go_T_5IX','M',1,'SI_Pure_Charge_And_Go_T_5IX','NA','M',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_POWER','SI_Pure_Charge_And_Go_T_5IX','P',1,'SI_Pure_Charge_And_Go_T_5IX','NA','P',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_POWER','SI_Pure_Charge_And_Go_T_5IX','S',1,'SI_Pure_Charge_And_Go_T_5IX','NA','S',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_POWER','SI_Pure_Charge_And_Go_T_7IX','HP',1,'SI_Pure_Charge_And_Go_T_7IX','NA','HP',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_POWER','SI_Pure_Charge_And_Go_T_7IX','M',1,'SI_Pure_Charge_And_Go_T_7IX','NA','M',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_POWER','SI_Pure_Charge_And_Go_T_7IX','P',1,'SI_Pure_Charge_And_Go_T_7IX','NA','P',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_POWER','SI_Pure_Charge_And_Go_T_7IX','S',1,'SI_Pure_Charge_And_Go_T_7IX','NA','S',getdate(),'sballa',getdate(),'sballa'






insert into catalog.ItemMasterAttributeValues
(AttributeCode
,Itemcode
,ModelAttributeValue
,IsActive
,VendorCode
,Modifier
,ModelAttributeValueDescription
,CreateDate
,CreateUser
,ModifyDate
,ModifyUser
)


select 'RECIEVER_SIZES','SI_CROS_Pure_Charge_And_Go_IX','0',1,'SI_CROS_Pure_Charge_And_Go_IX','NA','0',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_CROS_Pure_Charge_And_Go_IX','1',1,'SI_CROS_Pure_Charge_And_Go_IX','NA','1',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_CROS_Pure_Charge_And_Go_IX','2',1,'SI_CROS_Pure_Charge_And_Go_IX','NA','2',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_CROS_Pure_Charge_And_Go_IX','3',1,'SI_CROS_Pure_Charge_And_Go_IX','NA','3',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_CROS_Pure_Charge_And_Go_IX','4',1,'SI_CROS_Pure_Charge_And_Go_IX','NA','4',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_CROS_Pure_Charge_And_Go_IX','83',1,'SI_CROS_Pure_Charge_And_Go_IX','NA','83',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_CROS_Silk_Charge_And_Go_IX_L','0',1,'SI_CROS_Silk_Charge_And_Go_IX_L','NA','0',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_CROS_Silk_Charge_And_Go_IX_L','1',1,'SI_CROS_Silk_Charge_And_Go_IX_L','NA','1',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_CROS_Silk_Charge_And_Go_IX_L','2',1,'SI_CROS_Silk_Charge_And_Go_IX_L','NA','2',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_CROS_Silk_Charge_And_Go_IX_L','3',1,'SI_CROS_Silk_Charge_And_Go_IX_L','NA','3',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_CROS_Silk_Charge_And_Go_IX_L','4',1,'SI_CROS_Silk_Charge_And_Go_IX_L','NA','4',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_CROS_Silk_Charge_And_Go_IX_L','96',1,'SI_CROS_Silk_Charge_And_Go_IX_L','NA','96',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_CROS_Silk_Charge_And_Go_IX_R','0',1,'SI_CROS_Silk_Charge_And_Go_IX_R','NA','0',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_CROS_Silk_Charge_And_Go_IX_R','1',1,'SI_CROS_Silk_Charge_And_Go_IX_R','NA','1',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_CROS_Silk_Charge_And_Go_IX_R','2',1,'SI_CROS_Silk_Charge_And_Go_IX_R','NA','2',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_CROS_Silk_Charge_And_Go_IX_R','3',1,'SI_CROS_Silk_Charge_And_Go_IX_R','NA','3',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_CROS_Silk_Charge_And_Go_IX_R','4',1,'SI_CROS_Silk_Charge_And_Go_IX_R','NA','4',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_CROS_Silk_Charge_And_Go_IX_R','96',1,'SI_CROS_Silk_Charge_And_Go_IX_R','NA','96',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Pure_Charge_And_Go_3IX','0',1,'SI_Pure_Charge_And_Go_3IX','NA','0',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Pure_Charge_And_Go_3IX','1',1,'SI_Pure_Charge_And_Go_3IX','NA','1',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Pure_Charge_And_Go_3IX','2',1,'SI_Pure_Charge_And_Go_3IX','NA','2',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Pure_Charge_And_Go_3IX','3',1,'SI_Pure_Charge_And_Go_3IX','NA','3',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Pure_Charge_And_Go_3IX','4',1,'SI_Pure_Charge_And_Go_3IX','NA','4',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Pure_Charge_And_Go_3IX','64',1,'SI_Pure_Charge_And_Go_3IX','NA','64',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Pure_Charge_And_Go_5IX','0',1,'SI_Pure_Charge_And_Go_5IX','NA','0',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Pure_Charge_And_Go_5IX','1',1,'SI_Pure_Charge_And_Go_5IX','NA','1',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Pure_Charge_And_Go_5IX','2',1,'SI_Pure_Charge_And_Go_5IX','NA','2',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Pure_Charge_And_Go_5IX','3',1,'SI_Pure_Charge_And_Go_5IX','NA','3',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Pure_Charge_And_Go_5IX','4',1,'SI_Pure_Charge_And_Go_5IX','NA','4',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Pure_Charge_And_Go_5IX','45',1,'SI_Pure_Charge_And_Go_5IX','NA','45',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Pure_Charge_And_Go_7IX','0',1,'SI_Pure_Charge_And_Go_7IX','NA','0',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Pure_Charge_And_Go_7IX','1',1,'SI_Pure_Charge_And_Go_7IX','NA','1',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Pure_Charge_And_Go_7IX','2',1,'SI_Pure_Charge_And_Go_7IX','NA','2',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Pure_Charge_And_Go_7IX','3',1,'SI_Pure_Charge_And_Go_7IX','NA','3',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Pure_Charge_And_Go_7IX','4',1,'SI_Pure_Charge_And_Go_7IX','NA','4',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Pure_Charge_And_Go_7IX','44',1,'SI_Pure_Charge_And_Go_7IX','NA','44',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Pure_Charge_And_Go_T_3IX','0',1,'SI_Pure_Charge_And_Go_T_3IX','NA','0',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Pure_Charge_And_Go_T_3IX','1',1,'SI_Pure_Charge_And_Go_T_3IX','NA','1',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Pure_Charge_And_Go_T_3IX','2',1,'SI_Pure_Charge_And_Go_T_3IX','NA','2',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Pure_Charge_And_Go_T_3IX','25',1,'SI_Pure_Charge_And_Go_T_3IX','NA','25',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Pure_Charge_And_Go_T_3IX','3',1,'SI_Pure_Charge_And_Go_T_3IX','NA','3',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Pure_Charge_And_Go_T_3IX','4',1,'SI_Pure_Charge_And_Go_T_3IX','NA','4',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Pure_Charge_And_Go_T_5IX','0',1,'SI_Pure_Charge_And_Go_T_5IX','NA','0',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Pure_Charge_And_Go_T_5IX','1',1,'SI_Pure_Charge_And_Go_T_5IX','NA','1',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Pure_Charge_And_Go_T_5IX','17',1,'SI_Pure_Charge_And_Go_T_5IX','NA','17',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Pure_Charge_And_Go_T_5IX','2',1,'SI_Pure_Charge_And_Go_T_5IX','NA','2',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Pure_Charge_And_Go_T_5IX','3',1,'SI_Pure_Charge_And_Go_T_5IX','NA','3',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Pure_Charge_And_Go_T_5IX','4',1,'SI_Pure_Charge_And_Go_T_5IX','NA','4',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Pure_Charge_And_Go_T_7IX','0',1,'SI_Pure_Charge_And_Go_T_7IX','NA','0',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Pure_Charge_And_Go_T_7IX','1',1,'SI_Pure_Charge_And_Go_T_7IX','NA','1',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Pure_Charge_And_Go_T_7IX','2',1,'SI_Pure_Charge_And_Go_T_7IX','NA','2',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Pure_Charge_And_Go_T_7IX','3',1,'SI_Pure_Charge_And_Go_T_7IX','NA','3',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Pure_Charge_And_Go_T_7IX','4',1,'SI_Pure_Charge_And_Go_T_7IX','NA','4',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Pure_Charge_And_Go_T_7IX','5',1,'SI_Pure_Charge_And_Go_T_7IX','NA','5',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Silk_Charge_And_Go_3IX_L','0',1,'SI_Silk_Charge_And_Go_3IX_L','NA','0',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Silk_Charge_And_Go_3IX_L','1',1,'SI_Silk_Charge_And_Go_3IX_L','NA','1',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Silk_Charge_And_Go_3IX_L','2',1,'SI_Silk_Charge_And_Go_3IX_L','NA','2',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Silk_Charge_And_Go_3IX_L','3',1,'SI_Silk_Charge_And_Go_3IX_L','NA','3',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Silk_Charge_And_Go_3IX_L','4',1,'SI_Silk_Charge_And_Go_3IX_L','NA','4',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Silk_Charge_And_Go_3IX_L','79',1,'SI_Silk_Charge_And_Go_3IX_L','NA','79',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Silk_Charge_And_Go_3IX_R','0',1,'SI_Silk_Charge_And_Go_3IX_R','NA','0',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Silk_Charge_And_Go_3IX_R','1',1,'SI_Silk_Charge_And_Go_3IX_R','NA','1',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Silk_Charge_And_Go_3IX_R','2',1,'SI_Silk_Charge_And_Go_3IX_R','NA','2',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Silk_Charge_And_Go_3IX_R','3',1,'SI_Silk_Charge_And_Go_3IX_R','NA','3',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Silk_Charge_And_Go_3IX_R','4',1,'SI_Silk_Charge_And_Go_3IX_R','NA','4',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Silk_Charge_And_Go_3IX_R','82',1,'SI_Silk_Charge_And_Go_3IX_R','NA','82',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Silk_Charge_And_Go_5IX_L','0',1,'SI_Silk_Charge_And_Go_5IX_L','NA','0',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Silk_Charge_And_Go_5IX_L','1',1,'SI_Silk_Charge_And_Go_5IX_L','NA','1',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Silk_Charge_And_Go_5IX_L','2',1,'SI_Silk_Charge_And_Go_5IX_L','NA','2',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Silk_Charge_And_Go_5IX_L','3',1,'SI_Silk_Charge_And_Go_5IX_L','NA','3',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Silk_Charge_And_Go_5IX_L','4',1,'SI_Silk_Charge_And_Go_5IX_L','NA','4',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Silk_Charge_And_Go_5IX_L','75',1,'SI_Silk_Charge_And_Go_5IX_L','NA','75',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Silk_Charge_And_Go_5IX_R','0',1,'SI_Silk_Charge_And_Go_5IX_R','NA','0',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Silk_Charge_And_Go_5IX_R','1',1,'SI_Silk_Charge_And_Go_5IX_R','NA','1',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Silk_Charge_And_Go_5IX_R','2',1,'SI_Silk_Charge_And_Go_5IX_R','NA','2',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Silk_Charge_And_Go_5IX_R','3',1,'SI_Silk_Charge_And_Go_5IX_R','NA','3',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Silk_Charge_And_Go_5IX_R','4',1,'SI_Silk_Charge_And_Go_5IX_R','NA','4',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Silk_Charge_And_Go_5IX_R','78',1,'SI_Silk_Charge_And_Go_5IX_R','NA','78',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Silk_Charge_And_Go_7IX_L','0',1,'SI_Silk_Charge_And_Go_7IX_L','NA','0',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Silk_Charge_And_Go_7IX_L','1',1,'SI_Silk_Charge_And_Go_7IX_L','NA','1',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Silk_Charge_And_Go_7IX_L','2',1,'SI_Silk_Charge_And_Go_7IX_L','NA','2',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Silk_Charge_And_Go_7IX_L','3',1,'SI_Silk_Charge_And_Go_7IX_L','NA','3',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Silk_Charge_And_Go_7IX_L','4',1,'SI_Silk_Charge_And_Go_7IX_L','NA','4',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Silk_Charge_And_Go_7IX_L','71',1,'SI_Silk_Charge_And_Go_7IX_L','NA','71',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Silk_Charge_And_Go_7IX_R','0',1,'SI_Silk_Charge_And_Go_7IX_R','NA','0',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Silk_Charge_And_Go_7IX_R','1',1,'SI_Silk_Charge_And_Go_7IX_R','NA','1',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Silk_Charge_And_Go_7IX_R','2',1,'SI_Silk_Charge_And_Go_7IX_R','NA','2',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Silk_Charge_And_Go_7IX_R','3',1,'SI_Silk_Charge_And_Go_7IX_R','NA','3',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Silk_Charge_And_Go_7IX_R','4',1,'SI_Silk_Charge_And_Go_7IX_R','NA','4',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Silk_Charge_And_Go_7IX_R','74',1,'SI_Silk_Charge_And_Go_7IX_R','NA','74',getdate(),'sballa',getdate(),'sballa'



insert into catalog.ItemMasterAttributeValues
(AttributeCode
,Itemcode
,ModelAttributeValue
,IsActive
,VendorCode
,Modifier
,ModelAttributeValueDescription
,CreateDate
,CreateUser
,ModifyDate
,ModifyUser
)

select 'BATTERY_SIZES','SI_CROS_Pure_Charge_And_Go_IX','R',1,'SI_CROS_Pure_Charge_And_Go_IX','NA','R',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'BATTERY_SIZES','SI_CROS_Silk_Charge_And_Go_IX_L','R',1,'SI_CROS_Silk_Charge_And_Go_IX_L','NA','R',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'BATTERY_SIZES','SI_CROS_Silk_Charge_And_Go_IX_R','R',1,'SI_CROS_Silk_Charge_And_Go_IX_R','NA','R',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'BATTERY_SIZES','SI_Pure_Charge_And_Go_3IX','R',1,'SI_Pure_Charge_And_Go_3IX','NA','R',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'BATTERY_SIZES','SI_Pure_Charge_And_Go_5IX','R',1,'SI_Pure_Charge_And_Go_5IX','NA','R',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'BATTERY_SIZES','SI_Pure_Charge_And_Go_7IX','R',1,'SI_Pure_Charge_And_Go_7IX','NA','R',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'BATTERY_SIZES','SI_Pure_Charge_And_Go_T_3IX','R',1,'SI_Pure_Charge_And_Go_T_3IX','NA','R',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'BATTERY_SIZES','SI_Pure_Charge_And_Go_T_5IX','R',1,'SI_Pure_Charge_And_Go_T_5IX','NA','R',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'BATTERY_SIZES','SI_Pure_Charge_And_Go_T_7IX','R',1,'SI_Pure_Charge_And_Go_T_7IX','NA','R',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'BATTERY_SIZES','SI_Silk_Charge_And_Go_3IX_L','R',1,'SI_Silk_Charge_And_Go_3IX_L','NA','R',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'BATTERY_SIZES','SI_Silk_Charge_And_Go_3IX_R','R',1,'SI_Silk_Charge_And_Go_3IX_R','NA','R',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'BATTERY_SIZES','SI_Silk_Charge_And_Go_5IX_L','R',1,'SI_Silk_Charge_And_Go_5IX_L','NA','R',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'BATTERY_SIZES','SI_Silk_Charge_And_Go_5IX_R','R',1,'SI_Silk_Charge_And_Go_5IX_R','NA','R',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'BATTERY_SIZES','SI_Silk_Charge_And_Go_7IX_L','R',1,'SI_Silk_Charge_And_Go_7IX_L','NA','R',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'BATTERY_SIZES','SI_Silk_Charge_And_Go_7IX_R','R',1,'SI_Silk_Charge_And_Go_7IX_R','NA','R',getdate(),'sballa',getdate(),'sballa'


select * from catalog.ItemMasterList where brandcode = 'SIGNIA' order by createdate desc

select * from catalog.ItemMasterAttributeValues where itemcode in (select itemcode from catalog.ItemMasterList where brandcode = 'SIGNIA') order by createdate desc


rollback transaction catalog
