

VendorName				
ProductFamily 			
ProductStyle 			
ProductModelName 		
BatterySize 			
ReceiverLengthsAvailable
ReceiverPowersAvailable 
ColorsAvailable 

select * from dbo.InsigniaProduct

alter table dbo.InsigniaProduct add ItemCode varchar(200)
alter table dbo.InsigniaProduct add ItemCode1 varchar(200)
alter table dbo.InsigniaProduct add ModelCode varchar(200)

update dbo.InsigniaProduct set ItemCode  = ProductModelName
update dbo.InsigniaProduct set ItemCode = replace(ItemCode,'&', ' And ')
update dbo.InsigniaProduct set ModelCode  =  ItemCode
update dbo.InsigniaProduct set ItemCode1  =  ItemCode
update dbo.InsigniaProduct set ItemCode1  =  'SI_'+ replace(ItemCode1, ' ','_')


select ProductModelName, ReceiverLengthsAvailable from dbo.InsigniaProduct
cross apply string_split('Silver| beige| black| dark brown| dark champagne| fine gold| graphite| pearl white| rose gold| dark blonde', '|')
select value from string_split('Silver| beige| black| dark brown| dark champagne| fine gold| graphite| pearl white| rose gold| dark blonde', '|')


select distinct ProductModelName,* from dbo.InsigniaProduct
cross apply string_split(Ltrim(ReceiverPowersAvailable), '|') as ReceiverPowersAvailable
cross apply string_split(Ltrim(ColorsAvailable), '|') as ColorsAvailable
cross apply string_split(Ltrim(ReceiverLengthsAvailable), '|') as ReceiverLengthsAvailable
where ProductModelName = 'CROS Pure Charge&Go IX'


select ProductModelName, rtrim(ltrim(value)) as ReveiverPowersAvailable from dbo.InsigniaProduct cross apply string_split(Ltrim(ReceiverPowersAvailable), '|') where value not like 'N/A'
select ProductModelName, rtrim(ltrim(value)) as ReceiverLengthsAvailable from dbo.InsigniaProduct cross apply string_split(Ltrim(ReceiverLengthsAvailable), '|') where value not like 'N/A'
select ProductModelName, rtrim(ltrim(value)) as ColorsAvailable from dbo.InsigniaProduct cross apply string_split(Ltrim(ColorsAvailable), '|') where value not like 'N/A'


select * from catalog.ItemMasterList
where brandcode = 'Signia'
order by 1 desc

select * from catalog.ItemMasterAttributeValues
where itemcode in (select itemcode from catalog.ItemMasterList where brandcode = 'Signia') and AttributeCode = 'BATTERY_SIZES'


Itemcode,[ItemType],BrandCode,FamilyCode,TechnologyCode,ModelCode,StyleCode, IsActive, CreateDate, CreateUser, ModifyDate,ModifyUser,MonauralHCPCSCode, BinauralHCPCSCode



drop table #ItemMasterList
select * into #ItemMasterList from catalog.ItemMasterList where 1 =2
insert into #ItemMasterList
(
Itemcode
,[ItemType]
,BrandCode
,FamilyCode
,TechnologyCode
,ModelCode
,StyleCode
, IsActive
, CreateDate
, CreateUser
, ModifyDate
,ModifyUser
,MonauralHCPCSCode
, BinauralHCPCSCode
)

select 'Pure Charge&Go T 7IX'		,'HA'	,	'SIGNIA','T 7IX	'	,'Pure Charge&Go T 7IX		','Pure Charge&Go T 7IX		','RIC		 ',1	,	getdate(),'appuser',getdate(),'appuser','V5257','V5261'	  union all
select 'Pure Charge&Go T 5IX'		,'HA'	,	'SIGNIA','T 5IX	'	,'Pure Charge&Go T 5IX		','Pure Charge&Go T 5IX		','RIC		 ',1	,	getdate(),'appuser',getdate(),'appuser','V5257','V5261'	  union all
select 'Pure Charge&Go T 3IX'		,'HA'	,	'SIGNIA','T 3IX	'	,'Pure Charge&Go T 3IX 		','Pure Charge&Go T 3IX 	','RIC		 ',1	,	getdate(),'appuser',getdate(),'appuser','V5257','V5261'	  union all
select 'Pure Charge&Go 7IX'			,'HA'	,	'SIGNIA','7IX	'	,'Pure Charge&Go 7IX 		','Pure Charge&Go 7IX 		','RIC		 ',1	,	getdate(),'appuser',getdate(),'appuser','V5257','V5261'	  union all
select 'Pure Charge&Go 5IX'			,'HA'	,	'SIGNIA','5IX	'	,'Pure Charge&Go 5IX 		','Pure Charge&Go 5IX 		','RIC		 ',1	,	getdate(),'appuser',getdate(),'appuser','V5257','V5261'	  union all
select 'Pure Charge&Go 3IX'			,'HA'	,	'SIGNIA','3IX	'	,'Pure Charge&Go 3IX		','Pure Charge&Go 3IX		','RIC		 ',1	,	getdate(),'appuser',getdate(),'appuser','V5257','V5261'	  union all
select 'Silk Charge&Go 7IX L'		,'HA'	,	'SIGNIA','7IX L	'	,'Silk Charge&Go 7IX L 		','Silk Charge&Go 7IX L 	','Instantfit',1	,	getdate(),'appuser',getdate(),'appuser','V5257','V5261'	  union all
select 'Silk Charge&Go 7IX R'		,'HA'	,	'SIGNIA','7IX R	'	,'Silk Charge&Go 7IX R		','Silk Charge&Go 7IX R		','Instantfit',1	,	getdate(),'appuser',getdate(),'appuser','V5257','V5261'	  union all
select 'Silk Charge&Go 5IX L'		,'HA'	,	'SIGNIA','5IX L	'	,'Silk Charge&Go 5IX L		','Silk Charge&Go 5IX L		','Instantfit',1	,	getdate(),'appuser',getdate(),'appuser','V5257','V5261'	  union all
select 'Silk Charge&Go 5IX R'		,'HA'	,	'SIGNIA','5IX R	'	,'Silk Charge&Go 5IX R		','Silk Charge&Go 5IX R		','Instantfit',1	,	getdate(),'appuser',getdate(),'appuser','V5257','V5261'	  union all
select 'Silk Charge&Go 3IX L'		,'HA'	,	'SIGNIA','3IX L	'	,'Silk Charge&Go 3IX L 		','Silk Charge&Go 3IX L 	','Instantfit',1	,	getdate(),'appuser',getdate(),'appuser','V5257','V5261'	  union all
select 'Silk Charge&Go 3IX R'		,'HA'	,	'SIGNIA','3IX R	'	,'Silk Charge&Go 3IX R 		','Silk Charge&Go 3IX R 	','Instantfit',1	,	getdate(),'appuser',getdate(),'appuser','V5257','V5261'	  union all
select 'CROS Pure Charge&Go IX'		,'CROS',	'SIGNIA','IX 	'	,'CROS Pure Charge&Go IX	','CROS Pure Charge&Go IX 	','RIC		 ',1	,	getdate(),'appuser',getdate(),'appuser','V5257','V5261'	  union all
select 'CROS Silk Charge&Go IX L'	,'CROS',	'SIGNIA','IX L	'	,'CROS Silk Charge&Go IX L	','CROS Silk Charge&Go IX L	','Instantfit',1	,	getdate(),'appuser',getdate(),'appuser','V5257','V5261'	  union all
select 'CROS Silk Charge&Go IX R'	,'CROS',	'SIGNIA','IX R	'	,'CROS Silk Charge&Go IX R	','CROS Silk Charge&Go IX R	','Instantfit',1	,	getdate(),'appuser',getdate(),'appuser','V5257','V5261'


select * from #ItemMasterList

select * from catalog.ItemMasterAttributeValues
where itemcode in (select itemcode from catalog.ItemMasterList where brandcode = 'Signia') 


select ProductModelName as ItemCode, rtrim(ltrim(value)) as RECEIVERPOWER from dbo.InsigniaProduct cross apply string_split(Ltrim(ReceiverPowersAvailable), '|') where value not like 'N/A' -- RECEIVER_POWER  -- DONE
select ProductModelName as ItemCode, rtrim(ltrim(value)) as RECEIVERSIZES from dbo.InsigniaProduct cross apply string_split(Ltrim(ReceiverLengthsAvailable), '|') where value not like 'N/A' -- RECEIVER_SIZES -- DONE
select ProductModelName as ItemCode, upper(rtrim(ltrim(value))) as COLOR from dbo.InsigniaProduct cross apply string_split(Ltrim(ColorsAvailable), '|') where value not like 'N/A' -- COLOR -- Done
select ProductModelName as ItemCode, upper(rtrim(ltrim(value))) as BatterySizes from dbo.InsigniaProduct cross apply string_split(Ltrim(BatterySize), '|') where value not like 'N/A' -- BATTERY_SIZES -- Done



insert into catalog.ItemMasterAttributeValues
(AttributeCode
,Itemcode
,ModelAttributeValue
,IsActive
,VendorCode
,Modifier
,ModelAttributeValueDescription
,CreateDate
,CreateUser
,ModifyDate
,ModifyUser
)

--- COLOR
drop table #color
select * into #Color from ( select ProductModelName as ItemCode, upper(rtrim(ltrim(value))) as Color from dbo.InsigniaProduct cross apply string_split(Ltrim(ColorsAvailable), '|') where value not like 'N/A') a -- COLOR
select * from #color

select

'select ' + 
''''+'COLOR'+ ''''		+ ','+		-- AttributeCode
''''+a.ItemCode+''''	+ ','+		-- ItemCode
''''+b.COLOR+''''		+ ','		-- ModelAttributeValue
	+'1'				+ ','+		-- IsActive
''''+a.ItemCode+''''	+ ','+		-- VendorCode
''''+'NA'+''''		    + ','+		-- Modifier
''''+b.COLOR+''''		+ ','		-- ModelAttributeValueDescription
	+'getdate()'		+ ','+		-- CreateDate
''''+'appuser'+''''		+ ','		 --CreateUser
	+'getdate()'		+ ','+		-- ModifyDate
''''+'appuser'+''''		+ ' UNION ALL'		      --ModifyUser

from #ItemMasterList a left join #Color b on a.ItemCode = b.itemCode

select
a.*, b.*

from #ItemMasterList a right join #Color b on ltrim(rtrim(a.ItemCode)) = ltrim(rtrim(b.itemCode))

select * from dbo.InsigniaProduct
update dbo.InsigniaProduct set ProductModelName = ltrim(rtrim(ProductModelName))


select Itemcode from #Color where Itemcode = 'Pure Charge&Go T 7IX'
select itemcode from #ItemMasterList where Itemcode like 'Pure Charge&Go T 7IX'


-- ReceiverPower
drop table #ReceiverPower
select * into #ReceiverPower from ( select ProductModelName as ItemCode, upper(rtrim(ltrim(value))) as ReceiverPower from dbo.InsigniaProduct cross apply string_split(Ltrim(ReceiverPowersAvailable), '|') where value not like 'N/A') a -- ReceiverPowers
select * from #ReceiverPower


select distinct
'select ' + 
''''+'RECIEVER_POWER'+ ''''		+ ','+		-- AttributeCode
''''+a.ItemCode+''''	+ ','+		-- ItemCode
''''+b.ReceiverPower+''''		+ ','		-- ModelAttributeValue
	+'1'				+ ','+		-- IsActive
''''+a.ItemCode+''''	+ ','+		-- VendorCode
''''+'NA'+''''		    + ','+		-- Modifier
''''+b.ReceiverPower+''''		+ ','		-- ModelAttributeValueDescription
	+'getdate()'		+ ','+		-- CreateDate
''''+'appuser'+''''		+ ','		 --CreateUser
	+'getdate()'		+ ','+		-- ModifyDate
''''+'appuser'+''''		+ ' UNION ALL'		      --ModifyUser

from #ItemMasterList a join #ReceiverPower b on a.ItemCode = b.itemCode




select * from catalog.ItemMasterAttributeValues
where itemcode in (select itemcode from catalog.ItemMasterList where brandcode = 'Signia') and AttributeCode = 'RECIEVER_SIZES'

-- ReceiverSizes
drop table #ReceiverSizes
select * into #ReceiverSizes from ( select ProductModelName as ItemCode, upper(rtrim(ltrim(value))) as ReceiverSizes from dbo.InsigniaProduct cross apply string_split(Ltrim(ReceiverLengthsAvailable), '|') where value not like 'N/A') a -- ReceiverSizes
select * from #ReceiverSizes


select distinct
'select ' + 
''''+'RECIEVER_SIZES'+ ''''		+ ','+		-- AttributeCode
''''+a.ItemCode+''''	+ ','+		-- ItemCode
''''+b.ReceiverSizes+''''		+ ','		-- ModelAttributeValue
	+'1'				+ ','+		-- IsActive
''''+a.ItemCode+''''	+ ','+		-- VendorCode
''''+'NA'+''''		    + ','+		-- Modifier
''''+b.ReceiverSizes+''''		+ ','		-- ModelAttributeValueDescription
	+'getdate()'		+ ','+		-- CreateDate
''''+'appuser'+''''		+ ','		 --CreateUser
	+'getdate()'		+ ','+		-- ModifyDate
''''+'appuser'+''''		+ ' UNION ALL'		      --ModifyUser

from #ItemMasterList a join #ReceiverSizes b on a.ItemCode = b.itemCode







select * from catalog.ItemMasterAttributeValues
where itemcode in (select itemcode from catalog.ItemMasterList where brandcode = 'Signia') and AttributeCode = 'BATTERY_SIZES'

-- ReceiverSizes
drop table #BatterySizes
select * into #BatterySizes from ( select ProductModelName as ItemCode, upper(rtrim(ltrim(value))) as BatterySizes from dbo.InsigniaProduct cross apply string_split(Ltrim(BatterySize), '|') where value not like 'N/A') a -- BatterySizes
select * from #BatterySizes


select distinct
'select ' + 
''''+'BATTERY_SIZES'+ ''''		+ ','+		-- AttributeCode
''''+a.ItemCode+''''	+ ','+		-- ItemCode
''''+b.BatterySizes+''''		+ ','		-- ModelAttributeValue
	+'1'				+ ','+		-- IsActive
''''+a.ItemCode+''''	+ ','+		-- VendorCode
''''+'NA'+''''		    + ','+		-- Modifier
''''+b.BatterySizes+''''		+ ','		-- ModelAttributeValueDescription
	+'getdate()'		+ ','+		-- CreateDate
''''+'appuser'+''''		+ ','		 --CreateUser
	+'getdate()'		+ ','+		-- ModifyDate
''''+'appuser'+''''		+ ' UNION ALL'		      --ModifyUser

from #ItemMasterList a join #BatterySizes b on a.ItemCode = b.itemCode





-- COLOR Attribute
select * into #ItemMasterAttributeValues from catalog.ItemMasterAttributeValues where 1=2

insert into #ItemMasterAttributeValues
(AttributeCode
,Itemcode
,ModelAttributeValue
,IsActive
,VendorCode
,Modifier
,ModelAttributeValueDescription
,CreateDate
,CreateUser
,ModifyDate
,ModifyUser
)

--- COLOR
select * from catalog.ItemMasterAttributeValues
where itemcode in (select itemcode from catalog.ItemMasterList where brandcode = 'Signia') and AttributeCode = 'COLOR'


insert into #ItemMasterAttributeValues
(AttributeCode
,Itemcode
,ModelAttributeValue
,IsActive
,VendorCode
,Modifier
,ModelAttributeValueDescription
,CreateDate
,CreateUser
,ModifyDate
,ModifyUser
)

select 'COLOR','Pure Charge&Go T 7IX','SILVER',1,'Pure Charge&Go T 7IX','NA','SILVER',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','Pure Charge&Go T 7IX','BEIGE',1,'Pure Charge&Go T 7IX','NA','BEIGE',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','Pure Charge&Go T 7IX','BLACK',1,'Pure Charge&Go T 7IX','NA','BLACK',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','Pure Charge&Go T 7IX','DARK BROWN',1,'Pure Charge&Go T 7IX','NA','DARK BROWN',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','Pure Charge&Go T 7IX','DARK CHAMPAGNE',1,'Pure Charge&Go T 7IX','NA','DARK CHAMPAGNE',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','Pure Charge&Go T 7IX','FINE GOLD',1,'Pure Charge&Go T 7IX','NA','FINE GOLD',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','Pure Charge&Go T 7IX','GRAPHITE',1,'Pure Charge&Go T 7IX','NA','GRAPHITE',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','Pure Charge&Go T 7IX','PEARL WHITE',1,'Pure Charge&Go T 7IX','NA','PEARL WHITE',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','Pure Charge&Go T 7IX','ROSE GOLD',1,'Pure Charge&Go T 7IX','NA','ROSE GOLD',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','Pure Charge&Go T 7IX','DARK BLONDE',1,'Pure Charge&Go T 7IX','NA','DARK BLONDE',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','Pure Charge&Go T 5IX','SILVER',1,'Pure Charge&Go T 5IX','NA','SILVER',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','Pure Charge&Go T 5IX','BEIGE',1,'Pure Charge&Go T 5IX','NA','BEIGE',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','Pure Charge&Go T 5IX','BLACK',1,'Pure Charge&Go T 5IX','NA','BLACK',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','Pure Charge&Go T 5IX','DARK BROWN',1,'Pure Charge&Go T 5IX','NA','DARK BROWN',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','Pure Charge&Go T 5IX','DARK CHAMPAGNE',1,'Pure Charge&Go T 5IX','NA','DARK CHAMPAGNE',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','Pure Charge&Go T 5IX','FINE GOLD',1,'Pure Charge&Go T 5IX','NA','FINE GOLD',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','Pure Charge&Go T 5IX','GRAPHITE',1,'Pure Charge&Go T 5IX','NA','GRAPHITE',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','Pure Charge&Go T 5IX','PEARL WHITE',1,'Pure Charge&Go T 5IX','NA','PEARL WHITE',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','Pure Charge&Go T 5IX','ROSE GOLD',1,'Pure Charge&Go T 5IX','NA','ROSE GOLD',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','Pure Charge&Go T 5IX','DARK BLONDE',1,'Pure Charge&Go T 5IX','NA','DARK BLONDE',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','Pure Charge&Go T 3IX','SILVER',1,'Pure Charge&Go T 3IX','NA','SILVER',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','Pure Charge&Go T 3IX','BEIGE',1,'Pure Charge&Go T 3IX','NA','BEIGE',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','Pure Charge&Go T 3IX','BLACK',1,'Pure Charge&Go T 3IX','NA','BLACK',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','Pure Charge&Go T 3IX','DARK BROWN',1,'Pure Charge&Go T 3IX','NA','DARK BROWN',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','Pure Charge&Go T 3IX','DARK CHAMPAGNE',1,'Pure Charge&Go T 3IX','NA','DARK CHAMPAGNE',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','Pure Charge&Go T 3IX','FINE GOLD',1,'Pure Charge&Go T 3IX','NA','FINE GOLD',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','Pure Charge&Go T 3IX','GRAPHITE',1,'Pure Charge&Go T 3IX','NA','GRAPHITE',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','Pure Charge&Go T 3IX','PEARL WHITE',1,'Pure Charge&Go T 3IX','NA','PEARL WHITE',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','Pure Charge&Go T 3IX','ROSE GOLD',1,'Pure Charge&Go T 3IX','NA','ROSE GOLD',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','Pure Charge&Go T 3IX','DARK BLONDE',1,'Pure Charge&Go T 3IX','NA','DARK BLONDE',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','Pure Charge&Go 7IX','SILVER',1,'Pure Charge&Go 7IX','NA','SILVER',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','Pure Charge&Go 7IX','BEIGE',1,'Pure Charge&Go 7IX','NA','BEIGE',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','Pure Charge&Go 7IX','BLACK',1,'Pure Charge&Go 7IX','NA','BLACK',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','Pure Charge&Go 7IX','DARK BROWN',1,'Pure Charge&Go 7IX','NA','DARK BROWN',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','Pure Charge&Go 7IX','DARK CHAMPAGNE',1,'Pure Charge&Go 7IX','NA','DARK CHAMPAGNE',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','Pure Charge&Go 7IX','FINE GOLD',1,'Pure Charge&Go 7IX','NA','FINE GOLD',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','Pure Charge&Go 7IX','GRAPHITE',1,'Pure Charge&Go 7IX','NA','GRAPHITE',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','Pure Charge&Go 7IX','PEARL WHITE',1,'Pure Charge&Go 7IX','NA','PEARL WHITE',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','Pure Charge&Go 7IX','ROSE GOLD',1,'Pure Charge&Go 7IX','NA','ROSE GOLD',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','Pure Charge&Go 7IX','DARK BLONDE',1,'Pure Charge&Go 7IX','NA','DARK BLONDE',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','Pure Charge&Go 5IX','SILVER',1,'Pure Charge&Go 5IX','NA','SILVER',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','Pure Charge&Go 5IX','BEIGE',1,'Pure Charge&Go 5IX','NA','BEIGE',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','Pure Charge&Go 5IX','BLACK',1,'Pure Charge&Go 5IX','NA','BLACK',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','Pure Charge&Go 5IX','DARK BROWN',1,'Pure Charge&Go 5IX','NA','DARK BROWN',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','Pure Charge&Go 5IX','DARK CHAMPAGNE',1,'Pure Charge&Go 5IX','NA','DARK CHAMPAGNE',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','Pure Charge&Go 5IX','FINE GOLD',1,'Pure Charge&Go 5IX','NA','FINE GOLD',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','Pure Charge&Go 5IX','GRAPHITE',1,'Pure Charge&Go 5IX','NA','GRAPHITE',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','Pure Charge&Go 5IX','PEARL WHITE',1,'Pure Charge&Go 5IX','NA','PEARL WHITE',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','Pure Charge&Go 5IX','ROSE GOLD',1,'Pure Charge&Go 5IX','NA','ROSE GOLD',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','Pure Charge&Go 5IX','DARK BLONDE',1,'Pure Charge&Go 5IX','NA','DARK BLONDE',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','Pure Charge&Go 3IX','SILVER',1,'Pure Charge&Go 3IX','NA','SILVER',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','Pure Charge&Go 3IX','BEIGE',1,'Pure Charge&Go 3IX','NA','BEIGE',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','Pure Charge&Go 3IX','BLACK',1,'Pure Charge&Go 3IX','NA','BLACK',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','Pure Charge&Go 3IX','DARK BROWN',1,'Pure Charge&Go 3IX','NA','DARK BROWN',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','Pure Charge&Go 3IX','DARK CHAMPAGNE',1,'Pure Charge&Go 3IX','NA','DARK CHAMPAGNE',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','Pure Charge&Go 3IX','FINE GOLD',1,'Pure Charge&Go 3IX','NA','FINE GOLD',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','Pure Charge&Go 3IX','GRAPHITE',1,'Pure Charge&Go 3IX','NA','GRAPHITE',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','Pure Charge&Go 3IX','PEARL WHITE',1,'Pure Charge&Go 3IX','NA','PEARL WHITE',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','Pure Charge&Go 3IX','ROSE GOLD',1,'Pure Charge&Go 3IX','NA','ROSE GOLD',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','Pure Charge&Go 3IX','DARK BLONDE',1,'Pure Charge&Go 3IX','NA','DARK BLONDE',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','Silk Charge&Go 7IX L','BLACK FACEPLATE',1,'Silk Charge&Go 7IX L','NA','BLACK FACEPLATE',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','Silk Charge&Go 7IX L','MOCHA FACEPLATE',1,'Silk Charge&Go 7IX L','NA','MOCHA FACEPLATE',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','Silk Charge&Go 7IX R','BLACK FACEPLATE',1,'Silk Charge&Go 7IX R','NA','BLACK FACEPLATE',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','Silk Charge&Go 7IX R','MOCHA FACEPLATE',1,'Silk Charge&Go 7IX R','NA','MOCHA FACEPLATE',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','Silk Charge&Go 5IX L','BLACK FACEPLATE',1,'Silk Charge&Go 5IX L','NA','BLACK FACEPLATE',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','Silk Charge&Go 5IX L','MOCHA FACEPLATE',1,'Silk Charge&Go 5IX L','NA','MOCHA FACEPLATE',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','Silk Charge&Go 5IX R','BLACK FACEPLATE',1,'Silk Charge&Go 5IX R','NA','BLACK FACEPLATE',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','Silk Charge&Go 5IX R','MOCHA FACEPLATE',1,'Silk Charge&Go 5IX R','NA','MOCHA FACEPLATE',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','Silk Charge&Go 3IX L','BLACK FACEPLATE',1,'Silk Charge&Go 3IX L','NA','BLACK FACEPLATE',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','Silk Charge&Go 3IX L','MOCHA FACEPLATE',1,'Silk Charge&Go 3IX L','NA','MOCHA FACEPLATE',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','Silk Charge&Go 3IX R','BLACK FACEPLATE',1,'Silk Charge&Go 3IX R','NA','BLACK FACEPLATE',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','Silk Charge&Go 3IX R','MOCHA FACEPLATE',1,'Silk Charge&Go 3IX R','NA','MOCHA FACEPLATE',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','CROS Pure Charge&Go IX','SILVER',1,'CROS Pure Charge&Go IX','NA','SILVER',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','CROS Pure Charge&Go IX','BEIGE',1,'CROS Pure Charge&Go IX','NA','BEIGE',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','CROS Pure Charge&Go IX','BLACK',1,'CROS Pure Charge&Go IX','NA','BLACK',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','CROS Pure Charge&Go IX','DARK BROWN',1,'CROS Pure Charge&Go IX','NA','DARK BROWN',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','CROS Pure Charge&Go IX','DARK CHAMPAGNE',1,'CROS Pure Charge&Go IX','NA','DARK CHAMPAGNE',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','CROS Pure Charge&Go IX','FINE GOLD',1,'CROS Pure Charge&Go IX','NA','FINE GOLD',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','CROS Pure Charge&Go IX','GRAPHITE',1,'CROS Pure Charge&Go IX','NA','GRAPHITE',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','CROS Pure Charge&Go IX','PEARL WHITE',1,'CROS Pure Charge&Go IX','NA','PEARL WHITE',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','CROS Pure Charge&Go IX','ROSE GOLD',1,'CROS Pure Charge&Go IX','NA','ROSE GOLD',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','CROS Pure Charge&Go IX','DARK BLONDE',1,'CROS Pure Charge&Go IX','NA','DARK BLONDE',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','CROS Silk Charge&Go IX L','BLACK FACEPLATE',1,'CROS Silk Charge&Go IX L','NA','BLACK FACEPLATE',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','CROS Silk Charge&Go IX L','MOCHA FACEPLATE',1,'CROS Silk Charge&Go IX L','NA','MOCHA FACEPLATE',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','CROS Silk Charge&Go IX R','BLACK FACEPLATE',1,'CROS Silk Charge&Go IX R','NA','BLACK FACEPLATE',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'COLOR','CROS Silk Charge&Go IX R','MOCHA FACEPLATE',1,'CROS Silk Charge&Go IX R','NA','MOCHA FACEPLATE',getdate(),'appuser',getdate(),'appuser' 


---- RECEIVER POWER
select * from catalog.ItemMasterAttributeValues
where itemcode in (select itemcode from catalog.ItemMasterList where brandcode = 'Signia') and AttributeCode = 'RECIEVER_POWER'


insert into #ItemMasterAttributeValues
(AttributeCode
,Itemcode
,ModelAttributeValue
,IsActive
,VendorCode
,Modifier
,ModelAttributeValueDescription
,CreateDate
,CreateUser
,ModifyDate
,ModifyUser
)


select 'RECIEVER_POWER','CROS Pure Charge&Go IX','HP',1,'CROS Pure Charge&Go IX','NA','HP',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_POWER','CROS Pure Charge&Go IX','M',1,'CROS Pure Charge&Go IX','NA','M',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_POWER','CROS Pure Charge&Go IX','P',1,'CROS Pure Charge&Go IX','NA','P',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_POWER','CROS Pure Charge&Go IX','S',1,'CROS Pure Charge&Go IX','NA','S',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_POWER','Pure Charge&Go 3IX','HP',1,'Pure Charge&Go 3IX','NA','HP',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_POWER','Pure Charge&Go 3IX','M',1,'Pure Charge&Go 3IX','NA','M',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_POWER','Pure Charge&Go 3IX','P',1,'Pure Charge&Go 3IX','NA','P',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_POWER','Pure Charge&Go 3IX','S',1,'Pure Charge&Go 3IX','NA','S',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_POWER','Pure Charge&Go 5IX','HP',1,'Pure Charge&Go 5IX','NA','HP',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_POWER','Pure Charge&Go 5IX','M',1,'Pure Charge&Go 5IX','NA','M',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_POWER','Pure Charge&Go 5IX','P',1,'Pure Charge&Go 5IX','NA','P',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_POWER','Pure Charge&Go 5IX','S',1,'Pure Charge&Go 5IX','NA','S',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_POWER','Pure Charge&Go 7IX','HP',1,'Pure Charge&Go 7IX','NA','HP',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_POWER','Pure Charge&Go 7IX','M',1,'Pure Charge&Go 7IX','NA','M',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_POWER','Pure Charge&Go 7IX','P',1,'Pure Charge&Go 7IX','NA','P',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_POWER','Pure Charge&Go 7IX','S',1,'Pure Charge&Go 7IX','NA','S',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_POWER','Pure Charge&Go T 3IX','HP',1,'Pure Charge&Go T 3IX','NA','HP',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_POWER','Pure Charge&Go T 3IX','M',1,'Pure Charge&Go T 3IX','NA','M',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_POWER','Pure Charge&Go T 3IX','P',1,'Pure Charge&Go T 3IX','NA','P',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_POWER','Pure Charge&Go T 3IX','S',1,'Pure Charge&Go T 3IX','NA','S',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_POWER','Pure Charge&Go T 5IX','HP',1,'Pure Charge&Go T 5IX','NA','HP',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_POWER','Pure Charge&Go T 5IX','M',1,'Pure Charge&Go T 5IX','NA','M',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_POWER','Pure Charge&Go T 5IX','P',1,'Pure Charge&Go T 5IX','NA','P',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_POWER','Pure Charge&Go T 5IX','S',1,'Pure Charge&Go T 5IX','NA','S',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_POWER','Pure Charge&Go T 7IX','HP',1,'Pure Charge&Go T 7IX','NA','HP',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_POWER','Pure Charge&Go T 7IX','M',1,'Pure Charge&Go T 7IX','NA','M',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_POWER','Pure Charge&Go T 7IX','P',1,'Pure Charge&Go T 7IX','NA','P',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_POWER','Pure Charge&Go T 7IX','S',1,'Pure Charge&Go T 7IX','NA','S',getdate(),'appuser',getdate(),'appuser' 













-- RECEIVER SIZES

select * from catalog.ItemMasterAttributeValues
where itemcode in (select itemcode from catalog.ItemMasterList where brandcode = 'Signia') and AttributeCode = 'RECIEVER_SIZES'



insert into #ItemMasterAttributeValues
(AttributeCode
,Itemcode
,ModelAttributeValue
,IsActive
,VendorCode
,Modifier
,ModelAttributeValueDescription
,CreateDate
,CreateUser
,ModifyDate
,ModifyUser
)


select 'RECIEVER_SIZES','CROS Pure Charge&Go IX','0',1,'CROS Pure Charge&Go IX','NA','0',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','CROS Pure Charge&Go IX','1',1,'CROS Pure Charge&Go IX','NA','1',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','CROS Pure Charge&Go IX','2',1,'CROS Pure Charge&Go IX','NA','2',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','CROS Pure Charge&Go IX','3',1,'CROS Pure Charge&Go IX','NA','3',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','CROS Pure Charge&Go IX','4',1,'CROS Pure Charge&Go IX','NA','4',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','CROS Pure Charge&Go IX','83',1,'CROS Pure Charge&Go IX','NA','83',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','CROS Silk Charge&Go IX L','0',1,'CROS Silk Charge&Go IX L','NA','0',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','CROS Silk Charge&Go IX L','1',1,'CROS Silk Charge&Go IX L','NA','1',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','CROS Silk Charge&Go IX L','2',1,'CROS Silk Charge&Go IX L','NA','2',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','CROS Silk Charge&Go IX L','3',1,'CROS Silk Charge&Go IX L','NA','3',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','CROS Silk Charge&Go IX L','4',1,'CROS Silk Charge&Go IX L','NA','4',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','CROS Silk Charge&Go IX L','96',1,'CROS Silk Charge&Go IX L','NA','96',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','CROS Silk Charge&Go IX R','0',1,'CROS Silk Charge&Go IX R','NA','0',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','CROS Silk Charge&Go IX R','1',1,'CROS Silk Charge&Go IX R','NA','1',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','CROS Silk Charge&Go IX R','2',1,'CROS Silk Charge&Go IX R','NA','2',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','CROS Silk Charge&Go IX R','3',1,'CROS Silk Charge&Go IX R','NA','3',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','CROS Silk Charge&Go IX R','4',1,'CROS Silk Charge&Go IX R','NA','4',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','CROS Silk Charge&Go IX R','96',1,'CROS Silk Charge&Go IX R','NA','96',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','Pure Charge&Go 3IX','0',1,'Pure Charge&Go 3IX','NA','0',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','Pure Charge&Go 3IX','1',1,'Pure Charge&Go 3IX','NA','1',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','Pure Charge&Go 3IX','2',1,'Pure Charge&Go 3IX','NA','2',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','Pure Charge&Go 3IX','3',1,'Pure Charge&Go 3IX','NA','3',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','Pure Charge&Go 3IX','4',1,'Pure Charge&Go 3IX','NA','4',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','Pure Charge&Go 3IX','64',1,'Pure Charge&Go 3IX','NA','64',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','Pure Charge&Go 5IX','0',1,'Pure Charge&Go 5IX','NA','0',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','Pure Charge&Go 5IX','1',1,'Pure Charge&Go 5IX','NA','1',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','Pure Charge&Go 5IX','2',1,'Pure Charge&Go 5IX','NA','2',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','Pure Charge&Go 5IX','3',1,'Pure Charge&Go 5IX','NA','3',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','Pure Charge&Go 5IX','4',1,'Pure Charge&Go 5IX','NA','4',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','Pure Charge&Go 5IX','45',1,'Pure Charge&Go 5IX','NA','45',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','Pure Charge&Go 7IX','0',1,'Pure Charge&Go 7IX','NA','0',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','Pure Charge&Go 7IX','1',1,'Pure Charge&Go 7IX','NA','1',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','Pure Charge&Go 7IX','2',1,'Pure Charge&Go 7IX','NA','2',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','Pure Charge&Go 7IX','3',1,'Pure Charge&Go 7IX','NA','3',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','Pure Charge&Go 7IX','4',1,'Pure Charge&Go 7IX','NA','4',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','Pure Charge&Go 7IX','44',1,'Pure Charge&Go 7IX','NA','44',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','Pure Charge&Go T 3IX','0',1,'Pure Charge&Go T 3IX','NA','0',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','Pure Charge&Go T 3IX','1',1,'Pure Charge&Go T 3IX','NA','1',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','Pure Charge&Go T 3IX','2',1,'Pure Charge&Go T 3IX','NA','2',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','Pure Charge&Go T 3IX','25',1,'Pure Charge&Go T 3IX','NA','25',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','Pure Charge&Go T 3IX','3',1,'Pure Charge&Go T 3IX','NA','3',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','Pure Charge&Go T 3IX','4',1,'Pure Charge&Go T 3IX','NA','4',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','Pure Charge&Go T 5IX','0',1,'Pure Charge&Go T 5IX','NA','0',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','Pure Charge&Go T 5IX','1',1,'Pure Charge&Go T 5IX','NA','1',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','Pure Charge&Go T 5IX','17',1,'Pure Charge&Go T 5IX','NA','17',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','Pure Charge&Go T 5IX','2',1,'Pure Charge&Go T 5IX','NA','2',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','Pure Charge&Go T 5IX','3',1,'Pure Charge&Go T 5IX','NA','3',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','Pure Charge&Go T 5IX','4',1,'Pure Charge&Go T 5IX','NA','4',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','Pure Charge&Go T 7IX','0',1,'Pure Charge&Go T 7IX','NA','0',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','Pure Charge&Go T 7IX','1',1,'Pure Charge&Go T 7IX','NA','1',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','Pure Charge&Go T 7IX','2',1,'Pure Charge&Go T 7IX','NA','2',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','Pure Charge&Go T 7IX','3',1,'Pure Charge&Go T 7IX','NA','3',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','Pure Charge&Go T 7IX','4',1,'Pure Charge&Go T 7IX','NA','4',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','Pure Charge&Go T 7IX','5',1,'Pure Charge&Go T 7IX','NA','5',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','Silk Charge&Go 3IX L','0',1,'Silk Charge&Go 3IX L','NA','0',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','Silk Charge&Go 3IX L','1',1,'Silk Charge&Go 3IX L','NA','1',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','Silk Charge&Go 3IX L','2',1,'Silk Charge&Go 3IX L','NA','2',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','Silk Charge&Go 3IX L','3',1,'Silk Charge&Go 3IX L','NA','3',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','Silk Charge&Go 3IX L','4',1,'Silk Charge&Go 3IX L','NA','4',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','Silk Charge&Go 3IX L','79',1,'Silk Charge&Go 3IX L','NA','79',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','Silk Charge&Go 3IX R','0',1,'Silk Charge&Go 3IX R','NA','0',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','Silk Charge&Go 3IX R','1',1,'Silk Charge&Go 3IX R','NA','1',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','Silk Charge&Go 3IX R','2',1,'Silk Charge&Go 3IX R','NA','2',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','Silk Charge&Go 3IX R','3',1,'Silk Charge&Go 3IX R','NA','3',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','Silk Charge&Go 3IX R','4',1,'Silk Charge&Go 3IX R','NA','4',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','Silk Charge&Go 3IX R','82',1,'Silk Charge&Go 3IX R','NA','82',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','Silk Charge&Go 5IX L','0',1,'Silk Charge&Go 5IX L','NA','0',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','Silk Charge&Go 5IX L','1',1,'Silk Charge&Go 5IX L','NA','1',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','Silk Charge&Go 5IX L','2',1,'Silk Charge&Go 5IX L','NA','2',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','Silk Charge&Go 5IX L','3',1,'Silk Charge&Go 5IX L','NA','3',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','Silk Charge&Go 5IX L','4',1,'Silk Charge&Go 5IX L','NA','4',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','Silk Charge&Go 5IX L','75',1,'Silk Charge&Go 5IX L','NA','75',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','Silk Charge&Go 5IX R','0',1,'Silk Charge&Go 5IX R','NA','0',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','Silk Charge&Go 5IX R','1',1,'Silk Charge&Go 5IX R','NA','1',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','Silk Charge&Go 5IX R','2',1,'Silk Charge&Go 5IX R','NA','2',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','Silk Charge&Go 5IX R','3',1,'Silk Charge&Go 5IX R','NA','3',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','Silk Charge&Go 5IX R','4',1,'Silk Charge&Go 5IX R','NA','4',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','Silk Charge&Go 5IX R','78',1,'Silk Charge&Go 5IX R','NA','78',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','Silk Charge&Go 7IX L','0',1,'Silk Charge&Go 7IX L','NA','0',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','Silk Charge&Go 7IX L','1',1,'Silk Charge&Go 7IX L','NA','1',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','Silk Charge&Go 7IX L','2',1,'Silk Charge&Go 7IX L','NA','2',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','Silk Charge&Go 7IX L','3',1,'Silk Charge&Go 7IX L','NA','3',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','Silk Charge&Go 7IX L','4',1,'Silk Charge&Go 7IX L','NA','4',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','Silk Charge&Go 7IX L','71',1,'Silk Charge&Go 7IX L','NA','71',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','Silk Charge&Go 7IX R','0',1,'Silk Charge&Go 7IX R','NA','0',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','Silk Charge&Go 7IX R','1',1,'Silk Charge&Go 7IX R','NA','1',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','Silk Charge&Go 7IX R','2',1,'Silk Charge&Go 7IX R','NA','2',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','Silk Charge&Go 7IX R','3',1,'Silk Charge&Go 7IX R','NA','3',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','Silk Charge&Go 7IX R','4',1,'Silk Charge&Go 7IX R','NA','4',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'RECIEVER_SIZES','Silk Charge&Go 7IX R','74',1,'Silk Charge&Go 7IX R','NA','74',getdate(),'appuser',getdate(),'appuser' 



--- BATTERY SIZES
select * from catalog.ItemMasterAttributeValues
where itemcode in (select itemcode from catalog.ItemMasterList where brandcode = 'Signia') and AttributeCode = 'BATTERY_SIZES'



insert into #ItemMasterAttributeValues
(AttributeCode
,Itemcode
,ModelAttributeValue
,IsActive
,VendorCode
,Modifier
,ModelAttributeValueDescription
,CreateDate
,CreateUser
,ModifyDate
,ModifyUser
)


select 'BATTERY_SIZES','CROS Pure Charge&Go IX','R',1,'CROS Pure Charge&Go IX','NA','R',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'BATTERY_SIZES','CROS Silk Charge&Go IX L','R',1,'CROS Silk Charge&Go IX L','NA','R',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'BATTERY_SIZES','CROS Silk Charge&Go IX R','R',1,'CROS Silk Charge&Go IX R','NA','R',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'BATTERY_SIZES','Pure Charge&Go 3IX','R',1,'Pure Charge&Go 3IX','NA','R',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'BATTERY_SIZES','Pure Charge&Go 5IX','R',1,'Pure Charge&Go 5IX','NA','R',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'BATTERY_SIZES','Pure Charge&Go 7IX','R',1,'Pure Charge&Go 7IX','NA','R',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'BATTERY_SIZES','Pure Charge&Go T 3IX','R',1,'Pure Charge&Go T 3IX','NA','R',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'BATTERY_SIZES','Pure Charge&Go T 5IX','R',1,'Pure Charge&Go T 5IX','NA','R',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'BATTERY_SIZES','Pure Charge&Go T 7IX','R',1,'Pure Charge&Go T 7IX','NA','R',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'BATTERY_SIZES','Silk Charge&Go 3IX L','R',1,'Silk Charge&Go 3IX L','NA','R',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'BATTERY_SIZES','Silk Charge&Go 3IX R','R',1,'Silk Charge&Go 3IX R','NA','R',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'BATTERY_SIZES','Silk Charge&Go 5IX L','R',1,'Silk Charge&Go 5IX L','NA','R',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'BATTERY_SIZES','Silk Charge&Go 5IX R','R',1,'Silk Charge&Go 5IX R','NA','R',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'BATTERY_SIZES','Silk Charge&Go 7IX L','R',1,'Silk Charge&Go 7IX L','NA','R',getdate(),'appuser',getdate(),'appuser' UNION ALL
select 'BATTERY_SIZES','Silk Charge&Go 7IX R','R',1,'Silk Charge&Go 7IX R','NA','R',getdate(),'appuser',getdate(),'appuser'


select * from #ItemMasterAttributeValues


begin transaction catalog

rollback transaction catalog