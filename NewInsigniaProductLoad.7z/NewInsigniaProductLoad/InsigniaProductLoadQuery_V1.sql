/*
VendorName				
ProductFamily 			
ProductStyle 			
ProductModelName 		
BatterySize 			
ReceiverLengthsAvailable
ReceiverPowersAvailable 
ColorsAvailable 


Create Table InsigniaProduct
(
VendorName	varchar(200),
ProductFamily varchar(200),
ProductStyle varchar(200),
ProductModelName varchar(200),
BatterySize varchar(200),
ReceiverLengthsAvailable varchar(200),
ReceiverPowersAvailable varchar(200),
ColorsAvailable varchar(200)
)


insert into dbo.InsigniaProduct
(
VendorName,				
ProductFamily,	
ProductStyle,		
ProductModelName,
BatterySize,		
ReceiverLengthsAvailable,
ReceiverPowersAvailable,
ColorsAvailable 
)

select 'Signia','IX','RIC','Pure Charge&Go T 7IX','R','0| 1| 2| 3| 4| 5','S| M| P| HP','Silver| beige| black| dark brown| dark champagne| fine gold| graphite| pearl white| rose gold| dark blonde'      Union all 
select 'Signia','IX','RIC','Pure Charge&Go T 5IX','R','0| 1| 2| 3| 4| 17','S| M| P| HP','Silver| beige| black| dark brown| dark champagne| fine gold| graphite| pearl white| rose gold| dark blonde'     Union all 
select 'Signia','IX','RIC','Pure Charge&Go T 3IX ','R','0| 1| 2| 3| 4| 25','S| M| P| HP','Silver| beige| black| dark brown| dark champagne| fine gold| graphite| pearl white| rose gold| dark blonde'    Union all 
select 'Signia','IX','RIC','Pure Charge&Go 7IX ','R','0| 1| 2| 3| 4| 44','S| M| P| HP','Silver| beige| black| dark brown| dark champagne| fine gold| graphite| pearl white| rose gold| dark blonde'      Union all 
select 'Signia','IX','RIC','Pure Charge&Go 5IX ','R','0| 1| 2| 3| 4| 45','S| M| P| HP','Silver| beige| black| dark brown| dark champagne| fine gold| graphite| pearl white| rose gold| dark blonde'      Union all 
select 'Signia','IX','RIC','Pure Charge&Go 3IX','R','0| 1| 2| 3| 4| 64','S| M| P| HP','Silver| beige| black| dark brown| dark champagne| fine gold| graphite| pearl white| rose gold| dark blonde'       Union all 
select 'Signia','IX','Instant fit CIC','Silk Charge&Go 7IX L ','R','0| 1| 2| 3| 4| 71','N/A','Black faceplate| mocha faceplate'                                                                          Union all 
select 'Signia','IX','Instant fit CIC','Silk Charge&Go 7IX R','R','0| 1| 2| 3| 4| 74','N/A','Black faceplate| mocha faceplate'                                                                           Union all 
select 'Signia','IX','Instant fit CIC','Silk Charge&Go 5IX L','R','0| 1| 2| 3| 4| 75','N/A','Black faceplate| mocha faceplate'                                                                           Union all 
select 'Signia','IX','Instant fit CIC','Silk Charge&Go 5IX R','R','0| 1| 2| 3| 4| 78','N/A','Black faceplate| mocha faceplate'                                                                           Union all 
select 'Signia','IX','Instant fit CIC','Silk Charge&Go 3IX L ','R','0| 1| 2| 3| 4| 79','N/A','Black faceplate| mocha faceplate'                                                                          Union all 
select 'Signia','IX','Instant fit CIC','Silk Charge&Go 3IX R ','R','0| 1| 2| 3| 4| 82','N/A','Black faceplate| mocha faceplate'                                                                          Union all 
select 'Signia','IX','RIC','CROS Pure Charge&Go IX ','R','0| 1| 2| 3| 4| 83','S| M| P| HP','Silver| beige| black| dark brown| dark champagne| fine gold| graphite| pearl white| rose gold| dark blonde'  Union all 
select 'Signia','IX','Instant fit CIC','CROS Silk Charge&Go IX L','R','0| 1| 2| 3| 4| 96','N/A','Black faceplate| mocha faceplate'                                                                       Union all 
select 'Signia','IX','Instant fit CIC','CROS Silk Charge&Go IX R','R','0| 1| 2| 3| 4| 96','N/A','Black faceplate| mocha faceplate'                                                                       


*/
select * from dbo.InsigniaProduct

alter table dbo.InsigniaProduct add ItemCode varchar(200)
alter table dbo.InsigniaProduct add ItemCode1 varchar(200)
alter table dbo.InsigniaProduct add ModelCode varchar(200)
alter table dbo.InsigniaProduct add ItemType varchar(200)
alter table dbo.InsigniaProduct add FamilyCode varchar(200)
alter table dbo.InsigniaProduct add StyleCode varchar(200)
alter table dbo.InsigniaProduct add BrandCode varchar(200)
alter table dbo.InsigniaProduct add TechnologyCode varchar(200)

update dbo.InsigniaProduct set ItemCode  = ProductModelName
update dbo.InsigniaProduct set ItemCode = replace(ItemCode,'&', ' And ')
update dbo.InsigniaProduct set ModelCode  =  ItemCode
update dbo.InsigniaProduct set ItemCode1  =  ItemCode
update dbo.InsigniaProduct set ItemCode1  =  'SI_'+ replace(ItemCode1, ' ','_')
update dbo.InsigniaProduct set ItemType = 'HA' where ProductModelName not like '%CROS%'
update dbo.InsigniaProduct set ItemType = 'CROS' where ProductModelName like '%CROS%'


select
'update dbo.InsigniaProduct set FamilyCode = ' + ItemCode + ' where '+' ItemCode  = ' + ''''+ ItemCode+''''  from dbo.InsigniaProduct

update dbo.InsigniaProduct set FamilyCode = 'T 7IX'	where  ItemCode  = 'Pure Charge And Go T 7IX'
update dbo.InsigniaProduct set FamilyCode = 'T 5IX'	where  ItemCode  = 'Pure Charge And Go T 5IX'
update dbo.InsigniaProduct set FamilyCode = 'T 3IX'	where  ItemCode  = 'Pure Charge And Go T 3IX'
update dbo.InsigniaProduct set FamilyCode = '7IX'	where  ItemCode  = 'Pure Charge And Go 7IX'
update dbo.InsigniaProduct set FamilyCode = '5IX'	where  ItemCode  = 'Pure Charge And Go 5IX'
update dbo.InsigniaProduct set FamilyCode = '3IX'	where  ItemCode  = 'Pure Charge And Go 3IX'
update dbo.InsigniaProduct set FamilyCode = '7IX L'	where  ItemCode  = 'Silk Charge And Go 7IX L'
update dbo.InsigniaProduct set FamilyCode = '7IX R'	where  ItemCode  = 'Silk Charge And Go 7IX R'
update dbo.InsigniaProduct set FamilyCode = '5IX L'	where  ItemCode  = 'Silk Charge And Go 5IX L'
update dbo.InsigniaProduct set FamilyCode = '5IX R'	where  ItemCode  = 'Silk Charge And Go 5IX R'
update dbo.InsigniaProduct set FamilyCode = '3IX L'	where  ItemCode  = 'Silk Charge And Go 3IX L'
update dbo.InsigniaProduct set FamilyCode = '3IX R'	where  ItemCode  = 'Silk Charge And Go 3IX R'
update dbo.InsigniaProduct set FamilyCode = 'IX'	where  ItemCode  = 'CROS Pure Charge And Go IX'
update dbo.InsigniaProduct set FamilyCode = 'IX L'	where  ItemCode  = 'CROS Silk Charge And Go IX L'
update dbo.InsigniaProduct set FamilyCode = 'IX R'	where  ItemCode  = 'CROS Silk Charge And Go IX R'

update dbo.InsigniaProduct set StyleCode = 'RIC' where ProductStyle = 'RIC'
update dbo.InsigniaProduct set StyleCode = 'InstantFit' where ProductStyle like '%Instant%'

update dbo.InsigniaProduct set BrandCode = 'SIGNIA' 
update dbo.InsigniaProduct set TechnologyCode  = 'SI '+FamilyCode


insert into #ItemMasterList
(
Itemcode
,[ItemType]
,BrandCode
,FamilyCode
,TechnologyCode
,ModelCode
,StyleCode
, IsActive
, CreateDate
, CreateUser
, ModifyDate
,ModifyUser
,MonauralHCPCSCode
, BinauralHCPCSCode
)




select

'select ' + 
''''+ItemCode1+ ''''		+ ','+					-- ItemCode
''''+ItemType+  ''''		+ ','+					-- ItemType
''''+BrandCode+''''			+ ','+					-- BrandCode
''''+FamilyCode+''''		+ ','+					-- FamilyCode
''''+TechnologyCode+''''	+ ','+					-- TechnologyCode
''''+ModelCode+''''			+ ','+					-- ModelCode
''''+StyleCode+''''			+ ','					-- StyleCode
	+'1'					+ ','					-- IsActive
	+'getdate()'			+ ','+					-- CreateDate
''''+'sballa'+''''			+ ','					-- CreateUser
	+'getdate()'			+ ','+					-- ModifyDate
''''+'sballa'+''''			+ ','+					-- ModifyUser
''''+'V5257'+''''			+ ','+					-- MonauralHCPCSCode
''''+'V5261'+''''			+ 	' UNION ALL'	-- BinauralHCPCSCode

from  dbo.InsigniaProduct
	    



drop table #ItemMasterList
select * into #ItemMasterList from catalog.ItemMasterList where 1 =2
insert into #ItemMasterList
(
Itemcode
,[ItemType]
,BrandCode
,FamilyCode
,TechnologyCode
,ModelCode
,StyleCode
, IsActive
, CreateDate
, CreateUser
, ModifyDate
,ModifyUser
,MonauralHCPCSCode
, BinauralHCPCSCode
)

select 'SI_Pure_Charge_And_Go_T_7IX','HA','SIGNIA','T 7IX','SI T 7IX','Pure Charge And Go T 7IX','RIC',1,getdate(),'sballa',getdate(),'sballa','V5257','V5261' UNION ALL
select 'SI_Pure_Charge_And_Go_T_5IX','HA','SIGNIA','T 5IX','SI T 5IX','Pure Charge And Go T 5IX','RIC',1,getdate(),'sballa',getdate(),'sballa','V5257','V5261' UNION ALL
select 'SI_Pure_Charge_And_Go_T_3IX','HA','SIGNIA','T 3IX','SI T 3IX','Pure Charge And Go T 3IX','RIC',1,getdate(),'sballa',getdate(),'sballa','V5257','V5261' UNION ALL
select 'SI_Pure_Charge_And_Go_7IX','HA','SIGNIA','7IX','SI 7IX','Pure Charge And Go 7IX','RIC',1,getdate(),'sballa',getdate(),'sballa','V5257','V5261' UNION ALL
select 'SI_Pure_Charge_And_Go_5IX','HA','SIGNIA','5IX','SI 5IX','Pure Charge And Go 5IX','RIC',1,getdate(),'sballa',getdate(),'sballa','V5257','V5261' UNION ALL
select 'SI_Pure_Charge_And_Go_3IX','HA','SIGNIA','3IX','SI 3IX','Pure Charge And Go 3IX','RIC',1,getdate(),'sballa',getdate(),'sballa','V5257','V5261' UNION ALL
select 'SI_Silk_Charge_And_Go_7IX_L','HA','SIGNIA','7IX L','SI 7IX L','Silk Charge And Go 7IX L','InstantFit',1,getdate(),'sballa',getdate(),'sballa','V5257','V5261' UNION ALL
select 'SI_Silk_Charge_And_Go_7IX_R','HA','SIGNIA','7IX R','SI 7IX R','Silk Charge And Go 7IX R','InstantFit',1,getdate(),'sballa',getdate(),'sballa','V5257','V5261' UNION ALL
select 'SI_Silk_Charge_And_Go_5IX_L','HA','SIGNIA','5IX L','SI 5IX L','Silk Charge And Go 5IX L','InstantFit',1,getdate(),'sballa',getdate(),'sballa','V5257','V5261' UNION ALL
select 'SI_Silk_Charge_And_Go_5IX_R','HA','SIGNIA','5IX R','SI 5IX R','Silk Charge And Go 5IX R','InstantFit',1,getdate(),'sballa',getdate(),'sballa','V5257','V5261' UNION ALL
select 'SI_Silk_Charge_And_Go_3IX_L','HA','SIGNIA','3IX L','SI 3IX L','Silk Charge And Go 3IX L','InstantFit',1,getdate(),'sballa',getdate(),'sballa','V5257','V5261' UNION ALL
select 'SI_Silk_Charge_And_Go_3IX_R','HA','SIGNIA','3IX R','SI 3IX R','Silk Charge And Go 3IX R','InstantFit',1,getdate(),'sballa',getdate(),'sballa','V5257','V5261' UNION ALL
select 'SI_CROS_Pure_Charge_And_Go_IX','CROS','SIGNIA','IX','SI IX','CROS Pure Charge And Go IX','RIC',1,getdate(),'sballa',getdate(),'sballa','V5257','V5261' UNION ALL
select 'SI_CROS_Silk_Charge_And_Go_IX_L','CROS','SIGNIA','IX L','SI IX L','CROS Silk Charge And Go IX L','InstantFit',1,getdate(),'sballa',getdate(),'sballa','V5257','V5261' UNION ALL
select 'SI_CROS_Silk_Charge_And_Go_IX_R','CROS','SIGNIA','IX R','SI IX R','CROS Silk Charge And Go IX R','InstantFit',1,getdate(),'sballa',getdate(),'sballa','V5257','V5261'

select * from #ItemMasterList


select ProductModelName, ReceiverLengthsAvailable from dbo.InsigniaProduct
cross apply string_split('Silver| beige| black| dark brown| dark champagne| fine gold| graphite| pearl white| rose gold| dark blonde', '|')
select value from string_split('Silver| beige| black| dark brown| dark champagne| fine gold| graphite| pearl white| rose gold| dark blonde', '|')


select distinct ProductModelName,* from dbo.InsigniaProduct
cross apply string_split(Ltrim(ReceiverPowersAvailable), '|') as ReceiverPowersAvailable
cross apply string_split(Ltrim(ColorsAvailable), '|') as ColorsAvailable
cross apply string_split(Ltrim(ReceiverLengthsAvailable), '|') as ReceiverLengthsAvailable
where ProductModelName = 'CROS Pure Charge&Go IX'


select ProductModelName, rtrim(ltrim(value)) as ReveiverPowersAvailable from dbo.InsigniaProduct cross apply string_split(Ltrim(ReceiverPowersAvailable), '|') where value not like 'N/A'
select ProductModelName, rtrim(ltrim(value)) as ReceiverLengthsAvailable from dbo.InsigniaProduct cross apply string_split(Ltrim(ReceiverLengthsAvailable), '|') where value not like 'N/A'
select ProductModelName, rtrim(ltrim(value)) as ColorsAvailable from dbo.InsigniaProduct cross apply string_split(Ltrim(ColorsAvailable), '|') where value not like 'N/A'


select * from catalog.ItemMasterList
where brandcode = 'Signia'
order by 1 desc

select * from catalog.ItemMasterAttributeValues
where itemcode in (select itemcode from catalog.ItemMasterList where brandcode = 'Signia') and AttributeCode = 'BATTERY_SIZES'


Itemcode,[ItemType],BrandCode,FamilyCode,TechnologyCode,ModelCode,StyleCode, IsActive, CreateDate, CreateUser, ModifyDate,ModifyUser,MonauralHCPCSCode, BinauralHCPCSCode


select * from #ItemMasterList

select * from catalog.ItemMasterAttributeValues
where itemcode in (select itemcode from catalog.ItemMasterList where brandcode = 'Signia') 


select ProductModelName as ItemCode, rtrim(ltrim(value)) as RECEIVERPOWER from dbo.InsigniaProduct cross apply string_split(Ltrim(ReceiverPowersAvailable), '|') where value not like 'N/A' -- RECEIVER_POWER  -- DONE
select ProductModelName as ItemCode, rtrim(ltrim(value)) as RECEIVERSIZES from dbo.InsigniaProduct cross apply string_split(Ltrim(ReceiverLengthsAvailable), '|') where value not like 'N/A' -- RECEIVER_SIZES -- DONE
select ProductModelName as ItemCode, upper(rtrim(ltrim(value))) as COLOR from dbo.InsigniaProduct cross apply string_split(Ltrim(ColorsAvailable), '|') where value not like 'N/A' -- COLOR -- Done
select ProductModelName as ItemCode, upper(rtrim(ltrim(value))) as BatterySizes from dbo.InsigniaProduct cross apply string_split(Ltrim(BatterySize), '|') where value not like 'N/A' -- BATTERY_SIZES -- Done



insert into catalog.ItemMasterAttributeValues
(AttributeCode
,Itemcode
,ModelAttributeValue
,IsActive
,VendorCode
,Modifier
,ModelAttributeValueDescription
,CreateDate
,CreateUser
,ModifyDate
,ModifyUser
)

--- COLOR
drop table #color
select * into #Color from ( select ItemCode1 as ItemCode, upper(rtrim(ltrim(value))) as Color from dbo.InsigniaProduct cross apply string_split(Ltrim(ColorsAvailable), '|') where value not like 'N/A') a -- COLOR
select * from #color

select

'select ' + 
''''+'COLOR'+ ''''		+ ','+		-- AttributeCode
''''+a.ItemCode+''''	+ ','+		-- ItemCode
''''+b.COLOR+''''		+ ','		-- ModelAttributeValue
	+'1'				+ ','+		-- IsActive
''''+a.ItemCode+''''	+ ','+		-- VendorCode
''''+'NA'+''''		    + ','+		-- Modifier
''''+b.COLOR+''''		+ ','		-- ModelAttributeValueDescription
	+'getdate()'		+ ','+		-- CreateDate
''''+'sballa'+''''		+ ','		 --CreateUser
	+'getdate()'		+ ','+		-- ModifyDate
''''+'sballa'+''''		+ ' UNION ALL'		      --ModifyUser

from #ItemMasterList a left join #Color b on a.ItemCode = b.itemCode

select
a.*, b.*

from #ItemMasterList a right join #Color b on ltrim(rtrim(a.ItemCode)) = ltrim(rtrim(b.itemCode))

select * from dbo.InsigniaProduct
update dbo.InsigniaProduct set ProductModelName = ltrim(rtrim(ProductModelName))


select Itemcode from #Color where Itemcode = 'Pure Charge&Go T 7IX'
select itemcode from #ItemMasterList where Itemcode like 'Pure Charge&Go T 7IX'


-- ReceiverPower
drop table #ReceiverPower
select * into #ReceiverPower from ( select ItemCode1 as ItemCode, upper(rtrim(ltrim(value))) as ReceiverPower from dbo.InsigniaProduct cross apply string_split(Ltrim(ReceiverPowersAvailable), '|') where value not like 'N/A') a -- ReceiverPowers
select * from #ReceiverPower


select distinct
'select ' + 
''''+'RECIEVER_POWER'+ ''''		+ ','+		-- AttributeCode
''''+a.ItemCode+''''	+ ','+		-- ItemCode
''''+b.ReceiverPower+''''		+ ','		-- ModelAttributeValue
	+'1'				+ ','+		-- IsActive
''''+a.ItemCode+''''	+ ','+		-- VendorCode
''''+'NA'+''''		    + ','+		-- Modifier
''''+b.ReceiverPower+''''		+ ','		-- ModelAttributeValueDescription
	+'getdate()'		+ ','+		-- CreateDate
''''+'sballa'+''''		+ ','		 --CreateUser
	+'getdate()'		+ ','+		-- ModifyDate
''''+'sballa'+''''		+ ' UNION ALL'		      --ModifyUser

from #ItemMasterList a join #ReceiverPower b on a.ItemCode = b.itemCode




select * from catalog.ItemMasterAttributeValues
where itemcode in (select itemcode from catalog.ItemMasterList where brandcode = 'Signia') and AttributeCode = 'RECIEVER_SIZES'

-- ReceiverSizes
drop table #ReceiverSizes
select * into #ReceiverSizes from ( select ItemCode1 as ItemCode, upper(rtrim(ltrim(value))) as ReceiverSizes from dbo.InsigniaProduct cross apply string_split(Ltrim(ReceiverLengthsAvailable), '|') where value not like 'N/A') a -- ReceiverSizes
select * from #ReceiverSizes


select distinct
'select ' + 
''''+'RECIEVER_SIZES'+ ''''		+ ','+		-- AttributeCode
''''+a.ItemCode+''''	+ ','+		-- ItemCode
''''+b.ReceiverSizes+''''		+ ','		-- ModelAttributeValue
	+'1'				+ ','+		-- IsActive
''''+a.ItemCode+''''	+ ','+		-- VendorCode
''''+'NA'+''''		    + ','+		-- Modifier
''''+b.ReceiverSizes+''''		+ ','		-- ModelAttributeValueDescription
	+'getdate()'		+ ','+		-- CreateDate
''''+'sballa'+''''		+ ','		 --CreateUser
	+'getdate()'		+ ','+		-- ModifyDate
''''+'sballa'+''''		+ ' UNION ALL'		      --ModifyUser

from #ItemMasterList a join #ReceiverSizes b on a.ItemCode = b.itemCode







select * from catalog.ItemMasterAttributeValues
where itemcode in (select itemcode from catalog.ItemMasterList where brandcode = 'Signia') and AttributeCode = 'BATTERY_SIZES'

-- BatterySizes
drop table #BatterySizes
select * into #BatterySizes from ( select ItemCode1 as ItemCode, upper(rtrim(ltrim(value))) as BatterySizes from dbo.InsigniaProduct cross apply string_split(Ltrim(BatterySize), '|') where value not like 'N/A') a -- BatterySizes
select * from #BatterySizes


select distinct
'select ' + 
''''+'BATTERY_SIZES'+ ''''		+ ','+		-- AttributeCode
''''+a.ItemCode+''''	+ ','+				-- ItemCode
''''+b.BatterySizes+''''		+ ','		-- ModelAttributeValue
	+'1'				+ ','+				-- IsActive
''''+a.ItemCode+''''	+ ','+				-- VendorCode
''''+'NA'+''''		    + ','+				-- Modifier
''''+b.BatterySizes+''''		+ ','		-- ModelAttributeValueDescription
	+'getdate()'		+ ','+				-- CreateDate
''''+'sballa'+''''		+ ','				-- CreateUser
	+'getdate()'		+ ','+				-- ModifyDate
''''+'sballa'+''''		+ ' UNION ALL'		-- ModifyUser

from #ItemMasterList a join #BatterySizes b on a.ItemCode = b.itemCode





-- COLOR Attribute
select * into #ItemMasterAttributeValues from catalog.ItemMasterAttributeValues where 1=2

insert into #ItemMasterAttributeValues
(AttributeCode
,Itemcode
,ModelAttributeValue
,IsActive
,VendorCode
,Modifier
,ModelAttributeValueDescription
,CreateDate
,CreateUser
,ModifyDate
,ModifyUser
)

--- COLOR
select * from catalog.ItemMasterAttributeValues
where itemcode in (select itemcode from catalog.ItemMasterList where brandcode = 'Signia') and AttributeCode = 'COLOR'


insert into #ItemMasterAttributeValues
(AttributeCode
,Itemcode
,ModelAttributeValue
,IsActive
,VendorCode
,Modifier
,ModelAttributeValueDescription
,CreateDate
,CreateUser
,ModifyDate
,ModifyUser
)

select 'COLOR','SI_Pure_Charge_And_Go_T_7IX','SILVER',1,'SI_Pure_Charge_And_Go_T_7IX','NA','SILVER',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_T_7IX','BEIGE',1,'SI_Pure_Charge_And_Go_T_7IX','NA','BEIGE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_T_7IX','BLACK',1,'SI_Pure_Charge_And_Go_T_7IX','NA','BLACK',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_T_7IX','DARK BROWN',1,'SI_Pure_Charge_And_Go_T_7IX','NA','DARK BROWN',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_T_7IX','DARK CHAMPAGNE',1,'SI_Pure_Charge_And_Go_T_7IX','NA','DARK CHAMPAGNE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_T_7IX','FINE GOLD',1,'SI_Pure_Charge_And_Go_T_7IX','NA','FINE GOLD',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_T_7IX','GRAPHITE',1,'SI_Pure_Charge_And_Go_T_7IX','NA','GRAPHITE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_T_7IX','PEARL WHITE',1,'SI_Pure_Charge_And_Go_T_7IX','NA','PEARL WHITE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_T_7IX','ROSE GOLD',1,'SI_Pure_Charge_And_Go_T_7IX','NA','ROSE GOLD',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_T_7IX','DARK BLONDE',1,'SI_Pure_Charge_And_Go_T_7IX','NA','DARK BLONDE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_T_5IX','SILVER',1,'SI_Pure_Charge_And_Go_T_5IX','NA','SILVER',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_T_5IX','BEIGE',1,'SI_Pure_Charge_And_Go_T_5IX','NA','BEIGE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_T_5IX','BLACK',1,'SI_Pure_Charge_And_Go_T_5IX','NA','BLACK',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_T_5IX','DARK BROWN',1,'SI_Pure_Charge_And_Go_T_5IX','NA','DARK BROWN',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_T_5IX','DARK CHAMPAGNE',1,'SI_Pure_Charge_And_Go_T_5IX','NA','DARK CHAMPAGNE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_T_5IX','FINE GOLD',1,'SI_Pure_Charge_And_Go_T_5IX','NA','FINE GOLD',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_T_5IX','GRAPHITE',1,'SI_Pure_Charge_And_Go_T_5IX','NA','GRAPHITE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_T_5IX','PEARL WHITE',1,'SI_Pure_Charge_And_Go_T_5IX','NA','PEARL WHITE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_T_5IX','ROSE GOLD',1,'SI_Pure_Charge_And_Go_T_5IX','NA','ROSE GOLD',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_T_5IX','DARK BLONDE',1,'SI_Pure_Charge_And_Go_T_5IX','NA','DARK BLONDE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_T_3IX','SILVER',1,'SI_Pure_Charge_And_Go_T_3IX','NA','SILVER',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_T_3IX','BEIGE',1,'SI_Pure_Charge_And_Go_T_3IX','NA','BEIGE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_T_3IX','BLACK',1,'SI_Pure_Charge_And_Go_T_3IX','NA','BLACK',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_T_3IX','DARK BROWN',1,'SI_Pure_Charge_And_Go_T_3IX','NA','DARK BROWN',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_T_3IX','DARK CHAMPAGNE',1,'SI_Pure_Charge_And_Go_T_3IX','NA','DARK CHAMPAGNE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_T_3IX','FINE GOLD',1,'SI_Pure_Charge_And_Go_T_3IX','NA','FINE GOLD',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_T_3IX','GRAPHITE',1,'SI_Pure_Charge_And_Go_T_3IX','NA','GRAPHITE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_T_3IX','PEARL WHITE',1,'SI_Pure_Charge_And_Go_T_3IX','NA','PEARL WHITE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_T_3IX','ROSE GOLD',1,'SI_Pure_Charge_And_Go_T_3IX','NA','ROSE GOLD',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_T_3IX','DARK BLONDE',1,'SI_Pure_Charge_And_Go_T_3IX','NA','DARK BLONDE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_7IX','SILVER',1,'SI_Pure_Charge_And_Go_7IX','NA','SILVER',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_7IX','BEIGE',1,'SI_Pure_Charge_And_Go_7IX','NA','BEIGE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_7IX','BLACK',1,'SI_Pure_Charge_And_Go_7IX','NA','BLACK',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_7IX','DARK BROWN',1,'SI_Pure_Charge_And_Go_7IX','NA','DARK BROWN',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_7IX','DARK CHAMPAGNE',1,'SI_Pure_Charge_And_Go_7IX','NA','DARK CHAMPAGNE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_7IX','FINE GOLD',1,'SI_Pure_Charge_And_Go_7IX','NA','FINE GOLD',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_7IX','GRAPHITE',1,'SI_Pure_Charge_And_Go_7IX','NA','GRAPHITE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_7IX','PEARL WHITE',1,'SI_Pure_Charge_And_Go_7IX','NA','PEARL WHITE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_7IX','ROSE GOLD',1,'SI_Pure_Charge_And_Go_7IX','NA','ROSE GOLD',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_7IX','DARK BLONDE',1,'SI_Pure_Charge_And_Go_7IX','NA','DARK BLONDE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_5IX','SILVER',1,'SI_Pure_Charge_And_Go_5IX','NA','SILVER',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_5IX','BEIGE',1,'SI_Pure_Charge_And_Go_5IX','NA','BEIGE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_5IX','BLACK',1,'SI_Pure_Charge_And_Go_5IX','NA','BLACK',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_5IX','DARK BROWN',1,'SI_Pure_Charge_And_Go_5IX','NA','DARK BROWN',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_5IX','DARK CHAMPAGNE',1,'SI_Pure_Charge_And_Go_5IX','NA','DARK CHAMPAGNE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_5IX','FINE GOLD',1,'SI_Pure_Charge_And_Go_5IX','NA','FINE GOLD',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_5IX','GRAPHITE',1,'SI_Pure_Charge_And_Go_5IX','NA','GRAPHITE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_5IX','PEARL WHITE',1,'SI_Pure_Charge_And_Go_5IX','NA','PEARL WHITE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_5IX','ROSE GOLD',1,'SI_Pure_Charge_And_Go_5IX','NA','ROSE GOLD',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_5IX','DARK BLONDE',1,'SI_Pure_Charge_And_Go_5IX','NA','DARK BLONDE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_3IX','SILVER',1,'SI_Pure_Charge_And_Go_3IX','NA','SILVER',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_3IX','BEIGE',1,'SI_Pure_Charge_And_Go_3IX','NA','BEIGE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_3IX','BLACK',1,'SI_Pure_Charge_And_Go_3IX','NA','BLACK',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_3IX','DARK BROWN',1,'SI_Pure_Charge_And_Go_3IX','NA','DARK BROWN',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_3IX','DARK CHAMPAGNE',1,'SI_Pure_Charge_And_Go_3IX','NA','DARK CHAMPAGNE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_3IX','FINE GOLD',1,'SI_Pure_Charge_And_Go_3IX','NA','FINE GOLD',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_3IX','GRAPHITE',1,'SI_Pure_Charge_And_Go_3IX','NA','GRAPHITE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_3IX','PEARL WHITE',1,'SI_Pure_Charge_And_Go_3IX','NA','PEARL WHITE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_3IX','ROSE GOLD',1,'SI_Pure_Charge_And_Go_3IX','NA','ROSE GOLD',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Pure_Charge_And_Go_3IX','DARK BLONDE',1,'SI_Pure_Charge_And_Go_3IX','NA','DARK BLONDE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Silk_Charge_And_Go_7IX_L','BLACK FACEPLATE',1,'SI_Silk_Charge_And_Go_7IX_L','NA','BLACK FACEPLATE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Silk_Charge_And_Go_7IX_L','MOCHA FACEPLATE',1,'SI_Silk_Charge_And_Go_7IX_L','NA','MOCHA FACEPLATE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Silk_Charge_And_Go_7IX_R','BLACK FACEPLATE',1,'SI_Silk_Charge_And_Go_7IX_R','NA','BLACK FACEPLATE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Silk_Charge_And_Go_7IX_R','MOCHA FACEPLATE',1,'SI_Silk_Charge_And_Go_7IX_R','NA','MOCHA FACEPLATE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Silk_Charge_And_Go_5IX_L','BLACK FACEPLATE',1,'SI_Silk_Charge_And_Go_5IX_L','NA','BLACK FACEPLATE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Silk_Charge_And_Go_5IX_L','MOCHA FACEPLATE',1,'SI_Silk_Charge_And_Go_5IX_L','NA','MOCHA FACEPLATE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Silk_Charge_And_Go_5IX_R','BLACK FACEPLATE',1,'SI_Silk_Charge_And_Go_5IX_R','NA','BLACK FACEPLATE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Silk_Charge_And_Go_5IX_R','MOCHA FACEPLATE',1,'SI_Silk_Charge_And_Go_5IX_R','NA','MOCHA FACEPLATE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Silk_Charge_And_Go_3IX_L','BLACK FACEPLATE',1,'SI_Silk_Charge_And_Go_3IX_L','NA','BLACK FACEPLATE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Silk_Charge_And_Go_3IX_L','MOCHA FACEPLATE',1,'SI_Silk_Charge_And_Go_3IX_L','NA','MOCHA FACEPLATE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Silk_Charge_And_Go_3IX_R','BLACK FACEPLATE',1,'SI_Silk_Charge_And_Go_3IX_R','NA','BLACK FACEPLATE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_Silk_Charge_And_Go_3IX_R','MOCHA FACEPLATE',1,'SI_Silk_Charge_And_Go_3IX_R','NA','MOCHA FACEPLATE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_CROS_Pure_Charge_And_Go_IX','SILVER',1,'SI_CROS_Pure_Charge_And_Go_IX','NA','SILVER',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_CROS_Pure_Charge_And_Go_IX','BEIGE',1,'SI_CROS_Pure_Charge_And_Go_IX','NA','BEIGE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_CROS_Pure_Charge_And_Go_IX','BLACK',1,'SI_CROS_Pure_Charge_And_Go_IX','NA','BLACK',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_CROS_Pure_Charge_And_Go_IX','DARK BROWN',1,'SI_CROS_Pure_Charge_And_Go_IX','NA','DARK BROWN',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_CROS_Pure_Charge_And_Go_IX','DARK CHAMPAGNE',1,'SI_CROS_Pure_Charge_And_Go_IX','NA','DARK CHAMPAGNE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_CROS_Pure_Charge_And_Go_IX','FINE GOLD',1,'SI_CROS_Pure_Charge_And_Go_IX','NA','FINE GOLD',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_CROS_Pure_Charge_And_Go_IX','GRAPHITE',1,'SI_CROS_Pure_Charge_And_Go_IX','NA','GRAPHITE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_CROS_Pure_Charge_And_Go_IX','PEARL WHITE',1,'SI_CROS_Pure_Charge_And_Go_IX','NA','PEARL WHITE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_CROS_Pure_Charge_And_Go_IX','ROSE GOLD',1,'SI_CROS_Pure_Charge_And_Go_IX','NA','ROSE GOLD',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_CROS_Pure_Charge_And_Go_IX','DARK BLONDE',1,'SI_CROS_Pure_Charge_And_Go_IX','NA','DARK BLONDE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_CROS_Silk_Charge_And_Go_IX_L','BLACK FACEPLATE',1,'SI_CROS_Silk_Charge_And_Go_IX_L','NA','BLACK FACEPLATE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_CROS_Silk_Charge_And_Go_IX_L','MOCHA FACEPLATE',1,'SI_CROS_Silk_Charge_And_Go_IX_L','NA','MOCHA FACEPLATE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_CROS_Silk_Charge_And_Go_IX_R','BLACK FACEPLATE',1,'SI_CROS_Silk_Charge_And_Go_IX_R','NA','BLACK FACEPLATE',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'COLOR','SI_CROS_Silk_Charge_And_Go_IX_R','MOCHA FACEPLATE',1,'SI_CROS_Silk_Charge_And_Go_IX_R','NA','MOCHA FACEPLATE',getdate(),'sballa',getdate(),'sballa'


---- RECEIVER POWER
select * from catalog.ItemMasterAttributeValues
where itemcode in (select itemcode from catalog.ItemMasterList where brandcode = 'Signia') and AttributeCode = 'RECIEVER_POWER'


insert into #ItemMasterAttributeValues
(AttributeCode
,Itemcode
,ModelAttributeValue
,IsActive
,VendorCode
,Modifier
,ModelAttributeValueDescription
,CreateDate
,CreateUser
,ModifyDate
,ModifyUser
)

select 'RECIEVER_POWER','SI_CROS_Pure_Charge_And_Go_IX','HP',1,'SI_CROS_Pure_Charge_And_Go_IX','NA','HP',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_POWER','SI_CROS_Pure_Charge_And_Go_IX','M',1,'SI_CROS_Pure_Charge_And_Go_IX','NA','M',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_POWER','SI_CROS_Pure_Charge_And_Go_IX','P',1,'SI_CROS_Pure_Charge_And_Go_IX','NA','P',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_POWER','SI_CROS_Pure_Charge_And_Go_IX','S',1,'SI_CROS_Pure_Charge_And_Go_IX','NA','S',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_POWER','SI_Pure_Charge_And_Go_3IX','HP',1,'SI_Pure_Charge_And_Go_3IX','NA','HP',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_POWER','SI_Pure_Charge_And_Go_3IX','M',1,'SI_Pure_Charge_And_Go_3IX','NA','M',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_POWER','SI_Pure_Charge_And_Go_3IX','P',1,'SI_Pure_Charge_And_Go_3IX','NA','P',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_POWER','SI_Pure_Charge_And_Go_3IX','S',1,'SI_Pure_Charge_And_Go_3IX','NA','S',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_POWER','SI_Pure_Charge_And_Go_5IX','HP',1,'SI_Pure_Charge_And_Go_5IX','NA','HP',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_POWER','SI_Pure_Charge_And_Go_5IX','M',1,'SI_Pure_Charge_And_Go_5IX','NA','M',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_POWER','SI_Pure_Charge_And_Go_5IX','P',1,'SI_Pure_Charge_And_Go_5IX','NA','P',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_POWER','SI_Pure_Charge_And_Go_5IX','S',1,'SI_Pure_Charge_And_Go_5IX','NA','S',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_POWER','SI_Pure_Charge_And_Go_7IX','HP',1,'SI_Pure_Charge_And_Go_7IX','NA','HP',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_POWER','SI_Pure_Charge_And_Go_7IX','M',1,'SI_Pure_Charge_And_Go_7IX','NA','M',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_POWER','SI_Pure_Charge_And_Go_7IX','P',1,'SI_Pure_Charge_And_Go_7IX','NA','P',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_POWER','SI_Pure_Charge_And_Go_7IX','S',1,'SI_Pure_Charge_And_Go_7IX','NA','S',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_POWER','SI_Pure_Charge_And_Go_T_3IX','HP',1,'SI_Pure_Charge_And_Go_T_3IX','NA','HP',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_POWER','SI_Pure_Charge_And_Go_T_3IX','M',1,'SI_Pure_Charge_And_Go_T_3IX','NA','M',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_POWER','SI_Pure_Charge_And_Go_T_3IX','P',1,'SI_Pure_Charge_And_Go_T_3IX','NA','P',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_POWER','SI_Pure_Charge_And_Go_T_3IX','S',1,'SI_Pure_Charge_And_Go_T_3IX','NA','S',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_POWER','SI_Pure_Charge_And_Go_T_5IX','HP',1,'SI_Pure_Charge_And_Go_T_5IX','NA','HP',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_POWER','SI_Pure_Charge_And_Go_T_5IX','M',1,'SI_Pure_Charge_And_Go_T_5IX','NA','M',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_POWER','SI_Pure_Charge_And_Go_T_5IX','P',1,'SI_Pure_Charge_And_Go_T_5IX','NA','P',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_POWER','SI_Pure_Charge_And_Go_T_5IX','S',1,'SI_Pure_Charge_And_Go_T_5IX','NA','S',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_POWER','SI_Pure_Charge_And_Go_T_7IX','HP',1,'SI_Pure_Charge_And_Go_T_7IX','NA','HP',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_POWER','SI_Pure_Charge_And_Go_T_7IX','M',1,'SI_Pure_Charge_And_Go_T_7IX','NA','M',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_POWER','SI_Pure_Charge_And_Go_T_7IX','P',1,'SI_Pure_Charge_And_Go_T_7IX','NA','P',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_POWER','SI_Pure_Charge_And_Go_T_7IX','S',1,'SI_Pure_Charge_And_Go_T_7IX','NA','S',getdate(),'sballa',getdate(),'sballa'













-- RECEIVER SIZES

select * from catalog.ItemMasterAttributeValues
where itemcode in (select itemcode from catalog.ItemMasterList where brandcode = 'Signia') and AttributeCode = 'RECIEVER_SIZES'



insert into #ItemMasterAttributeValues
(AttributeCode
,Itemcode
,ModelAttributeValue
,IsActive
,VendorCode
,Modifier
,ModelAttributeValueDescription
,CreateDate
,CreateUser
,ModifyDate
,ModifyUser
)


select 'RECIEVER_SIZES','SI_CROS_Pure_Charge_And_Go_IX','0',1,'SI_CROS_Pure_Charge_And_Go_IX','NA','0',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_CROS_Pure_Charge_And_Go_IX','1',1,'SI_CROS_Pure_Charge_And_Go_IX','NA','1',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_CROS_Pure_Charge_And_Go_IX','2',1,'SI_CROS_Pure_Charge_And_Go_IX','NA','2',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_CROS_Pure_Charge_And_Go_IX','3',1,'SI_CROS_Pure_Charge_And_Go_IX','NA','3',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_CROS_Pure_Charge_And_Go_IX','4',1,'SI_CROS_Pure_Charge_And_Go_IX','NA','4',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_CROS_Pure_Charge_And_Go_IX','83',1,'SI_CROS_Pure_Charge_And_Go_IX','NA','83',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_CROS_Silk_Charge_And_Go_IX_L','0',1,'SI_CROS_Silk_Charge_And_Go_IX_L','NA','0',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_CROS_Silk_Charge_And_Go_IX_L','1',1,'SI_CROS_Silk_Charge_And_Go_IX_L','NA','1',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_CROS_Silk_Charge_And_Go_IX_L','2',1,'SI_CROS_Silk_Charge_And_Go_IX_L','NA','2',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_CROS_Silk_Charge_And_Go_IX_L','3',1,'SI_CROS_Silk_Charge_And_Go_IX_L','NA','3',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_CROS_Silk_Charge_And_Go_IX_L','4',1,'SI_CROS_Silk_Charge_And_Go_IX_L','NA','4',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_CROS_Silk_Charge_And_Go_IX_L','96',1,'SI_CROS_Silk_Charge_And_Go_IX_L','NA','96',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_CROS_Silk_Charge_And_Go_IX_R','0',1,'SI_CROS_Silk_Charge_And_Go_IX_R','NA','0',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_CROS_Silk_Charge_And_Go_IX_R','1',1,'SI_CROS_Silk_Charge_And_Go_IX_R','NA','1',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_CROS_Silk_Charge_And_Go_IX_R','2',1,'SI_CROS_Silk_Charge_And_Go_IX_R','NA','2',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_CROS_Silk_Charge_And_Go_IX_R','3',1,'SI_CROS_Silk_Charge_And_Go_IX_R','NA','3',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_CROS_Silk_Charge_And_Go_IX_R','4',1,'SI_CROS_Silk_Charge_And_Go_IX_R','NA','4',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_CROS_Silk_Charge_And_Go_IX_R','96',1,'SI_CROS_Silk_Charge_And_Go_IX_R','NA','96',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Pure_Charge_And_Go_3IX','0',1,'SI_Pure_Charge_And_Go_3IX','NA','0',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Pure_Charge_And_Go_3IX','1',1,'SI_Pure_Charge_And_Go_3IX','NA','1',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Pure_Charge_And_Go_3IX','2',1,'SI_Pure_Charge_And_Go_3IX','NA','2',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Pure_Charge_And_Go_3IX','3',1,'SI_Pure_Charge_And_Go_3IX','NA','3',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Pure_Charge_And_Go_3IX','4',1,'SI_Pure_Charge_And_Go_3IX','NA','4',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Pure_Charge_And_Go_3IX','64',1,'SI_Pure_Charge_And_Go_3IX','NA','64',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Pure_Charge_And_Go_5IX','0',1,'SI_Pure_Charge_And_Go_5IX','NA','0',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Pure_Charge_And_Go_5IX','1',1,'SI_Pure_Charge_And_Go_5IX','NA','1',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Pure_Charge_And_Go_5IX','2',1,'SI_Pure_Charge_And_Go_5IX','NA','2',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Pure_Charge_And_Go_5IX','3',1,'SI_Pure_Charge_And_Go_5IX','NA','3',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Pure_Charge_And_Go_5IX','4',1,'SI_Pure_Charge_And_Go_5IX','NA','4',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Pure_Charge_And_Go_5IX','45',1,'SI_Pure_Charge_And_Go_5IX','NA','45',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Pure_Charge_And_Go_7IX','0',1,'SI_Pure_Charge_And_Go_7IX','NA','0',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Pure_Charge_And_Go_7IX','1',1,'SI_Pure_Charge_And_Go_7IX','NA','1',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Pure_Charge_And_Go_7IX','2',1,'SI_Pure_Charge_And_Go_7IX','NA','2',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Pure_Charge_And_Go_7IX','3',1,'SI_Pure_Charge_And_Go_7IX','NA','3',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Pure_Charge_And_Go_7IX','4',1,'SI_Pure_Charge_And_Go_7IX','NA','4',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Pure_Charge_And_Go_7IX','44',1,'SI_Pure_Charge_And_Go_7IX','NA','44',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Pure_Charge_And_Go_T_3IX','0',1,'SI_Pure_Charge_And_Go_T_3IX','NA','0',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Pure_Charge_And_Go_T_3IX','1',1,'SI_Pure_Charge_And_Go_T_3IX','NA','1',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Pure_Charge_And_Go_T_3IX','2',1,'SI_Pure_Charge_And_Go_T_3IX','NA','2',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Pure_Charge_And_Go_T_3IX','25',1,'SI_Pure_Charge_And_Go_T_3IX','NA','25',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Pure_Charge_And_Go_T_3IX','3',1,'SI_Pure_Charge_And_Go_T_3IX','NA','3',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Pure_Charge_And_Go_T_3IX','4',1,'SI_Pure_Charge_And_Go_T_3IX','NA','4',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Pure_Charge_And_Go_T_5IX','0',1,'SI_Pure_Charge_And_Go_T_5IX','NA','0',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Pure_Charge_And_Go_T_5IX','1',1,'SI_Pure_Charge_And_Go_T_5IX','NA','1',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Pure_Charge_And_Go_T_5IX','17',1,'SI_Pure_Charge_And_Go_T_5IX','NA','17',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Pure_Charge_And_Go_T_5IX','2',1,'SI_Pure_Charge_And_Go_T_5IX','NA','2',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Pure_Charge_And_Go_T_5IX','3',1,'SI_Pure_Charge_And_Go_T_5IX','NA','3',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Pure_Charge_And_Go_T_5IX','4',1,'SI_Pure_Charge_And_Go_T_5IX','NA','4',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Pure_Charge_And_Go_T_7IX','0',1,'SI_Pure_Charge_And_Go_T_7IX','NA','0',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Pure_Charge_And_Go_T_7IX','1',1,'SI_Pure_Charge_And_Go_T_7IX','NA','1',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Pure_Charge_And_Go_T_7IX','2',1,'SI_Pure_Charge_And_Go_T_7IX','NA','2',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Pure_Charge_And_Go_T_7IX','3',1,'SI_Pure_Charge_And_Go_T_7IX','NA','3',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Pure_Charge_And_Go_T_7IX','4',1,'SI_Pure_Charge_And_Go_T_7IX','NA','4',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Pure_Charge_And_Go_T_7IX','5',1,'SI_Pure_Charge_And_Go_T_7IX','NA','5',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Silk_Charge_And_Go_3IX_L','0',1,'SI_Silk_Charge_And_Go_3IX_L','NA','0',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Silk_Charge_And_Go_3IX_L','1',1,'SI_Silk_Charge_And_Go_3IX_L','NA','1',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Silk_Charge_And_Go_3IX_L','2',1,'SI_Silk_Charge_And_Go_3IX_L','NA','2',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Silk_Charge_And_Go_3IX_L','3',1,'SI_Silk_Charge_And_Go_3IX_L','NA','3',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Silk_Charge_And_Go_3IX_L','4',1,'SI_Silk_Charge_And_Go_3IX_L','NA','4',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Silk_Charge_And_Go_3IX_L','79',1,'SI_Silk_Charge_And_Go_3IX_L','NA','79',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Silk_Charge_And_Go_3IX_R','0',1,'SI_Silk_Charge_And_Go_3IX_R','NA','0',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Silk_Charge_And_Go_3IX_R','1',1,'SI_Silk_Charge_And_Go_3IX_R','NA','1',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Silk_Charge_And_Go_3IX_R','2',1,'SI_Silk_Charge_And_Go_3IX_R','NA','2',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Silk_Charge_And_Go_3IX_R','3',1,'SI_Silk_Charge_And_Go_3IX_R','NA','3',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Silk_Charge_And_Go_3IX_R','4',1,'SI_Silk_Charge_And_Go_3IX_R','NA','4',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Silk_Charge_And_Go_3IX_R','82',1,'SI_Silk_Charge_And_Go_3IX_R','NA','82',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Silk_Charge_And_Go_5IX_L','0',1,'SI_Silk_Charge_And_Go_5IX_L','NA','0',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Silk_Charge_And_Go_5IX_L','1',1,'SI_Silk_Charge_And_Go_5IX_L','NA','1',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Silk_Charge_And_Go_5IX_L','2',1,'SI_Silk_Charge_And_Go_5IX_L','NA','2',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Silk_Charge_And_Go_5IX_L','3',1,'SI_Silk_Charge_And_Go_5IX_L','NA','3',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Silk_Charge_And_Go_5IX_L','4',1,'SI_Silk_Charge_And_Go_5IX_L','NA','4',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Silk_Charge_And_Go_5IX_L','75',1,'SI_Silk_Charge_And_Go_5IX_L','NA','75',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Silk_Charge_And_Go_5IX_R','0',1,'SI_Silk_Charge_And_Go_5IX_R','NA','0',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Silk_Charge_And_Go_5IX_R','1',1,'SI_Silk_Charge_And_Go_5IX_R','NA','1',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Silk_Charge_And_Go_5IX_R','2',1,'SI_Silk_Charge_And_Go_5IX_R','NA','2',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Silk_Charge_And_Go_5IX_R','3',1,'SI_Silk_Charge_And_Go_5IX_R','NA','3',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Silk_Charge_And_Go_5IX_R','4',1,'SI_Silk_Charge_And_Go_5IX_R','NA','4',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Silk_Charge_And_Go_5IX_R','78',1,'SI_Silk_Charge_And_Go_5IX_R','NA','78',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Silk_Charge_And_Go_7IX_L','0',1,'SI_Silk_Charge_And_Go_7IX_L','NA','0',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Silk_Charge_And_Go_7IX_L','1',1,'SI_Silk_Charge_And_Go_7IX_L','NA','1',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Silk_Charge_And_Go_7IX_L','2',1,'SI_Silk_Charge_And_Go_7IX_L','NA','2',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Silk_Charge_And_Go_7IX_L','3',1,'SI_Silk_Charge_And_Go_7IX_L','NA','3',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Silk_Charge_And_Go_7IX_L','4',1,'SI_Silk_Charge_And_Go_7IX_L','NA','4',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Silk_Charge_And_Go_7IX_L','71',1,'SI_Silk_Charge_And_Go_7IX_L','NA','71',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Silk_Charge_And_Go_7IX_R','0',1,'SI_Silk_Charge_And_Go_7IX_R','NA','0',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Silk_Charge_And_Go_7IX_R','1',1,'SI_Silk_Charge_And_Go_7IX_R','NA','1',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Silk_Charge_And_Go_7IX_R','2',1,'SI_Silk_Charge_And_Go_7IX_R','NA','2',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Silk_Charge_And_Go_7IX_R','3',1,'SI_Silk_Charge_And_Go_7IX_R','NA','3',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Silk_Charge_And_Go_7IX_R','4',1,'SI_Silk_Charge_And_Go_7IX_R','NA','4',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'RECIEVER_SIZES','SI_Silk_Charge_And_Go_7IX_R','74',1,'SI_Silk_Charge_And_Go_7IX_R','NA','74',getdate(),'sballa',getdate(),'sballa'


--- BATTERY SIZES
select * from catalog.ItemMasterAttributeValues
where itemcode in (select itemcode from catalog.ItemMasterList where brandcode = 'Signia') and AttributeCode = 'BATTERY_SIZES'



insert into #ItemMasterAttributeValues
(AttributeCode
,Itemcode
,ModelAttributeValue
,IsActive
,VendorCode
,Modifier
,ModelAttributeValueDescription
,CreateDate
,CreateUser
,ModifyDate
,ModifyUser
)


select 'BATTERY_SIZES','SI_CROS_Pure_Charge_And_Go_IX','R',1,'SI_CROS_Pure_Charge_And_Go_IX','NA','R',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'BATTERY_SIZES','SI_CROS_Silk_Charge_And_Go_IX_L','R',1,'SI_CROS_Silk_Charge_And_Go_IX_L','NA','R',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'BATTERY_SIZES','SI_CROS_Silk_Charge_And_Go_IX_R','R',1,'SI_CROS_Silk_Charge_And_Go_IX_R','NA','R',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'BATTERY_SIZES','SI_Pure_Charge_And_Go_3IX','R',1,'SI_Pure_Charge_And_Go_3IX','NA','R',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'BATTERY_SIZES','SI_Pure_Charge_And_Go_5IX','R',1,'SI_Pure_Charge_And_Go_5IX','NA','R',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'BATTERY_SIZES','SI_Pure_Charge_And_Go_7IX','R',1,'SI_Pure_Charge_And_Go_7IX','NA','R',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'BATTERY_SIZES','SI_Pure_Charge_And_Go_T_3IX','R',1,'SI_Pure_Charge_And_Go_T_3IX','NA','R',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'BATTERY_SIZES','SI_Pure_Charge_And_Go_T_5IX','R',1,'SI_Pure_Charge_And_Go_T_5IX','NA','R',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'BATTERY_SIZES','SI_Pure_Charge_And_Go_T_7IX','R',1,'SI_Pure_Charge_And_Go_T_7IX','NA','R',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'BATTERY_SIZES','SI_Silk_Charge_And_Go_3IX_L','R',1,'SI_Silk_Charge_And_Go_3IX_L','NA','R',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'BATTERY_SIZES','SI_Silk_Charge_And_Go_3IX_R','R',1,'SI_Silk_Charge_And_Go_3IX_R','NA','R',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'BATTERY_SIZES','SI_Silk_Charge_And_Go_5IX_L','R',1,'SI_Silk_Charge_And_Go_5IX_L','NA','R',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'BATTERY_SIZES','SI_Silk_Charge_And_Go_5IX_R','R',1,'SI_Silk_Charge_And_Go_5IX_R','NA','R',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'BATTERY_SIZES','SI_Silk_Charge_And_Go_7IX_L','R',1,'SI_Silk_Charge_And_Go_7IX_L','NA','R',getdate(),'sballa',getdate(),'sballa' UNION ALL
select 'BATTERY_SIZES','SI_Silk_Charge_And_Go_7IX_R','R',1,'SI_Silk_Charge_And_Go_7IX_R','NA','R',getdate(),'sballa',getdate(),'sballa' 


select * from #ItemMasterAttributeValues


begin transaction catalog

rollback transaction catalog