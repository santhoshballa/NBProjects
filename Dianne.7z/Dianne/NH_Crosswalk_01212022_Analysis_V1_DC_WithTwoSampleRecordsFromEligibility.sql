/*
select top 10 * from Insurance.ContractProducts
select top 10 * from Insurance.HealthPlanContracts
select top 10 * from Insurance.HealthPlanContracts where HealthPlanContractID = 153
*/

select 'insurance.InsuranceHealthPlans' as TableName,  * from insurance.InsuranceHealthPlans where InsuranceHealthPlanID in (5358,5360,5359,5454)
select * from master.MemberInsurances where InsuranceHealthPlanID in (5358,5360,5359,5454)

select top 10 * from elig.BenefitCrossWalk
select top 10 * from elig.mstrEligBenefitData

select top 100 'Top 100 elig.BenefitCrossWalk' as TableName,GroupNbr, SubGroupNbr, BusinessCategory, ProductValueCode, LOB, ProductID from elig.BenefitCrossWalk
where 1=1
and GroupNBR in ('10000026','10000029','10000660')
and SubGroupNbr in ('1006')
and BusinessCategory in ('MA')
and ProductValueCode in ('HMO', 'PPO' )
and LOB in (1000, 4000)
and ProductID in ('MA000270','MA000271','MA000272','MA000273','MA000274','MA000276','MA000277','MA000278','MA000279','MA000280','MA000281','MAT00006')


-- Only 13 row are available 
select 'elig.BenefitCrossWalk' as TableName, SubGroupNbr, BusinessCategory, ProductValueCode, LOB, ProductID, * from elig.BenefitCrossWalk
where 1=1
and GroupNBR in ('10000026','10000029','10000660')
and SubGroupNbr in ('1006')
and BusinessCategory in ('MA')
and ProductValueCode in ('HMO', 'PPO' )
and LOB in (1000, 4000)
and ProductID in ('MA000270','MA000271','MA000272','MA000273','MA000274','MA000276','MA000277','MA000278','MA000279','MA000280','MA000281','MAT00006')

select * from information_schema.columns where column_name like '%ColumnValidation%'

select 'elig.mstrEligBenefitData' as TableName, * from elig.mstrEligBenefitData where 1=1 
and GroupNBR in ('10000026','10000029','10000660')
and SubGroupNbr in ('1006')
and BusinessCategory in ('MA')
and InsuranceLineCode in ('HMO', 'PPO' ) --and ProductValueCode in ('HMO', 'PPO' )
and LineOFBusiness in (1000, 4000)  --and LOB in (1000, 4000)
and ProductID in ('MA000270','MA000271','MA000272','MA000273','MA000274','MA000276','MA000277','MA000278','MA000279','MA000280','MA000281','MAT00006')
and insHealthPlanID in (5358,5360,5359,5454)

IF OBJECT_ID('tempdb..#TElig') IS NOT NULL DROP TABLE #TElig

create table #TElig 
(
sno int, 
insHealthPlanID nvarchar(30), 
GroupNBR nvarchar(30), 
SubGroupNbr nvarchar(30), 
BusinessCategory nvarchar(30), 
InsuranceLineCode nvarchar(30), 
LineOfBusiness nvarchar(30), 
ProductID nvarchar(30)
)


insert into #TElig (sno, insHealthPlanID, GroupNBR, SubGroupNbr, BusinessCategory, InsuranceLineCode, LineOfBusiness, ProductID) values (1,'5358','10000026','1006','MA','HMO','1000','MAT00006')
insert into #TElig (sno, insHealthPlanID, GroupNBR, SubGroupNbr, BusinessCategory, InsuranceLineCode, LineOfBusiness, ProductID) values (2,'5360','10000029','1006','MA','PPO','4000','MA000281')
insert into #TElig (sno, insHealthPlanID, GroupNBR, SubGroupNbr, BusinessCategory, InsuranceLineCode, LineOfBusiness, ProductID) values (3,'5360','10000660','1006','MA','PPO','4000','MA000281')
insert into #TElig (sno, insHealthPlanID, GroupNBR, SubGroupNbr, BusinessCategory, InsuranceLineCode, LineOfBusiness, ProductID) values (4,'5360','10000029','1006','MA','PPO','4000','MA000280')
insert into #TElig (sno, insHealthPlanID, GroupNBR, SubGroupNbr, BusinessCategory, InsuranceLineCode, LineOfBusiness, ProductID) values (5,'5360','10000029','1006','MA','PPO','4000','MA000279')
insert into #TElig (sno, insHealthPlanID, GroupNBR, SubGroupNbr, BusinessCategory, InsuranceLineCode, LineOfBusiness, ProductID) values (6,'5359','10000029','1006','MA','PPO','4000','MA000278')
insert into #TElig (sno, insHealthPlanID, GroupNBR, SubGroupNbr, BusinessCategory, InsuranceLineCode, LineOfBusiness, ProductID) values (7,'5360','10000026','1006','MA','HMO','1000','MA000277')
insert into #TElig (sno, insHealthPlanID, GroupNBR, SubGroupNbr, BusinessCategory, InsuranceLineCode, LineOfBusiness, ProductID) values (8,'5360','10000026','1006','MA','HMO','1000','MA000276')
insert into #TElig (sno, insHealthPlanID, GroupNBR, SubGroupNbr, BusinessCategory, InsuranceLineCode, LineOfBusiness, ProductID) values (9,'5454','10000026','1006','MA','HMO','1000','MA000274')
insert into #TElig (sno, insHealthPlanID, GroupNBR, SubGroupNbr, BusinessCategory, InsuranceLineCode, LineOfBusiness, ProductID) values (10,'5360','10000026','1006','MA','HMO','1000','MA000273')
insert into #TElig (sno, insHealthPlanID, GroupNBR, SubGroupNbr, BusinessCategory, InsuranceLineCode, LineOfBusiness, ProductID) values (11,'5454','10000026','1006','MA','HMO','1000','MA000272')
insert into #TElig (sno, insHealthPlanID, GroupNBR, SubGroupNbr, BusinessCategory, InsuranceLineCode, LineOfBusiness, ProductID) values (12,'5360','10000026','1006','MA','HMO','1000','MA000271')
insert into #TElig (sno, insHealthPlanID, GroupNBR, SubGroupNbr, BusinessCategory, InsuranceLineCode, LineOfBusiness, ProductID) values (13,'5359','10000026','1006','MA','HMO','1000','MA000270')


select top 2  b.* , a.* from elig.mstrEligBenefitData a left join #TElig b 
on (b.insHealthPlanID = a.insHealthPlanID and b.GroupNBR = a.GroupNbr and b.SubGroupNbr = a.SubGroupNbr and b.BusinessCategory =a.BusinessCategory and b.InsuranceLineCode = a.InsuranceLineCode and b.LineOfBusiness = a.LineOfBusiness and b.ProductID = a.ProductID)
where 1=1 and a.IsActive=1 and b.sno = 1
UNION
select top 2  b.* , a.* from elig.mstrEligBenefitData a left join #TElig b 
on (b.insHealthPlanID = a.insHealthPlanID and b.GroupNBR = a.GroupNbr and b.SubGroupNbr = a.SubGroupNbr and b.BusinessCategory =a.BusinessCategory and b.InsuranceLineCode = a.InsuranceLineCode and b.LineOfBusiness = a.LineOfBusiness and b.ProductID = a.ProductID)
where 1=1 and a.IsActive=1 and b.sno = 2
UNION
select top 2  b.* , a.* from elig.mstrEligBenefitData a left join #TElig b 
on (b.insHealthPlanID = a.insHealthPlanID and b.GroupNBR = a.GroupNbr and b.SubGroupNbr = a.SubGroupNbr and b.BusinessCategory =a.BusinessCategory and b.InsuranceLineCode = a.InsuranceLineCode and b.LineOfBusiness = a.LineOfBusiness and b.ProductID = a.ProductID)
where 1=1 and a.IsActive=1 and b.sno = 3
UNION
select top 2  b.* , a.* from elig.mstrEligBenefitData a left join #TElig b 
on (b.insHealthPlanID = a.insHealthPlanID and b.GroupNBR = a.GroupNbr and b.SubGroupNbr = a.SubGroupNbr and b.BusinessCategory =a.BusinessCategory and b.InsuranceLineCode = a.InsuranceLineCode and b.LineOfBusiness = a.LineOfBusiness and b.ProductID = a.ProductID)
where 1=1 and a.IsActive=1 and b.sno = 4
UNION
select top 2  b.* , a.* from elig.mstrEligBenefitData a left join #TElig b 
on (b.insHealthPlanID = a.insHealthPlanID and b.GroupNBR = a.GroupNbr and b.SubGroupNbr = a.SubGroupNbr and b.BusinessCategory =a.BusinessCategory and b.InsuranceLineCode = a.InsuranceLineCode and b.LineOfBusiness = a.LineOfBusiness and b.ProductID = a.ProductID)
where 1=1 and a.IsActive=1 and b.sno = 5
UNION
select top 2  b.* , a.* from elig.mstrEligBenefitData a left join #TElig b 
on (b.insHealthPlanID = a.insHealthPlanID and b.GroupNBR = a.GroupNbr and b.SubGroupNbr = a.SubGroupNbr and b.BusinessCategory =a.BusinessCategory and b.InsuranceLineCode = a.InsuranceLineCode and b.LineOfBusiness = a.LineOfBusiness and b.ProductID = a.ProductID)
where 1=1 and a.IsActive=1 and b.sno = 6
UNION
select top 2  b.* , a.* from elig.mstrEligBenefitData a left join #TElig b 
on (b.insHealthPlanID = a.insHealthPlanID and b.GroupNBR = a.GroupNbr and b.SubGroupNbr = a.SubGroupNbr and b.BusinessCategory =a.BusinessCategory and b.InsuranceLineCode = a.InsuranceLineCode and b.LineOfBusiness = a.LineOfBusiness and b.ProductID = a.ProductID)
where 1=1 and a.IsActive=1 and b.sno = 7
UNION
select top 2  b.* , a.* from elig.mstrEligBenefitData a left join #TElig b 
on (b.insHealthPlanID = a.insHealthPlanID and b.GroupNBR = a.GroupNbr and b.SubGroupNbr = a.SubGroupNbr and b.BusinessCategory =a.BusinessCategory and b.InsuranceLineCode = a.InsuranceLineCode and b.LineOfBusiness = a.LineOfBusiness and b.ProductID = a.ProductID)
where 1=1 and a.IsActive=1 and b.sno = 8
UNION
select top 2  b.* , a.* from elig.mstrEligBenefitData a left join #TElig b 
on (b.insHealthPlanID = a.insHealthPlanID and b.GroupNBR = a.GroupNbr and b.SubGroupNbr = a.SubGroupNbr and b.BusinessCategory =a.BusinessCategory and b.InsuranceLineCode = a.InsuranceLineCode and b.LineOfBusiness = a.LineOfBusiness and b.ProductID = a.ProductID)
where 1=1 and a.IsActive=1 and b.sno = 9
UNION
select top 2  b.* , a.* from elig.mstrEligBenefitData a left join #TElig b 
on (b.insHealthPlanID = a.insHealthPlanID and b.GroupNBR = a.GroupNbr and b.SubGroupNbr = a.SubGroupNbr and b.BusinessCategory =a.BusinessCategory and b.InsuranceLineCode = a.InsuranceLineCode and b.LineOfBusiness = a.LineOfBusiness and b.ProductID = a.ProductID)
where 1=1 and a.IsActive=1 and b.sno = 10
UNION
select top 2  b.* , a.* from elig.mstrEligBenefitData a left join #TElig b 
on (b.insHealthPlanID = a.insHealthPlanID and b.GroupNBR = a.GroupNbr and b.SubGroupNbr = a.SubGroupNbr and b.BusinessCategory =a.BusinessCategory and b.InsuranceLineCode = a.InsuranceLineCode and b.LineOfBusiness = a.LineOfBusiness and b.ProductID = a.ProductID)
where 1=1 and a.IsActive=1 and b.sno = 11
UNION
select top 2  b.* , a.* from elig.mstrEligBenefitData a left join #TElig b 
on (b.insHealthPlanID = a.insHealthPlanID and b.GroupNBR = a.GroupNbr and b.SubGroupNbr = a.SubGroupNbr and b.BusinessCategory =a.BusinessCategory and b.InsuranceLineCode = a.InsuranceLineCode and b.LineOfBusiness = a.LineOfBusiness and b.ProductID = a.ProductID)
where 1=1 and a.IsActive=1 and b.sno = 12
UNION
select top 2  b.* , a.* from elig.mstrEligBenefitData a left join #TElig b 
on (b.insHealthPlanID = a.insHealthPlanID and b.GroupNBR = a.GroupNbr and b.SubGroupNbr = a.SubGroupNbr and b.BusinessCategory =a.BusinessCategory and b.InsuranceLineCode = a.InsuranceLineCode and b.LineOfBusiness = a.LineOfBusiness and b.ProductID = a.ProductID)
where 1=1 and a.IsActive=1 and b.sno = 13
















