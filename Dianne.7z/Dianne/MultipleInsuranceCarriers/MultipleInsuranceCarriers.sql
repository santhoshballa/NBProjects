drop table #ActiveDups
-- Find all records that have the same FirstName, LastName, DOB, zipcode and address1 and are active and benefits are good
Select count(*) as DuplicateCnt, firstname,lastname,DOB,zipcode,address1 into  #ActiveDups
from elig.mstrEligBenefitData (nolock) where isactive=1 and BenefitEndDate>getdate() 
group by firstname,lastname,DOB,zipcode,address1
having count(*)>1

Select count(*) as DuplicateCnt, firstname,lastname,DOB,zipcode,address1 into  #ActiveDups1
from elig.mstrEligBenefitData (nolock) where isactive=1 and Getdate() between BenefitStartDate and BenefitEndDate
group by firstname,lastname,DOB,zipcode,address1
having count(*)>1


-- my scripts
select * from #ActiveDups where duplicateCnt > 4 order by dob, zipcode, address1, firstname, lastname 
select * from elig.mstrEligBenefitData where firstName = 'Jason' and Lastname = 'Plante' and isActive =1


-- Insurance CarrierID is not the same, but the Member Demographic information is similar
select count(*) as cnt,e.firstname,e.lastname,e.DOB,e.zipcode,e.address1, e.MasterMemberID,e.insCarrierID, ic.InsuranceCarrierName 
into #insdups
from #ActiveDups ad
join elig.mstrEligBenefitData (nolock) e on e.firstname=ad.FirstName and e.LastName=ad.LastName and e.dob=ad.dob and e.Address1=ad.Address1 and e.ZipCode=ad.ZipCode
join insurance.InsuranceCarriers ic on ic.InsuranceCarrierID=e.insCarrierID
where e.isactive=1 and e.BenefitEndDate>getdate() 
group by e.firstname,e.lastname,e.DOB,e.zipcode,e.address1,  e.MasterMemberID ,e.insCarrierID ,ic.InsuranceCarrierName
having count(*)=1  order by 2,3,4,5,6

--My Scripts
select * from elig.mstrEligBenefitData where FirstName = 'CHARLES' and LastName like 'WHARTON' and isActive =1 order by DataSource
select * from #insdups where FirstName = 'CHARLES' and LastName like 'WHARTON' 
select * from #insdups where FirstName = 'Jason' and LastName like 'Plante' 


select * into #uaw from #insdups where InsuranceCarrierName like '%UAW%'

select * from #uaw
select * from elig.mstrEligBenefitData where firstName = 'KEVIN' and Lastname = 'VEJNOVICH' and isActive =1

select ins.* into #UAWrecords 
from #insdups ins
join #uaw u on u.FirstName=ins.firstname 
and u.LastName=ins.LastName and u.Address1=ins.Address1
and u.DOB=ins.DOB and u.ZipCode=ins.ZipCode
order by  2,3,4,5,6

--select * from #UAWrecords order by 2,3,4,5,6

select * into #nonuaw 
from #insdups ins
where not exists ( select 1 from #uaw u  where ins.FirstName=u.FirstName and ins.LastName=u.LastName
and ins.Address1=u.Address1 and ins.DOB=u.dob and ins.ZipCode=u.ZipCode)
order by 2,3,4,5,6

select distinct  e.firstname, e.LastName,e.dob,e.Address1, e.ZipCode,e.BenefitStartDate,e.BenefitEndDate,inc.InsuranceCarrierName,e.insCarrierID,e.insHealthPlanID 
into #nuawdet from  #nonuaw nuaw 
join elig.mstrEligBenefitData (nolock) e on e.firstname=nuaw.FirstName 
and e.LastName=nuaw.LastName and e.dob=nuaw.dob and e.Address1=nuaw.Address1 and e.ZipCode=nuaw.ZipCode
join insurance.InsuranceCarriers inc on inc.InsuranceCarrierID=e.insCarrierID
where e.isactive=1 and e.BenefitEndDate>getdate() 
-- 

select * from #UAWrecords order by 2,3,4,5,6
Select * from #nonuaw order by 2,3,4,5,6


select * from (

select Firstname, lastname,dob, address1,zipcode, insCarrierID,
ROW_NUMBER() OVER (PARTITION BY  Firstname,lastname,dob, address1,zipcode order by Firstname,lastname,dob, address1,zipcode) as rowid
from elig.mstrEligBenefitData
where isActive =1 and getdate() between BenefitStartDate and BenefitEndDate
) a
where rowid > 3

select FirstName, LastName, dob, Address1, zipCode,insCarrierID from elig.mstrEligBenefitData where FirstName like 'Charlene' and LastName like 'Brissette' and Dob = '12-13-1943' and IsActive =1


-- Zero records Returned ( There are no records where a member has 5 accounts from 5 different carriers and are active
select 
a.MasterMemberID, a.FirstName, a.LastName, a.dob, a.Address1, a.zipcode, a.insCarrierID,
b.MasterMemberID, b.FirstName, b.LastName, b.dob, b.Address1, b.zipcode, b.insCarrierID,
c.MasterMemberID, c.FirstName, c.LastName, c.dob, c.Address1, c.zipcode, c.insCarrierID,
d.MasterMemberID, d.FirstName, d.LastName, d.dob, d.Address1, d.zipcode, d.insCarrierID,
e.MasterMemberID, e.FirstName, e.LastName, e.dob, e.Address1, e.zipcode, e.insCarrierID
from 
elig.mstrEligBenefitData a 
left join elig.mstrEligBenefitData b on ( a.FirstName = b.FirstName and a.LastName =  b.LastName and a.dob = b.dob and a.Address1 = b.Address1 and a.zipcode = b.zipcode and a.insCarrierID <> b.insCarrierID )
left join elig.mstrEligBenefitData c on ( b.FirstName = c.FirstName and b.LastName =  c.LastName and b.dob = c.dob and b.Address1 = c.Address1 and b.zipcode = c.zipcode and b.insCarrierID <> c.insCarrierID and a.insCarrierID <> c.insCarrierID )
left join elig.mstrEligBenefitData d on ( c.FirstName = d.FirstName and c.LastName =  d.LastName and c.dob = d.dob and c.Address1 = d.Address1 and c.zipcode = d.zipcode and c.insCarrierID <> d.insCarrierID and b.insCarrierID <> d.insCarrierID and a.insCarrierID <> d.insCarrierID  )
left join elig.mstrEligBenefitData e on ( d.FirstName = e.FirstName and d.LastName =  e.LastName and d.dob = e.dob and d.Address1 = e.Address1 and d.zipcode = e.zipcode and d.insCarrierID <> e.insCarrierID and a.insCarrierID <> e.insCarrierID and b.insCarrierID <> e.insCarrierID and c.insCarrierID <> e.insCarrierID )
where 1=1
and a.IsActive =1 and b.isActive = 1 and c.Isactive =1 and d.IsActive =1 and e.Isactive =1
and Getdate() between a.BenefitStartDate and a.BenefitEndDate
and Getdate() between b.BenefitStartDate and b.BenefitEndDate
and Getdate() between c.BenefitStartDate and c.BenefitEndDate
and Getdate() between d.BenefitStartDate and d.BenefitEndDate
and Getdate() between e.BenefitStartDate and e.BenefitEndDate


-- Zero records Returned ( There are no records where a member has 4 accounts from 4 different carriers and are active
select 
a.MasterMemberID, a.FirstName, a.LastName, a.dob, a.Address1, a.zipcode, a.insCarrierID,
b.MasterMemberID, b.FirstName, b.LastName, b.dob, b.Address1, b.zipcode, b.insCarrierID,
c.MasterMemberID, c.FirstName, c.LastName, c.dob, c.Address1, c.zipcode, c.insCarrierID,
d.MasterMemberID, d.FirstName, d.LastName, d.dob, d.Address1, d.zipcode, d.insCarrierID

from 
elig.mstrEligBenefitData a 
left join elig.mstrEligBenefitData b on ( a.FirstName = b.FirstName and a.LastName =  b.LastName and a.dob = b.dob and a.Address1 = b.Address1 and a.zipcode = b.zipcode and a.insCarrierID <> b.insCarrierID )
left join elig.mstrEligBenefitData c on ( b.FirstName = c.FirstName and b.LastName =  c.LastName and b.dob = c.dob and b.Address1 = c.Address1 and b.zipcode = c.zipcode and b.insCarrierID <> c.insCarrierID and a.insCarrierID <> c.insCarrierID )
left join elig.mstrEligBenefitData d on ( c.FirstName = d.FirstName and c.LastName =  d.LastName and c.dob = d.dob and c.Address1 = d.Address1 and c.zipcode = d.zipcode and c.insCarrierID <> d.insCarrierID and b.insCarrierID <> d.insCarrierID and a.insCarrierID <> d.insCarrierID  )
where 1=1
and a.IsActive =1 and b.isActive = 1 and c.Isactive =1 and d.IsActive =1 
and Getdate() between a.BenefitStartDate and a.BenefitEndDate
and Getdate() between b.BenefitStartDate and b.BenefitEndDate
and Getdate() between c.BenefitStartDate and c.BenefitEndDate
and Getdate() between d.BenefitStartDate and d.BenefitEndDate


-- 66 records, Returned ( There are 66 records where a member has 3 accounts from 3 different carriers and are active, There are only 11 distinct records

select 
a.MasterMemberID AMasterMemberID  , a.FirstName AFirstName, a.LastName ALastName, a.dob Adob, a.Address1 AAddress1, a.zipcode Azipcode, a.insCarrierID AinsCarrierID,
b.MasterMemberID BMasterMemberID  , b.FirstName BFirstName, b.LastName BLastName, b.dob Bdob, b.Address1 BAddress1, b.zipcode Bzipcode, b.insCarrierID BinsCarrierID,
c.MasterMemberID CMasterMemberID  , c.FirstName CFirstName, c.LastName CLastName, c.dob Cdob, c.Address1 CAddress1, c.zipcode Czipcode, c.insCarrierID CinsCarrierID

from 
elig.mstrEligBenefitData a 
join elig.mstrEligBenefitData b on ( a.FirstName = b.FirstName and a.LastName =  b.LastName and a.dob = b.dob and a.Address1 = b.Address1 and a.zipcode = b.zipcode and a.insCarrierID <> b.insCarrierID )
join elig.mstrEligBenefitData c on ( b.FirstName = c.FirstName and b.LastName =  c.LastName and b.dob = c.dob and b.Address1 = c.Address1 and b.zipcode = c.zipcode and b.insCarrierID <> c.insCarrierID and a.insCarrierID <> c.insCarrierID )
where 1=1
and a.IsActive =1 and b.isActive = 1 and c.Isactive =1 
and Getdate() between a.BenefitStartDate and a.BenefitEndDate
and Getdate() between b.BenefitStartDate and b.BenefitEndDate
and Getdate() between c.BenefitStartDate and c.BenefitEndDate




-- 11 records, ( 11 members have 3 active records with 3 insurance carriers
select * from (
select 
a.MasterMemberID AMasterMemberID  , a.FirstName AFirstName, a.LastName ALastName, a.dob Adob, a.Address1 AAddress1, a.zipcode Azipcode, a.insCarrierID AinsCarrierID,
b.MasterMemberID BMasterMemberID  , b.FirstName BFirstName, b.LastName BLastName, b.dob Bdob, b.Address1 BAddress1, b.zipcode Bzipcode, b.insCarrierID BinsCarrierID,
c.MasterMemberID CMasterMemberID  , c.FirstName CFirstName, c.LastName CLastName, c.dob Cdob, c.Address1 CAddress1, c.zipcode Czipcode, c.insCarrierID CinsCarrierID,
row_number() over (PARTITION BY  a.Firstname,a.lastname,a.dob, a.Address1, a.ZipCode order by  a.Firstname,a.lastname,a.dob, a.Address1, a.ZipCode) as rowid_RowNumber
from 
elig.mstrEligBenefitData a 
join elig.mstrEligBenefitData b on ( a.FirstName = b.FirstName and a.LastName =  b.LastName and a.dob = b.dob and a.Address1 = b.Address1 and a.zipcode = b.zipcode and a.insCarrierID <> b.insCarrierID )
join elig.mstrEligBenefitData c on ( b.FirstName = c.FirstName and b.LastName =  c.LastName and b.dob = c.dob and b.Address1 = c.Address1 and b.zipcode = c.zipcode and b.insCarrierID <> c.insCarrierID and a.insCarrierID <> c.insCarrierID )
where 1=1
and a.IsActive =1 and b.isActive = 1 and c.Isactive =1 
and Getdate() between a.BenefitStartDate and a.BenefitEndDate
and Getdate() between b.BenefitStartDate and b.BenefitEndDate
and Getdate() between c.BenefitStartDate and c.BenefitEndDate
) a
where a.rowid_RowNumber =1


--Members having two accounts that are active and are from two different carriers, 23085 records

select * into #TDuplicate from (
select 
a.MasterMemberID AMasterMemberID  , a.FirstName AFirstName, a.LastName ALastName, a.dob Adob, a.Address1 AAddress1, a.zipcode Azipcode, a.insCarrierID AinsCarrierID,
b.MasterMemberID BMasterMemberID  , b.FirstName BFirstName, b.LastName BLastName, b.dob Bdob, b.Address1 BAddress1, b.zipcode Bzipcode, b.insCarrierID BinsCarrierID,
row_number() over (PARTITION BY  a.Firstname,a.lastname,a.dob, a.Address1, a.ZipCode order by  a.Firstname,a.lastname,a.dob, a.Address1, a.ZipCode) as rowid_RowNumber
from 
elig.mstrEligBenefitData a 
join elig.mstrEligBenefitData b on ( a.FirstName = b.FirstName and a.LastName =  b.LastName and a.dob = b.dob and a.Address1 = b.Address1 and a.zipcode = b.zipcode and a.insCarrierID <> b.insCarrierID )
where 1=1
and a.IsActive =1 and b.isActive = 1 
and Getdate() between a.BenefitStartDate and a.BenefitEndDate
and Getdate() between b.BenefitStartDate and b.BenefitEndDate
) a
where a.rowid_RowNumber =1



select * into #TDuplicate from (
select 
a.MasterMemberID AMasterMemberID  , a.FirstName AFirstName, a.LastName ALastName, a.dob Adob, a.Address1 AAddress1, a.zipcode Azipcode, a.insCarrierID AinsCarrierID,
b.MasterMemberID BMasterMemberID  , b.FirstName BFirstName, b.LastName BLastName, b.dob Bdob, b.Address1 BAddress1, b.zipcode Bzipcode, b.insCarrierID BinsCarrierID,
row_number() over (PARTITION BY  a.Firstname,a.lastname,a.dob, a.Address1, a.ZipCode order by  a.Firstname,a.lastname,a.dob, a.Address1, a.ZipCode) as rowid_RowNumber
from 
elig.mstrEligBenefitData a 
join elig.mstrEligBenefitData b on ( a.FirstName = b.FirstName and a.LastName =  b.LastName and a.dob = b.dob and a.Address1 = b.Address1 and a.zipcode = b.zipcode and a.insCarrierID <> b.insCarrierID )
where 1=1
and a.IsActive =1 and b.isActive = 1 
and Getdate() between a.BenefitStartDate and a.BenefitEndDate
and Getdate() between b.BenefitStartDate and b.BenefitEndDate
) a
where a.rowid_RowNumber =1

select * from  #TDuplicate where AinsCarrierID in (277,254) or BinsCarrierID in (277,254)

select * from insurance.insuranceCarriers where InsuranceCarrierID in (277,16)