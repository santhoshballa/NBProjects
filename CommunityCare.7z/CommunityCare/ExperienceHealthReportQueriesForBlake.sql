-- Experience Health | The SQL queries to generate the report for Blake.

-- Step 1 | Members Enrolled, Total Hours Utilized and Hours per enrolled member YTD
-- UnPivot Members Enrolled, Total Hours Utilized and Hours per enrolled member YTD
select 
'Member Enrolled' as SummaryYTD, MembersEnrolled as Count from 
(

select count(MemberID) as MembersEnrolled,  round(sum(Hours),2) as TotalHoursUtilized, round((sum(Hours)/cast(count(MemberID) as float)),2) as HoursPerEnrolledMemberYTD 
from (
	  select MemberID, sum(cast(hours as float)) as Hours from dbo.MemberLevelBreakDownMain
	  group by MemberID
	 ) a
) a

UNION


select 
'Total Hours Utilized' as SummaryYTD, TotalHoursUtilized as Count from 
(

select count(MemberID) as MembersEnrolled,  round(sum(Hours),2) as TotalHoursUtilized, round((sum(Hours)/cast(count(MemberID) as float)),2) as HoursPerEnrolledMemberYTD 
from (
	  select MemberID, sum(cast(hours as float)) as Hours from dbo.MemberLevelBreakDownMain
	  group by MemberID
	 ) a
) a

UNION

select 
'Hours Per Enrolled Member YTD' as SummaryYTD, HoursPerEnrolledMemberYTD as Count from 
(

select count(MemberID) as MembersEnrolled,  round(sum(Hours),2) as TotalHoursUtilized, round((sum(Hours)/cast(count(MemberID) as float)),2) as HoursPerEnrolledMemberYTD 
from (
	  select MemberID, sum(cast(hours as float)) as Hours from dbo.MemberLevelBreakDownMain
	  group by MemberID
	 ) a
) a


-- Step 2 | Consultation Vs In Person Visit
select ConsultationInPerson as VisitType, 
[1] as January, [2] as February, [3] as March, [4] as April, [5] as May, [6] as June, [7] as July, [8] as August, [9] as September, [10] as October, [11] as November, [12] as December
from
(select month(DateOfVisit) as DateOfVisit, (case when Virtual like '%yes%' then 'Consultation/Virtual' else 'In-Person Visit' end ) as ConsultationInPerson
from dbo.MemberLevelBreakDownMain ) p
pivot
(
count(DateOfVisit)
for DateofVisit in ([1],[2],[3],[4],[5],[6],[7],[8],[9],[10],[11],[12])
) as pvt


-- Step 3 | Tasks Accomplished
select Tasks as TaskType, sum(TasksCount) as Amount from 
(
select VisitID, DateOfVisit, 'Companionship' as Tasks, 1 as TasksCount from dbo.MemberLevelBreakDownMain  where Companionship =1
union
select VisitID, DateOfVisit, 'HouseTasks' as Tasks, 1 as TasksCount from dbo.MemberLevelBreakDownMain  where HouseTasks =1
union
select VisitID, DateOfVisit, 'Transportation' as Tasks, 1 as TasksCount from dbo.MemberLevelBreakDownMain  where Transportation =1
union
select VisitID, DateOfVisit, 'DrVisits' as Tasks, 1 as TasksCount from dbo.MemberLevelBreakDownMain  where DrVisits =1
union
select VisitID, DateOfVisit, 'TechHelp' as Tasks, 1 as TasksCount from dbo.MemberLevelBreakDownMain  where TechHelp =1
union
select VisitID, DateOfVisit, 'GroceryShopping' as Tasks, 1 as TasksCount from dbo.MemberLevelBreakDownMain  where GroceryShopping =1
union
select VisitID, DateOfVisit, 'PetHelp' as Tasks, 1 as TasksCount from dbo.MemberLevelBreakDownMain   where PetHelp =1
union
select VisitID, DateOfVisit, 'RunErrands' as Tasks, 1 as TasksCount from dbo.MemberLevelBreakDownMain  where RunErrands =1
union
select VisitID, DateOfVisit, 'Exercise' as Tasks, 1 as TasksCount from dbo.MemberLevelBreakDownMain  where Exercise =1
union
select VisitID, DateOfVisit, 'MedicationRX' as Tasks, 1 as TasksCount from dbo.MemberLevelBreakDownMain  where MedicationRX =1
) a

group by Tasks
Order by 2 desc


-- Step 4 | Locations of Visits YTD
select City, Count(*) as NoOfVisitsPerCity from dbo.MemberLevelBreakDownMain
group by City

-- Step 5 | Enrolled Members, Count of Visits
select 
(FirstName + ' ' + LastName) as Name,MemberID ,Count(MemberID) as MemberCount
from dbo.MemberLevelBreakDownMain
group by (FirstName + ' ' + LastName),MemberID

