/****** Object:  StoredProcedure [elig].[sp_Eligibility_PAPA_file]    Script Date: 10/21/2021 1:47:41 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



--exec [elig].[sp_Eligibility_PAPA_file] 'ELIG_PPHP',NULL  --'ELIG_PPHP'-- 'ELIG_EXPH'
CREATE PROCEDURE [elig].[sp_Eligibility_PAPA_file] (@DataSource varchar(20),@HealthPlanID varchar(5))

AS
BEGIN


select 0 as fororder, 'Header' as fororderdesc,
'SERVICE' +'|'+ 'ORGANIZATION' +'|'+ 'BUSINESS' +'|'+ 'BUSINESS_TYPE' +'|'+ 'MEMBER_ID' +'|'+ 'RELATIONSHIP' +'|'+ 'FIRST_NAME' +'|'+'MIDDLE_INITIAL' +'|'+ 
'LAST_NAME' +'|'+ 'DOB' +'|'+ 'GENDER' +'|'+ 'ADDRESS_LN_1' +'|'+ 'ADDRESS_LN_2' +'|'+'CITY' +'|'+ 'STATE' +'|'+ 'ZIP' +'|'+ 'COUNTY' +'|'+'PHONE_1' +'|'+ 'PHONE_2' +'|'+'PHONE_3' +'|'+ 
'PHONE_4' +'|'+ 'EMAIL' +'|'+ 'METRO_AREA' +'|'+ 'LANGUAGE' +'|'+ 'RACE' +'|'+ 'ETHNICITY' +'|'+ 'HEARING_IMPAIRED' +'|'+ 'VISUALLY_IMPAIRED' +'|'+'WHEELCHAIR-BOUND' +'|'+ 'PCP_NAME' +'|'+ 'PCP_ADDRESS' +'|'+ 'PCP_CITY' +'|'+ 
'PCP_STATE' +'|'+ 'PCP_ZIP' +'|'+ 'PCP_PHONE' +'|'+'HEALTH_PLAN' +'|'+ 'PLAN_TYPE' +'|'+ 'PLAN_ID' +'|'+'PLAN_PHONE' +'|'+ 'PBP'+'|'+'SUBSCRIBER_ID'+'|'+ 'LINE_OF_BUSINESS'   +'|'+ 
'BENEFIT_DATE_ACTIVE'+'|'+'BENEFIT_DATE_INACTIVE'+'|'+ 'BENEFITPLANCODE'    +'|'+ 'COUNTY_CODE'+'|'+'DNC_IND'+'|'+ 'EMPLOYEE_PLAN_NAME'  +'|'+ 'MAIN_GROUP_NAME'+'|'+'MAIN_GROUP_NO'+'|'+ 'INS_GROUP_ID'    +'|'+ 
'MEDICARE_NUM'+'|'+'BARCODE_ID'+'|'+ 'STROKE'    +'|'+ 'CANCER'+'|'+'DIABETES'+'|'+ 'HEART_DISEASE'  +'|'+ 'HYPERTENSION'+'|'+'ALZHEIMERS_DISEASE'+'|'+ 'KIDNEY_DISEASE'  +'|'+ 
'PHYS_HEALTH_MGMT'+'|'+'MENTAL_HEALTH_MGMT'+'|'+ 'SP_NEEDS_PLAN_CARE_MGMT'  +'|'+ 'RHEUM_ARTHRITIS_MGMT'+'|'+'OSTEOPOROSIS_MGMT_WOMEN'+'|'+ 'MONITOR_PHYS_ACTIVITY'  +'|'+ 
'AWV'+'|'+'HRA'+'|'+ 'BMI_ASSESSMENT'+'|'+ 'FUNC_STATUS_ASSESSMENT'+'|'+'PAIN_ASSESSMENT'+'|'+ 'DIABETES_EYE_EXAM' +'|'+ 
'DIABETES_KIDNEY_FUNCTION'+'|'+'DIABETES_A1C'+'|'+ 'DIABETES_NEPHROPATHY_TEST'+'|'+ 'DIABETES_STATIN'+'|'+'HEART_DISEASE_STATIN'+'|'+ 'MED_REVIEW' +'|'+ 
'MED_ADHERENCE_DIABETES'+'|'+'MED_ADHERENCE_HYPERTENSION'+'|'+ 'MED_ADHERENCE_CHOLESTEROL'+'|'+ 'MED_REC_POST-DISCHARGE'+'|'+'BREAST_CANCER_SCREENING'+'|'+ 'COLORECTAL_CANCER_SCREENING' +'|'+ 
'CERVICAL_CANCER_SCREENING'+'|'+'DEPRESSION_SCREENING'+'|'+ 'SUBSTANCE_ABUSE'+'|'+ 'FLU_VACCINE'+'|'+'DENTAL_VISIT'+'|'+ 'CAHPS' +'|'+ 
'BLADDER_CONTROL_MGMT'+'|'+'FALL_RISK_MGMT'+'|'+ 'FREQUENT_ER'+'|'+ 'NUM_ER_VISITS'+'|'+'RECENT_IP_OBS'+'|'+ 'NUM_IP_STAYS'+'|'+ 
'PCP_SPC_ELIGIBLE'+'|'+'PPC_PRENATAL'+'|'+ 'PPC_POSTPARTUM'+'|'+ 'CHILD_IMMUNIZATIONS'+'|'+'ADOLESC_IMMUNIZATIONS'+'|'+ 'LEAD_SCREENING'+'|'+'CHILD_ADOLESC_VISIT'+'|'+ 'CHLAMYDIA_SCREENING'
as Outputtext
union
select  DISTINCT TOP(10) 1 as fororder, 'Data' as fororderdesc,
'1' --SERVICE
+'|'+'Nations Benefit' --ORGANIZATION
+'|'+ isnull(cc.ClientName,'') --BUSINESS
+'|'+  'Health Plan' -- Business_Type
--+'|'+ CAST(isnull(MSTR.[MASTERMEMBERID],'') AS VARCHAR(10)) --MEMBER_ID
+'|'+ isnull(mem.[NHMemberID],'') --MEMBER_ID
+'|'+ 'Self' -- RELATIONSHIP ?? 
+'|'+ isnull(MSTR.FirstName,'') -- FIRST_NAME
+'|'+ LEFT(isnull(mstr.MiddleInitial,''),2) --MIDDLE_INITIAL
+'|'+ isnull(mstr.LastName,'') --LAST_NAME
+'|'+isnull(convert(varchar, mstr.DOB, 23),'')--DOB
+'|'+ isnull(MSTR.Gender,'') -- GENDER
+'|'+ isnull(MSTR.Address1,'') -- ADDRESS_LN_1
+'|'+ isnull(MSTR.Address2,'') -- ADDRESS_LN_2
+'|'+ isnull(MSTR.CITY,'') -- CITY
+'|'+ LEFT(isnull(MSTR.STATE,''),2) -- STATE
+'|'+ isnull(MSTR.ZIPcode,'') -- ZIP
+'|'+ '' -- COUNTY ??
+'|'+ cast(ISNULL(NULLIF(MSTR.HOMEPHONENBR, ''), 'NA') as varchar(10)) -- PHONE_1
+'|'+ cast(isnull(MSTR.[OtherPhoneNbr],'')  as varchar(10))-- PHONE_2
+'|'+ '' --  PHONE_3 ??
+'|'+ '' --  PHONE_4 ??
+'|'+ISNULL(NULLIF(MSTR.[MemberEmail], ''), 'NA') --  EMAIL ??
--+'|'+ CASE WHEN ISNULL(MSTR.[MemberEmail],'')='' THEN 'NA' ELSE Mstr.[MemberEmail] END [MemberEmail]
--+'|'+ isnull(MSTR.[MemberEmail],'NA') --  EMAIL ??
+'|'+ '' --  METRO_AREA
+'|'+ ISNULL(NULLIF(MSTR.LANGUAGE, ''), 'NA') --  LANGUAGE ??
+'|'+ '' --  RACE
+'|'+ '' -- ETHNICITY
+'|'+ '' -- HEARING_IMPAIRED
+'|'+ '' -- VISUALLY_IMPAIRED
+'|'+ '' --WHEELCHAIR-BOUND
+'|'+ isnull(MSTR.[PCPName],'') --  PCP_NAME ??
+'|'+ isnull(MSTR.[PCPAddress1],'') --  PCP_ADDRESS ??
+'|'+ isnull(MSTR.[PCPCity],'')--PCP_CITY
+'|'+ LEFT(isnull(MSTR.[PCPState],''),2)--PCP_STATE
+'|'+ isnull(MSTR.[PCPZipCode],'')--PCP_ZIP
+'|'+ cast(isnull(MSTR.[PCPBusinessPhone],'') as varchar(10)) --PCP_PHONE
+'|'+ ISNULL(NULLIF(HP.[HealthPlanName], ''), 'NA') --HEALTH_PLAN
+'|'+ ISNULL(NULLIF(MSTR.PBPID, ''), 'NA') --PLAN_TYPE ???
+'|'+ ISNULL(NULLIF(HP.[HealthPlanNumber], ''), 'NA') --PLAN_ID ???
+'|'+ '' --PLAN_PHONE
+'|'+ isnull(MSTR.PBPID,'')--PBP ??
+'|'+ isnull(MSTR.SubscriberID,'')--SUBSCRIBER_ID
+'|'+ isnull(MSTR.LineOfBusiness,'')---LINE_OF_BUSINESS
+'|'+isnull(convert(varchar, mstr.BenefitStartDate, 23),'')---BENEFIT_DATE_ACTIVE
+'|'+isnull(convert(varchar, mstr.BenefitEndDate, 23),'')---BENEFIT_DATE_INACTIVE
+'|'+ '' --BENEFITPLANCODE
+'|'+ '' --COUNTY_CODE
+'|'+ '' --DNC_IND
+'|'+ ''--EMPLOYEE_PLAN_NAME ??
+'|'+ ''--MAIN_GROUP_NAME?
+'|'+ ''--MAIN_GROUP_NO ?
+'|'+ isnull(MSTR.GroupNbr,'')--INS_GROUP_ID
+'|'+ isnull(MSTR.MedicareID,'')--MEDICARE_NUM
+'|'+ ''--BARCODE_ID
+'|'+ ''--STROKE
+'|'+ ''--CANCER
+'|'+ ''--DIABETES
+'|'+ ''--HEART_DISEASE
+'|'+ ''--HYPERTENSION
+'|'+ ''--ALZHEIMERS_DISEASE
+'|'+ ''--KIDNEY_DISEASE
+'|'+ ''--PHYS_HEALTH_MGMT
+'|'+ ''--MENTAL_HEALTH_MGMT
+'|'+ ''--SP_NEEDS_PLAN_CARE_MGMT
+'|'+ ''--RHEUM_ARTHRITIS_MGMT
+'|'+ ''--OSTEOPOROSIS_MGMT_WOMEN
+'|'+ ''--MONITOR_PHYS_ACTIVITY
+'|'+ ''--AWV
+'|'+ ''--HRA
+'|'+ ''--BMI_ASSESSMENT
+'|'+ ''--FUNC_STATUS_ASSESSMENT
+'|'+ ''--PAIN_ASSESSMENT
+'|'+ ''--DIABETES_EYE_EXAM
+'|'+ ''--DIABETES_KIDNEY_FUNCTION
+'|'+ ''--DIABETES_A1C
+'|'+ ''--DIABETES_NEPHROPATHY_TEST
+'|'+ ''--DIABETES_STATIN
+'|'+ ''--HEART_DISEASE_STATIN
+'|'+ ''--MED_REVIEW
+'|'+ ''--MED_ADHERENCE_DIABETES
+'|'+ ''--MED_ADHERENCE_HYPERTENSION
+'|'+ ''--MED_ADHERENCE_CHOLESTEROL
+'|'+ ''--MED_REC_POST-DISCHARGE
+'|'+ ''--BREAST_CANCER_SCREENING
+'|'+ ''--COLORECTAL_CANCER_SCREENING
+'|'+ ''--CERVICAL_CANCER_SCREENING
+'|'+ ''--DEPRESSION_SCREENING
+'|'+ ''--SUBSTANCE_ABUSE
+'|'+ ''--FLU_VACCINE
+'|'+ ''--DENTAL_VISIT
+'|'+ ''--CAHPS
+'|'+ ''--BLADDER_CONTROL_MGMT
+'|'+ ''--FALL_RISK_MGMT
+'|'+ ''--FREQUENT_ER
+'|'+ ''--NUM_ER_VISITS
+'|'+ ''--RECENT_IP_OBS
+'|'+ ''--NUM_IP_STAYS
+'|'+ ''--PCP_SPC_ELIGIBLE
+'|'+ ''--PPC_PRENATAL
+'|'+ ''--PPC_POSTPARTUM
+'|'+ ''--CHILD_IMMUNIZATIONS
+'|'+ ''--ADOLESC_IMMUNIZATIONS
+'|'+ ''--LEAD_SCREENING
+'|'+ ''--CHILD_ADOLESC_VISIT
+'|'+ ''--CHLAMYDIA_SCREENING
as Outputtext
FROM [elig].[mstrEligBenefitData] MSTR WITH (NOLOCK)
  join [elig].[PAPA_ClientCodes] cc WITH (NOLOCK)
  on MSTR.DataSource=cc.DataSource 
  join Insurance.InsuranceHealthPlans hp WITH (NOLOCK)
  on hp.InsuranceHealthPlanID=mstr.insHealthPlanID
  join [Master].[Members] mem WITH (NOLOCK)
  on mem.memberid=mstr.mastermemberid
 where 1=1 
       and cc.DATASOURCE = @DataSource
	   and ((@HealthPlanID IS NULL) OR (cc.insHealthPlanID IN ( SELECT  splitdata FROM  [elig].[fnSplitString](@HealthPlanID, ','))))
       and MSTR.isActive = 1
       AND CAST(GETDATE() AT TIME ZONE 'UTC' AT TIME ZONE 'Eastern Standard Time' AS DATE) BETWEEN MSTR.RecordEffDate AND MSTR.RecordEndDate
       AND (CAST(GETDATE() AT TIME ZONE 'UTC' AT TIME ZONE 'Eastern Standard Time' AS DATE) BETWEEN MSTR.BenefitStartDate AND MSTR.BenefitEndDate
       OR (MSTR.BenefitStartDate > CAST(GETDATE() AT TIME ZONE 'UTC' AT TIME ZONE 'Eastern Standard Time' AS DATE) AND MSTR.BenefitEndDate > MSTR.BenefitStartDate))
	  
END
GO


