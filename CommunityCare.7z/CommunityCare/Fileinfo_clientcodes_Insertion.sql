
-- Client Codes
insert into elig.ClientCodes (ClientCode,ClientName,DataSource,isActive)
select 'H483','PAPA','ELIG_PAPA',1


--- FTP
insert into elig.FTPUserInfo (ClientCode,HostAddress,Port,UserID,Password,WinSCPLoginName,ContactPerson,ContactPhoneNbr,isActive,FileType)
select 'H483' as ClientCode,HostAddress,Port,'Papa_nations' as UserID,Password, WinSCPLoginName,ContactPerson,ContactPhoneNbr,isActive,'ELIG_PAPA_H376' FileType
from elig.FTPUserInfo --where ClientCode ='H000_IN'
where 1=1
and FtpID = 35
union
select 'H483' as ClientCode,HostAddress+'2',Port,'Papa_nations' as UserID,Password, WinSCPLoginName,ContactPerson,ContactPhoneNbr,isActive,'ELIG_PAPA_H343' FileType
from elig.FTPUserInfo --where ClientCode ='H000_IN'
where 1=1
and FtpID = 35
union
select 'H483' as ClientCode,HostAddress+'3',Port,'Papa_nations' as UserID,Password, WinSCPLoginName,ContactPerson,ContactPhoneNbr,isActive,'ELIG_PAPA_H453' FileType
from elig.FTPUserInfo --where ClientCode ='H000_IN'
where 1=1
and FtpID = 35




Select 'H483' as InClientCode,
fi.ClientCode,
replace(fi.FileName,'yyyymmddhhmmss',cast(format(CONVERT(datetime, SWITCHOFFSET(getdate(), DATEPART(TZOFFSET,getdate() AT TIME ZONE 'Eastern Standard Time'))),'yyyyMMddHHmmss') as varchar(16))) +'.'+fi.fileExtension as Outfilename,
fi.fileExtension,
fi.FromLocation,
fi.ToLocation,
fi.DataSource,
ftp.WinSCPLoginName
from elig.fileinfo fi
join elig.FTPUserInfo ftp on fi.ClientCode = ftp.ClientCode and fi.FileType = ftp.FileType
where 1=1
and fi.ClientCode = 'H483'
and fi.DataSource= 'ELIG_PPHP'
and fi.filetype = 'ELIG_PAPA_H343'
and fi.Direction ='OUT'


SELECT * FROM elig.ClientCodes
WHERE ClientCode='H483'


SELECT * FROM elig.FTPUserInfo
WHERE ClientCode='H483'


SELECT * FROM elig.fileinfo
WHERE ClientCode='H483'


Update elig.FileInfo
set FromLocation ='C:\NHEligJobs\PAPA\DAT\OUT'
where ClientCode='H483'


SELECT COUNT(*) FROM [elig].[mstrEligBenefitData] MSTR WITH (NOLOCK)
  join [elig].[PAPA_ClientCodes] cc WITH (NOLOCK)
  on MSTR.DataSource=cc.DataSource 
  join Insurance.InsuranceHealthPlans hp WITH (NOLOCK)
  on hp.InsuranceHealthPlanID=mstr.insHealthPlanID
  --join [Master].[Members] mem WITH (NOLOCK)
  --on mem.memberid=mstr.mastermemberid
 where 1=1 
       and cc.DATASOURCE = 'ELIG_HAP'
	  -- and (cc.insHealthPlanID IN ( SELECT  splitdata FROM  [elig].[fnSplitString](@HealthPlanID, ',')))
       and MSTR.isActive = 1
       AND CAST(GETDATE() AT TIME ZONE 'UTC' AT TIME ZONE 'Eastern Standard Time' AS DATE) BETWEEN MSTR.RecordEffDate AND MSTR.RecordEndDate
       AND (CAST(GETDATE() AT TIME ZONE 'UTC' AT TIME ZONE 'Eastern Standard Time' AS DATE) BETWEEN MSTR.BenefitStartDate AND MSTR.BenefitEndDate
       OR (MSTR.BenefitStartDate > CAST(GETDATE() AT TIME ZONE 'UTC' AT TIME ZONE 'Eastern Standard Time' AS DATE) AND MSTR.BenefitEndDate > MSTR.BenefitStartDate))







	   Select  
replace(replace(fi.FileName,'YYYYMMDD',cast(format(CONVERT(datetime, SWITCHOFFSET(getdate(), DATEPART(TZOFFSET,getdate() AT TIME ZONE 'Eastern Standard Time'))),'yyyyMMdd') as varchar(16))),'HHmm',cast(format(CONVERT(datetime, SWITCHOFFSET(getdate(), DATEPART(TZOFFSET,getdate() AT TIME ZONE 'Eastern Standard Time'))),'HHmm') as varchar(16))  ) +'.'+fi.fileExtension as Outfilename,
 fi.FromLocation,
 fi.ToLocation,
 fi.DataSource,
 ftp.WinSCPLoginName

from elig.fileinfo fi 
join elig.FTPUserInfo ftp 
on fi.ClientCode = ftp.ClientCode
and fi.filetype=ftp.filetype
where 1=1
and fi.ClientCode = 'h483'
AND Fi.SnapshotFlag ='FULL'
and fi.filetype like 'ELIG_PAPA_%'
and fi.Direction ='OUT'



SELECT TOP(10) * FROM ELIG.mstrEligBenefitData
WHERE DataSource='ELIG_EXPH'