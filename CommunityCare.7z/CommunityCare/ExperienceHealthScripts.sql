select * from dbo.MemberLevelBreakDown

select distinct VisitID from dbo.MemberLevelBreakDown


select 
'select top 10 ' + ''''+ '[' + table_schema+  '.' + table_name + ']' + ''''+ ' as TableName' + ', * from ' + table_schema + '.' +table_name 
from information_schema.TABLES 
where TABLE_SCHEMA like 'dbo' and table_name like '%MemberLevelBreakDown%'

select top 10 '[dbo.MemberLevelBreakDown]' as TableName, * from dbo.MemberLevelBreakDown



select 
Column_name+',' from information_schema.columns where TABLE_SCHEMA like 'dbo' and table_name like '%MemberLevelBreakDown%'



/****** Object:  Table [dbo].[MemberLevelBreakDown$]    Script Date: 7/13/2022 4:00:24 PM ******/

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[MemberLevelBreakDown](
	[VisitID] [nvarchar](255) NULL,
	[Virtual] [nvarchar](255) NULL,
	[GroceryDelivery] [nvarchar](255) NULL,
	[RDMedicationsDelivery] [nvarchar](255) NULL,
	[MemberID] [nvarchar](255) NULL,
	[FirstName] [nvarchar](255) NULL,
	[LastName] [nvarchar](255) NULL,
	[DOB] [nvarchar] (255)NULL,
	[Gender] [nvarchar](255) NULL,
	[Phone] [nvarchar] (255)NULL,
	[Address1] [nvarchar](255) NULL,
	[Address2] [nvarchar](255) NULL,
	[City] [nvarchar](255) NULL,
	[State] [nvarchar](255) NULL,
	[Zip] [nvarchar] (255)NULL,
	[County] [nvarchar](255) NULL,
	[Language] [nvarchar](255) NULL,
	[PlanID] [nvarchar](255) NULL,
	[MedicareID] [nvarchar](255) NULL,
	[DateOfVisit] [nvarchar] (255) NULL,
	[StartTime] [nvarchar] (255) NULL,
	[EndTime] [nvarchar] (255) NULL,
	[Hours] [nvarchar] (255) NULL,
	[BillableMiles] [nvarchar] (255) NULL,
	[Cost] [nvarchar] (255) NULL,
	[Tasks1] [nvarchar](255) NULL,
	[Tasks2] [nvarchar](255) NULL,
	[Tasks3] [nvarchar](255) NULL,
	[Tasks4] [nvarchar](255) NULL,
	[Tasks5] [nvarchar](255) NULL,
	[Tasks6] [nvarchar](255) NULL,
	[Tasks7] [nvarchar](255) NULL

) ON [PRIMARY]
GO


drop table [dbo].[MemberLevelBreakDownMain]
CREATE TABLE [dbo].[MemberLevelBreakDownMain](
	[VisitID] [nvarchar](255) NULL,
	[Virtual] [nvarchar](255) NULL,
	[GroceryDelivery] [nvarchar](255) NULL,
	[RDMedicationsDelivery] [nvarchar](255) NULL,
	[MemberID] [nvarchar](255) NULL,
	[FirstName] [nvarchar](255) NULL,
	[LastName] [nvarchar](255) NULL,
	[DOB] [nvarchar] (255)NULL,
	[Gender] [nvarchar](255) NULL,
	[Phone] [nvarchar] (255)NULL,
	[Address1] [nvarchar](255) NULL,
	[Address2] [nvarchar](255) NULL,
	[City] [nvarchar](255) NULL,
	[State] [nvarchar](255) NULL,
	[Zip] [nvarchar] (255)NULL,
	[County] [nvarchar](255) NULL,
	[Language] [nvarchar](255) NULL,
	[PlanID] [nvarchar](255) NULL,
	[MedicareID] [nvarchar](255) NULL,
	[DateOfVisit] [nvarchar] (255) NULL,
	[StartTime] [nvarchar] (255) NULL,
	[EndTime] [nvarchar] (255) NULL,
	[Hours] [nvarchar] (255) NULL,
	[BillableMiles] [nvarchar] (255) NULL,
	[Cost] [nvarchar] (255) NULL,
	[Tasks1] [nvarchar](255) NULL,
	[Tasks2] [nvarchar](255) NULL,
	[Tasks3] [nvarchar](255) NULL,
	[Tasks4] [nvarchar](255) NULL,
	[Tasks5] [nvarchar](255) NULL,
	[Tasks6] [nvarchar](255) NULL,
	[Tasks7] [nvarchar](255) NULL,
	[Companionship] int NULL,
	[HouseTasks] int NULL,
	[Transportation] int NULL,
	[DrVisits] int NULL,
	[TechHelp] int NULL,
	[GroceryShopping] int NULL,
	[PetHelp] int NULL,
	[RunErrands] int NULL,
	[Exercise] int NULL,
	[MedicationRX] int NULL,
	[ConsultaionInPerson] nvarcahr(20) NULL,
	[Consultation] int NULL,
	[InPerson] int NULL
) ON [PRIMARY]
GO


delete from dbo.MemberLevelBreakDown where VisitID is null

delete a from (
select
ROW_NUMBER() OVER (PARTITION BY ltrim(rtrim(VisitID)) ORDER BY ltrim(rtrim(VisitID))) as VisitIDRowNumber
,VisitID,Virtual,GroceryDelivery,RDMedicationsDelivery,MemberID,FirstName,LastName,DOB,Gender,Phone,Address1,Address2,City,State,Zip,County,Language,PlanID,MedicareID,	DateOfVisit,	
StartTime,EndTime,Hours,BillableMiles,Cost,Tasks1,Tasks2,Tasks3,Tasks4,Tasks5,Tasks6,Tasks7
from dbo.MemberLevelBreakDown
) a
where a.VisitIDRowNumber > 1

-- Delete all VisitID's where the values are NULL
delete from dbo.MemberLevelBreakDown where VisitID is null
-- Delete all duplicate values based on the VisitID
delete a from (
select
ROW_NUMBER() OVER (PARTITION BY ltrim(rtrim(VisitID)) ORDER BY ltrim(rtrim(VisitID)) ) as VisitIDRowNumber
from dbo.MemberLevelBreakDown
) a
where a.VisitIDRowNumber > 1

select MemberID from dbo.MemberLevelBreakDown order by MemberID
select distinct MemberID from dbo.MemberLevelBreakDown

select * from dbo.MemberLevelBreakDown where MemberID = 'NH202005714506'

select Distinct MemberID from dbo.MemberLevelBreakDown


-- Delete all VisitID's where the values are NULL
delete from dbo.MemberLevelBreakDown where VisitID is null
-- Delete all duplicate values based on the VisitID
delete a from (
select
ROW_NUMBER() OVER (PARTITION BY ltrim(rtrim(VisitID)) ORDER BY ltrim(rtrim(VisitID)) ) as VisitIDRowNumber
from dbo.MemberLevelBreakDown
) a
where a.VisitIDRowNumber > 1

insert into dbo.MemberLevelBreakDownMain (
VisitID,Virtual,GroceryDelivery,RDMedicationsDelivery,MemberID,FirstName,LastName,DOB,Gender,Phone,Address1,Address2,City,State,Zip,County,Language,PlanID,	MedicareID,	DateOfVisit,	
StartTime,EndTime,Hours,BillableMiles,Cost,Tasks1,Tasks2,Tasks3,Tasks4,Tasks5,Tasks6,Tasks7 )
(select distinct VisitID,Virtual,GroceryDelivery,RDMedicationsDelivery,MemberID,FirstName,LastName,DOB,Gender,Phone,Address1,Address2,City,State,Zip,County,Language,PlanID,	MedicareID,	DateOfVisit,	
StartTime,EndTime,Hours,BillableMiles,Cost,Tasks1,Tasks2,Tasks3,Tasks4,Tasks5,Tasks6,Tasks7 from dbo.MemberLevelBreakDown where VisitID not in (select distinct VisitID from dbo.MemberLevelBreakDownMain ))


update dbo.MemberLevelBreakDownMain set Tasks5 = NULL

-- update statement for Tasks
update dbo.MemberLevelBreakDownMain set Companionship = 1 where (Tasks1 like '%companionship%' or Tasks2 like '%companionship%' or Tasks3 like '%companionship%' or Tasks4 like '%companionship%') and (Companionship is NULL or Companionship <> 1)
update dbo.MemberLevelBreakDownMain set HouseTasks = 1 where (Tasks1 like '%House%Tasks%' or Tasks2 like '%House%Tasks%' or Tasks3 like '%House%Tasks%' or Tasks4 like '%House%Tasks%') and ( HouseTasks is NULL or HouseTasks <>1 )
update dbo.MemberLevelBreakDownMain set Transportation = 1 where (Tasks1 like '%Transportation%' or Tasks2 like '%Transportation%' or Tasks3 like '%Transportation%' or Tasks4 like '%Transportation%') and (Transportation is NULL and Transportation <> 1)
update dbo.MemberLevelBreakDownMain set DrVisits = 1 where (Tasks1 like '%Dr%Visits%' or Tasks2 like '%Dr%Visits%' or Tasks3 like '%Dr%Visits%' or Tasks4 like '%Dr%Visits%') and ( DrVisits is NULL or DrVisits <> 1 )
update dbo.MemberLevelBreakDownMain set TechHelp = 1 where (Tasks1 like '%Tech%Help%' or Tasks2 like '%Tech%Help%' or Tasks3 like '%Tech%Help%' or Tasks4 like '%Tech%Help%') and (TechHelp is NULL or TechHelp <> 1)
update dbo.MemberLevelBreakDownMain set GroceryShopping = 1 where (Tasks1 like '%Grocery%Shopping%' or Tasks2 like '%Grocery%Shopping%' or Tasks3 like '%Grocery%Shopping%' or Tasks4 like '%Grocery%Shopping%') and (GroceryShopping is NULL or GroceryShopping <> 1)
update dbo.MemberLevelBreakDownMain set PetHelp = 1 where (Tasks1 like '%Pet%Help%' or Tasks2 like '%Pet%Help%' or Tasks3 like '%Pet%Help%' or Tasks4 like '%Pet%Help%') and (PetHelp is NULL or PetHelp <> 1)
update dbo.MemberLevelBreakDownMain set RunErrands = 1 where (Tasks1 like '%Run%Errands%' or Tasks2 like '%Run%Errands%' or Tasks3 like '%Run%Errands%' or Tasks4 like '%Run%Errands%') and (RunErrands is NULL or RunErrands <> 1)
update dbo.MemberLevelBreakDownMain set Exercise = 1 where (Tasks1 like '%Exercise%' or Tasks2 like '%Exercise%' or Tasks3 like '%Exercise%' or Tasks4 like '%Exercise%') and (Exercise is NULL or Exercise <> 1)
update dbo.MemberLevelBreakDownMain set MedicationRX = 1 where (Tasks1 like '%Medication%RX%' or Tasks2 like '%Medication%RX%' or Tasks3 like '%Medication%RX%' or Tasks4 like '%Medication%RX%') and (MedicationRX is NULL or MedicationRX <> 1)

update dbo.MemberLevelBreakDownMain set Consultation = 1 where Virtual like '%yes%'
update dbo.MemberLevelBreakDownMain set InPerson = 1 where Virtual not like '%yes%' or Virtual is NULL
update dbo.MemberLevelBreakDownMain set ConsultationInperson = 'Consultation/Virtual' where Consultation = 1
update dbo.MemberLevelBreakDownMain set ConsultationInperson = 'InPerson Visit' where InPerson = 1


-- Count of each Task by Month
select  month(DateOfVisit) as MonthIndex, year(DateOfVisit) as Year,  DATENAME(month, DateOfVisit) as Month, sum(Companionship) as Companionship, sum(HouseTasks) as HouseTasks, sum(Transportation) as Transportation,sum(DrVisits) as DrVisits, 
sum(TechHelp) as TechHelp, sum(GroceryShopping) as GroceryShopping, sum(Pethelp) as PetHelp, sum(RunErrands) as RunErrands, sum(Exercise) as Exercise, sum(MedicationRX) as MedicationRX
from dbo.MemberLevelBreakDownMain
group by year(DateOfVisit), DATENAME(month, DateOfVisit), month(DateOfVisit)
order by month(DateOfVisit) asc


/*
select distinct month(DateOfVisit) from  dbo.MemberLevelBreakDownMain
select  month(DateOfVisit),sum(Companionship) from dbo.MemberLevelBreakDownMain group by month(DateOfVisit)
select * from dbo.MemberLevelBreakDownMain order by  Companionship desc
update dbo.MemberLevelBreakDownMain set Companionship = NULL
*/

declare @DistinctMemberCount float

select @DistinctMemberCount = (
								select count(*) 
								from 
									(
									select distinct MemberID from dbo.MemberLevelBreakDownMain
									) a
								)

select @DistinctMemberCount

-- Members Enrolled, Total Hours Utilized and Hours per enrolled member YTD
select count(MemberID) as MembersEnrolled,  round(sum(Hours),2) as TotalHoursUtilized, round((sum(Hours)/cast(count(MemberID) as float)),2) as HoursPerEnrolledMemberYTD from (
select MemberID, sum(cast(hours as float)) as Hours from dbo.MemberLevelBreakDownMain
group by MemberID
) a

--- UnPivot Members Enrolled, Total Hours Utilized and Hours per enrolled member YTD
select 
'Member Enrolled' as SummaryYTD, MembersEnrolled as Count from 
(

select count(MemberID) as MembersEnrolled,  round(sum(Hours),2) as TotalHoursUtilized, round((sum(Hours)/cast(count(MemberID) as float)),2) as HoursPerEnrolledMemberYTD 
from (
	  select MemberID, sum(cast(hours as float)) as Hours from dbo.MemberLevelBreakDownMain
	  group by MemberID
	 ) a
) a
UNION


select 
'Total Hours Utilized' as SummaryYTD, TotalHoursUtilized as Count from 
(

select count(MemberID) as MembersEnrolled,  round(sum(Hours),2) as TotalHoursUtilized, round((sum(Hours)/cast(count(MemberID) as float)),2) as HoursPerEnrolledMemberYTD 
from (
	  select MemberID, sum(cast(hours as float)) as Hours from dbo.MemberLevelBreakDownMain
	  group by MemberID
	 ) a
) a

UNION

select 
'Hours Per Enrolled Member YTD' as SummaryYTD, HoursPerEnrolledMemberYTD as Count from 
(

select count(MemberID) as MembersEnrolled,  round(sum(Hours),2) as TotalHoursUtilized, round((sum(Hours)/cast(count(MemberID) as float)),2) as HoursPerEnrolledMemberYTD 
from (
	  select MemberID, sum(cast(hours as float)) as Hours from dbo.MemberLevelBreakDownMain
	  group by MemberID
	 ) a
) a




-- Unpivot the table.  
SELECT VendorID, Employee, Orders  
FROM   
   (

   SELECT VendorID, Emp1, Emp2, Emp3, Emp4, Emp5  
   FROM pvt
   
   ) p  
UNPIVOT  
   (Orders FOR Employee IN   
      (Emp1, Emp2, Emp3, Emp4, Emp5)  
)AS unpvt;  
GO  


-- Count of Consultation vs In-Person by Month
select ConsultationInPerson, count(ConsultationInPerson) as ConsultationInPersonCount, MonthIndex,  Year,  Month  from 
(
select
 month(DateOfVisit) as MonthIndex, year(DateOfVisit) as Year,  DATENAME(month, DateOfVisit) as Month,
(case when Virtual like '%yes%' then 'Consultation/Virtual' else 'In-Person Visit' end ) as ConsultationInPerson
from dbo.MemberLevelBreakDownMain
--group by (case when Virtual like '%yes%' then 'Consultation/Virtual' else 'In-Person Visit' end ),  year(DateOfVisit), DATENAME(month, DateOfVisit), month(DateOfVisit)
--order by 1
) a
group by ConsultationInPerson, MonthIndex, year, month



select City, Count(*) as NoOfVisitsPerCity from dbo.MemberLevelBreakDownMain
group by City


select 
(FirstName + ' ' + LastName) as Name,MemberID ,Count(MemberID) as MemberCount
from dbo.MemberLevelBreakDownMain
group by (FirstName + ' ' + LastName),MemberID




SELECT VendorID, [250] AS Emp1, [251] AS Emp2, [256] AS Emp3, [257] AS Emp4, [260] AS Emp5  
FROM   
(SELECT PurchaseOrderID, EmployeeID, VendorID  
FROM Purchasing.PurchaseOrderHeader) p  
PIVOT  
(  
COUNT (PurchaseOrderID)  
FOR EmployeeID IN  
( [250], [251], [256], [257], [260] )  
) AS pvt  
ORDER BY pvt.VendorID; 



select ConsultationInPerson as VisitType, 
[1] as January, [2] as February, [3] as March, [4] as April, [5] as May, [6] as June, [7] as July, [8] as August, [9] as September, [10] as October, [11] as November, [12] as December
from
(select month(DateOfVisit) as DateOfVisit, (case when Virtual like '%yes%' then 'Consultation/Virtual' else 'In-Person Visit' end ) as ConsultationInPerson
from dbo.MemberLevelBreakDownMain ) p
pivot
(
count(DateOfVisit)
for DateofVisit in ([1],[2],[3],[4],[5],[6],[7],[8],[9],[10],[11],[12])
) as pvt


select Tasks as TaskType, sum(TasksCount) as Amount from 
(
select VisitID, DateOfVisit, 'Companionship' as Tasks, 1 as TasksCount from dbo.MemberLevelBreakDownMain  where Companionship =1
union
select VisitID, DateOfVisit, 'HouseTasks' as Tasks, 1 as TasksCount from dbo.MemberLevelBreakDownMain  where HouseTasks =1
union
select VisitID, DateOfVisit, 'Transportation' as Tasks, 1 as TasksCount from dbo.MemberLevelBreakDownMain  where Transportation =1
union
select VisitID, DateOfVisit, 'DrVisits' as Tasks, 1 as TasksCount from dbo.MemberLevelBreakDownMain  where DrVisits =1
union
select VisitID, DateOfVisit, 'TechHelp' as Tasks, 1 as TasksCount from dbo.MemberLevelBreakDownMain  where TechHelp =1
union
select VisitID, DateOfVisit, 'GroceryShopping' as Tasks, 1 as TasksCount from dbo.MemberLevelBreakDownMain  where GroceryShopping =1
union
select VisitID, DateOfVisit, 'PetHelp' as Tasks, 1 as TasksCount from dbo.MemberLevelBreakDownMain   where PetHelp =1
union
select VisitID, DateOfVisit, 'RunErrands' as Tasks, 1 as TasksCount from dbo.MemberLevelBreakDownMain  where RunErrands =1
union
select VisitID, DateOfVisit, 'Exercise' as Tasks, 1 as TasksCount from dbo.MemberLevelBreakDownMain  where Exercise =1
union
select VisitID, DateOfVisit, 'MedicationRX' as Tasks, 1 as TasksCount from dbo.MemberLevelBreakDownMain  where MedicationRX =1
) a

group by Tasks
Order by 2 desc

alter table dbo.MemberLevelBreakdownMain add ConsultationInPerson nvarchar(20)
alter table dbo.MemberLevelBreakdownMain add Consultation int
alter table dbo.MemberLevelBreakdownMain add InPerson int

select * from dbo.MemberLevelBreakdownMain
select Virtual, ConsultationInPerson, Consultation, InPerson from dbo.MemberLevelBreakdownMain

select month(DateOfVisit) as MonthIndex, year(DateOfVisit) as Year,  DATENAME(month, DateOfVisit) as Month,ConsultationInPerson, sum(consultation) CountConsultation, sum(InPerson) CountInperson from dbo.MemberLevelBreakdownMain
group by  month(DateOfVisit), year(DateOfVisit),  DATENAME(month, DateOfVisit) ,ConsultationInPerson