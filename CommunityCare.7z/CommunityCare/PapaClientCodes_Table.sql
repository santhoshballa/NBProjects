/****** Object:  Table [elig].[PAPA_ClientCodes]    Script Date: 10/21/2021 10:47:11 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [elig].[PAPA_ClientCodes](
	[ID] [bigint] IDENTITY(1,1) NOT NULL,
	[ClientCode] [varchar](20) NULL,
	[ClientName] [varchar](100) NULL,
	[DataSource] [varchar](30) NULL,	
	[InsHealthPlanID] VARCHAR(5) NULL,
	[isactive] [char](1) NULL
) ON [PRIMARY]
GO



INSERT INTO [elig].[PAPA_ClientCodes]([ClientCode],[ClientName],[DataSource],[InsHealthPlanID],[isactive])
VALUES('H453','Experience Health','ELIG_EXPH',3247,1)
INSERT INTO [elig].[PAPA_ClientCodes]([ClientCode],[ClientName],[DataSource],[InsHealthPlanID],[isactive])
VALUES('H343','Provider Partners Health Plan','ELIG_PPHP',0,1)
INSERT INTO [elig].[PAPA_ClientCodes]([ClientCode],[ClientName],[DataSource],[InsHealthPlanID],[isactive])
VALUES('H376','Health Plan Alliance','ELIG_HAP',0,1)
