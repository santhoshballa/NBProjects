alter procedure [dbo].[sp_CareRadiusNationsToHAPLoad]

as

/*
IF OBJECT_ID('dbo.HAPTestFile') IS NOT NULL DROP TABLE dbo.HAPTestFile

CREATE TABLE dbo.HAPTestFile (
HAPTestFileID int IDENTITY(1,1), 
BusinessType varchar(1000) NOT NULL,
NHmemberID varchar(1000) NOT NULL,
EnrollmentDate varchar(1000) ,
IsActive int,  -- This is to filter records if needed
MemberID varchar(10),
AlternateID varchar(10),
NHLinkID varchar(20),
MasterMemberID varchar(20),
MemberIsActive int,
EligIsActive int,
SubscriberID varchar(1000),
CaseManagementProgram	varchar(1000),
EnrollmentType	varchar(1000),
ProgramBeginDate	varchar(1000),
ProgramEndDate	varchar(1000)		,
ProgramInitiationDate	varchar(1000)		,
ProgramStatus	varchar(1000),
ProgramDisenrollmentReasonCode	varchar(1000)		,
AcuityLevel	varchar(1000)		,
ReferralSourceorSourceofData	varchar(1000),
PrimaryCondition	varchar(1000)		,
DiagnosisCode1	varchar(1000)		,
DiagnosisCode2	varchar(1000)		,
DiagnosisCode3	varchar(1000)		,
MemberAccepted	varchar(1000)		,
MemberReason	varchar(1000)		,
MemberResponseByMR	varchar(1000)		,
MemberContactedBy	varchar(1000)		,
DateMemberAcceptedVerbal	varchar(1000)		,
DateMemberDeclinedVerbal	varchar(1000)		,
DateMemberAcceptedWritten	varchar(1000)		,
DateMemberDeclinedWritten	varchar(1000)		,
DateMemberAcceptedElectronic	varchar(1000)		,
DateMemberDeclinedElectronic	varchar(1000)		,
CaseManagerAccepted	varchar(1000)		,
CaseManagerReason	varchar(1000)		,
ContactedbyStaffID	varchar(1000)		,
DateCaseManagerAccepted	varchar(1000)		,
DateCaseManagerDeclined	varchar(1000)		,
AcceptanceNotes	varchar(1000)		,
CaseManagerStaffID	varchar(1000)		,
CaseManagerBeginDate	varchar(1000)		,
CaseManagerEndDate	varchar(1000)		,
PrimaryCaseManager	varchar(1000)		,
TasktoCaseManagerorWorkGroup	varchar(1000)		,
WorkgrouptoGetTask	varchar(1000)		,
TaskDueDate	varchar(1000)		,
TaskDueTime	varchar(1000)		,
TaskOwnerUserID	varchar(1000)		,
NoteType	varchar(1000)		,
GeneralNote	varchar(1000)		,
	)

SET IDENTITY_INSERT dbo.HAPTestFileArchive ON;  
insert into dbo.HAPTestFileArchive 
(HAPTestFileID,	BusinessType,	NHmemberID,	EnrollmentDate,	IsActive,	MemberID,	AlternateID,	NHLinkID,	MasterMemberID,	MemberIsActive,	EligIsActive,	SubscriberID,	CaseManagementProgram,	EnrollmentType,	ProgramBeginDate,	ProgramEndDate,	ProgramInitiationDate,	ProgramStatus,	ProgramDisenrollmentReasonCode,	AcuityLevel,	ReferralSourceorSourceofData,	PrimaryCondition,	DiagnosisCode1,	DiagnosisCode2,	DiagnosisCode3,	MemberAccepted,	MemberReason,	MemberResponseByMR,	MemberContactedBy,	DateMemberAcceptedVerbal,	DateMemberDeclinedVerbal,	DateMemberAcceptedWritten,	DateMemberDeclinedWritten,	DateMemberAcceptedElectronic,	DateMemberDeclinedElectronic,	CaseManagerAccepted,	CaseManagerReason,	ContactedbyStaffID,	DateCaseManagerAccepted,	DateCaseManagerDeclined,	AcceptanceNotes,	CaseManagerStaffID,	CaseManagerBeginDate,	CaseManagerEndDate,	PrimaryCaseManager,	TasktoCaseManagerorWorkGroup,	WorkgrouptoGetTask,	TaskDueDate,	TaskDueTime,	TaskOwnerUserID,	NoteType,	GeneralNote)

(
select HAPTestFileID,	BusinessType,	NHmemberID,	EnrollmentDate,	IsActive,	MemberID,	AlternateID,	NHLinkID,	MasterMemberID,	MemberIsActive,	EligIsActive,	SubscriberID,	CaseManagementProgram,	EnrollmentType,	ProgramBeginDate,	ProgramEndDate,	ProgramInitiationDate,	ProgramStatus,	ProgramDisenrollmentReasonCode,	AcuityLevel,	ReferralSourceorSourceofData,	PrimaryCondition,	DiagnosisCode1,	DiagnosisCode2,	DiagnosisCode3,	MemberAccepted,	MemberReason,	MemberResponseByMR,	MemberContactedBy,	DateMemberAcceptedVerbal,	DateMemberDeclinedVerbal,	DateMemberAcceptedWritten,	DateMemberDeclinedWritten,	DateMemberAcceptedElectronic,	DateMemberDeclinedElectronic,	CaseManagerAccepted,	CaseManagerReason,	ContactedbyStaffID,	DateCaseManagerAccepted,	DateCaseManagerDeclined,	AcceptanceNotes,	CaseManagerStaffID,	CaseManagerBeginDate,	CaseManagerEndDate,	PrimaryCaseManager,	TasktoCaseManagerorWorkGroup,	WorkgrouptoGetTask,	TaskDueDate,	TaskDueTime,	TaskOwnerUserID,	NoteType,	GeneralNote
from dbo.HAPTestFile
)



*/

begin
	begin try
	begin transaction CareRadiusNationsToHAPLoad

-- Temp Table to filter the alternateID which is the SubscriberID
select distinct a.IsActive Member_IsActive, b.IsActive elig_IsActive, a.NHMemberID, a.MemberID, b.alternateID, b.NHLinkID,  b.MasterMemberID
into #MasterElig 
from master.Members a join elig.mstrEligBenefitData b on a.MemberID = b.MasterMemberID and a.IsActive = 1 and b.IsActive =1
where a.NHMemberID in (select distinct NHMemberID from dbo.HAPTestFile)

/*
select * from #MasterElig
select NHMemberID from dbo.HAPTestFile where NHmemberID not in (select distinct NHMemberID from #MasterElig)
select NHMemberID, count(*) from dbo.HAPTestFile group by NHMemberID having count(*) > 1
select * from dbo.HAPTestFile where NHMemberID in (select NHMemberID from dbo.HAPTestFile group by NHMemberID having count(*) > 1)
*/

update dbo.HAPTestFile 
set 
 MemberID =  me.MemberID
,AlternateID = me.AlternateID
,NHLinkID = me.NHLinkID
,MasterMemberID = me.MasterMemberID
,EligIsActive = me.elig_IsActive
,MemberIsActive = me.Member_IsActive
,IsActive = 1

from
dbo.HAPTestFile h join #MasterElig me on h.NHMemberID = me.NHMemberID

update dbo.HAPTestFile set SubscriberID = AlternateID where BusinessType in ('PERS', 'Ccare') and IsActive = 1
update dbo.HAPTestFile set CaseManagementProgram = 'NBPERS' where BusinessType = 'PERS'  and IsActive = 1
update dbo.HAPTestFile set CaseManagementProgram = 'NBCOMP' where BusinessType = 'Ccare' and IsActive = 1
update dbo.HAPTestFile set EnrollmentType = 'CE' where BusinessType in ('PERS', 'Ccare') and IsActive = 1
update dbo.HAPTestFile set ProgramStatus = 'ACT' where BusinessType in ('PERS', 'Ccare') and IsActive = 1
update dbo.HAPTestFile set ReferralSourceorSourceofData = 'RFS086' where BusinessType in ('PERS', 'Ccare') and IsActive = 1
update dbo.HAPTestFile set ProgramBeginDate = EnrollmentDate

commit transaction CareRadiusNationsToHAPLoad

end try

	begin catch
		declare @ErrorMessage nvarchar(4000);  
		--   DECLARE @ErrorSeverity INT;  
		--   DECLARE @ErrorState INT;  
		--   SELECT   
		--       @ErrorMessage = ERROR_MESSAGE(),  
		--       @ErrorSeverity = ERROR_SEVERITY(),  
		--       @ErrorState = ERROR_STATE();  
				if (@@TRANCOUNT > 0)
				begin
				rollback transaction
				print 'FAILED'
		END
   end catch
end