
select * from insurance.insuranceCarriers where InsuranceCarrierName like '%mvp%'
/*
--InsuranceCarrierID	ClaimsAddress1	ClaimsAddress2	ClaimsCity	ClaimsEmailAddress	ClaimsPhoneNbr	ClaimsState	ClaimsZipCode	CreateDate	CreateUser	CustServiceAddress1	CustServiceAddress2	CustServiceCity	CustServiceEmailAddress	CustServicePhoneNbr	CustServiceState	CustServiceZipCode	InsuranceCarrierName	IsActive	IsContracted	IsDiscountProgram	MemberDataFileProvided	ModifyDate	ModifyUser	IsAutoSendPaymentReceipt	CarrierConfig	IsNHDiscount	AllowAdditionalServices	OldCarrierConfig
141	NULL	NULL	NULL	NULL	NULL	NULL	NULL	2017-12-15 18:34:17.5200000	Script	NULL	NULL	NULL	NULL	NULL	NULL	NULL	MVP Health Care, Inc.	1	1	0	0	2022-01-01 05:47:06.2500000	Sirigiri66155	0	{"alwaysViewCatalog":false,"canSubscribe":false,"disablePromotions":false,"disclaimer":false,"isLoginRestricted":false,"isRegisterable":true,"isTeleAudiologyEnabled":false,"showHeadPhonesText":false,"showOTCGuidelines":false,"subdomain":"mvp","useOldPortal":false,"carrierCode":"mvp"}	0	0	NULL
*/

select * from insurance.insuranceCarriers where InsuranceCarrierName like '%mvp%'
select * from insurance.insuranceHealthPlans where InsuranceCarrierID = 141
select * from elig.BenefitCrossWalk where InsuranceCarrierID = 141
select * from elig.clientcodes where ClientName like '%mvp%'  -- H482
/*
ID	ClientCode	ClientName	DataSource	InsuranceCarrierID	InsuranceHealthPlanID	EligStartDate	isActive	CreateDate	CreateUser	ModifyDate	ModifyUser	MasterDataSource	RptClientName
71	H482	MVP	ELIG_MVP	141	NULL	2022-01-01	1	2021-10-04 18:20:17.653	rsareddy	2021-10-04 18:20:17.653	rsareddy	ELIG_MVP	MVP

*/

select * from elig.EligibilityColumnValidation where ClientCode = 'H482'
--Eligibility file
select ContractNbr,PBPID,SubscriberID,DOB,FirstName,MiddleInitial,LastName,Address1,Address2,City,State,ZipCode,GroupNbr,BenefitStartDate,BenefitEndDate,HomePhoneNbr,DataSourceCreateDate, ModifyDate, *
from elig.stgEligBenefitData where DataSource = 'ELIG_MVP'

select * from (
select distinct ContractNbr, PBPID, GroupNbr from elig.stgEligBenefitData where DataSource = 'ELIG_MVP' UNION
select distinct ContractNbr, PBPID, GroupNbr from elig.stgEligBenefitDataHist where DataSource = 'ELIG_MVP'
)a
Order by a.ContractNbr, a.PBPID


/*
ContractNbr	PBPID
NULL	NULL	
NULL    015
H3305	007  - y
H3305	014  - y
H3305	015  - y
H3305	021
H3305	022
H3305	032
H3305	033
H9615	007
H9615	009
H9615	010
H9615	012
H9615	014
H9615	015
H9615	016
H9615	017

*/

--Insurance Carrier
Select InsuranceCarrierName, InsuranceCarrierID from insurance.insuranceCarriers where InsuranceCarrierID = 141 and IsActive =1

-- Insurance Health Plans
Select HealthPlanName, InsuranceHealthPlanID from insurance.insuranceHealthPlans where InsuranceCarrierID = 141 and IsActive = 1



--Eligibility
select distinct 'Eligibility' as TableName, ContractNbr, PBPID, GroupNbr from elig.mstrEligBenefitData where DataSource  = 'ELIG_MVP' order by ContractNbr, PBPID

-- BenefitCrossWalk
select distinct 'BenefitCrossWalk' as TableName, ContractNbr, PBPID,GroupNbr from elig.BenefitCrossWalk where InsuranceCarrierID = 141 order by ContractNbr, PBPID

select distinct 'BeneefitCrossWalk' as TableName, ClientCode,ContractNbr, PBPID, PlanName, InsuranceCarrierID, InsuranceHealthPlanID, IsActive from elig.BenefitCrossWalk where InsuranceCarrierID = 141 order by COntractNbr, PBPID 

select ContractNbr,PBPID,SubscriberID,DOB,FirstName,MiddleInitial,LastName,Address1,Address2,City,State,ZipCode,GroupNbr,BenefitStartDate,BenefitEndDate,HomePhoneNbr,CreateDate, ModifyDate
from elig.stgEligBenefitDataHist where DataSource = 'ELIG_MVP'

select * from elig.BenefitCrossWalk where Isactive = 0


--------------------------Script Begin Here --------------------------------------------
/*

Plans no longer offering in 2023:

H3305-014           MVP Medicare Patriot Plan with Part D (PPO) H9615-014
H3305-016           UVM Health Advantage Secure H9615-016
H3305-017           UVM Health Advantage Preferred H9615-017To inactive the Plans that are No longer being offered in 2023
select * from elig.BenefitCrossWalk where ContractNBR in ('H3305') and PBPID in ('014', '016', '017')

Select InsuranceHealthPlanID, HealthPlanName, InsuranceHealthPlanID from insurance.insuranceHealthPlans where InsuranceCarrierID = 141 and IsActive = 1
and InsuranceHealthPlanID in ( 4949,4951,4952)
/*
HealthPlanName	InsuranceHealthPlanID
MVP Medicare Patriot Plan with Part D (PPO) H9615-014	4949
UVM Health Advantage Secure H9615-016	4951
UVM Health Advantage Preferred H9615-017	4952
*/

*/


-- select Plans made InActive, year 2022
select [IsActive], [InsuranceHealthPlanID], [HealthPlanName], [HealthPlanNumber], [InsuranceCarrierID], [IsDiscountProgram], [ModifyDate], [ModifyUser], [IsMedicaid], [IsMedicare], [PlanConfigData], [IsProgramCode], [CreateDate], [CreateUser]
from [Insurance].[InsuranceHealthPlans] where [InsuranceHealthPlanID] in (4949,4951,4952)  and InsuranceCarrierID = 141

-- select Plans Added Active, year 2023
select [InsuranceHealthPlanID], [HealthPlanName], [IsActive], [HealthPlanNumber], [InsuranceCarrierID], [IsDiscountProgram], [ModifyDate], [ModifyUser], [IsMedicaid], [IsMedicare], [PlanConfigData], [IsProgramCode], [CreateDate], [CreateUser]
from [Insurance].[InsuranceHealthPlans] where InsuranceCarrierID = 141 
and [HealthPlanName] in ('MVP Medicare Preferred Gold without Part D (HMO-POS) H3305-020','MVP Medicare Secure with Part D (HMO-POS) H3305-030','MVP Medicare WellSelect with Part D (PPO) H9615-008','MVP Medicare Patriot Plan with Part D (PPO) H9615-018')

-- select Plans made InActive in BenefitCrossWalk, year 2022
select [Isactive],[ContractNbr],[PBPID],[InsuranceCarrierId],[InsuranceHealthPlanId], [ClientCode],  [GroupNbr], [ProductID], [PlanID],  [LOB], [PlanName], [IncommPlanCode], [HealthPlanNumber],  [InsuranceHealthPlanId],  [CreateDate], [CreateUser], [ModifyDate], [ModifyUser], [SubGroupNbr], [BusinessCategory], [ProductValueCode], [CarrierPriority], [HealthPlanStartDate], [HealthPlanEndDate]
from elig.BenefitCrossWalk where [ContractNbr] = 'H3305' and [PBPID] in ('014','016', '017') -- ID in (37526, 37527, 37528 ) in Production 

-- select Plans Made Active in BenefitCrossWalk, year 2023
select [Isactive],[ContractNbr],[PBPID],[InsuranceCarrierId],[InsuranceHealthPlanId], [ClientCode],  [GroupNbr], [ProductID], [PlanID],  [LOB], [PlanName], [IncommPlanCode], [HealthPlanNumber],  [InsuranceHealthPlanId],  [CreateDate], [CreateUser], [ModifyDate], [ModifyUser], [SubGroupNbr], [BusinessCategory], [ProductValueCode], [CarrierPriority], [HealthPlanStartDate], [HealthPlanEndDate]
from elig.BenefitCrossWalk where [ContractNbr] in ( 'H3305', 'H9615') and [PBPID] in ('020','030', '008', '018' ) and ClientCode = 'H482' --  in Production 



begin transaction MVPConfiguration

-- Update the InsuranceHealthPlan Table
Update insurance.insuranceHealthPlans set IsActive = 0 where InsuranceHealthPlanID = 4949 and InsuranceCarrierID = 141   -- H3305-014 | MVP Medicare Patriot Plan with Part D (PPO) H9615-014
Update insurance.insuranceHealthPlans set IsActive = 0 where InsuranceHealthPlanID = 4951 and InsuranceCarrierID = 141   -- H3305-016 | UVM Health Advantage Secure H9615-016
Update insurance.insuranceHealthPlans set IsActive = 0 where InsuranceHealthPlanID = 4952 and InsuranceCarrierID = 141   -- H3305-017 | UVM Health Advantage Preferred H9615-017

-- Update the BenefitCrossWalk Table
update elig.BenefitCrossWalk set IsActive = 0 where ClientCode = 'H482' and ContractNbr = 'H3305' and PBPID = '014' and InsuranceCarrierID = 141   -- H3305-014 | MVP Medicare Patriot Plan with Part D (PPO) H9615-014
update elig.BenefitCrossWalk set IsActive = 0 where ClientCode = 'H482' and ContractNbr = 'H3305' and PBPID = '016' and InsuranceCarrierID = 141   -- H3305-016 | UVM Health Advantage Secure H9615-016
update elig.BenefitCrossWalk set IsActive = 0 where ClientCode = 'H482' and ContractNbr = 'H3305' and PBPID = '017' and InsuranceCarrierID = 141   -- H3305-017 | UVM Health Advantage Preferred H9615-017

/*
Plans being added in 2023: Original
H3305-020           MVP Medicare Preferred Gold without Part D (HMO-POS)  OTC - $25 per quarter, no rollover, all members qualify
H3305-030           MVP Medicare Secure with Part D (HMO-POS) OTC - $25 per quarter, no rollover, all members qualify
H9615-008           MVP Medicare WellSelect with Part D (PPO) � OTC - $25 per quarter, no rollover, all members qualify
H9615-018           MVP Medicare Patriot Plan with Part D (PPO) � OTC - $25 per quarter, no rollover, all members qualify

-- This was how the HealthPlan was inserted
H3305-020           MVP Medicare Preferred Gold without Part D (HMO-POS) H3305-020
H3305-030           MVP Medicare Secure with Part D (HMO-POS) H3305-030
H9615-008           MVP Medicare WellSelect with Part D (PPO) H9615-008
H9615-018           MVP Medicare Patriot Plan with Part D (PPO) H9615-018
*/

-- Insert the 4 HealthPlans for the Carrier MVP (141)
INSERT [Insurance].[InsuranceHealthPlans] ( [CreateDate], [CreateUser], [HealthPlanName], [HealthPlanNumber], [InsuranceCarrierID], [IsActive], [IsDiscountProgram], [ModifyDate], [ModifyUser], [IsMedicaid], [IsMedicare], [PlanConfigData], [IsProgramCode]) VALUES (getdate(), N'appuser', N'MVP Medicare Preferred Gold without Part D (HMO-POS) H3305-020', N'H3305-020', 141, 1, 0, getdate(), N'appuser', 0, 0, NULL, 0)
INSERT [Insurance].[InsuranceHealthPlans] ( [CreateDate], [CreateUser], [HealthPlanName], [HealthPlanNumber], [InsuranceCarrierID], [IsActive], [IsDiscountProgram], [ModifyDate], [ModifyUser], [IsMedicaid], [IsMedicare], [PlanConfigData], [IsProgramCode]) VALUES (getdate(), N'appuser', N'MVP Medicare Secure with Part D (HMO-POS) H3305-030', N'H3305-030', 141, 1, 0, getdate(), N'appuser', 0, 0, NULL, 0)
INSERT [Insurance].[InsuranceHealthPlans] ( [CreateDate], [CreateUser], [HealthPlanName], [HealthPlanNumber], [InsuranceCarrierID], [IsActive], [IsDiscountProgram], [ModifyDate], [ModifyUser], [IsMedicaid], [IsMedicare], [PlanConfigData], [IsProgramCode]) VALUES (getdate(), N'appuser', N'MVP Medicare WellSelect with Part D (PPO) H9615-008',N'H9615-008', 141, 1, 0, getdate(), N'appuser', 0, 0, NULL, 0)
INSERT [Insurance].[InsuranceHealthPlans] ( [CreateDate], [CreateUser], [HealthPlanName], [HealthPlanNumber], [InsuranceCarrierID], [IsActive], [IsDiscountProgram], [ModifyDate], [ModifyUser], [IsMedicaid], [IsMedicare], [PlanConfigData], [IsProgramCode]) VALUES (getdate(), N'appuser', N'MVP Medicare Patriot Plan with Part D (PPO) H9615-018', N'H9615-018', 141, 1, 0, getdate(), N'appuser', 0, 0, NULL, 0)
	
-- Insert the 4 HealthPlans with ContractNbr and PBPID
INSERT [elig].[BenefitCrossWalk] ( [ClientCode], [ContractNbr], [GroupNbr], [ProductID], [PlanID], [PBPID], [LOB], [PlanName], [IncommPlanCode], [HealthPlanNumber], [InsuranceCarrierId], [InsuranceHealthPlanId], [Isactive], [CreateDate], [CreateUser], [ModifyDate], [ModifyUser], [SubGroupNbr], [BusinessCategory], [ProductValueCode], [CarrierPriority], [HealthPlanStartDate], [HealthPlanEndDate]) VALUES 
( N'H482', N'H3305', NULL, NULL, NULL, N'020', NULL, N'MVP Medicare Preferred Gold without Part D (HMO-POS) H3305-020', NULL, NULL, 141, (select InsuranceHealthPlanID from [Insurance].[InsuranceHealthPlans] where HealthPlanName like '%H3305-020%' and HealthPlanName like '%MVP%') , 1, getdate(), N'appuser', getdate(), N'appuser', NULL, NULL, NULL, NULL, NULL, NULL)
INSERT [elig].[BenefitCrossWalk] ( [ClientCode], [ContractNbr], [GroupNbr], [ProductID], [PlanID], [PBPID], [LOB], [PlanName], [IncommPlanCode], [HealthPlanNumber], [InsuranceCarrierId], [InsuranceHealthPlanId], [Isactive], [CreateDate], [CreateUser], [ModifyDate], [ModifyUser], [SubGroupNbr], [BusinessCategory], [ProductValueCode], [CarrierPriority], [HealthPlanStartDate], [HealthPlanEndDate]) VALUES 
( N'H482', N'H3305', NULL, NULL, NULL, N'030', NULL, N'MVP Medicare Secure with Part D (HMO-POS) H3305-030', NULL, NULL, 141, (select InsuranceHealthPlanID from [Insurance].[InsuranceHealthPlans] where HealthPlanName like '%H3305-030%' and HealthPlanName like '%MVP%'), 1,  getdate(), N'appuser', getdate(), N'appuser', NULL, NULL, NULL, NULL, NULL, NULL)
INSERT [elig].[BenefitCrossWalk] ( [ClientCode], [ContractNbr], [GroupNbr], [ProductID], [PlanID], [PBPID], [LOB], [PlanName], [IncommPlanCode], [HealthPlanNumber], [InsuranceCarrierId], [InsuranceHealthPlanId], [Isactive], [CreateDate], [CreateUser], [ModifyDate], [ModifyUser], [SubGroupNbr], [BusinessCategory], [ProductValueCode], [CarrierPriority], [HealthPlanStartDate], [HealthPlanEndDate]) VALUES 
( N'H482', N'H9615', NULL, NULL, NULL, N'008', NULL, N'MVP Medicare WellSelect with Part D (PPO) H9615-008', NULL, NULL, 141, (select InsuranceHealthPlanID from [Insurance].[InsuranceHealthPlans] where HealthPlanName like '%H9615-008%' and HealthPlanName like '%MVP%'), 1,  getdate(), N'appuser', getdate(), N'appuser', NULL, NULL, NULL, NULL, NULL, NULL)
INSERT [elig].[BenefitCrossWalk] ( [ClientCode], [ContractNbr], [GroupNbr], [ProductID], [PlanID], [PBPID], [LOB], [PlanName], [IncommPlanCode], [HealthPlanNumber], [InsuranceCarrierId], [InsuranceHealthPlanId], [Isactive], [CreateDate], [CreateUser], [ModifyDate], [ModifyUser], [SubGroupNbr], [BusinessCategory], [ProductValueCode], [CarrierPriority], [HealthPlanStartDate], [HealthPlanEndDate]) VALUES 
( N'H482', N'H9615', NULL, NULL, NULL, N'018', NULL, N'MVP Medicare Patriot Plan with Part D (PPO) H9615-018', NULL, NULL, 141, (select InsuranceHealthPlanID from [Insurance].[InsuranceHealthPlans] where HealthPlanName like '%H9615-018%' and HealthPlanName like '%MVP%'), 1,  getdate(), N'appuser', getdate(), N'appuser', NULL, NULL, NULL, NULL, NULL, NULL)


-- Select query to check is the values are updated and inserted correctly

-- select Plans made InActive, year 2022
select [IsActive],[InsuranceHealthPlanID], [HealthPlanName],  [HealthPlanNumber], [InsuranceCarrierID], [IsDiscountProgram], [ModifyDate], [ModifyUser], [IsMedicaid], [IsMedicare], [PlanConfigData], [IsProgramCode], [CreateDate], [CreateUser]
from [Insurance].[InsuranceHealthPlans] where [InsuranceHealthPlanID] in (4949,4951,4952)  and InsuranceCarrierID = 141

-- select Plans Added Active, year 2023
select [IsActive],[InsuranceHealthPlanID], [HealthPlanName],  [HealthPlanNumber], [InsuranceCarrierID], [IsDiscountProgram], [ModifyDate], [ModifyUser], [IsMedicaid], [IsMedicare], [PlanConfigData], [IsProgramCode], [CreateDate], [CreateUser]
from [Insurance].[InsuranceHealthPlans] where InsuranceCarrierID = 141 
and [HealthPlanName] in ('MVP Medicare Preferred Gold without Part D (HMO-POS) H3305-020','MVP Medicare Secure with Part D (HMO-POS) H3305-030','MVP Medicare WellSelect with Part D (PPO) H9615-008','MVP Medicare Patriot Plan with Part D (PPO) H9615-018')

-- select Plans made InActive in BenefitCrossWalk, year 2022
select [Isactive],[ContractNbr],[PBPID],[InsuranceCarrierId],[InsuranceHealthPlanId], [ClientCode],  [GroupNbr], [ProductID], [PlanID],  [LOB], [PlanName], [IncommPlanCode], [HealthPlanNumber],  [InsuranceHealthPlanId],  [CreateDate], [CreateUser], [ModifyDate], [ModifyUser], [SubGroupNbr], [BusinessCategory], [ProductValueCode], [CarrierPriority], [HealthPlanStartDate], [HealthPlanEndDate]
from elig.BenefitCrossWalk where [ContractNbr] = 'H3305' and [PBPID] in ('014','016', '017') -- ID in (37526, 37527, 37528 ) in Production 

-- select Plans Made Active in BenefitCrossWalk, year 2023
select [Isactive],[ContractNbr],[PBPID],[InsuranceCarrierId],[InsuranceHealthPlanId], [ClientCode],  [GroupNbr], [ProductID], [PlanID],  [LOB], [PlanName], [IncommPlanCode], [HealthPlanNumber],  [InsuranceHealthPlanId],  [CreateDate], [CreateUser], [ModifyDate], [ModifyUser], [SubGroupNbr], [BusinessCategory], [ProductValueCode], [CarrierPriority], [HealthPlanStartDate], [HealthPlanEndDate]
from elig.BenefitCrossWalk where [ContractNbr] in ( 'H3305', 'H9615') and [PBPID] in ('020','030', '008', '018' ) and ClientCode = 'H482' --  in Production 


Rollback transaction MVPConfiguration