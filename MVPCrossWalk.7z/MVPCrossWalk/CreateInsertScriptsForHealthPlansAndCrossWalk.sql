drop table if exists #InsertHealthPlansCrossWalk
create table #InsertHealthPlansCrossWalk
(
ID int IDENTITY (1,1),
ClientCode varchar(10),
InsuranceCarrierID varchar(10),
HealthPlanName varchar(500),
HealthPlanNumber varchar(50),
ContractNbr varchar(50),
PBPID varchar(20),
)

INSERT #InsertHealthPlansCrossWalk (ClientCode, InsuranceCarrierID, HealthPlanName, HealthPlanNumber, ContractNbr, PBPID ) values ('H482',141,'MVP Medicare Preferred Gold without Part D (HMO-POS) H3305-020','H3305-020','H3305','020')
INSERT #InsertHealthPlansCrossWalk (ClientCode, InsuranceCarrierID, HealthPlanName, HealthPlanNumber, ContractNbr, PBPID ) values ('H482',141,'MVP Medicare Secure with Part D (HMO-POS) H3305-030','H3305-030','H3305','030')
INSERT #InsertHealthPlansCrossWalk (ClientCode, InsuranceCarrierID, HealthPlanName, HealthPlanNumber, ContractNbr, PBPID ) values ('H482',141,'MVP Medicare WellSelect with Part D (PPO) H9615-008','H9615-008','H9615','008')
INSERT #InsertHealthPlansCrossWalk (ClientCode, InsuranceCarrierID, HealthPlanName, HealthPlanNumber, ContractNbr, PBPID ) values ('H482',141,'MVP Medicare Patriot Plan with Part D (PPO) H9615-018','H9615-018','H9615','018')

select * from #InsertHealthPlansCrossWalk

-- Create Insert Scripts for the HealthPlans
select
'INSERT [Insurance].[InsuranceHealthPlans] ( [CreateDate], [CreateUser], [HealthPlanName], [HealthPlanNumber], [InsuranceCarrierID], [IsActive], [IsDiscountProgram], [ModifyDate], [ModifyUser], [IsMedicaid], [IsMedicare], [PlanConfigData], [IsProgramCode]) 
VALUES ('

+ 'getdate()'+','
+ ''''+'appuser'+ ''''+',' 
+ ''''+cast(HealthPlanName as varchar)+'''' +','
+ ''''+cast(HealthPlanNumber as varchar)+''''+  ',' 
+ ''''+cast(InsuranceCarrierID as varchar)+ '''' + ',' 
+ '1' + ',' 
+ '0' +  ','+
+ 'getdate()'+','
+ ''''+'appuser'+ ''''+',' 
+  'NULL' + ','
+  'NULL' + ','
+  'NULL' + ','
+  'NULL' + ','
+  'NULL' + ','
+  'NULL' + ')'
from #InsertHealthPlansCrossWalk


INSERT [elig].[BenefitCrossWalk] ( [ClientCode], [ContractNbr], [GroupNbr], [ProductID], [PlanID], [PBPID], [LOB], [PlanName], [IncommPlanCode], [HealthPlanNumber], [InsuranceCarrierId], [InsuranceHealthPlanId], [Isactive], [CreateDate], [CreateUser], [ModifyDate], [ModifyUser], [SubGroupNbr], [BusinessCategory], [ProductValueCode], [CarrierPriority], [HealthPlanStartDate], [HealthPlanEndDate]) VALUES 
( N'H482', N'H3305', NULL, NULL, NULL, N'020', NULL, N'MVP Medicare Preferred Gold without Part D (HMO-POS) H3305-020', NULL, NULL, 141, (select InsuranceHealthPlanID from [Insurance].[InsuranceHealthPlans] where HealthPlanName like '%H3305-020%' and HealthPlanName like '%MVP%') , 1, getdate(), N'appuser', getdate(), N'appuser', NULL, NULL, NULL, NULL, NULL, NULL)
INSERT [elig].[BenefitCrossWalk] ( [ClientCode], [ContractNbr], [GroupNbr], [ProductID], [PlanID], [PBPID], [LOB], [PlanName], [IncommPlanCode], [HealthPlanNumber], [InsuranceCarrierId], [InsuranceHealthPlanId], [Isactive], [CreateDate], [CreateUser], [ModifyDate], [ModifyUser], [SubGroupNbr], [BusinessCategory], [ProductValueCode], [CarrierPriority], [HealthPlanStartDate], [HealthPlanEndDate]) VALUES 
( N'H482', N'H3305', NULL, NULL, NULL, N'030', NULL, N'MVP Medicare Secure with Part D (HMO-POS) H3305-030', NULL, NULL, 141, (select InsuranceHealthPlanID from [Insurance].[InsuranceHealthPlans] where HealthPlanName like '%H3305-030%' and HealthPlanName like '%MVP%'), 1,  getdate(), N'appuser', getdate(), N'appuser', NULL, NULL, NULL, NULL, NULL, NULL)
INSERT [elig].[BenefitCrossWalk] ( [ClientCode], [ContractNbr], [GroupNbr], [ProductID], [PlanID], [PBPID], [LOB], [PlanName], [IncommPlanCode], [HealthPlanNumber], [InsuranceCarrierId], [InsuranceHealthPlanId], [Isactive], [CreateDate], [CreateUser], [ModifyDate], [ModifyUser], [SubGroupNbr], [BusinessCategory], [ProductValueCode], [CarrierPriority], [HealthPlanStartDate], [HealthPlanEndDate]) VALUES 
( N'H482', N'H9615', NULL, NULL, NULL, N'008', NULL, N'MVP Medicare WellSelect with Part D (PPO) H9615-008', NULL, NULL, 141, (select InsuranceHealthPlanID from [Insurance].[InsuranceHealthPlans] where HealthPlanName like '%H9615-008%' and HealthPlanName like '%MVP%'), 1,  getdate(), N'appuser', getdate(), N'appuser', NULL, NULL, NULL, NULL, NULL, NULL)
INSERT [elig].[BenefitCrossWalk] ( [ClientCode], [ContractNbr], [GroupNbr], [ProductID], [PlanID], [PBPID], [LOB], [PlanName], [IncommPlanCode], [HealthPlanNumber], [InsuranceCarrierId], [InsuranceHealthPlanId], [Isactive], [CreateDate], [CreateUser], [ModifyDate], [ModifyUser], [SubGroupNbr], [BusinessCategory], [ProductValueCode], [CarrierPriority], [HealthPlanStartDate], [HealthPlanEndDate]) VALUES 
( N'H482', N'H9615', NULL, NULL, NULL, N'018', NULL, N'MVP Medicare Patriot Plan with Part D (PPO) H9615-018', NULL, NULL, 141, (select InsuranceHealthPlanID from [Insurance].[InsuranceHealthPlans] where HealthPlanName like '%H9615-018%' and HealthPlanName like '%MVP%'), 1,  getdate(), N'appuser', getdate(), N'appuser', NULL, NULL, NULL, NULL, NULL, NULL)


-- Create insert scripts for the BenefitCrossWalk
declare @HealthName varchar(30) = 'MVP'

select
'INSERT [elig].[BenefitCrossWalk] ( [ClientCode], [ContractNbr], [GroupNbr], [ProductID], [PlanID], [PBPID], [LOB], [PlanName], [IncommPlanCode], [HealthPlanNumber], [InsuranceCarrierId], [InsuranceHealthPlanId], [Isactive], [CreateDate], [CreateUser], [ModifyDate], [ModifyUser], [SubGroupNbr], [BusinessCategory], [ProductValueCode], [CarrierPriority], [HealthPlanStartDate], [HealthPlanEndDate]) VALUES ('
+ ''''+cast(ClientCode as varchar)+'''' +','
+ ''''+cast(ContractNbr as varchar)+'''' +','
+  'NULL' + ','
+  'NULL' + ','
+  'NULL' + ','
+ ''''+cast(PBPID as varchar)+'''' +','
+  'NULL' + ','
+ ''''+cast(HealthPlanName as varchar(400))+'''' +','
+  'NULL' + ','
+  'NULL' + ','
+ ''''+cast(InsuranceCarrierID as varchar)+'''' +','
+ '(select InsuranceHealthPlanID from [Insurance].[InsuranceHealthPlans] where HealthPlanName like ' + '''' + '%'+ cast(HealthPlanNumber as varchar) + '%' +''''+ ' and HealthPlanName like ' + '''' + '%'+ @HealthName +'%' +'''' + ')'+','
+ '1' + ',' 
+ 'getdate()'+','
+ ''''+'appuser'+ ''''+',' 
+ 'getdate()'+','
+ ''''+'appuser'+ ''''+',' 
+  'NULL' + ','
+  'NULL' + ','
+  'NULL' + ','
+  'NULL' + ','
+  'NULL' + ','
+  'NULL' + ')'
from #InsertHealthPlansCrossWalk

-- To create a temp table same as the original
select * into #BenefitCrossWalk from (select * from [elig].[BenefitCrossWalk] where 1 = 2 ) a

INSERT [#BenefitCrossWalk] ( [ClientCode], [ContractNbr], [GroupNbr], [ProductID], [PlanID], [PBPID], [LOB], [PlanName], [IncommPlanCode], [HealthPlanNumber], [InsuranceCarrierId], [InsuranceHealthPlanId], [Isactive], [CreateDate], [CreateUser], [ModifyDate], [ModifyUser], [SubGroupNbr], [BusinessCategory], [ProductValueCode], [CarrierPriority], [HealthPlanStartDate], [HealthPlanEndDate]) VALUES ('H482','H3305',NULL,NULL,NULL,'020',NULL,'MVP Medicare Preferred Gold without Part D (HMO-POS) H3305-020',NULL,NULL,'141',(select InsuranceHealthPlanID from [Insurance].[InsuranceHealthPlans] where HealthPlanName like '%H3305-020%' and HealthPlanName like '%MVP%'),1,getdate(),'appuser',getdate(),'appuser', NULL,NULL,NULL,NULL,NULL,NULL)
INSERT [#BenefitCrossWalk] ( [ClientCode], [ContractNbr], [GroupNbr], [ProductID], [PlanID], [PBPID], [LOB], [PlanName], [IncommPlanCode], [HealthPlanNumber], [InsuranceCarrierId], [InsuranceHealthPlanId], [Isactive], [CreateDate], [CreateUser], [ModifyDate], [ModifyUser], [SubGroupNbr], [BusinessCategory], [ProductValueCode], [CarrierPriority], [HealthPlanStartDate], [HealthPlanEndDate]) VALUES ('H482','H3305',NULL,NULL,NULL,'030',NULL,'MVP Medicare Secure with Part D (HMO-POS) H3305-030',NULL,NULL,'141',(select InsuranceHealthPlanID from [Insurance].[InsuranceHealthPlans] where HealthPlanName like '%H3305-030%' and HealthPlanName like '%MVP%'),1,getdate(),'appuser',getdate(),'appuser', NULL,NULL,NULL,NULL,NULL,NULL)
INSERT [#BenefitCrossWalk] ( [ClientCode], [ContractNbr], [GroupNbr], [ProductID], [PlanID], [PBPID], [LOB], [PlanName], [IncommPlanCode], [HealthPlanNumber], [InsuranceCarrierId], [InsuranceHealthPlanId], [Isactive], [CreateDate], [CreateUser], [ModifyDate], [ModifyUser], [SubGroupNbr], [BusinessCategory], [ProductValueCode], [CarrierPriority], [HealthPlanStartDate], [HealthPlanEndDate]) VALUES ('H482','H9615',NULL,NULL,NULL,'008',NULL,'MVP Medicare WellSelect with Part D (PPO) H9615-008',NULL,NULL,'141',(select InsuranceHealthPlanID from [Insurance].[InsuranceHealthPlans] where HealthPlanName like '%H9615-008%' and HealthPlanName like '%MVP%'),1,getdate(),'appuser',getdate(),'appuser', NULL,NULL,NULL,NULL,NULL,NULL)
INSERT [#BenefitCrossWalk] ( [ClientCode], [ContractNbr], [GroupNbr], [ProductID], [PlanID], [PBPID], [LOB], [PlanName], [IncommPlanCode], [HealthPlanNumber], [InsuranceCarrierId], [InsuranceHealthPlanId], [Isactive], [CreateDate], [CreateUser], [ModifyDate], [ModifyUser], [SubGroupNbr], [BusinessCategory], [ProductValueCode], [CarrierPriority], [HealthPlanStartDate], [HealthPlanEndDate]) VALUES ('H482','H9615',NULL,NULL,NULL,'018',NULL,'MVP Medicare Patriot Plan with Part D (PPO) H9615-018',NULL,NULL,'141',(select InsuranceHealthPlanID from [Insurance].[InsuranceHealthPlans] where HealthPlanName like '%H9615-018%' and HealthPlanName like '%MVP%'),1,getdate(),'appuser',getdate(),'appuser', NULL,NULL,NULL,NULL,NULL,NULL)

INSERT [elig].[BenefitCrossWalk] ( [ClientCode], [ContractNbr], [GroupNbr], [ProductID], [PlanID], [PBPID], [LOB], [PlanName], [IncommPlanCode], [HealthPlanNumber], [InsuranceCarrierId], [InsuranceHealthPlanId], [Isactive], [CreateDate], [CreateUser], [ModifyDate], [ModifyUser], [SubGroupNbr], [BusinessCategory], [ProductValueCode], [CarrierPriority], [HealthPlanStartDate], [HealthPlanEndDate]) VALUES ('H482','H3305',NULL,NULL,NULL,'020',NULL,'MVP Medicare Preferred Gold without Part D (HMO-POS) H3305-020',NULL,NULL,'141',(select InsuranceHealthPlanID from [Insurance].[InsuranceHealthPlans] where HealthPlanName like '%H3305-020%' and HealthPlanName like '%MVP%'),1,getdate(),'appuser',getdate(),'appuser',NULL,NULL,NULL,NULL,NULL,NULL)
INSERT [elig].[BenefitCrossWalk] ( [ClientCode], [ContractNbr], [GroupNbr], [ProductID], [PlanID], [PBPID], [LOB], [PlanName], [IncommPlanCode], [HealthPlanNumber], [InsuranceCarrierId], [InsuranceHealthPlanId], [Isactive], [CreateDate], [CreateUser], [ModifyDate], [ModifyUser], [SubGroupNbr], [BusinessCategory], [ProductValueCode], [CarrierPriority], [HealthPlanStartDate], [HealthPlanEndDate]) VALUES ('H482','H3305',NULL,NULL,NULL,'030',NULL,'MVP Medicare Secure with Part D (HMO-POS) H3305-030',NULL,NULL,'141',(select InsuranceHealthPlanID from [Insurance].[InsuranceHealthPlans] where HealthPlanName like '%H3305-030%' and HealthPlanName like '%MVP%'),1,getdate(),'appuser',getdate(),'appuser',NULL,NULL,NULL,NULL,NULL,NULL)
INSERT [elig].[BenefitCrossWalk] ( [ClientCode], [ContractNbr], [GroupNbr], [ProductID], [PlanID], [PBPID], [LOB], [PlanName], [IncommPlanCode], [HealthPlanNumber], [InsuranceCarrierId], [InsuranceHealthPlanId], [Isactive], [CreateDate], [CreateUser], [ModifyDate], [ModifyUser], [SubGroupNbr], [BusinessCategory], [ProductValueCode], [CarrierPriority], [HealthPlanStartDate], [HealthPlanEndDate]) VALUES ('H482','H9615',NULL,NULL,NULL,'008',NULL,'MVP Medicare WellSelect with Part D (PPO) H9615-008',NULL,NULL,'141',(select InsuranceHealthPlanID from [Insurance].[InsuranceHealthPlans] where HealthPlanName like '%H9615-008%' and HealthPlanName like '%MVP%'),1,getdate(),'appuser',getdate(),'appuser',NULL,NULL,NULL,NULL,NULL,NULL)
INSERT [elig].[BenefitCrossWalk] ( [ClientCode], [ContractNbr], [GroupNbr], [ProductID], [PlanID], [PBPID], [LOB], [PlanName], [IncommPlanCode], [HealthPlanNumber], [InsuranceCarrierId], [InsuranceHealthPlanId], [Isactive], [CreateDate], [CreateUser], [ModifyDate], [ModifyUser], [SubGroupNbr], [BusinessCategory], [ProductValueCode], [CarrierPriority], [HealthPlanStartDate], [HealthPlanEndDate]) VALUES ('H482','H9615',NULL,NULL,NULL,'018',NULL,'MVP Medicare Patriot Plan with Part D (PPO) H9615-018',NULL,NULL,'141',(select InsuranceHealthPlanID from [Insurance].[InsuranceHealthPlans] where HealthPlanName like '%H9615-018%' and HealthPlanName like '%MVP%'),1,getdate(),'appuser',getdate(),'appuser',NULL,NULL,NULL,NULL,NULL,NULL)