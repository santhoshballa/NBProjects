
----Sent
select ci.InsCarrierID, ic.InsuranceCarrierName,ci.InsHealthPlanID,hp.HealthPlanName,hp.HealthPlanNumber,ci.Language
,ci.ClientID,ci.SubProgramID,ci.PackageID,count(DISTINCT ci.NHLinkID) MemberCount
from otcfunds.CardBenefitLoad_CI ci
left join Insurance.InsuranceHealthPlans hp on hp.InsuranceHealthPlanID = ci.InsHealthPlanID and hp.InsuranceCarrierID = ci.InsCarrierID
left join Insurance.InsuranceCarriers ic on hp.InsuranceCarrierID = ic.InsuranceCarrierID
where 1=1
and ci.InsCarrierID = 417
and ci.RequestRecordStatus = 'SUCCESS'
and ci.NHLinkID NOT in
(
    SELECT DISTINCT nhlinkid FROM [dbo].[Elevance_69K_FOD_SSBCI_CarrierMessage_Impacted_Members_20221209]  -- 23,521
    UNION ALL
    SELECT DISTINCT nhlinkid FROM [dbo].[Elevance_69K_Language_Missing_CarrierMessage_20221209] -- 11,007
    UNION ALL
    SELECT DISTINCT nhlinkid FROM [dbo].[Elevance_610K_FOD_SSBCI_CarrierMessage_Impacted_Members_20221209] --4,115
    UNION ALL
    SELECT DISTINCT nhlinkid FROM [dbo].[Elevance_610K_Language_Missing_CarrierMessage_20221209] -- 3,580
)
group by ci.InsCarrierID, ic.InsuranceCarrierName,ci.InsHealthPlanID,hp.HealthPlanName,hp.HealthPlanNumber,ci.Language
,ci.ClientID,ci.SubProgramID,ci.PackageID
order by ci.InsCarrierID, ic.InsuranceCarrierName,ci.InsHealthPlanID,hp.HealthPlanName,hp.HealthPlanNumber,ci.Language
,ci.ClientID,ci.SubProgramID,ci.PackageID


-------REmoved
select ci.InsCarrierID, ic.InsuranceCarrierName,ci.InsHealthPlanID,hp.HealthPlanName,hp.HealthPlanNumber,ci.Language
,ci.ClientID,ci.SubProgramID,ci.PackageID,count(DISTINCT ci.NHLinkID) MemberCount
from otcfunds.CardBenefitLoad_CI ci
left join Insurance.InsuranceHealthPlans hp on hp.InsuranceHealthPlanID = ci.InsHealthPlanID and hp.InsuranceCarrierID = ci.InsCarrierID
left join Insurance.InsuranceCarriers ic on hp.InsuranceCarrierID = ic.InsuranceCarrierID
where 1=1
and ci.InsCarrierID = 417
and ci.RequestRecordStatus = 'SUCCESS'
and ci.NHLinkID in
(
    SELECT DISTINCT nhlinkid FROM [dbo].[Elevance_69K_FOD_SSBCI_CarrierMessage_Impacted_Members_20221209]  -- 23,521
    UNION ALL
    SELECT DISTINCT nhlinkid FROM [dbo].[Elevance_69K_Language_Missing_CarrierMessage_20221209] -- 11,007
    UNION ALL
    SELECT DISTINCT nhlinkid FROM [dbo].[Elevance_610K_FOD_SSBCI_CarrierMessage_Impacted_Members_20221209] --4,115
    UNION ALL
    SELECT DISTINCT nhlinkid FROM [dbo].[Elevance_610K_Language_Missing_CarrierMessage_20221209] -- 3,580
)
group by ci.InsCarrierID, ic.InsuranceCarrierName,ci.InsHealthPlanID,hp.HealthPlanName,hp.HealthPlanNumber,ci.Language
,ci.ClientID,ci.SubProgramID,ci.PackageID
order by ci.InsCarrierID, ic.InsuranceCarrierName,ci.InsHealthPlanID,hp.HealthPlanName,hp.HealthPlanNumber,ci.Language
,ci.ClientID,ci.SubProgramID,ci.PackageID


--Pending
select DISTINCT ci.NHLinkID into #NHLinkIDSent
		from otcfunds.CardBenefitLoad_CI ci
		left join Insurance.InsuranceHealthPlans hp on hp.InsuranceHealthPlanID = ci.InsHealthPlanID and hp.InsuranceCarrierID = ci.InsCarrierID
		left join Insurance.InsuranceCarriers ic on hp.InsuranceCarrierID = ic.InsuranceCarrierID
		where 1=1
		and ci.InsCarrierID = 417
		and ci.RequestRecordStatus = 'SUCCESS'


drop table if exists #ElevanceNotSentCount
select mstr.insCarrierID, mstr.insHealthPlanID, 
CASE WHEN ISNULL(Mstr.Language,'') = '' THEN 'ENG' ELSE Mstr.Language END [Language]
, count(distinct NHLinkid) MemberCount
into #ElevanceNotSentCount
from elig.mstrEligBenefitDataEH  Mstr
WHERE  1=1
AND Mstr.isActive = 1
AND CAST('01/02/2023'  AS DATE) BETWEEN Mstr.RecordEffDate AND Mstr.RecordEndDate  --- Active records
AND CAST('01/02/2023'  AS DATE) BETWEEN Mstr.BenefitStartDate AND Mstr.BenefitEndDate  -- Active benefit term
AND Mstr.BenefitEndDate > Mstr.BenefitStartDate -- Exclude void records
AND NOT Exists (select 1 from #NHLinkIDSent s where s.NHLinkID = mstr.NHLinkid)
group by mstr.insCarrierID, mstr.insHealthPlanID, CASE WHEN ISNULL(Mstr.Language,'') = '' THEN 'ENG' ELSE Mstr.Language END




select a.InsCarrierID, ic.InsuranceCarrierName,a.InsHealthPlanID,hp.HealthPlanName,hp.HealthPlanNumber,a.Language
,ci.ClientID,ci.SubProgramID,ci.PackageID,A.MemberCount
from #ElevanceNotSentCount A
left join Insurance.InsuranceHealthPlans hp on hp.InsuranceHealthPlanID = a.InsHealthPlanID and hp.InsuranceCarrierID = a.InsCarrierID
left join Insurance.InsuranceCarriers ic on hp.InsuranceCarrierID = ic.InsuranceCarrierID
left JOIN (
		SELECT DISTINCT	ClientID,ProgramID,SubProgramID,PackageID,LanguageIndicator,LanguageLOV,CarrierID,HealthPlanID
		FROM flex.FISWalletMapping	
		WHERE ISNULL(isactive,0)=1
		and CarrierID = 417
		) CI ON CI.CarrierID = A.InsCarrierID AND CI.HealthPlanID = A.InsHealthPlanID AND (      
																							( 
																								(ISNULL(CI.LanguageIndicator,'') = 'Y') AND (ISNULL(A.Language,'') IN (SELECT VALUE FROM STRING_SPLIT(CI.LanguageLOV, ',')))  
																							)    
																								
																							OR

																							(
																								ISNULL(CI.LanguageIndicator,'') = ''
																							)
																						)
